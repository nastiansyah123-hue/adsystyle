// MEDIS pack (ADSY v1.0): health-content signature elements used by the KLINIK, RESEP and MITOS-FAKTA styles.
// They render in every style. UkuranKapsul: a clinical size gauge (capsule/tablet grows, shrinks, locks on the
// answer). KertasResep: a prescription sheet whose lines are handwritten on their words. Stempel: a rubber stamp
// (MITOS / FAKTA / any user label) that slams onto the frame.
import React from 'react';
import {clamp, lerp, prog, rand} from '../lib/anim.js';
import {Icon} from './Icons.jsx';
import {theme, tw, qIn, qOut} from './Scenes.jsx';
// KLINIK signature: a clinical size gauge in the headroom. A two-tone capsule grows ("besar"), shrinks ("kecil"),
// settles on the middle tick ("standar"), then locks on "pas" with a check and the spoken sub line.

export const UkuranKapsul = ({E, t, o}) => {
  const W = E.width, T = theme(E), C = E.style.colors;
  const teal = C.accent2 || '#0F766E', mint = C.accent || '#5EEAD4', ink = C.ink || '#12201E';
  const mono = {fontFamily: 'GeistMono', fontWeight: 600, letterSpacing: '0.16em', textTransform: 'uppercase'};
  const ui = {fontFamily: 'InterTight', fontWeight: 800};
  const items = o.items || [];                          // [{text, at, pos: -1|0|1, size}]
  const lock = items.find((x) => x.lock);
  const pin = tw(t, o.start, 0.6), out = qIn(prog(t, o.end - 0.3, o.end));
  // capsule width and marker position follow the last spoken state
  let pos = 0, size = 1, prevPos = 0, prevSize = 1, at = o.start;
  for (const it of items) { if (t >= it.at) { prevPos = pos; prevSize = size; pos = it.pos ?? 0; size = it.size ?? 1; at = it.at; } }
  const m = tw(t, at, 0.55);
  const p = lerp(prevPos, pos, m), s = lerp(prevSize, size, m);
  const jig = t < at + 0.6 ? Math.sin((t - at) * 30) * 4 * (1 - prog(t, at, at + 0.6)) : 0;
  const y0 = o.y ?? 300, w = 900, h = 360, x0 = (W - w) / 2;
  const trackL = 90, trackR = w - 90, cx = (trackL + trackR) / 2 + p * (trackR - trackL) / 2;
  const capW = 230 * s, capH = 92 * Math.sqrt(s);
  const capX = clamp(cx, capW / 2 + 24, w - capW / 2 - 24);
  const locked = lock && t >= lock.at;
  const lk = lock ? tw(t, lock.at, 0.5) : 0;
  return (
    <div style={{position: 'absolute', left: x0, top: y0, width: w, height: h, opacity: clamp(pin * 1.4) * (1 - out),
      transform: `translateY(${(1 - pin) * -30 - out * 20}px)`, filter: pin < 0.98 ? `blur(${((1 - pin) * 8).toFixed(1)}px)` : 'none'}}>
      <div style={{position: 'absolute', inset: 0, borderRadius: 28, background: 'rgba(255,255,255,0.94)', border: `3px solid ${teal}`,
        boxShadow: '0 20px 50px rgba(15,60,55,0.18)'}} />
      <div style={{position: 'absolute', left: 30, top: 22, display: 'flex', alignItems: 'center', gap: 12, ...mono, fontSize: 24, color: teal}}>
        <div style={{width: 30, height: 30, borderRadius: 8, background: teal, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
          <div style={{width: 16, height: 4, background: '#fff', position: 'absolute'}} /><div style={{width: 4, height: 16, background: '#fff', position: 'absolute'}} />
        </div>
        {o.title}
      </div>
      {/* capsule */}
      <div style={{position: 'absolute', left: capX - capW / 2 + jig, top: 150 - capH / 2, width: capW, height: capH, display: 'flex',
        borderRadius: capH, overflow: 'hidden', boxShadow: `0 12px 24px rgba(15,60,55,0.22), inset 0 0 0 3px ${ink}`}}>
        <div style={{flex: 1, background: teal}} /><div style={{flex: 1, background: '#F8FAFA'}} />
        <div style={{position: 'absolute', left: '8%', top: '14%', width: '40%', height: '18%', borderRadius: 20, background: 'rgba(255,255,255,0.45)'}} />
      </div>
      {/* track + ticks */}
      <div style={{position: 'absolute', left: trackL, width: trackR - trackL, top: 236, height: 6, borderRadius: 3, background: 'rgba(18,32,30,0.15)'}} />
      {[-1, 0, 1].map((k) => {
        const lab = items.find((x) => (x.pos ?? 0) === k && !x.lock);
        const on = lab && t >= lab.at;
        const x = (trackL + trackR) / 2 + k * (trackR - trackL) / 2;
        return (
          <div key={k}>
            <div style={{position: 'absolute', left: x - 2, top: 224, width: 4, height: 30, background: ink, opacity: 0.5}} />
            {lab && <div style={{position: 'absolute', left: x - 120, width: 240, top: 266, textAlign: 'center', ...ui, fontSize: 42,
              color: Math.abs(p - k) < 0.2 ? teal : 'rgba(18,32,30,0.45)', opacity: on ? 1 : 0.25}}>{lab.text}</div>}
          </div>
        );
      })}
      {/* marker */}
      <div style={{position: 'absolute', left: cx - 16, top: 210, width: 0, height: 0, borderLeft: '16px solid transparent', borderRight: '16px solid transparent', borderTop: `20px solid ${teal}`}} />
      {/* lock */}
      {locked && (
        <div style={{position: 'absolute', right: 26, top: 18, display: 'flex', alignItems: 'center', gap: 12, transform: `scale(${0.7 + 0.3 * lk})`, opacity: clamp(lk * 1.5)}}>
          <div style={{...ui, fontSize: 40, color: ink, background: mint, borderRadius: 40, padding: '4px 22px'}}>{lock.text}</div>
          <div style={{width: 52, height: 52, borderRadius: 26, background: teal, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
            <Icon name="check" size={32} color="#fff" stroke={4} />
          </div>
        </div>
      )}
      {o.sub && t >= (o.subAt ?? 1e9) && (
        <div style={{position: 'absolute', left: 0, right: 0, top: 316, textAlign: 'center', ...mono, fontSize: 24, color: teal,
          opacity: clamp(tw(t, o.subAt, 0.4) * 1.5)}}>{o.sub}</div>
      )}
    </div>
  );
};

// RESEP signature: a prescription sheet in the headroom. Mono header (product), then each spoken line is handwritten
// left to right on its word; a line can get a highlighter stroke; a signature scribble draws at the end.

export const KertasResep = ({E, t, o}) => {
  const W = E.width, C = E.style.colors;
  const ink = '#1C2B5A', red = C.accent2 || '#E5383B', hl = C.accent || '#FFD43B';
  const pin = tw(t, o.start, 0.6), out = qIn(prog(t, o.end - 0.3, o.end));
  const w = 860, h = 400, x0 = (W - w) / 2, y0 = o.y ?? 290;
  const items = o.items || [];
  const sigQ = o.signAt != null ? prog(t, o.signAt, o.signAt + 0.7) : 0;
  return (
    <div style={{position: 'absolute', left: x0, top: y0, width: w, height: h, opacity: clamp(pin * 1.4) * (1 - out),
      transform: `translateY(${(1 - pin) * -40}px) rotate(${-2 + (1 - pin) * -4}deg)`, filter: pin < 0.98 ? `blur(${((1 - pin) * 8).toFixed(1)}px)` : 'none'}}>
      <div style={{position: 'absolute', inset: 0, background: '#FFFEF9', borderRadius: 6, boxShadow: '0 18px 40px rgba(20,20,40,0.22)',
        backgroundImage: 'repeating-linear-gradient(180deg, transparent 0 69px, rgba(28,43,90,0.12) 69px 71px)', backgroundPosition: '0 96px'}} />
      {/* header strip */}
      <div style={{position: 'absolute', left: 0, right: 0, top: 0, height: 92, borderBottom: `3px solid ${ink}`, display: 'flex', alignItems: 'center', padding: '0 30px', gap: 22}}>
        <div style={{fontFamily: 'InstrumentSerif', fontStyle: 'italic', fontSize: 80, color: ink, lineHeight: 1, marginTop: -6}}>R/</div>
        <div style={{fontFamily: 'GeistMono', fontWeight: 600, fontSize: 28, letterSpacing: '0.14em', textTransform: 'uppercase', color: ink,
          opacity: o.titleAt != null ? clamp(tw(t, o.titleAt, 0.4) * 1.5) : 1}}>{o.title}</div>
      </div>
      {items.map((it, k) => {
        const q = prog(t, it.at, it.at + (it.dur ?? 0.55));
        if (t < it.at) return null;
        const mk = it.mark && t >= (it.markAt ?? it.at + 0.6) ? prog(t, it.markAt ?? it.at + 0.6, (it.markAt ?? it.at + 0.6) + 0.35) : 0;
        return (
          <div key={k} style={{position: 'absolute', left: 60, top: 110 + k * 120, height: 110, display: 'flex', alignItems: 'center'}}>
            <div style={{position: 'relative'}}>
              <div style={{position: 'absolute', left: -10, right: -10, top: '44%', height: '42%', background: hl, opacity: 0.85, transformOrigin: 'left',
                transform: `scaleX(${mk}) skewX(-8deg)`, borderRadius: 6}} />
              <div style={{position: 'relative', fontFamily: 'MsMadi', fontSize: it.size ?? 104, color: ink, lineHeight: 1, whiteSpace: 'nowrap',
                clipPath: `inset(-20% ${(1 - q) * 100}% -20% 0)`}}>{it.text}</div>
            </div>
          </div>
        );
      })}
      {/* signature scribble */}
      <svg width="220" height="90" viewBox="0 0 220 90" style={{position: 'absolute', right: 30, bottom: 16}}>
        <path d="M10 60 C30 10 50 80 70 40 S110 10 120 50 S160 70 210 30" fill="none" stroke={ink} strokeWidth="4" strokeLinecap="round"
          pathLength="1" strokeDasharray="1 2" strokeDashoffset={1 - sigQ} opacity={sigQ > 0 ? 1 : 0} />
      </svg>
      <div style={{position: 'absolute', left: 30, bottom: -6, width: 6, height: 0}} />
      <div style={{position: 'absolute', right: -14, top: -16, width: 120, height: 34, background: 'rgba(236,227,206,0.92)', transform: 'rotate(8deg)', boxShadow: '0 2px 4px rgba(0,0,0,0.12)'}} />
      <div style={{position: 'absolute', left: -14, top: -12, width: 110, height: 34, background: 'rgba(236,227,206,0.92)', transform: 'rotate(-6deg)', boxShadow: '0 2px 4px rgba(0,0,0,0.12)'}} />
      <div style={{position: 'absolute', left: 6, top: 96, bottom: 6, width: 3, background: red, opacity: 0.6}} />
    </div>
  );
};

// MITOS / FAKTA signature: a rubber stamp that slams onto the frame (scale 2.2 -> 1 with motion blur), double border,
// worn ink texture, slight rotation. Text is the user's chosen label (copy: "user"); sub line = spoken words.

export const Stempel = ({E, t, o}) => {
  const C = E.style.colors;
  const col = o.color ? o.color : o.tone === 'ok' ? (C.ok || '#16A34A') : (C.danger || '#E11D2E');
  const a = o.at ?? o.start;
  const q = qOut(prog(t, a, a + 0.22)), out = qIn(prog(t, o.end - 0.25, o.end));
  if (t < a) return null;
  const s = lerp(2.2, 1, q), blur = (1 - q) * 14;
  const shake = q < 1 ? 0 : Math.sin((t - a) * 40) * 3 * (1 - prog(t, a + 0.22, a + 0.5));
  const x = o.x ?? E.width / 2, y = o.y ?? 470, rot = o.rot ?? -10;
  const specks = Array.from({length: 26}, (_, k) => ({x: rand(k * 7.1 + (o.seed ?? 1)) * 100, y: rand(k * 3.3 + 9 + (o.seed ?? 1)) * 100, r: 2 + rand(k + 4) * 7}));
  return (
    <div style={{position: 'absolute', left: x, top: y, transform: `translate(-50%, -50%) translateY(${shake}px) rotate(${rot}deg) scale(${s})`,
      opacity: clamp(q * 3) * (1 - out) * 0.94, filter: blur > 0.3 ? `blur(${blur.toFixed(1)}px)` : 'none'}}>
      <div style={{position: 'relative', border: `12px solid ${col}`, borderRadius: 22, padding: 8}}>
        <div style={{border: `4px solid ${col}`, borderRadius: 12, padding: '6px 40px 10px', textAlign: 'center'}}>
          <div style={{fontFamily: 'Archivo', fontWeight: 900, fontSize: o.size ?? 150, lineHeight: 1, letterSpacing: '0.04em', color: col}}>{o.text}</div>
          {o.sub && <div style={{fontFamily: 'GeistMono', fontWeight: 700, fontSize: 30, letterSpacing: '0.16em', textTransform: 'uppercase', color: col, marginTop: 4}}>{o.sub}</div>}
        </div>
        {specks.map((p, k) => <div key={k} style={{position: 'absolute', left: `${p.x}%`, top: `${p.y}%`, width: p.r, height: p.r, borderRadius: p.r, background: '#fff', opacity: 0.55}} />)}
      </div>
    </div>
  );
};

