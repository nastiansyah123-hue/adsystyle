# Style: RESEP · `resep` (ADSY MEDIS)

> A doctor's prescription in the headroom: an `R/` sheet with the product in a mono header, the spoken rule handwritten
> line by line, a highlighter on the key line and a quick signature. Calm, personal, trustworthy.

**Use for** how to use a product, dosage and timing that the speaker says ("pas buat sekali minum", "diminum malam"),
habits framed as a "resep", tips from health workers, product explanations.
**Not for** myth-busting (→ MITOS-FAKTA), measurements (→ KLINIK), ads with many offers (→ IMPACT).
**Recommended settings** editing_intensity medium · sound_effects medium · visual_overlays moderate.

## Look
- NOTED stationery with prescription paper: off-white sheet `#FFFEF9`, faint blue rules, a red margin line, tape on two
  corners, ink `#1C2B5A`, a yellow highlighter `#FFD43B`.
- Fonts: Instrument Serif Italic for the `R/` mark, Geist Mono for the header, **Ms Madi** handwriting for the lines,
  Geist captions.

## Captions
`note` captions with a stronger pool (`scrim 0.6`); emphasis = yellow highlighter.

## Signature graphics
| Moment | Element | Rule |
|---|---|---|
| The question / old belief (hook) | `NoteTags` with a mono `label`, the doubted word struck out (`strikeAt` on "enggak/bukan") and the answer as a yellow strip | spoken words |
| The rule itself | **`KertasResep`** (MEDIS pack): `title` (product, user copy) + `items: [{text, at, dur, mark?, markAt?}]` handwritten on their words, `signAt` for the signature | 1–3 lines of 1–3 words; keep it on screen ≥ 1 s after the last line |
| CTA | `NoteTags` `surface: "outline"` column: the question + the CTA as a yellow strip | `x`,`y` fixed in the headroom |

## Rules
- Only rules that were said. Never write a dose, frequency or warning the speaker did not say.
- The sheet is a stylised illustration, never a real prescription form, clinic name or doctor's name.
- Preview stills before the full render.

## Config

```json style-config
{
  "id": "resep",
  "colors": {
    "bg": "#EEE6D3",
    "paper": "#FFFFFF",
    "ink": "#1C2B5A",
    "muted": "#6F6858",
    "soft": "#E6DCC6",
    "line": "#D6CBB2",
    "accent": "#FFD43B",
    "accent2": "#E5383B",
    "danger": "#E5383B",
    "tag": "#ECE3CE",
    "tagEdge": "#C7B891",
    "board": "#EEE6D3",
    "grid": "rgba(22,20,15,0.035)",
    "glow1": "rgba(255,212,59,0.10)",
    "glow2": "rgba(229,56,59,0.05)"
  },
  "fonts": {
    "head": "InterTight",
    "body": "Geist",
    "ui": "Geist",
    "display": "InterTight",
    "displayWeight": 900,
    "serif": "InstrumentSerif",
    "serifWeight": 400,
    "accent": "InstrumentSerif",
    "mono": "GeistMono",
    "tag": "InterTight",
    "tagWeight": 800
  },
  "captions": {
    "variant": "note",
    "size": 50,
    "hookSize": 56,
    "weight": 560,
    "radius": 10,
    "maxWords": 6,
    "maxChars": 34,
    "hookMaxWords": 4,
    "hookMaxChars": 24,
    "maxPageDur": 2.4,
    "text": "#FFFFFF",
    "mark": "#FFD43B",
    "scrim": 0.6
  },
  "grade": {
    "sat": 1.0,
    "con": 1.0,
    "bri": 1.0,
    "warm": 0.0,
    "rawSat": 0.6,
    "rawCon": 0.95,
    "rawBri": 1.0
  },
  "camera": {
    "talk": 1.06,
    "close": 1.2,
    "jumpZoom": 1.0,
    "punch": 0.045,
    "smooth": true,
    "punchDur": 0.65,
    "relaxDur": 1.0,
    "breathe": 0.01,
    "drift": 1.2,
    "push": 0.035
  },
  "wipe": {
    "band": 120,
    "skew": 130
  },
  "sound": {
    "bed": "note",
    "music_db": -16,
    "sfx_db": -8,
    "punch_sfx": "swoosh",
    "emph_pop": false
  },
  "cuts": {
    "fx": [],
    "minGap": 6.0,
    "dur": 0.22,
    "pre": 0.1
  },
  "rhythm": {
    "maxStatic": 3.4,
    "maxGraphicsPerMin": 22,
    "maxSfxPerSec": 1.3,
    "maxWipes": 1
  },
  "finish": {
    "grain": 0.0,
    "vignette": 0.0
  },
  "depth_defaults": {
    "look": "fill",
    "creep": 0.02
  },
  "endcard": {
    "variant": "title"
  },
  "textFx": "type",
  "defaults": {
    "sound_effects": "medium",
    "editing_intensity": "medium",
    "visual_overlays": "moderate"
  }
}
```
