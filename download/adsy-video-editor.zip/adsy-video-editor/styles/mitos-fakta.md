# Style: MITOS / FAKTA · `mitos-fakta` (ADSY MEDIS)

> Myth-busting on a poster: the doubtful claim slams in huge behind the head and gets stamped **MITOS**, then the frame
> turns green, the speaker pops forward and the answer is stamped **FAKTA**. Bold, fast, shareable.

**Use for** "katanya…", "apa benar…?", Q&A that corrects a belief, health myths, product doubts ("kapsulnya gede?").
**Not for** calm explanations (→ KLINIK / NOTED), when nothing is being corrected.
**Recommended settings** editing_intensity medium · sound_effects medium · visual_overlays moderate.

## Look
- POSTER's bold language in two signal colours: red `#E11D2E` (myth) and green `#16A34A` (fact) + white and ink.
- Fonts: Archivo Black (stamps, big type), Geist Mono (stamp sub line), poster captions.

## Captions
`poster` captions (heavy white words, emphasis on a solid label); hide them under big type that repeats the words.

## Signature graphics
| Moment | Element | Rule |
|---|---|---|
| The claim (hook) | `DepthText` `mode: "echo"` behind the head, `tone: "danger"`, the doubted word | spoken words |
| The denial | **`Stempel`** (MEDIS pack) `text: "MITOS"` `tone: "danger"` on the denial word ("enggak", "bukan") | the stamp label is the style's label: list it in `user_copy` |
| The answer | `Cutout` `bg: "poster"` green (`color #16A34A`, `color2 #064E3B`) + `DepthText` `stack` (subject small, the answer word huge) | 2–4 s |
| Proof of the answer | `Stempel` `text: "FAKTA"`, `color: "#FFFFFF"` on green, `sub` = 1–3 spoken words | place it in free space beside the head (the speaker is drawn over overlays during a Cutout) |
| CTA | `GlowPill` `surface: "accent"` + hidden caption zone | user copy |

## Rules
- Only stamp MITOS on something the speaker actually corrects; never declare a medical fact the speaker did not say.
- Max 2 stamps per video.
- Preview stills before the full render.

## Config

```json style-config
{
  "id": "mitos-fakta",
  "colors": {
    "bg": "#B5161E",
    "paper": "#FFFFFF",
    "ink": "#141414",
    "muted": "#8C8C8C",
    "soft": "#F4F1EC",
    "line": "#E2DDD5",
    "accent": "#E11D2E",
    "accent2": "#16A34A",
    "danger": "#E11D2E",
    "deep": "#6E0A10",
    "grid": "rgba(255,255,255,0.05)",
    "glow1": "rgba(232,38,46,0.14)",
    "glow2": "rgba(255,210,63,0.08)",
    "ok": "#16A34A"
  },
  "fonts": {
    "head": "Archivo",
    "body": "Archivo",
    "ui": "Archivo",
    "display": "Archivo",
    "displayWeight": 900,
    "serif": "PlayfairDisplay",
    "serifWeight": 600
  },
  "captions": {
    "variant": "poster",
    "size": 56,
    "hookSize": 64,
    "weight": 800,
    "radius": 10,
    "maxWords": 3,
    "maxChars": 20,
    "hookMaxWords": 2,
    "hookMaxChars": 14,
    "maxPageDur": 1.8,
    "text": "#FFFFFF",
    "label": "#E8262E",
    "labelText": "#FFFFFF"
  },
  "grade": {
    "sat": 1.0,
    "con": 1.0,
    "bri": 1.0,
    "rawSat": 0.45,
    "rawCon": 0.9,
    "rawBri": 1.0,
    "warm": 0.0
  },
  "camera": {
    "talk": 1.12,
    "close": 1.3,
    "jumpZoom": 1.06,
    "punch": 0.08,
    "breathe": 0.012,
    "drift": 1.0,
    "push": 0.05
  },
  "wipe": {
    "band": 140,
    "skew": 150
  },
  "sound": {
    "bed": "playful",
    "music_db": -15,
    "sfx_db": -7,
    "punch_sfx": "swoosh",
    "emph_pop": false
  },
  "cuts": {
    "fx": [
      "push",
      "zoom"
    ],
    "minGap": 3.4,
    "dur": 0.24,
    "pre": 0.1
  },
  "rhythm": {
    "maxStatic": 2.8,
    "maxGraphicsPerMin": 24,
    "maxSfxPerSec": 1.5,
    "maxWipes": 1
  },
  "finish": {
    "grain": 0.0,
    "vignette": 0.0
  },
  "depth_defaults": {
    "look": "fill",
    "creep": 0.03
  },
  "endcard": {
    "variant": "block"
  },
  "textFx": "rise",
  "defaults": {
    "sound_effects": "medium",
    "editing_intensity": "medium",
    "visual_overlays": "moderate"
  }
}
```
