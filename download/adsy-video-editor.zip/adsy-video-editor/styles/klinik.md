# Style: KLINIK · `klinik` (ADSY MEDIS)

> Clean and clinical, like a visit to a good clinic: white-teal notes in the headroom, one measurement card that answers the
> question, a mint highlighter, and a clear CTA pill. The footage stays natural and true to skin; the graphics look like
> medical stationery and devices, never like a hospital ad.

**Use for** doctors, nurses, midwives, nutritionists and health-product sellers explaining a product or a habit; Q&A
("kapsulnya gede gak?", "boleh diminum sebelum makan?"), sizes, doses, before/after checks, reviews of health products.
**Not for** drama, loud promos (→ IMPACT / MITOS-FAKTA), long lists only (→ NOTED).
**Recommended settings** editing_intensity medium · sound_effects medium · visual_overlays moderate.

## Look
- Built on NOTED's stationery language in a clinical palette: white panels with a 3 px teal edge `#0F766E`, mint
  accents `#5EEAD4`, teal ink, soft shadows. No glow, no gradients, no fake hospital logos.
- Fonts: Geist (captions), Geist Mono uppercase labels, Inter Tight ExtraBold/Black for big words and card text.
- Notes live in the headroom; the card sits between the top safe line (~280) and the hair.

## Captions
`note` captions (Geist, sentence case, blur-in), emphasis = a **mint** highlighter stroke; a stronger dark pool
(`scrim 0.6`) keeps white words readable on light walls.

## Signature graphics
| Moment | Element | Rule |
|---|---|---|
| The viewer's question (hook) | `BigNote` with `mark: "circle"` (`markAt` on the answer word), `tone: "accent2"`, kicker = the subject | the question word itself, 1 per video |
| A size, dose or amount being judged | **`UkuranKapsul`** (MEDIS pack): a clinical gauge card; the capsule grows on "besar", shrinks on "kecil", sits on "standar" and **locks** with a check on the answer (`lock: true`) | `items: [{text, at, pos -1/0/1, size 0.6-1.4, lock?}]`; labels = spoken words only; `box` over the card |
| Things named | `NoteTags` `surface: "paper"` or `accent` | 1–3 words per strip |
| A rule ("sekali minum", "2× sehari") | `GlowPill` `badge: "check"` `surface: "paper"` | only rules that were said |
| CTA | `GlowPill` `badge: "down"` `surface: "accent"` on the CTA words, `hide_captions` + a caption zone `hidden` for the same words | user copy for product/brand spelling |

## Rules
- Health claims: show only what was said; never add benefits, doses, BPOM numbers or "aman" stamps that were not said
  or written by the user. A product name is user copy (`glossary` + `user_copy`).
- One focal graphic at a time; the face stays clear.
- Preview stills (opening, signature, CTA) go to the user before the full render.

## Checklist
- [ ] Gauge labels are spoken words; the lock lands on the answer word.
- [ ] CTA text not duplicated by captions.
- [ ] Product visible and not washed out (ADSY colour system, SKILL.md).

## Config

```json style-config
{
  "id": "klinik",
  "colors": {
    "bg": "#E6F4F1",
    "paper": "#FFFFFF",
    "ink": "#16140F",
    "muted": "#6F6858",
    "soft": "#D7EEE9",
    "line": "#BFE3DB",
    "accent": "#5EEAD4",
    "accent2": "#0F766E",
    "danger": "#E5383B",
    "tag": "#E0F2EF",
    "tagEdge": "#9ED8CC",
    "board": "#EEE6D3",
    "grid": "rgba(22,20,15,0.035)",
    "glow1": "rgba(255,212,59,0.10)",
    "glow2": "rgba(229,56,59,0.05)",
    "ok": "#0F766E"
  },
  "fonts": {
    "head": "InterTight",
    "body": "Geist",
    "ui": "Geist",
    "display": "InterTight",
    "displayWeight": 900,
    "serif": "InstrumentSerif",
    "serifWeight": 400,
    "accent": "InstrumentSerif",
    "mono": "GeistMono",
    "tag": "InterTight",
    "tagWeight": 800
  },
  "captions": {
    "variant": "note",
    "size": 50,
    "hookSize": 56,
    "weight": 560,
    "radius": 10,
    "maxWords": 6,
    "maxChars": 34,
    "hookMaxWords": 4,
    "hookMaxChars": 24,
    "maxPageDur": 2.4,
    "text": "#FFFFFF",
    "mark": "#5EEAD4",
    "scrim": 0.6
  },
  "grade": {
    "sat": 1.0,
    "con": 1.0,
    "bri": 1.0,
    "warm": 0.0,
    "rawSat": 0.6,
    "rawCon": 0.95,
    "rawBri": 1.0
  },
  "camera": {
    "talk": 1.06,
    "close": 1.2,
    "jumpZoom": 1.0,
    "punch": 0.045,
    "smooth": true,
    "punchDur": 0.65,
    "relaxDur": 1.0,
    "breathe": 0.01,
    "drift": 1.2,
    "push": 0.035
  },
  "wipe": {
    "band": 120,
    "skew": 130
  },
  "sound": {
    "bed": "note",
    "music_db": -16,
    "sfx_db": -8,
    "punch_sfx": "swoosh",
    "emph_pop": false
  },
  "cuts": {
    "fx": [],
    "minGap": 6.0,
    "dur": 0.22,
    "pre": 0.1
  },
  "rhythm": {
    "maxStatic": 3.4,
    "maxGraphicsPerMin": 22,
    "maxSfxPerSec": 1.3,
    "maxWipes": 1
  },
  "finish": {
    "grain": 0.0,
    "vignette": 0.0
  },
  "depth_defaults": {
    "look": "fill",
    "creep": 0.02
  },
  "endcard": {
    "variant": "title"
  },
  "textFx": "type",
  "defaults": {
    "sound_effects": "medium",
    "editing_intensity": "medium",
    "visual_overlays": "moderate"
  }
}
```
