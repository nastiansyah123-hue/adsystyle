# MEDIS looks — 12 named looks for health and disease education (v2.0)

Twelve looks built for videos about the body, diseases, symptoms, nutrition, prevention and treatment. Pick ONE per
video from the story (a buyer's "pakai gaya X" always wins). Each look is drawn with plain SVG/CSS, so all of them are
light enough for a chat sandbox; none need `renderQuality()` switches.

Shared kit: `src/styles/medis/kit.tsx`
- `<MedisFonts />` registers every MEDIS font (all SIL OFL, already in `public/fonts`). Render it once next to `<FontFaces />`.
- `Caps` (`t s y`): word-synced captions from `src/words.json` in the look's own typeface; `s` is a `CapStyle`
  (`font weight size color hl bg radius border shadow upper spacing`). Keep `y` between 1440 and 1520.
- `StyleTag` (`t a name font fg bg n`): small numbered chip with the look's name. Use it only in a style test reel; leave it out of a buyer video.
- `enter(t, a)`: short push-in when a shot starts. `iron(v)`: thermal colour map 0..1 (TERMAL).
- Shared helpers come from `src/styles/shared.tsx` (`p`, `pb`, `lerp`, `rnd`, `drawOn`, `camera`); time beats with `at()` / `endOf()` from `src/lib/words.ts`.

Reference demo: `references/examples/MEDIS_Sarapan-Bikin-Gemuk/` (64 s test reel, one look per sentence, with its
script, audio plan and Main.tsx). A buyer video uses ONE look for every shot; the reel switched looks only to compare them.

## Health content rules (all MEDIS looks)

- Show only claims that are in the script or in a source you checked. Prefer "membantu", "berisiko", "bisa" over "menyembuhkan", "pasti".
- Illustrative numbers carry a small label (`angka contoh`, `ilustrasi`). Official guidance gets a source line (e.g. `Acuan: Isi Piringku, Kemenkes RI`).
- On a beat where a viewer could self-diagnose or self-medicate, add a small line `ILUSTRASI · BUKAN SARAN MEDIS` or `Konsultasikan ke dokter`.
- No gore, no real patient photos, no toilet imagery, no brand-name drugs unless the script names them.
- Draw organs simplified and anatomically plausible (stomach left of centre under the ribs, heart left-centre, etc.).

---

## 01 POSTER PUSKESMAS — retro health-education poster
**Story:** prevention, campaigns, myths vs facts, hygiene, nutrition for families, immunisation, DBD.
**Look:** cream poster paper `#F4E6BF` with a navy halftone dot pattern (16 % opacity) and a thick navy frame; red `#D7372A`, teal `#127A78`, navy `#1C2A4D`, yellow `#F6C12E`. A teal ribbon label on top (`PENYULUHAN KESEHATAN`), a giant two-colour headline, chunky flat icons with 7–10 px navy outlines, arrows between cause and effect, a round red stamp for verdicts (`?`, `MITOS`, `FAKTA`).
**Type:** Bebas Neue (`'Pos Head'`) for headlines and captions, Nunito 800–900 (`'Pos Text'`) for labels.
**Captions:** Bebas 76 px on a red bar, active word yellow.
**Motion:** stamps slam in (scale 2.2 → 1, rotate), needles and counters jump on the spoken word, icons pop with overshoot.
**Sound:** bright plucky bed (`playful`/`curious`), `impact` on stamps, `pop` on icons.
**Pitfalls:** keep the stamp clear of numbers it would cover; the frame eats 54 px each side, so start content at x ≥ 80.

## 02 MONITOR — ICU patient monitor
**Story:** heart, blood pressure, oxygen, energy, shock, emergencies, anything measured in vital signs.
**Look:** near-black green `#03100C` with a 40 px grid; traces in green `#38F28A` (EKG), cyan `#3BD8F5` (pleth), amber `#FFC23D` (energy/values), red `#FF4D5E` (alarm). EKG is a polyline sampled from a beat function, scrolling with time; draw it twice (14 px at 18 % for glow, 5 px solid). Big condensed numbers top-right, a segmented bar panel for the main quantity, event chips (`+ SARAPAN MASUK`).
**Type:** Share Tech Mono (`'Mon Mono'`) for labels and captions, Barlow Condensed ExtraBold (`'Mon Head'`) for numbers.
**Captions:** mono, upper case, green on black with a green border, active word amber.
**Motion:** values ease to their target on the spoken word; alarms blink at ≤ 3 Hz.
**Sound:** soft monitor beeps synced to the trace, `rise` when a value climbs, `alarm` at low gain only.
**Pitfalls:** a scrolling trace must be computed from `t` (never from frame-to-frame state); don't fill the frame with tiny numbers.

## 03 TERMAL — infrared camera
**Story:** fever, inflammation, hunger, pain, metabolism, "where the heat is".
**Look:** body silhouettes filled with `iron()` radial gradients (black → purple → red → orange → yellow → white); hot spots are extra radial gradients that grow; a vertical colour scale on the right, a temperature readout and corner crosshair on the hot spot, `IR · ε 0.98 · REC ●` HUD, a clock top-right if time matters.
**Type:** Space Grotesk 700 (`'Ter Head'`), JetBrains Mono (`'Ter Mono'`) for readouts.
**Captions:** white on deep violet `#0b0420`, active word `iron(0.88)`.
**Motion:** heat swells and breathes (`±3 %` sine), objects slide in already glowing.
**Sound:** low warm drone (`tense`), a soft `alarm` when the spot peaks.
**Pitfalls:** no blur filters needed; gradients do the glow. Keep a cold margin around the body so the silhouette reads.

## 04 REKAM MEDIS — patient file and lab report
**Story:** reading lab results, cholesterol, sugar, diagnosis steps, myth "case files", checklists before a doctor's visit.
**Look:** cool desk `#C9D3DC`, a manila folder `#E8C67F`, a white form with ruled rows (`NAMA KASUS`, `SUMBER`, `HASIL`), typed values, yellow highlighter on the key value, a blue ballpoint note in handwriting, a red rubber stamp (`BELUM TERBUKTI`, `NORMAL`, `PERLU CEK`), a paperclip.
**Type:** IBM Plex Mono SemiBold (`'Rek Mono'`) for the form, Kalam Bold (`'Rek Hand'`) for doctor notes.
**Captions:** mono on white with a navy border, active word red.
**Motion:** values type on (≈ 26 chars/s) from the spoken word, highlighter sweeps left→right, stamp slams.
**Sound:** typewriter `tap`, `snap` for the highlighter, `impact` for the stamp.
**Pitfalls:** lab ranges shown must be real reference ranges with a source, or labelled `contoh`.

## 05 PAPER CUT — layered paper diorama
**Story:** simulations ("bayangin kalau…"), kids and families, life-style comparisons, crowds.
**Look:** warm paper layers (`#FFF1E2` sky, `#F6A879`, `#E9775A`, `#FBD7B9`) with a double drop-shadow (`0 10px 0 #3e214033`, `0 18px 18px #3e214033`) so each layer floats; flat paper people in plum `#9B4E6C` / ink `#3E2140`; a `SIMULASI` pill; verdict banners in green `#5BAE8C`.
**Type:** Baloo 2 800 (`'Pap Head'`).
**Captions:** Baloo on a cream pill with a hard paper shadow, active word plum.
**Motion:** paper people bob gently, inflate/deflate by width, banners rotate in with overshoot.
**Sound:** paper rustle/`pop`, playful bed.
**Pitfalls:** keep the sun/props out of the headline; when a crowd appears, enter it from behind the hill layer.

## 06 KOTA TUBUH — the body as a city
**Story:** immune system, circulation, how drugs travel, energy in vs out, organs working together.
**Look:** night city `#1E2240` seen from above; blocks `#2C3260`; blood vessels are red roads (`#C8384B` over a darker edge); buildings are organs (`OTOT`, `OTAK`, `GUDANG LEMAK`); trucks carry nutrients/energy (amber `#FFB547` in, mint `#4CD6B4` out); cells can be police (immune), intruders (virus) etc. A ledger at the top counts what enters and leaves.
**Type:** Sora (`'Kot Head'`) and Martian Mono (`'Kot Mono'`).
**Captions:** Sora on deep navy, active word pale yellow `#F7E38A`.
**Motion:** trucks loop along roads with `(t * speed + k/n) % 1`; storage bars fill and drain.
**Sound:** soft city pulse, `tick` per truck wave.
**Pitfalls:** it is a metaphor: label example numbers `angka contoh`; one metaphor per video, explained once.

## 07 HERBARIUM — botanical plates
**Story:** healthy food, herbal plants, vitamins, what to eat for a condition, prevention through diet.
**Look:** aged paper `#EFE3C6` with faint speckles; specimen cards with tape; plants drawn in ink with `drawOn` then a watercolour wash fades in (fill at ~80 % opacity); local name in Playfair italic, Latin name in Cormorant italic; a `LEMBAR VII ·` plate number.
**Type:** Playfair Display (`'Her Head'`), Cormorant Garamond (`'Her Text'`).
**Captions:** Playfair on dark brown `#3B3222`, active word yellow.
**Motion:** each specimen draws on during its spoken name; cards sit slightly rotated.
**Sound:** acoustic, calm (`warm`/`reflective`), `shimmer` on each drawing.
**Pitfalls:** check Latin names; no "obat" claims for plants unless the script cites evidence.

## 08 RONTGEN — X-ray and scans
**Story:** bones, lungs, stomach, what happens inside when something is missing or wrong.
**Look:** black-blue `#05080F`; soft tissue as dark radial gradients, bones as light strokes `#DDE8F2` (skull, spine blocks, ribs, pelvis); a sweeping scan line; one organ outlined in orange `#FF8A3D` with a dashed stroke and a callout; HUD text (`PA · 110 kV`), a battery/energy meter.
**Type:** Barlow Condensed SemiBold (`'Ron Head'`), DejaVu Sans Mono (`'Ron Mono'`).
**Captions:** upper-case condensed on dark blue, active word orange.
**Motion:** scan line loops every ~1.6 s, the outlined organ pulses, a big `?` scales in for questions.
**Sound:** airy `breath`, low hum, single soft hits.
**Pitfalls:** keep anatomy simple but in the right place; never show a "diagnosis" on the scan.

## 09 NEON SEL — glowing cells and neurons
**Story:** brain, mood, concentration, sleep, hormones, viruses, DNA, vaccines.
**Look:** deep black-violet `#04020F`; nodes and links in cyan `#35E7FF` and magenta `#FF3FD0`, warm accent `#FFB25E` for "good feeling"; glow drawn as a wide low-opacity stroke under a thin bright one (no blur filters); pulses travel along links; two meter cards (`FOKUS`, `MOOD`) with glowing bars.
**Type:** Manrope 800 (`'Neo Head'`).
**Captions:** Manrope on near-black with a magenta border, active word cyan.
**Motion:** the network lights up in order with the spoken key word; pulses move with `(t * 0.9 + seed) % 1`.
**Sound:** `hopeful` synth bed, `shimmer` when the network lights.
**Pitfalls:** about 20–25 nodes is enough; more becomes noise at phone size.

## 10 MIKROSKOP — through the lens
**Story:** bacteria, food safety, portion checks, "zooming in" on what is really in something.
**Look:** black frame with a round lens (r ≈ 430); inside, a bright field `#F3F0E4`; content starts blurred and pulls into focus; a reticle with ticks; labels with green check `#2FA36B` or red cross `#D5463A`; HUD `OBJ ×40 · FOKUS 100 %`.
**Type:** Space Grotesk (`'Ter Head'`) for captions, IBM Plex Mono (`'Mik Mono'`) for labels.
**Captions:** Space Grotesk on the field colour, round pill, active word green.
**Motion:** focus pull (CSS blur 14 → 0 px) on the first beat only; bad items shrink or get crossed out.
**Sound:** lens click, `pop` on checks, `snap` on crosses.
**Pitfalls:** the blur is the only costly effect: switch it off (`undefined`) once focused.

## 11 ANATOMI — medical textbook plate
**Story:** how an organ works, the parts of something, balanced plates, step-by-step body processes.
**Look:** off-white `#F6F1E7`, ink `#2A2420`; a figure caption (`GAMBAR 11 ·`); a clean diagram (organ, plate, cross-section) with thin leader lines to labels set in a serif, fractions or values in small grey sans; one red strike-through or highlight for the key contrast.
**Type:** DM Serif Display (`'Ana Head'`), Inter (`'Ana Text'`).
**Captions:** DM Serif on ink, active word warm yellow `#F2C46B`.
**Motion:** segments draw in one by one on the spoken word, leader lines draw with `drawOn`.
**Sound:** quiet documentary bed, `tap` on each label.
**Pitfalls:** labels must not collide: keep left-side labels anchored `start` and right-side `end`, at least 70 px apart vertically.

## 12 KACA PREPARAT — lab slides
**Story:** samples and comparisons ("which one is yours?"), lab tests, closing questions to the audience.
**Look:** pale blue bench `#DCE4E8` with faint diagonal reflections; glass slides with a white label area (`No. 001`, sample name) and pink/purple stain blobs `#B0457E`, `#7B4FA8`; the special slide gets a yellow label.
**Type:** Archivo 800–900 (`'Pre Head'`), Martian Mono (`'Pre Mono'`).
**Captions:** Archivo white on purple, active word yellow.
**Motion:** slides slide in staggered from the left; the last slide asks the question.
**Sound:** glass `tap`s, a warm closing chord.
**Pitfalls:** stain blobs are decoration: never present them as a real microscopy result.

---

# v2.1 looks (7 more)

Fonts for these are registered by the same `<MedisFonts />`. Reference demos: `references/examples/MEDIS2_Sarapan-Uji-Gaya-2/`
(JAM TUBUH, DUA SISI, LABEL GIZI, WEBTOON, APOTEK, ENDOSKOPI; the reel also has four test-only looks that are not part of the skill)
and `references/examples/DOKTER-KARTUN_Sarapan-Bikin-Gemuk/` (a full 64 s video in one look).

## 13 JAM TUBUH — 24-hour body clock
**Story:** sleep, body clock, when to eat or take medicine, fasting, staying up late, energy through the day.
**Look:** night navy `#0B1230` that warms to a dawn gradient (`#1B2A6B` → `#F08A5D`) as the clock moves; a big 24 h dial (r ≈ 360, 00 at the bottom, 12 at the top) with a night arc `#2C3A8C` and a day arc `#F6B25A`; coloured arcs for activities (`#FF7A59`) and an inner energy ring (`#7CF2B4`); event markers (a sun/plate disc) on the hour they happen; the time in big digits in the centre.
**Type:** Sora 800 (`'Jam Head'`) for the time and captions, Martian Mono (`'Jam Mono'`) for hours and the legend.
**Captions:** Sora on navy, round pill, active word mint.
**Motion:** the hand sweeps between hours on the spoken word; arcs grow from their start hour; the sky colour follows the hour.
**Sound:** soft ticking, a `shimmer` on markers, `rise` when energy fills.
**Pitfalls:** keep the legend below the dial (y ≥ 1370) so it does not sit on the hour labels.

## 14 DUA SISI — split-screen comparison
**Story:** do vs don't, habit A vs habit B, before vs after, smoker vs non-smoker.
**Look:** the frame split down the middle by a zigzag line; left side mint `#E3F6F2` with teal `#2BB3A3`, right side blush `#FDE7E3` with coral `#F2665A`; the same simple character on both sides (round head, flat body, ink `#2A2235` 6 px outlines) whose face and meters change; a shared clock pill on top; results at the bottom (plates, meters, numbers).
**Type:** Fredoka 600–700 (`'Dua Head'`).
**Captions:** Fredoka on white with a thick ink border, active word coral.
**Motion:** both sides react at the same time; the "bad" side's meter climbs and its mood flips; results pop in with overshoot.
**Sound:** playful bed, `pop` for results, a soft `alarm` for the bad side.
**Pitfalls:** keep both sides symmetric so the only difference is the point being made.

## 15 LABEL GIZI — nutrition facts panel
**Story:** hidden sugar, salt and fat, sweet drinks, diabetes, hypertension, reading food labels.
**Look:** a black-and-white "INFORMASI NILAI GIZI" panel (8 px border, heavy rules) on a kraft background `#F2E6D0`; rows for energy, fat, protein, carbs, sugar, sodium with % AKG; a yellow highlighter `#FFE14D` sweeps the row being discussed; a handwritten sticky note for the myth; a red banner `#D7263D` for the fact.
**Type:** Archivo 900 (`'Gizi Head'`), Inter (`'Gizi Text'`), Caveat Brush (`'Kal Hand'`) for the sticky note.
**Captions:** Archivo on white with a 6 px black border, square, active word red.
**Motion:** the panel slides up; numbers count from 0 on the spoken word; the highlighter sweeps left→right.
**Sound:** `tick` while numbers count, `snap` for the note, `impact` for the fact banner.
**Pitfalls:** use Indonesian label conventions: % AKG on a 2150 kkal reference (fat 67 g, protein 60 g, carbs 325 g, sodium 1500 mg); say `(contoh)` in the serving line when values are illustrative, and keep energy consistent with the macros (fat × 9 + protein × 4 + carbs × 4).

## 16 WEBTOON — vertical comic
**Story:** patient stories, ignored symptoms, "bayangin kalau…" simulations, plot twists.
**Look:** white panels with 8 px black borders stacked vertically on light grey `#EDEDED`, scrolled up as the story moves on; halftone screen tone in some panels; simple ink characters; a yellow caption box (`Bayangin kalau…`); big onomatopoeia in Bungee with a thick stroke (`BLUB!`, `HAH?!`); a final panel with the twist; a small `SIMULASI` tag.
**Type:** Bungee (`'Web SFX'`) for sound effects, Patrick Hand (`'Web Text'`) for speech and captions.
**Captions:** Patrick Hand on a white rounded pill with a black border, active word red-pink.
**Motion:** the strip scrolls with eased steps on spoken cues; effects pop in with scale and rotation.
**Sound:** comic `pop`, `question` for reactions, an `impact` on the twist.
**Pitfalls:** one idea per panel; at most three panels visible at once.

## 17 APOTEK — pharmacy label and blister pack
**Story:** how to take medicine, finishing antibiotics, OTC vs prescription, "aturan pakai" for habits.
**Look:** a white pharmacy label with a blue header `#1E5FB4` (`APOTEK SEHAT · ETIKET`, fictional), mono fields (`Nama`, `Resep`), the rule in big condensed type (`1 × sehari · pagi`); a foil blister strip `#C9D2DB` whose pockets hold the items, which pop out one by one with labels.
**Type:** Barlow Condensed ExtraBold (`'Apo Head'`), IBM Plex Mono SemiBold (`'Apo Text'`).
**Captions:** condensed upper case, white on blue, active word yellow.
**Motion:** the label drops in; fields type on; blister items pop out on the spoken words.
**Sound:** `snap` per blister pocket, a paper rustle for the label.
**Pitfalls:** when the items are food or habits, add a line such as `ini makanan, bukan obat`; never show a real drug brand or a dose the script does not give.

## 18 ENDOSKOPI — camera inside the body
**Story:** stomach and throat problems (maag, GERD), "what happens in your stomach", digestion.
**Look:** a round fisheye lens on black; inside, a pink tunnel made of concentric rings (`rgb(70,10,25)` → `rgb(236,140,130)`) that grow toward the camera so it feels like travelling; wet white highlights; a vignette; on arrival a cavity with folds and one big word (`KOSONG`); HUD in mono (`● REC ENDO-CAM`, depth in cm, organ name, `ILUSTRASI`).
**Type:** Share Tech Mono (`'End Mono'`) for the HUD, Space Grotesk 700 (`'End Head'`) for words and captions.
**Captions:** Space Grotesk on dark red, active word pink.
**Motion:** rings travel at a steady speed, then stop when the camera arrives; growl waves pulse for hunger.
**Sound:** airy `breath`, low rumble, `crackle` for a growling stomach.
**Pitfalls:** stylised only, never realistic tissue or anything that reads as gore; always label it `ILUSTRASI`.

## 19 DOKTER KARTUN — cartoon doctor presenter
**Story:** tips, step-by-step guides, myths vs facts, any explainer where a friendly host helps; works for a whole video.
**Look:** an original cartoon doctor (`src/styles/medis/Dokter.tsx`: hijab `#2A9D8F`, white coat, stethoscope, `DOKTER` badge, 6–7 px ink outlines) standing at the bottom right (`x 500, y 1120`); a white title card on top with one keyword in a yellow `#FFD43B` box (write it as `[kata]` in the title); one infographic per sentence in the middle (icon circles, cards with a coloured top edge, check/cross rows, VS cards, numbered steps, a balance scale); pastel gradient backgrounds that change per scene; a thin red progress bar at the very top.
**Character:** `<Dokter t pose poseAt prevPose />`. Poses: `point` (points up at the infographic), `wave`, `open` (palm), `think` (hand at the chin), `thumb`. The mouth follows the voice: run `npm run mouth -- public/audio/voiceover.<ext>` after `prepare-vo` (writes `src/mouth.json`). It also blinks and bobs slightly. Change the hijab or coat colours, or swap the hijab for hair, only through the constants at the top of the file so the outline style stays.
**Type:** the starter's Plus Jakarta Sans (`'Mograph Sans'` 800 for titles, cards and captions).
**Captions:** a dark pill `#1F1F33` at y ≈ 1010 (above the doctor), white words, the active word on a yellow box with ink text.
**Motion:** the title card drops in, then its keyword pops; infographic parts pop with overshoot on the spoken words; the pose changes at each scene start and eases over 0.35 s.
**Sound:** friendly `playful`/`warm` bed, `whoosh` per title card, `pop` per keyword and element.
**Pitfalls:** keep infographics inside y 420–980 so they never touch the doctor; the mouth follows loudness, not phonemes, so do not promise exact lip-sync; never copy another creator's presenter character, design a new one per channel if the buyer wants their own.
