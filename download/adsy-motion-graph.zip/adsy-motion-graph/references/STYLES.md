# ADSY MOTION GRAPH — named looks (v1.6 – v1.9)

The skill stays **adaptive**: every video gets its own storyboard. What v1.6–v1.9 add is seventeen **named looks**, each a complete
visual and sonic language you can commit to for one video: palette, type, world/camera grammar, signature moves,
captions, music bed and SFX. Fifteen of them ship as code kits in the starter (`src/styles/`). Read the section of the look
you pick before building; it is the difference between "uses the colours" and "looks like the demo".

| Look | Pick it when the story is… | Typical script signals | Ships as |
|---|---|---|---|
| **MIDNIGHT** | a what-if simulation, money, privacy, apps, social systems, suspense | "Kalau besok…", "bayangin", balances, notifications, rules changing | v1.5 component kit + `theme.ts` (`C`) |
| **MINIATUR** | places, cities, environment, crowds, a policy that changes a whole area | streets, weather, neighbourhoods, "semua orang di…" | `IsoCity` + layered 2.5D (SKILL.md §6) |
| **ARSIP** | history, origins, myths vs facts, true stories, "siapa pelakunya?", records and dates | years, kings/founders, "katanya…", "ternyata", documents, cases | `src/styles/arsip/kit.tsx` |
| **BLUEPRINT** | how something works: machines, infrastructure, safety systems, technology internals | "cara kerjanya", parts, "pertama… kedua…", engineering numbers | `src/styles/blueprint/kit.tsx` |
| **SKETSA** | psychology, habits, feelings, social behaviour, studies about people, warm reflective topics | "pernah nggak…", "kenapa kita…", experiments, everyday moments | `src/styles/sketsa/kit.tsx` |
| **HIKAYAT** | legends, folklore, Nusantara history, origins of places, myth vs science | "dahulu kala", kingdoms, heroes, curses, "konon", lakes/mountains with a story | `src/styles/hikayat/kit.tsx` |
| **GEOMETRIK** | money, economics, business, statistics, rules of thumb, comparisons | percentages, "dibagi", "kali lipat", prices, growth, inflation | `src/styles/geometrik/kit.tsx` |
| **TERMINAL** | scams, data privacy, AI, hacking awareness, apps and systems behind the screen | OTP, password, akun, "di layar si…", login, data bocor | `src/styles/terminal/kit.tsx` |
| **LANTANG** | an idea, a law or rule of thumb, a mindset or productivity point, a punchy opinion where the *words themselves* carry it (no objects or places needed) | "hukum…", "aturan…", "efek…", "jangan…", "kenapa kita selalu…", contrasts (seminggu vs besok), short commands, a quotable payoff line | `src/styles/lantang/kit.tsx` |
| **FLATLIFE** | everyday behaviour, consumer psychology and simple studies told through one relatable character who acts it out | a named protagonist ("Kenalin, ini…"), someone builds/buys/tries something, experiments with two groups, "efek …", what people would pay, everyday objects | `src/styles/flatlife/kit.tsx` |
| **CAIR** | the body, health, biology, water/food/drink science, anything measured in volume or that flows, filters, fills or drains (blood, rain, fuel, "how much passes through") | litres/ml, gelas, galon, "mengalir", "disaring", "setiap hari … kali", organ names, "persen kembali", "yang tersisa" | `src/styles/cair/kit.tsx` |
| **PETA** | geography and "why here?": borders, straits, islands, migrations, trade routes, a region's history, places compared on a real map | place names, islands/countries, "di barat… di timur…", distances in km, seas and oceans, routes, "di peta" | `src/styles/peta/kit.tsx` |
| **KLIPING** | misinformation and media literacy, viral rumours, internet/social-media behaviour, "what a study says about us" told with attitude | hoaks, viral, "grup keluarga", "sebarkan", berita, share/teruskan, "siapa pelakunya?", "ternyata…", a study that blames us | `src/styles/kliping/kit.tsx` |
| **LEMPUNG** | food and kitchen science, how something is made/grows/bakes, biology made cute, child-friendly "kenapa…?" curiosity told with warmth and handmade charm | adonan, ragi, masak/oven/panggang, "kenapa bisa mengembang/meleleh/matang", tiny creatures, "bahan", step-by-step making, sugar/flour/water, "di dalam…" | `src/styles/lempung/kit.tsx` |
| **KASET** | media, gadget and pop-culture history from the analog era (70s–2000s): format wars, a product that won or died, TV/radio/music/home-video history, "how it used to be", nostalgia told with facts | VHS, kaset, TV, radio, rental, "dulu", "tahun 70-an/80-an/90-an", "perang …", brand vs brand, "kenapa X menang?", "berhenti diproduksi", "pelajarannya" | `src/styles/kaset/kit.tsx` |
| **PIKSEL** | habits, self-improvement, progress over time, streaks and levels, gamification, "how long does it take", a number myth busted, told as a playful quest | "hari ke-…", kebiasaan, level, progres, streak, target/angka ajaib, "berapa lama", "gagal sehari", "mulai dari nol", rata-rata vs rentang, "pemain/peserta" | `src/styles/piksel/kit.tsx` |
| **TITIK** | statistics and probability, "how many / how likely", surprising numbers and paradoxes, anything you can show unit by unit (days, people, votes, a share of a group, a crowd that fills up) | "peluang", "berapa persen", "dari … orang", "setiap …", "satu per satu", "rata-rata", "hampir pasti", counts like 365/100/1000, "ternyata lebih dari…", a calculation in the script | `src/styles/titik/kit.tsx` |

**Rules (zero-prompt):**
- Pick the look yourself from the script. **Never ask "which style?"**. If the buyer wrote "pakai gaya ARSIP" / "style blueprint" / "gaya sketsa" (any spelling), that look wins.
- One look per video. You may borrow a building block from another look only after redrawing it in the chosen language (a chart in SKETSA is a hand-drawn `Pie`, not a clean SVG chart).
- When two looks fit equally, choose the one whose **signature move can show the payoff** (a stamp verdict → ARSIP, a mechanism locking → BLUEPRINT, a feeling made visible → SKETSA, a legend played out → HIKAYAT, a number that changes everything → GEOMETRIK, what happens on the other screen → TERMINAL, one word that stretches or squeezes → LANTANG, a character acting it out → FLATLIFE, something filling, draining or flowing → CAIR, a line drawn on a map → PETA, a clipping slapped down and stamped → KLIPING, something modelled, pinched or baked by hand → LEMPUNG, a tape rewound to the past → KASET, a bar filling up or a level gained → PIKSEL, many units counted one by one → TITIK). ARSIP vs HIKAYAT: an *investigation* of history (evidence, suspects, verdict) is ARSIP; a *told* legend or chronicle (characters, wonder, a moral) is HIKAYAT. SKETSA vs FLATLIFE: an inner, reflective feeling is SKETSA; an upbeat everyday story with a protagonist and props is FLATLIFE. GEOMETRIK vs LANTANG: when numbers carry the idea, GEOMETRIK; when a rule, phrase or argument carries it, LANTANG. ARSIP vs KLIPING: investigating the past is ARSIP; media, rumours and the internet now are KLIPING. MINIATUR vs PETA: life inside one place (streets, a neighbourhood) is MINIATUR; relations between places (borders, routes, regions, distances) are PETA. GEOMETRIK vs TITIK: a few big numbers compared → GEOMETRIK; many individual units (people, days, cases) or probabilities → TITIK. FLATLIFE vs LEMPUNG: modern everyday consumer life → FLATLIFE; food, making, kitchen and child-friendly warmth → LEMPUNG. ARSIP vs KASET: investigating documents → ARSIP; remembering the 70s–2000s through TV/tape → KASET.
- Name the look in the delivery message (first line, e.g. "gaya ARSIP"); the one-line reason goes into the production notes file. Do not announce it before the video exists.
- Labels: a what-if keeps `SIMULASI`; a factual piece uses a topic label instead (ARSIP: "BERKAS · FAKTA", BLUEPRINT: "CARA KERJA", SKETSA: "PSIKOLOGI", HIKAYAT: "LEGENDA" while the legend is told and "SAINS"/"SEJARAH" when facts take over, GEOMETRIK: "FAKTA & ANGKA" + "ILUSTRASI · BUKAN SARAN KEUANGAN" for money math, TERMINAL: "EDUKASI · KEAMANAN", LANTANG: none needed (a small folio with the topic name is enough), FLATLIFE: "PSIKOLOGI" / "SAINS SEHARI-HARI", CAIR: "SAINS · TUBUH" + "ILUSTRASI · BUKAN SARAN MEDIS" for health, PETA: "GEOGRAFI" / "SEJARAH", KLIPING: "MEDIA · CEK FAKTA", LEMPUNG: "SAINS DAPUR" / "SAINS SEHARI-HARI", KASET: a TV-style bug like "KANAL 9 · ARSIP" (invented, never a real channel), PIKSEL: "QUEST" / chapter tabs, TITIK: "DATA" + the unit legend ("● = 1 HARI"). Money and security pieces are education, never advice or attack instructions. Facts still go through the accuracy gate: myths and history are where errors hide.
- **SFX density, every look:** about 25–45 cues per minute. Not every block, card or line needs a sound: give one to each scene entrance, each key reveal and each payoff, and let the music carry the rest (buyer tests with 54 cues in 44 s sounded busy).
- **Cue words carefully.** `at('jadi')` returns the *first* "jadi" in the VO (maybe "berubah jadi…" at 13 s, not "Jadi, mana…" at 62 s). For common words always use a two-word phrase (`at('jadi mana')`) or an occurrence index (`at('jadi', 1)`), and check the printed word list.
- **Never land on an empty frame.** When the camera arrives at a station, page or panel, its main object is already there. The words reveal *details*, not the whole station. At every moment, content covers most of the safe area (y 170–1460). A big bare cork board, empty blueprint grid or blank page reads as a broken frame: size objects up instead of leaving the lower half empty.
- **Flicker sources (every look, found by `flicker-scan` on the v1.8 demos):** the shared `shake()` jitters at ~14 Hz and reads as single-frame blinks at 60 fps — keep it short and small, or use a slower local punch (≤ 6 Hz); counters and odometers must not change digits every frame (tick them at ≤ 20 Hz); fast spins (≈2 rad/frame) strobe — cap rotation speed; slams should start ≤ 1.6× and ease in over ~5 frames, not flash at 1.9× for one frame. Intentional stop-motion holds (KLIPING) are not blinks.
- Brand kit: the brand name/handle/logo may appear (a tab, a header, the end card), but the look's palette stays. Do not recolour ARSIP paper or BLUEPRINT blue with brand colours unless the buyer asks.

## Shared helpers — `src/styles/shared.tsx`

| Helper | Use |
|---|---|
| `useTime()` | `{t, frame, fps}` with `t` in seconds |
| `p(t, a, b)`, `pb` (overshoot), `pio` (in-out) | 0→1 progress between two times (seconds); the whole animation language is built from these |
| `camera(t, startPose, moves)` + `<World pose offset h>` | one world, one camera. `Move = {from, to, x?, y?, s?, r?}`; put moves in the **pauses** between spoken phrases. `(x, y)` lands at screen centre |
| `shake(t, impacts, amp)` | decaying shake after stamp/clamp impacts; pass as `offset` to `World` |
| `drawOn(q)` | spread on any SVG stroke to draw it on (`pathLength` normalised). It sets `pathLength`, `strokeDasharray`, `strokeDashoffset` and `opacity`: never pass those props on the same element too (TypeScript error TS2783). Put an extra opacity on a wrapping `<g>`, and for a dashed line that draws on, reveal it with a growing `clipPath` instead |
| `roughLine`, `roughEllipse`, `roughRect`, `spline` | hand-drawn geometry, seeded (deterministic) |
| `noise(freq, octaves, seed, size)` | tileable SVG noise as a CSS background (paper, desk, cork, grain) |
| `PAGES` / `pagesFor(words)` / `pageAt(t, pages)` | word-synced caption pages from `src/words.json`; every look's `Caption` takes `pages` |
| `<StyleFonts />` | registers the style fonts of all fifteen kits; render it once next to `<FontFaces />` when a named look is used |

Fonts (all SIL OFL, licences in `public/fonts`): ARSIP `'Arsip Head'` Playfair Display 400–900 + `'Arsip Type'` Courier Prime 400/700 · BLUEPRINT `'BP Head'` Space Grotesk 300–700 + `'BP Mono'` IBM Plex Mono 500/600 · SKETSA `'Sketsa Head'` Caveat Brush + `'Sketsa Hand'` Patrick Hand · HIKAYAT `'Hik Head'` Cinzel + `'Hik Text'` Cormorant Garamond · GEOMETRIK `'Geo Head'` Archivo (variable width: `fontStretch` 62–125%) + `'Geo Text'` Inter · TERMINAL `'Term Head'` VT323 + `'Term Mono'` JetBrains Mono. Each look uses exactly its two fonts.

Preview the kits: `npm run style-preview` → `out/styles/sheet.jpg` (composition `StyleGallery`, never delivered).

---

## ARSIP — case file / documentary

**Look.** Papers on a dark wooden desk under a warm lamp (vignette), manila folders, newspaper front pages, sepia polaroids with tape, index cards, rubber stamps, red-marker circles and crosses, push-pins and red string on a cork wall. Palette `A`: desk `#1B1712`, paper `#EEE5D0`, card `#F5F0E3`, manila `#CFAE6E`, ink `#1E1C19`, red `#C22F26`, highlighter `#FFD54A`.

**Type.** Playfair Display 900 for headlines and names (newspaper voice); Courier Prime for every label, typed note and caption.

**World and camera.** One `World` holds a desk area and a tall cork wall. Group beats into **stations** (≈1300–1500 world px tall, content kept between screen y 170 and 1460). The camera pans between stations in VO pauses and pushes in slowly inside one. For a verdict, pull back over the whole wall (`s ≈ 0.24`) for about a second with a screen-space `Stamp` on top, then dive into the final station.

**Signature moves.** Headlines print line by line (`Reveal`); typed notes follow the voice (`TypeOn`); the key verdict word slams a `Stamp` with `shake`; `EvidenceTag` and yellow evidence markers point at the clue; a new suspect or link draws red string between `Pin`s; `Ring` / `MarkerX` draw on with the word they judge.

**Kit (`src/styles/arsip/kit.tsx`).**
- Surfaces: `Sheet` (paper with grain and aged edges), `Card` (drops in with `q`), `Tape`, `Pin`, `Polaroid` (taped photo, `label`), `TextBars` (fake newspaper columns).
- Type: `TypeOn` (typewriter with caret), `Reveal` (masked line).
- Marks: `Stamp` (`id` unique, `lines`, `at`; slams in, ink broken by noise, paper fill keeps it legible), `Ring`, `MarkerX`, `EvidenceTag`.
- Pictures: `Bust` (generic profile silhouettes: `helmet`, `beard`, `laurel`, `fringe` on a height chart), `Mugshot` (polaroid + bust + placard), `NameCard`, `CrowdPhoto` (halftone crowd), `CalendarPage` (wall calendar with day count, dashed missing days, evidence markers, circled day).
- `Caption`: torn paper strip, typed text, yellow highlighter on the spoken word (`top` default 1500).

**Sound.** `npm run style-sfx -- arsip` → `type`, `stamp`, `paper`, `scroll`, `pin`, `marker`, `string`, `bell`, `thud`, `shutter`, `tick`, `whoosh`. Map one-to-one: `TypeOn` → type, `Stamp` → stamp, sheet lands → paper, polaroid → shutter, pin → pin, `Ring`/`MarkerX` → marker, red string → string, a total/answer → bell, camera travel → whoosh. Bed: `npm run style-score -- arsip …`: noir pizzicato walking bass, clock ticks and vinyl crackle in D minor; `suspense/tense/dramatic` sections get eighth notes, `reflective/warm` drop the bass, a `hopeful` section resolves to major. Use `hopeful` for "kasus ditutup".

**Pitfalls (learned on the demo and in buyer tests).** Every station needs one big anchor (a polaroid, document or calendar 700–900 px wide) that is visible when the camera arrives: a header card alone looks empty. Not every card needs a sound: one `paper`/`shutter` per station entrance plus the stamps and typed notes, about 25–45 cues per minute, paper at gain 0.3–0.45. A stamp over a dark photo vanishes: put it on paper or rely on its paper fill. A stamp must not cover the words it judges: place it beside them. Card titles need `whiteSpace: 'nowrap'` and a size that fits. Captions sit at 1500, so keep station content above 1460 on screen. The whole-wall pull-back reads as a thin strip: keep it short. Silhouettes stay generic: never draw a real person's likeness.

## BLUEPRINT — technical drawing

**Look.** Blueprint paper `#0E3A6B` with a 36/180 px grid, white linework that draws itself, cyan secondary lines, **yellow for the part being explained**, red-orange for failure and warnings. A title-block header bar, numbered callouts, dimension lines, hatched sections, break marks, phantom (dashed) lines for hidden parts, and DETAIL panels.

**Type.** Space Grotesk 700 for big statements; IBM Plex Mono for every label, spec and caption.

**World and camera.** One big drawing (for example a 4–5k px tall section through the object), **detail `Panel`s beside it on the same sheet** (x 1180–2160 or negative x), and an archive sheet for history. The camera travels between them in pauses; a full pull-back (`s ≈ 0.26–0.3`) shows "the whole thing" and the summary checklist.

**Signature moves.** Draw-on in reading order; explode and re-assemble (`IsoBox` z offsets); a `Callout` per named part, synced to the word; `Dim` for numbers; `BreakMark` for failure; phantom lines to show what is hidden; a ✓ checklist at the end.

**Kit (`src/styles/blueprint/kit.tsx`).**
- Geometry: `isoAt(cx, cy, k)` (iso projection), `poly`, `seg`, `line(q, w, color)` (stroke props that draw on).
- Parts: `IsoBox` (filled faces, visible edges draw on, hidden edges dashed; `topInset` for keycap/frustum shapes), `Hatch` (concrete or section hatch that wipes in), `BreakMark`, `Figure` (architectural scale person).
- Annotation: `Typed`, `Callout` (dot, elbow, numbered balloon, typed label; `side` left/right), `Dim`, `Panel` (titled detail frame).
- `Caption`: mono box with crop marks, the spoken word yellow and underlined.

**Sound.** `npm run style-sfx -- blueprint` → `blip`, `scribe`, `confirm`, `drop`, `whir`, `clank`, `snap`, `chop`, `spring`, `alarm`, `whoosh`. Map: a line draws → scribe, a callout appears → blip, a spec confirmed → confirm, failure → snap or alarm, a mechanism locks → clank, a spin-up → whir. Bed: plucked arpeggio + soft kick/hat + sub bass (A minor → C major for `hopeful`); `suspense/tense` remove the kick and lift the arpeggio with ticks; add `styleHits` `{"type":"hit"}` on the payoff click and `{"type":"riser"}` before it.

**Pitfalls.** SVG text in the world scales with the camera: a title shown at a pull-back needs 120–150 px world size and must fade before you zoom in. Callout labels near the frame edge get cut, so keep elbows at x 300–900 when `s ≈ 1`. Isometric front faces hide the centre column: explode further or draw phantom lines. The header bar sits at y 96–158, so keep sheet titles below ~200 on screen. The mechanism must be real: use "biasanya/umumnya" where designs vary.

## SKETSA — living notebook

**Look.** Lined paper `#FBF7EA` (rules every 66 px, red margin), pen ink `#1F2433`, yellow highlighter swipes, blue/coral marker hatching, stick figures, hand-drawn bubbles and charts. **Every drawing layer boils** (`Boil` filter, new seed every 5 frames), and at frame 0 a **pencil underdrawing** (`PENCIL`) of the page's main shapes is already there; ink follows the voice.

**Type.** Caveat Brush for titles and exclamations (`Write` reveals them like handwriting); Patrick Hand for labels and captions.

**World and camera.** Mostly static pages: one page ≈ one idea (5–15 s). At an act change, the next page slides up over the last (0.55 s, `pio`, slight rotation, the old page darkens). Inside a page, scale or pull back groups with `Sc` instead of moving a camera.

**Signature moves.** Handwritten title + highlighter swipe; stick figures at 1.4–1.6× (the default 200 px figure is small on 1080×1920); thought bubbles that replay the problem; hand-drawn `Pie` comparisons; a `Spotlight` cone for attention/feelings; a pencil-to-ink reveal at the start.

**Kit (`src/styles/sketsa/kit.tsx`).**
- Page: `Page` (lined paper), `Boil` (filter: one unique `id` per page), `pen(q, width, color)` (ink stroke that draws on), `PENCIL`.
- Writing: `Write` (clip reveal, `anchor`), `Swipe` (highlighter).
- People and things: `Stick` (`style` from `HAIR`: spiky, bun, cap, long, curl, scarf; `pencil` for underdrawing; `wave`), `Sc` (scale a group about an anchor), `Hand` (pointing hand), `Cheeks` (blush + sweat), `Bed`, `Head` (small head that looks up "!" or down at a phone).
- Diagrams: `Bubble` (speech or `thought`), `Pie` (hatched wedge), `Spotlight` (lamp + cone, `power` to dim).
- `Caption`: handwriting on a paper wash with a highlighter on the spoken word (`top` default 1490).

**Sound.** `npm run style-sfx -- sketsa` → `scribble`, `flip`, `pop`, `squeak`, `boing`, `ding`, `chime`, `switch`, `bubble`, `tick`, `whoosh`. Map: drawing → scribble, page flip → flip, a doodle appears → pop, highlighter → squeak, a comic beat → boing, a reveal → ding, a warm ending → chime. Bed: lo-fi electric piano, brushes and a plucked melody in F; `playful/curious` get drums and melody, `reflective/warm` keep piano and pad, `tense` thins out to piano only.

**Pitfalls.** Doodles at default size leave pages empty: fill 60–70% of y 170–1460. Keep lamps, bubbles and labels clear of the page title (title baseline ~292). Put labels under figures, not above lamps. One `Boil` id per page, or two pages fight over one filter.

**Render cost / quality (v1.9).** The kit follows the shared `renderQuality()`: the input prop `quality` ('full' | 'lite') wins; otherwise software WebGL + ≤ 4 CPU threads → 'lite'. The starter passes `quality:'lite'` in a chat sandbox.

In FULL, `Boil` wobbles every line with a full-page `feTurbulence` + `feDisplacementMap` on the page group. On a CPU-only renderer that costs about 70 % of a 2 s frame. Worse, any filter on that group, even a no-op one, makes Chrome re-raster the whole page every frame.

LITE changes two things:
- `Boil` renders no filter element. The episode's `filter="url(#boil-pN)"` then points at nothing, and Chrome draws the group unfiltered.
- `Page` puts the ruled paper on its own static compositor layer. The grain is pre-faded to 16 % and multiplied into the paper background instead of using a blend layer. The drawing layer moves by whole pixels (−1/0/+1) every 5 frames, standing in for the boil at no raster cost.

Everything else is identical: pen draw-on, highlighter and spotlight multiply, `Write`, bubbles, pies, captions and page flips.

**LITE gives up** only the line boil. Strokes stay clean and still, and the page "breathes" by 1 px instead.

Chrome-tree CPU per frame (`swangle`, 2 workers, 120-frame ranges of the reference episode; a 2-core sandbox needs ≈ CPU ÷ 2 of wall time):

| range (frames) | content | FULL | LITE |
|---|---|---|---|
| 690–809 | page flip 1→2 + experiment page | 1814 ms | 364 ms |
| 1380–1499 | room full of heads | 2089 ms | 430 ms |
| 2040–2159 | guess-vs-reality pies | 2227 ms | 236 ms |
| 2680–2799 | page flip 4→5 + bed | 2075 ms | 436 ms |
| 600–2099 (25 s run) | mixed | — | 248 ms |

**Pitfalls.**
- **Never put your own filter on a page group.** That includes `feTurbulence`, `feDisplacementMap`, blur and drop-shadow. Any filter there brings back the full-page re-raster every frame, in LITE too. Use only the kit's `<defs><Boil id frame/></defs><g filter="url(#id)">` pattern.
- **Don't reuse a `Boil` id** for anything else. In LITE the filter element does not exist.
- **Keep the page still.** A camera drift or slow zoom on the page re-rasterises it every frame. The short page flips are fine.
- **Big multiply shapes are cheap only while static.** Highlighter swipes and spotlight cones blend inside the drawing layer, so keep them still once drawn.

## MIDNIGHT and MINIATUR

These are the v1.5 looks, now named. **MIDNIGHT**: navy `#0D1233` / cream / yellow (`C` in `theme.ts`), Plus Jakarta Sans, the UI/money/chart component kit, `SIMULASI` badge, a dark editorial world with bright reveals. **MINIATUR**: the bright isometric miniature world (`IsoCity`, layered 2.5D, SKILL.md §6) with weather, crowds and maps. Both follow SKILL.md §3–§7 directly.

## Reference demos — `references/examples/`

One complete episode per kit: `ARSIP_Februari-Dirampok.tsx` (68 s, desk → cork wall with 4 suspects → verdict), `BLUEPRINT_Tali-Lift-Putus.tsx` (62 s, lift-shaft section + DETAIL A–E + 1854 archive sheet), `SKETSA_Lampu-Sorot.tsx` (54 s, five notebook pages), `HIKAYAT_Legenda-Danau-Toba.tsx` (69 s, the legend as wayang, then the volcano), `GEOMETRIK_Aturan-72.tsx` (55 s, the rule of 72 in blocks), `TERMINAL_Kode-OTP.tsx` (56 s, your phone vs the sender's terminal), `LANTANG_Hukum-Parkinson.tsx` (74 s, every word as kinetic type), `FLATLIFE_Efek-IKEA.tsx` (74 s, Dimas builds a crooked shelf + a two-group experiment), `CAIR_Ginjal-180-Liter.tsx` (71 s, 180 L through a nephron), `PETA_Garis-Wallace.tsx` (79 s, Bali–Lombok to two continents), `KLIPING_Hoaks-Lebih-Cepat.tsx` (69 s, 11 torn sheets about a hoax study). Read them for **structure**: stations, camera moves in pauses, beats pinned to words, SFX cue lists. Do not reuse their stories, text or layouts, `LEMPUNG_Roti-Mengembang.tsx` (65 s, yeast and gluten in clay), `KASET_VHS-vs-Betamax.tsx` (67 s, a boxing-match TV special on tape), `PIKSEL_66-Hari.tsx` (63 s, the 21-day myth as an RPG quest), `TITIK_Paradoks-Ulang-Tahun.tsx` (65 s, 365 day-dots and 253 pairs).

## Building a named-look video (checklist)

1. Pick the look (table above) and read its section.
2. `npm run style-sfx -- <look>` once in the project.
3. In `Main.tsx`, render `<StyleFonts />` and build the scenes from the kit, timed with `at('phrase')`. Captions: the look's `<Caption t={t} pages={PAGES} />`, not `WordCaptions`.
4. Write `src/audio-plan.json` sections (mood + energy from the story) and `sfxCues` using `audio/sfx/<look>/<name>.wav`, then `npm run style-score -- <look> src/audio-plan.json public/audio/music/<name>.wav` (or `npm run score` if the generic bed suits the story better), set `musicFile`, `npm run auto-duck`.
5. QC on `Mograph` stills as usual. `style-preview` only checks the kit.

## HIKAYAT — shadow-puppet chronicle (v1.7)

**Look.** A lit **kelir** (screen) glowing amber from an oil lamp that flickers, a cloth weave texture, and **carved leather silhouettes** (wayang-like) whose perforations (*tatahan*) let the light through. Every puppet casts a soft second shadow, stands on a rod stuck into the banana-trunk stage at the bottom, and bobs gently as if a dalang holds it. The **gunungan** opens the play, sweeps across for scene changes and closes it. Everything written appears incised on **lontar** palm leaves. Palette `H`: glow `#F7C66C`/`#E08A36`, edge `#5E240C`, silhouette `#1B0D06`, leaf `#D9B678`, ember `#C2410F`. This is deliberately not the "textile + gold foil" look of other history channels: no fabric appliqué, no gold leaf.

**Type.** Cinzel (titles, names, numbers, incised on lontar) + Cormorant Garamond (labels, captions).

**World and camera.** No camera: the stage stays put, like a real kelir. Puppets enter and leave from the sides, scenery rises from below, and the gunungan wipes between acts. Darken the kelir (`Kelir dim`, cool `tint`) for night, storms and disasters; flash it warm for magic and explosions.

**Kit (`src/styles/hikayat/kit.tsx`).**
- Stage: `Kelir` (glow, weave, flicker, `dim`, `tint`), `Stage`, `HikDefs` (put once in every svg).
- Puppets: `Silhouette` (polygon `parts`, `perforate` step per part, `flip`, `rot`, `rod`, `extra` for solid ornaments), `GununganOrnament`, and a library of polygons: `GUNUNGAN`, `KING`, `THIEF` (also a commoner or fisherman), `WOMAN`, `CHILD`, `WOLF`, `FISH`, `HOUSE` (rumah adat), `MOUNTAINS`, `VOLCANO` ↔ `CALDERA` (same point count, so `lerpPts` morphs them), `ISLAND`, `SUN`, `QMARK`, `wave()` for water, `circlePts()`.
- Writing: `Lontar` (palm-leaf strip, `q` reveals it), `incised`, `lontarTitle()`, `lontarText()`, `Tally` (scratched counting marks).
- `Caption`: a lontar leaf with incised words, the spoken word in ember (`top` default 1488).

**Sound.** `npm run style-sfx -- hikayat` → `gong`, `kecrek`, `swoosh`, `kendang`, `chime`, `magic`, `water`, `splash`, `thunder`, `rain`, `flood`, `boom`, `rumble`. Bed: synthetic gamelan in slendro (saron, bonang, kenong, gong every 8 beats, kendang, suling). `reflective/warm` = saron + suling, `playful/curious` add bonang and kendang, `tense/dramatic` drop the melody for a low gong drone and kendang rolls; `styleHits` `hit` = a big gong.

**Pitfalls (learned on the demo).** Lontar text must be ONE line: use `lontarTitle`/`lontarText` (nowrap) and size the leaf to the text; a two-line leaf needs `h >= 150`, or the top line is cut. Perforations are generated on a lattice anchored at 0,0; keep that, or holes shimmer while a shape moves or morphs. Big scenery (mountains, house) goes behind the puppets at reduced opacity. The stage is never bare: when a beat has no character (a place name, "saudagar kaya"), show a prop or scenery puppet big in front instead of only the far mountains. Lontar swaps at the same spot: the old leaf must be fully gone (allow ≥ 0.3 s) before the next one appears, or the texts overprint ("BERDOA" over "…UR"). Mark the switch from legend to facts with the label (`LEGENDA` → `SAINS`).

**Render cost / quality (v1.9).** The kit follows the shared `renderQuality()`: the input prop `quality` ('full' | 'lite') wins; otherwise software WebGL + ≤ 4 CPU threads → 'lite'. The starter passes `quality:'lite'` in a chat sandbox.

FULL costs about 2–2.6 s of CPU per frame on a CPU-only renderer, for three reasons:
- **Masks.** Every `Silhouette` is an SVG mask made of hundreds to thousands of perforation ellipses: the water has ~5,800 and the gunungan ~1,700.
- **Blurred shadow.** Each silhouette also has an `feGaussianBlur` second shadow. Puppets bob and the water drifts, so all of this is redrawn every frame.
- **Lamp flicker.** It repaints the whole kelir under everything every frame: the gradient plus the multiply and screen layers.

LITE changes these parts:
- **Silhouettes have no mask.** Each perforated part is filled with a tiny repeating hole pattern. It uses the same lattice, anchored at the puppet's 0,0, so the holes travel with the puppet, and Chrome rasterises the tile once. Each part gets a solid 9 px rim: its outline is stroked 18 px wide and clipped to itself.
- **Hard second shadow.** It is the union of the parts, offset as in FULL, at 32 %, with no blur.
- **Kelir.** The flicker is frozen. The kelir and the `Stage` sit on their own static compositor layers. `dim` fades on its own layer, so it costs nothing. The `tint` alpha moves in 0.05 steps, which repaints the kelir about every sixth frame of a fade instead of every frame.
- **Lontar.** The leaf grain and veins are baked into one background, with no multiply-blend child layer.

Layout, timing, lontar and caption type, gunungan ornaments, rods and `extra` content are unchanged.

**LITE gives up:**
- the soft blurred second shadow (it becomes a crisp offset copy);
- the lamp flicker;
- the ±1 px scatter of the hole positions.

There are also small hole differences:
- Holes right at a part's edge can be half-covered by the rim instead of omitted.
- Where two parts overlap, the upper part covers the lower part's holes. FULL punches through both.

A tint fade moves in visible 0.05 steps only if you look for them.

Chrome-tree CPU per frame (`swangle`, 2 workers, 120-frame ranges of the reference episode; a 2-core sandbox needs ≈ CPU ÷ 2 of wall time):

| range (frames) | content | FULL | LITE |
|---|---|---|---|
| 60–179 | gunungan exits, mountains + house + Toba, title lontar | 2018 ms | 408 ms |
| 390–509 | water drifting, fishing line, fish rises | 2649 ms | 459 ms |
| 1380–1499 | woman + child, lontars | 2308 ms | 382 ms |
| 2400–2519 | storm ends: rain, flood rising, dark tint fading | 2115 ms | 569 ms |
| 2100–3599 (25 s run) | storm, flood, island, volcano | — | 379 ms |

**Pitfalls.**
- **Big shapes that move every frame are the remaining LITE cost.** A drifting `WATER`, a gunungan sweeping across, or full-screen rain re-rasterise everything under them in the scene SVG. Move large scenery only when the story needs it, and let small puppets carry the motion.
- **Don't fade the `tint` colour per frame through a whole scene.** Use `dim` for darkening, which is free in LITE, and keep the tint for storms.
- **Give every `Silhouette` a unique `id`.** LITE derives its pattern and clip ids from it.
- **Don't add masks, blurs or drop-shadows of your own** to silhouettes or the scene `<svg>`. In LITE they bring back the per-frame cost the kit removed.

## GEOMETRIK — Swiss/Bauhaus data (v1.7)

**Look.** Warm off-white page (`#F2EEE4`) on a strict 90 px grid, primary colour fields (red `#E5402E`, blue `#2149A6`, yellow `#F6C21C`, black `#121212`), **giant condensed numbers**, and shapes that *are* the data: a square is money, a row of blocks is years, a bar is a total, a red full-bleed flip is "the other way". Hard, snappy motion (`ps` easing), wipes and full-colour fields instead of camera moves.

**Type.** Archivo (variable: weight 900, `fontStretch` 62–100% for condensed headlines and numbers) + Inter (labels, captions).

**Kit (`src/styles/geometrik/kit.tsx`).** `GridPage`, `Big` (number/headline with `stretch`), `ps` (snappy progress), `Block` (colour block/circle that scales, slides from the left or up), `Abs` (positioned text), `label()` (tracked caps), `Caption` (black bar, the spoken word on yellow).

**Sound.** `npm run style-sfx -- geometrik` → `tick`, `slam`, `pop`, `click`, `swipe`, `wipe`, `flip`, `ding`, `rise`, `down`, `cut`, `thud`. Bed: marimba arpeggios with kick + clap in `bright` sections, a low pulse in `tense`, marimba only in `calm`.

**Pitfalls.** One idea per phase, cleared before the next (each phase owns the whole frame). Every phase needs one dominant shape covering roughly 40% or more of the frame (a giant number, a colour field, a big block or chart): a headline with one small square on an empty page reads as a broken frame. Numbers must be computed, not typed from memory. Label money math "ILUSTRASI · BUKAN SARAN KEUANGAN".

## TERMINAL — green-phosphor CRT (v1.7)

**Look.** A near-black CRT with scanlines, grain, vignette and dim hex rain; phosphor green `#3DFF8C` for text, amber `#FFB547` for warnings and codes, magenta `#FF3D7F` for alerts and the "other side". Bordered windows with title bars, commands typed with a block cursor, data as block-character bars (`█` / `░`), glitch slices on turns, ordered-dither pixel portraits, a radar for searching.

**Type.** VT323 (big pixel titles and numbers) + JetBrains Mono (everything else).

**Kit (`src/styles/terminal/kit.tsx`).** `Win` (window, `color`, `shake`), `Typed` (typing with cursor), `Bar` (block bar with missing cells), `PixelBust` (dithered portrait), `Phone` + `Bubble` (a terminal-styled phone and messages), `Lock` (open/closed padlock), `HexRain`, `Glitch`, `CRT` (render last), `glow()`, `Caption` (prompt line, the spoken word inverted).

**Sound.** `npm run style-sfx -- terminal` → `ting`, `msg`, `keys`, `key`, `blip`, `glitch`, `drone`, `ok`, `warn`, `lock`, `granted`, `drain`, `alarm`, `error`, `x`. Bed: dark synth, pulsing saw bass, square arpeggio and drums in `bright`, drone + ticks in `tense`.

**Pitfalls.** Synth transients push the true peak: keep SFX gains ≤ 0.6 and check `audio-qc` (the demo needed a limiter before mastering). Text in windows needs an explicit colour: an uncoloured label renders black on black. Security stories stay awareness-only: show what a code or password protects and the rule, never a working attack.

**Render cost / quality (v1.9).** The kit follows the shared `renderQuality()`: the input prop `quality` ('full' | 'lite') wins; otherwise software WebGL + ≤ 4 CPU threads → 'lite'. The starter passes `quality:'lite'` in a chat sandbox.

In FULL, `CRT`'s grain slides across the whole screen every frame. On a CPU-only renderer that makes Chrome re-raster everything every frame, about 1.3–1.4 s of CPU per frame:
- the 616 hex-rain digit groups, each with its own `opacity` and so its own offscreen layer;
- the blurred window and phone glows;
- every glowing text run;
- the scanlines and the vignette.

LITE changes these parts:
- **Grain.** It holds still.
- **CRT finish.** Scanlines, grain and vignette sit on one static compositor layer. The grain is composited at 7 % as normal alpha instead of a screen blend, which looks the same on the near-black screen.
- **`HexRain`.** It gets its own layer and repaints only on its 8 Hz ticks. Each digit group uses `fill-opacity` instead of `opacity`, which gives the same pixels without a layer each.
- **`Phone`.** The phone body gets its own layer, so the ting rings and typing no longer re-blur its glow.

Text glows (`glow()`), window and phone glows, `Glitch` slices, typing, cursor blink and hex-rain timing are all unchanged.

**LITE gives up** only the crawling grain: it becomes static dust, normal-blended.

Chrome-tree CPU per frame (`swangle`, 2 workers, 120-frame ranges of the reference episode; a 2-core sandbox needs ≈ CPU ÷ 2 of wall time):

| range (frames) | content | FULL | LITE |
|---|---|---|---|
| 0–119 | phone slides in, ting rings, typed SMS | 1375 ms | 417 ms |
| 1000–1119 | login window, typing, password | 1306 ms | 366 ms |
| 2340–2459 | balance drains, alarms, "404" | 1426 ms | 488 ms |
| 3240–3359 | the rule window, OTP lock phone | 1396 ms | 360 ms |
| 1200–2699 (25 s run) | locks, login, session, 404 | — | 372 ms |

**Pitfalls.**
- **Whole-screen motion every frame costs the most on a CPU renderer.** That includes a scrolling background, moving scanlines, a rolling bar, or a screen shake outside the short glitch windows. Keep shakes and `Glitch` to about 0.2 s bursts.
- **Dim SVG text with `fillOpacity`, not `opacity`.** Opacity on many `tspan`s gives each one an offscreen layer.
- **Keep scaling pops of huge glowing type short.** A `glow()` text of 150 px or more that scales every frame (the "404" pop) is the most expensive moment in a TERMINAL episode.
- **Don't animate a window's size or position continuously.** `Win` and `Phone` glows are blurred box-shadows. They are cheap while still and costly when they move every frame.

## LANTANG — kinetic typography (v1.8)

**Look.** Pure kinetic type: the words ARE the picture and ARE the captions — no illustrations, no caption bar. Full-bleed colour **cards** (ink `#0E0E0E`, paper `#F3EFE6`, hot `#FF4A1C`, accent blue `#2B4BFF`; `L` in the kit) wipe over each other (up/down/left/right/circle, snappy `ps` easing). Inside a card, lines are **justified by the width axis**: every line fills the 936 px column at its own size, so a stack reads as one poster. Size and width carry meaning: a long time is a word stretched wide, a deadline is a word squeezed between walls, "memuai" swells past the frame. Signature moves: words landing on their syllable (rise / slam / drop / stretch / pop), outline echoes, a word walled in, odometer digits, a slow push inside every card, camera punch on hits, print grain over everything.

**Type.** `'Lan Head'` = Anybody variable (weight 100–900, `fontStretch` 50–150%). House weight 900; squeezed words (wdth ≈50) use 760–780. All caps. One font only.

**World and camera.** No world: a stack of cards. A new card every idea (≈2–4 s); words keep arriving inside it, so the picture changes at least every 2.5 s. Camera = the card's slow push (`drift`) + `punch` on the big hits; for long lists, slide the stack so the revealed rows stay centred.

**Kit (`src/styles/lantang/kit.tsx`).**
- Sizing (the fit contract): `fl(text|words[], size, min?, width?)` → `{size, wdth}` justified props · `fillWdth(text, size, width?, ls?, weight?)` → wdth that fills · `fit(text, wdth, width?)` → size · `lineW(words[], wdth, size, ls?, weight?)` → px width · `ems()`; constants `W` 936, `LS` −0.02 em, `GAP` 0.22 em, `HEAD`, `SNAP`, `ps`.
- Width tables `A900`/`A780`: per-glyph advances measured at wdth 50 and 150 for weights 900 and 780 (linear in wdth; weights between interpolate, lighter → 780 table). Cover A–Z, 0–9, space and `. , ! ? : ; ' " - – — ½ > < % / # · … ( ) + = × & “ ”`, UPPERCASE only (lowercase → its capital, unknown → H). ±2 %, errs wide. Valid only for Line's default letter-spacing/gap or the `ls`/`weight` you pass.
- Lines: `Line` (`words: {text, at, color?, outline?, wdth?}[]`, `size`, `wdth`, `mode` rise|slam|drop|stretch|pop, `fromWdth`, `stagger`, `ls`, `weight`, `bob`, `align`, `out`) · `Stack` (centred column, `top` 170 / `bottom` 260) · `Gap` · `Txt` (static text) · `Tag` (label block, `parts` reveal word by word) · `Echo` (outline copies, `kind` scale|offset) · `Ghost` (huge glyph behind, e.g. "?") · `Marquee` (giant outline word drifting) · `Rule` (bar/underline/strike growing on its cue).
- Cards and camera: `Card` (`start`, `until` = next start + 0.45, `bg`, `wipe`, `dur`, `drift`, `slow`, circle `at`) · `punch(t, impacts, amp, dur)` → `{x, y}` · `Folio` (topic + time bar) · `Grain` (render last).
- Meaning devices: `SpanBar` (|—| span with a bar whose word stretches/squeezes to fill it) · `Walls` (`q`, `inner` = word width → two bars close on a word) · `Roll` (odometer `value`, `start`, `lock`, `step`, `travel`) · `Countdown` (mm:ss ticking each second) · `Chips` (row of popping chips) · `TimeRow` (timesheet row: big duration + task words + bar ∝ minutes, `more`, `wobble`).
- `Caption` (`pages`, `top` 1380, `size`, `color`, `hot`): the current page as 1–2 justified kinetic lines, spoken word in hot — for talky stretches without a hand-built card.

**Captions.** The kinetic lines are the captions: the whole VO must be readable on screen. Build each card from `Line`s whose words are timed with `at('phrase')` (filler words smaller lines, key words huge); use `<Caption t={t} pages={PAGES} />` only where no card carries the words. Never add `WordCaptions`/a caption bar on top.

**Topic label.** `Folio` top-left: the topic name ("HUKUM PARKINSON", "EFEK …"), or "IDE · FAKTA" for a general idea piece; money tips add "ILUSTRASI · BUKAN SARAN KEUANGAN".

**Sound.** `npm run style-sfx -- lantang` → `slam`, `whoosh`, `swipe`, `pop`, `stretch`, `squeeze`, `tick`, `thud`, `riser`, `snap`, `ding`, `clock`. Bed: 120 BPM electronic — syncopated kick, clap+snare, 808 sub, square stabs; half-time with clock ticks when `tense`; pad + Rhodes when calm. Sound the card wipes, slams, stretch/squeeze moments and the payoff, not every word.

**Reference.** `references/examples/LANTANG_Hukum-Parkinson.tsx` (74 s, 24 cards) was built in the demo workspace with `makeCues`/`EpisodeAudio`; in the starter use `at()/endOf()` from `src/lib/words.ts` and Main.tsx audio + `audio-plan.json` `sfxCues`. Do not copy its `noAudio` input prop — the starter has `npm run render -- --silent-draft`.

**Pitfalls (learned on the demo).**
- Never hand-guess font sizes: wide wdth runs ~10 % wider than a naive estimate and crops at the edges. Size every line with `fl()`/`fillWdth()`; a word with fixed wdth 100 at 130–140 px already overflows ("WAKTU YANG", "KARENA KALAU").
- Weight 900 below wdth ≈63 clogs (BESOK, NAMANYA unreadable). `fl` refuses to go narrower; for an intentional squeeze use weight 760–780, `ls` 0.01, and measure with `lineW(…, ls, 780)` so `Walls` hug the real word.
- A stretch from wdth 50 is unreadable for its first frames: start at `fromWdth` ≥ 58.
- Hidden words keep their space, so a card looks top-heavy until its last line lands. Start each card's first line ~0.1 s before its wipe (`at: cardStart - 0.1`) so no wipe lands on an empty card, make words big, and centre long lists as rows appear.
- Flicker: the shared `shake()` (~14 Hz) strobes at 60 fps — use the kit's `punch`. Random split-flap digits and frame-by-frame count-ups blink — use `Roll` (slow odometer, ≤ ~4 digits/s). A slam that starts at 1.9× flashes one frame (the kit's Line ramps in from 1.55×). Drops faster than ~70 px/frame and 180° spins read as blinks: fall with gravity over ≥0.4 s, flip with scaleY.
- Echo outlines and slams overshoot the margins by design; keep the solid word inside x 72–1008 and everything above y ≈1660.
- Counters: a ticking `Countdown` is fine (one change per second); every number on screen must come from the script.

## FLATLIFE — flat character explainer (v1.8)

**Look.** The classic flat 2D explainer: a warm cream stage (`#FFF3E2`) with one big soft circle (sky `#BFE6F2`, or a tint per scene), a sun disc, drifting confetti (dots, plus signs, squiggles) and a floor band (`#F6DFC3`) at y≈1390. Rounded vector people with squash-and-stretch, blinks and moods; props pop in with overshoot; scenes change with an **iris wipe** (circle clip with a sun/coral rim); "why/title/rule" beats move to a **navy spotlight** stage. Palette `FLAT`/`F`: navy `#22325A`, coral `#FF6B57`, teal `#16A394`, sun `#FFC845`, lilac `#8F7CF0`, skin `#F4B98C`, red `#E0483C`, brown `#8A5A3B`, wood `#E9B574`, kraft `#DDAA6C`, steel `#A9B4CC`, cream `#FFF9F0`. SKETSA vs FLATLIFE: a reflective inner-feeling piece is SKETSA; a story *acted out* by a character is FLATLIFE.

**Type.** `'Flat Head'` Fredoka 300–700 (titles, pills, labels, numbers) + `'Flat Text'` Nunito 200–1000 (captions, 900).

**World and camera.** One `Stage` (camera world + svg) per scene, floor at y 1390. Characters are BIG: the protagonist at `s` 1.3–1.5 (≈700–800 px tall), two people side by side ≥ 1.35. Slow drift (s 1.0–1.1), pushes in the pauses, a short punch zoom on impacts. Each scene is an `IrisScene` centred on the next subject. Comparisons: a split screen of two clipped panels, then **podiums as the bar chart** with the characters standing on them. Headline beats: `DropWord` letters on the navy `SpotStage`.

**Kit (`src/styles/flatlife/kit.tsx`).**
- Stage: `Backdrop` (bg, circle colour/pos, `sun` or null, `floorY`, confetti colours), `SpotStage` (navy + spotlight cone), `Stage` (pose, `off` for shake), `IrisScene` (`from`, `to`, `cx`, `cy`; stays `dur` 0.5 s past `to` so the next iris opens over it), `Iris`, `Confetti`, `Burst` (one-shot confetti at `at`), `Puffs` (landing dust), `SparkleField`/`Sparkle`.
- Rig: `Person` — origin between the feet, ≈546·s tall (head centre y −436·s, r 80·s, shoulders ±64·s at −318·s). Props: `look`, `mood` (`happy proud pain curious sad shock meh love`), `seed` (blink phase), `at` (drop in from `dropH` 700 px with squash; nothing drawn before `at`), `armL`/`armR`, `walk` (leg cycle + bob; move `x` yourself), `hop` (px), `lean` (deg about the feet), `tilt` (head deg), `lookX`/`lookY` (−1…1 pupils), `flip`, `sweat` 0–1, `bandage`, `thumbSwell` 0–1 (both on the screen-left hand).
- Arms: `Arm = {a, e, tool?, toolRot?}`, `a` shoulder (0 hanging, 90 out, 180 up; negative crosses the body), `e` elbow (+ keeps turning outward/up, − folds in). Tools `hammer screwdriver clipboard wrench`; `toolRot = side·(a+e)` keeps a clipboard upright (left −1, right +1). Tested poses: wave `{a:150,e:20+sin}`, hands on hips `{a:40,e:-100}`, cheer `{a:160,e:15}`, scratch head (left) `{a:160,e:30}`, hold box/hug in front `{a:25,e:-95}`, arms crossed `{a:25,e:-125}`, reach right `{a:80,e:-10}`. `handPos(side, arm)` gives the local hand point to aim props.
- Casting: `Look = {skin, hair, hairStyle: tuft|short|side|curly|bun|bald, shirt, pants, shoes, coat?, glasses?, beard?, stripe?}`; `Dimas` = `Person` with `DIMAS_LOOK`; `LOOKS` presets `labGlasses labNeat labCurly` (lab coats) `bunCoral shortLilac curlySun`. A new lead: `const RINA: Look = {...}; <Person look={RINA} seed={5} …/>`. Real people = generic look + plain name `SvgPill` (`upper={false}`), never a likeness.
- Pose over time: `armAt(t, [[t0, arm], [t1, arm]…])` (sorted; first key is the base; 0.3 s eases), `keyAt` (numbers), `stepAt<Mood>` (discrete), `armMix`; motion `land`, `squash`, `popIO(t, in, out?)`, `blink`, `FALL`.
- Props: `Shelf` (300×450 at s 1: `build` 0→1 sides/base/shelves/back, `books`, `plant`, `tilt` racks it, `lying` on its side pivoting bottom-left and extending 450·s left, `collapse` → plank pile, books fall), `shelfPoint(x,y,s,lx,ly,tilt)` to pin things on it, `FlatBox` (upright flat-pack, `open` flaps, `label`), `StorageBox` (`fold` net→box), `Screw`, `Hammer` (origin = head), `Clock` (`hours` from 10 o'clock spins both hands + a coral elapsed wedge), `Medal`, `Heart` (`crack`, `deflate`), `PriceTag` ((x,y) = tag top, `string` px up, `swing`, `text`), `Frog` origami (`crumple` 0 neat → 1 amateur, `happy`), `PaperFold` (`fold1`, `fold2`), `Podium` (`label`/`value` fade in by height), `BurstStar` ("BONK!"), `DizzyStars`, `SweatDrop`, `QMark`, `Magnifier`, `Table`, `Window`, `Plant`, `Frame`, `CheckCard` (`tick`, `cross`), `Manual`, `Beaker`, `Plaster`.
- Labels: `Pill` (HTML, screen space, centre x/y, `q` scale), `SvgPill` (world space, moves with the camera), `DropWord` (HTML title, letters drop in).

**Captions.** `<Caption t pages dark?>`: white pill, Nunito 900 56 px, `top` 1556, spoken word on a coral chip; `dark` (sun pill) on navy scenes. Pages `pagesFor(words, 4, 22)`.

**Topic label.** Optional small navy pill top-left: `RISET · PERILAKU` for study-based stories, `FAKTA · SEHARI-HARI` for everyday facts. Keep it off the main pill row (screen y≈300).

**Sound.** `npm run style-sfx -- flatlife` → `pop`, `boing`, `step`, `bonk`, `squeak`, `ding`, `whoosh`, `iris`, `clink`, `creak`, `sparkle`, `fold`, `kaching`. Bed: 110 BPM ukulele strums, marimba melody, bouncy bass, soft kick/clap; tiptoe pizzicato when tense. `iris` on every wipe gets repetitive: ≤ 0.45 and skip it when another cue lands within 0.3 s.

**Reference.** `references/examples/FLATLIFE_Efek-IKEA.tsx` (74 s, 14 scenes joined by iris wipes) uses the demo workspace's `makeCues`/`EpisodeAudio`; in the starter use `at()/endOf()` from `src/lib/words.ts` and Main.tsx audio + `audio-plan.json` sfxCues. Its `silentDraft` input prop is workspace-only — do not copy it (the starter has `--silent-draft`).

**Pitfalls (learned on the demo).**
- Small characters on an empty floor look weak, and a scene opening on bare backdrop reads as broken: start the camera close on the subject, or let people `at`-drop in DURING the iris. `Person`/`DropWord` draw nothing before `at`.
- Screen pills at y≈300 collide with heads when the camera zooms or a podium overshoots (`pb` adds ~10%). Head top on screen = `(y − 546·s − camY)·camS + 960`; keep it ≥ 360. Put hearts beside the head, not above it.
- Text on a rising bar hangs below the floor while it is short: use `Podium` (fades by height) or fade your own. Props standing on a podium must scale in with it, or they sit on the floor first.
- Pin medals and tags to a tilted shelf with `shelfPoint`. Hang tags from the shelf top with `string` ≈190 so they clear the medal. `lying` extends left off-screen: put the character in front.
- "Pack it back": move/scale the collapsed `Shelf` group up and draw a `FlatBox` after it, so the box front hides the pile.
- Split screens: each panel is its own svg in a clipped div; shift the left content by −270 as the right panel slides in. Hang tags at y≈680 so they clear boxes on tables (top ≈905 at box s 1.1).
- `shake()` alternates direction every frame (strobe): only on the one big impact, amp ≤ 28, ≤ 0.45 s. flicker-scan flags it, plus fast drop-ins, iris rims and count-ups: inspect the frame triples, those are motion.
- Fredoka renders A–Z, 0–9, `$ % + = ≈ ? ! #`; draw hearts, ticks and arrows with kit shapes, not glyphs. `SvgPill` width is estimated (0.62 em caps / 0.54 em mixed case): check long names in stills.
- No brand trade dress: a brand-named effect is plain Fredoka text, and boxes stay kraft/navy (the IKEA demo had no blue/yellow).
- **Pill swaps at the same spot (buyer test v1.8).** Two top pills overprinted ("TUG… BIKIN BESAR… ATU") because the next label landed while the old one was still leaving. The old pill must be fully gone (≥ 0.3 s) before a new pill lands in the same place, or put the new one at a different height.

## CAIR — liquid motion + liquid glass (v1.8)

**Look.** A slow mesh-gradient night (`#0B0A1F` with drifting violet/pink/cyan glows) where **volume is liquid**: gooey metaballs merge and split (SVG goo filter), glass tubes, galons, kidneys, beakers and tumblers fill with a sloshing sine surface, and **frosted glass** cards, pills and chips (backdrop blur + saturate) float on top. Scenes change with a **liquid sweep**: a 640 px band of liquid with wavy edges, bubbles and a foam line rises (flood) or falls (pour) across the frame, old shot above, new shot behind. Palette `K`: violet `#7B5CFF`, pink `#FF5FA2`, cyan `#33D6FF`, amber `#FFB547`, white `#F6F4FF`; `TONE` deep `#151040`, indigo `#2A1E73`, raspberry `#C42A68`, pale `#FFE9A6`; `SWATCH` pale→dark amber (5 steps). Give liquids a meaning and keep it (e.g. violet = the volume being counted, pink = blood, cyan = water).

**Type.** Sora only, registered as `'Cair Head'` (weights 300–800): 800 for numbers and titles, 600–700 for pills/chips, 300 for soft lead-in lines. `txt(size, weight, color)` gives the style object.

**World and camera.** No global camera. The video is a list of **shots**, each on its own mesh background, swapped by sweeps every 5–10 s (`up` = flood, `down` = pour). Inside a shot use a subtle `Drift`; to "dive into" something, push with the shared `camera()` + `World`, then fade the next shot in (`Shot.style` opacity) while its content scales up from the target point. A "wait…" beat freezes the liquid: render the shot with a clamped time (`tf = Math.min(t, T)`), dim it and pop a glass pill.

**Kit (`src/styles/cair/kit.tsx`).**
- Tokens: `CAIR`/`K`, `TONE`, `SWATCH`, `FONT`, `SOFT` + `ps` (soft progress), `txt()`, `mix(c1, c2, q)` (solid colour blend), `tick(t, hz=20)` (counter time).
- Liquid: `Goo` (`id`, `blur`=16; full-frame filter), `Blob` (`x y r fill t seed opacity`; body + two orbiting satellites = a living edge), `Gloss` (highlight for a blob, `x y r`), `wave(x0, x1, level, bottom, t, amp, seed)` (sloshing surface path), `edgeLine`, `GlassRect` (`x y w h r`; frosted vessel + streak).
- Shapes: `galonPath(cx, y0)`, `kidneyPath(cx, cy, s, flip)` + `inKidney(x, y)` (scatter points inside), `tumblerPath(cx, top, bottom, wTop, wBot)`, `KidneyIcon`, chip icons `Dot`, `Crystal`, `Hex`, `Ring`, `hexPts()`.
- Glass UI: `Glass` (`style`, `radius`), `Chip` (`t at text color|icon size out`; pops with overshoot), `Headline` (`t items=[{at, text}] until top=200`; pill that swaps text on cue), `Abs` (`x y w o center`).
- Scenes: `MeshBg` (`kind` night/deep/flood/amber/aqua), `Shots` (`t shots`) with `Shot = {from, render(t), bg, sweep?, until?, style?(t)}` and `Sweep = {at, dur=0.85, dir, colors, seed}`; `SweepBand`/`sweepClip`/`sweepGeo` are what `Shots` uses. `Drift` (`t seed amt`).
- `Caption`: frosted glass pill at `top` 1570, Sora 600 50 px, the spoken word on a pink→violet liquid pill, unspoken words at 40 %.

**Captions.** `pagesFor(words, 4, 24)`; render `<Caption t={t} pages={PAGES} />` after `<Shots>`. Big glass cards may repeat the line (the question card did); the caption stays.

**Topic label.** For body/health stories a small line `ILUSTRASI · BUKAN SARAN MEDIS` under the headline on the beat where a viewer could self-diagnose; otherwise a glass pill `SAINS · FAKTA`.

**Sound.** `npm run style-sfx -- cair` → `drip`, `bloop`, `bubble`, `splash`, `wave`, `glass`, `swell`, `drain`, `whoosh`, `gulp`, `pour`, `pop` (`wave` on every sweep, `splash` on counter landings, `glass` on pills and freezes). Bed: 90 BPM Rhodes chords, sub bass, water-drop arpeggios, soft kick; dark filtered pad + slow drops when tense.

**Reference episode.** `references/examples/CAIR_Ginjal-180-Liter.tsx` (71 s, nine shots) uses the demo workspace's `makeCues().at` and `<EpisodeAudio>`; in the starter use `at()/endOf()` from `src/lib/words.ts`, Main.tsx audio and `audio-plan.json` `sfxCues`. Do NOT copy its `draftNoMusic` input prop (the starter has `--silent-draft`).

**Pitfalls (learned on the demo).**
- Goo eats small radii: blobs under ~25 px vanish at `blur` 16. Use SOLID fills inside a goo group (gradients show seams between merged circles), draw `Gloss` outside it, and change a liquid's colour with `mix()`, never with opacity (the alpha threshold shrinks a faded blob). Every goo group is a full-frame blur: max two per frame, unique `id` per svg.
- Liquid in a vessel: clip AFTER the goo and make the `wave` wider than the vessel, or the threshold pulls the liquid off the walls; add the inflow column to the `clipPath` where drops or a stream enter.
- A stream only reads as liquid when drops overlap (spacing ≤ ~1.5 r, e.g. a drop every 0.03 s at 900 px/s); spaced drops look like dots.
- Flicker sources found by `flicker-scan` (51 frames): number counters changing digits every frame and an orbiting blob moving ~2 rad/frame (strobe). Fix: compute counters from `tick(t)`, cap orbits at ~2 laps/s with a smooth ramp, and draw a trail of ghost blobs spaced by speed (cap ~0.13 rad) so speed reads as a streak.
- Glass cards that reserve room for lines spoken later look like empty slabs: let each late line open its own height (`height: size * 1.06 * ps(...)`), so the card grows. Inline-block spans swallow trailing spaces (`Kalau180`): put `{' '}` between them.
- Never land on bare liquid or empty glass: the sweep band is only 640 px, every shot paints its own `MeshBg` (`Shots` does), and each shot must have content on its first revealed frame (fill vials/tubes on the beat before, start counters inside a card). Hide a vessel's liquid until the stream actually lands (no thin line at the bottom). The kit shows a caption page that starts before 0.15 s at full opacity, so frame 0 is designed.
- Keep streams and pipes out of the headline area (a stream behind a glass pill smears through its text): feed vessels from a glass tap below the title.
- `Shots` always sets a `clip-path` on every shot (`inset(0)` when idle) so `backdrop-filter` blurs the same before, during and after a sweep; keep that if you write your own layering.
- Chips stack in columns starting at x ≤ 690 (four chips fit inside x 960); flex-wrap rows only append, so earlier chips never jump.
- Health topics: no toilet imagery (show colour as glass vials/swatches), no medical claims beyond the script.
- **One blob is not a shot (buyer test v1.8).** A single drop on a dark field, an empty glass or a bar with nothing in it reads as a broken frame. Every shot needs one dominant liquid object covering roughly 40% of the safe area plus 2–3 supporting chips, labels or a vessel. Grow it from the previous shot's sweep instead of starting from nothing.

**Render cost / quality.** CAIR is one of the heavy looks in FULL: 1.3–2.0 s of Chrome CPU per frame on software GL (≈ 0.65–1.0 s wall per frame on a 2-core sandbox). Measured with a bisect on 60-frame ranges (`--gl=swangle`, 2 workers). The biggest cost is the **animated mesh background**: radial-gradient glows that move every frame and force a full-frame re-raster, about 0.65 s CPU/frame. Next comes **backdrop-filter glass**: the caption is glass on every frame, and cards/chips add more, about 0.33–0.44 s. The **goo filter** costs 0.06–0.16 s in FULL, but in LITE it becomes the main cost again (0.28 s on question/nephron). The blurred **60 px card shadow** costs about 0.21 s, and the idle `clip-path` about 0.09 s.

`renderQuality() === 'lite'` (input prop `quality`, or automatic on software GL with ≤ 4 threads) switches all of this inside the kit:
- `Goo` renders no filter, so attach it with `{...gooFilter(id)}`, which is `{}` in LITE. Blobs then just overlap, and a translucent `Blob` fill (`#rrggbbaa`) is drawn opaque with group opacity, so overlaps don't show.
- `MeshBg` glows are frozen on their own layer (`will-change: transform`), and `Drift` does nothing.
- `Glass`, `Chip` and the caption become tinted indigo panels with a border, an inset highlight and a hard 8–10 px offset shadow, with no backdrop blur.
- `Hex` loses its drop-shadow, and idle shots have no clip-path.

FULL is unchanged, pixel for pixel: 25/25 frames identical against the pre-LITE bundle.

| range (60 frames) | FULL CPU ms/frame | LITE CPU ms/frame | LITE wall ms/frame (12-core Mac under load) |
|---|---|---|---|
| tank + counter card | 1747 | 417 | 262 |
| kidneys, camera push | 1264 | 385 | 263 |
| sweep (two shots + band) | 2011 | 604 | 332 |
| nephron (goo ball, drops, chips) | 1594 | 380 | 224 |
| question (goo blobs, big card) | 1833 | 467 | 343 |
| reabsorption stream | 1576 | 332 | 191 |
| tumbler pour | 1489 | 349 | 188 |

LITE gives up these things:
- No gooey necks: blobs merging and streams of drops read as overlapping circles or beads, not one smooth liquid.
- No frosted blur behind glass: panels are tinted, so the content behind no longer shows through blurred.
- No slow glow drift and no shot drift.

It still reads as CAIR at phone size: liquid vessels, sloshing surfaces, glass panels, sweeps, the palette.

**Pitfalls (render cost).**
- Always attach goo with `{...gooFilter(id)}`, never a hard-coded `filter="url(#id)"`.
- Keep blob fills solid, or translucent as `#rrggbbaa` (LITE fades the group). Without goo, an `rgba()` fill shows the circle overlaps.
- Space stream drops at ≤ ~1.5 r so the LITE beads still read as a stream.
- Don't add your own full-screen animated gradients, blurs, `backdrop-filter` or big blurred shadows in a scene. Use `MeshBg`, `Glass` and `Chip`, which already switch.
- A whole-frame camera move (`World` push, dive) re-rasters everything on those frames. Keep pushes short (≤ 1 s).
- Sweeps are the most expensive frames (two shots + band). Don't stack sweeps back-to-back, and don't put a goo-heavy shot on both sides of one.

## PETA — video-essay map (v1.8)

**Look.** A real map, not an illustration: Natural Earth coastlines and borders (public domain) on a muted paper palette `PETA`: sea `#D7E3E1`, land `#F3EEE2`, coast `#A89E8B`, borders `#BDB3A0`, ink `#1F2A33`, one vermilion `#E2553A` (lines, pins, stamps), one highlighter yellow `#F6CF3A` (fills, `Hl` sweeps), card `#FFFDF8`, deep sea `#B4CBCF`, dry shelf `#E6D8B6` hatched `#C8B286`, and two side tints for comparisons, cool `west #6E93A8` / warm `east #DE8A5E`. Dashed white graticule, a soft offset shadow under the land, paper grain, a live scale bar with a north arrow. Signature moves: the camera **flies** between places, a line **draws** across the map, islands or countries **fill** with highlighter, pins drop with pulse rings, a red ✕ **stamps** an island, a sonar ring **reveals** the depth, the sea **drains** to show the dry shelf, and Vox-style white cards carry a source line.

**Type.** `'Peta Head'` = DM Serif Display (titles, big numbers, italic sea names) + `'Peta Label'` = Barlow Condensed 600/800 (tracked caps labels, kickers, captions). Both are registered by `<StyleFonts />`; the kit exports them as `SERIF` and `LABEL`.

**World and camera.** One map world; `flyCam(t, start, moves)` moves the camera between shots in the VO's pauses (1.1–2 s each), using a van Wijk smooth zoom, and pushes in slowly while it holds. A shot is `shot(lon, lat, s)`; `s` = screen px per map px. On the bundled map: s ≈ 0.45 shows Asia, Indonesia and Australia; s ≈ 1 shows an island group; s ≈ 6–12 shows a strait (inside the 10m detail box). Everything placed **on** the map is drawn in a screen-space `<svg>` from `toScreen(cam, lon, lat)` every frame, so type and strokes stay crisp at any zoom.

**Map data.** The bundled `src/styles/peta/map-nusantara.json` covers lon 86..160, lat −48..48: Indonesia, SE Asia, Australia, the 200 m depth zone, 12 named islands, `countries.Indonesia`, and a 10m close-up box around Bali–Lombok (lon 112.6..119, lat −13..−3.5). It works offline.
- **Another region:** download Natural Earth GeoJSON from `https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/` (public domain; needs network egress). Use `ne_50m_land`, `ne_50m_admin_0_countries`, and optionally `ne_10m_land` and `ne_10m_bathymetry_K_200`.
- **Bake it:** `node scripts/make-map.mjs --out src/styles/peta/map-<region>.json --bbox lonMin,lonMax,latMin,latMax --land … --countries … [--country Italy] [--island Sicilia=14.2,37.5] [--deep …] [--detail-land … --detail-box … --detail-island …] [--place Roma=12.5,41.9]`. Full help is in the script header.
- **Use it:** `import MAP from '../styles/peta/map-<region>.json'` and pass `map={MAP as PetaMap}` to `MapView`/`ScaleBar` and as the last argument of `shot`/`toScreen`/`geoPath`/`proj`/`kmPerPx`.

**Kit (`src/styles/peta/kit.tsx`).**
- **Map:**
  - `MapView` (`cam`, `fx`, `map`, `id`, `grid`, `detailAt`). `fx: MapFx` takes:
    - `fills` (named islands)
    - `countries` (country fills)
    - `deep` and `sonar` (depth tint and its circular reveal)
    - `shelf` (dry-shelf dilation in map px, ≈340 on the bundled map) and `shelfTints` (lon/lat polygons)
  - Data and projection: `NUSANTARA_MAP`, `PetaMap`, `proj`/`unproj`.
- **Camera:** `shot`, `flyCam` + `Fly` (`at`, `dur`, `to`, `drift`), `toScreen`, `kmPerPx`, `ScaleBar` (`cam`, `map`).
- **On-map marks (screen svg):** `geoPath` (smooth path through lon/lat points; draw on with pathLength), `MapLabel` (halo text, `\n` lines, `serif`/`italic` for seas), `Pin` (drop + pulse rings), `Cross` (✕ stamp), `Measure` (distance bar + label chip), `Badge` (round icon with name tag; `kind` from the animal library — harimau, badak, gajah, orangutan, kakatua, kuskus, kanguru, burung — or `art` + `name`; optional `anchor` leader line).
- **Icons:** `AnimalArt`, `Boat`, `Ferry`, `Explorer` (generic silhouette, no likeness), `ClockIcon`.
- **Cards and type:** `Headline` (`kicker` + serif lines over the map) with `TopVeil` behind it, `Card` (white, `source` line), `LowerThird` (`title`, `sub`, `icon`), `Chip`, `Kicker`, `Hl` (highlighter sweep).
- **Charts:** `LevelGauge` (sea level in m), `StraitSection` (schematic cross-section; `bed`, `level`, `drop`, label props), `Spectrum` (two-sided bar with a sliding marker).
- **Utilities:** `pg` (glide easing), `inOut`, `Grain`, `PETA`, `SERIF`, `LABEL`.

**Captions.** `<Caption t={t} pages={PAGES} />`: an ink box at `top` 1580 (bottom edge ≈ 1672) in Barlow Condensed 600 56 px. The spoken word is yellow and upcoming words are at 40% white. Build pages with `pagesFor(words, 5, 30)`.

**Topic label.** A running HUD at top-left: a red dash and the topic in tracked caps (`— GARIS WALLACE`). Put the `ScaleBar` at top-right. Headline kickers name the beat (`BAGI AHLI BIOLOGI`, `ZAMAN ES`, `PENAMPANG …`).

**Sound.** `npm run style-sfx -- peta` → `pin`, `swoosh`, `draw`, `stamp`, `click`, `paper`, `rumble`, `wave`, `ding`, `thud`, `tick`, `pop`. Bed: 92 BPM documentary, pizzicato ostinato, warm pad, piano motif; low timpani and ticking when tense.

**Reference episode.** `references/examples/PETA_Garis-Wallace.tsx` uses the demo workspace's `makeCues`/`EpisodeAudio`; in the starter those are `at()`/`endOf()` from `src/lib/words.ts` plus Main.tsx audio and audio-plan `sfxCues`. Do NOT copy its `draftNoAudio` input prop; the starter has `--silent-draft`.

**Pitfalls (learned on the demo).**
- **Sequence cards and headlines in the same spot.** The old one must be fully gone (≥ 0.3 s) before the next comes in. A card fading out under a new headline overprints.
- **Never draw-on a line inside the camera group.** Do not put `pathLength`/dash draw-on there, and do not mix it with `non-scaling-stroke`. Draw it in screen space via `geoPath`.
- **Bbox margin.** Make the bbox ≈ 20% bigger than the widest shot. Land is clipped at the bbox, so a cut continent shows a straight edge. Portrait frames are tall: check the top and bottom latitude of the widest shot.
- **Detail box.** The detail box must contain the whole viewport whenever `s ≥ detailAt[1]`. Keep close-up cameras centred in it. Without it, 50m coasts look jagged above s ≈ 4.
- **Country fills inside the detail box.** They disappear there unless the baker set `--detail-country` (only valid when all detail land is that country). Island fills there use `detail.islands` if baked.
- **Fills stack.** An island tint over a yellow country fill turns olive: fade the tints out while the country highlight shows. Keep big land tints (a whole continent) ≤ 0.45 opacity.
- **Labels collide.** Move labels away from lines, pin heads, route endpoints and the right 120 px. A label anchored to a far place sits at the frame edge during a fly, so fade it in after the fly settles.
- **Distance bars.** `Measure` puts its chip 70 px above the midpoint, so a vertical bar hides under it: use horizontal bars over water, not red on a yellow fill. Compute distances from the data (closest coast points) and write "±".
- **No counting numbers.** A rolling counter in proportional serif digits was flagged by the flicker scan, and it said "lebih dari 20 m" mid-roll. Reveal the final number instead.
- **✕ stamp and first frame.** The ✕ draws its circle first, then the strokes (a zero-length round-cap line shows as a red dot). Start the first headline and map label at negative times so frame 0 is never a bare map.
- **Draft renders.** `--muted` still fetches music and SFX files: render with `--silent-draft` until audio exists.

**Render cost / quality.** PETA has a LITE path, chosen by `renderQuality()` from `src/styles/shared.tsx` (input prop `quality`, or automatic on software GL with ≤ 4 threads, which is the chat sandbox). FULL is unchanged.

In FULL the map is SVG. On software GL (SwiftShader), Chrome re-runs every big path for every raster tile, so one map re-raster costs about 3 s of CPU. It happens on every frame where the camera or any map effect changes, which in FULL is every frame because of the slow push-in.

In LITE, `MapView` draws the same layers on a CPU-backed `<canvas>` (2D context with `willReadFrequently`, so Skia rasterises in software) from cached `Path2D`s of the same path data. An unchanged frame is not redrawn. LITE also changes these things:
- When zoomed out, paths are thinned to about 2.4 screen px, and islets smaller than about 3 px are dropped.
- The camera does not push in while it holds.
- The 50m and 10m maps switch at the midpoint of the zoom instead of crossfading.
- The dry shelf fades in as one shallow-sea fill: it does not grow out of the coast and has no hatching.
- The land has no offset shadow.
- The grain is a light normal-blend layer instead of a multiply blend.
- Cards and lower thirds get hard offset shadows instead of blurred ones.

The overlay marks (labels, pins, lines, badges, cards, captions) are identical in both qualities.

| Chrome-tree CPU ms/frame (swangle, 2 workers) | FULL | LITE |
|---|---|---|
| zoom-out fly, strait → region (Bali/Lombok to the west) | 1210 | 338 |
| fly at zoom ≈ 1 across the region | 3313 | 375 |
| ice-age shelf drying | 7420 | 285 |
| strait close-up + dry shelf + cross-section card | 22289 | 381 |
| whole-region final view (s ≈ 0.47) | 3393 | 243 |

LITE was measured over 60-frame windows and FULL over 20–30-frame windows. Measured on the PETA "Garis Wallace" episode.

**Pitfalls (render cost).**
- **Map changes are expensive in FULL.** Every frame in which the map changes (camera, an island or country fill fading, `shelf`, `sonar`, `deep`) is a full map redraw: about 0.3 s in LITE, 1–20 s in FULL on software GL. Keep map-effect animations short. Put anything that pulses or loops (rings, bobbing badges) in the screen-space overlay, not in `MapFx`.
- **New map layers go in both renderers.** Add any new layer to both `MapLayers` (FULL SVG) and `drawMap` (LITE canvas), or LITE will not show it. Never put SVG filters, blur or `mix-blend-mode` on the map.
- **Huge strokes.** The FULL dry shelf is a coast stroke hundreds of px wide. A round join per vertex on the 10m coast was about 19 s of the 22 s strait frame. In LITE it is a plain fill; do not reintroduce giant strokes.
- **Dashes run the full length.** Dashed strokes (the graticule) generate dashes along the whole line before clipping. LITE draws the graticule only inside the viewport.
- **Legend swatches.** A hatched swatch in a legend no longer matches the unhatched LITE shelf. Use a plain swatch if the video will render in LITE.
- **Stills.** Checking LITE locally: pass `--props='{"quality":"lite"}'` to renders and stills. Without it a Mac with a GPU renders FULL.

## KLIPING — zine collage in stop-motion (v1.8)

**Look.** A kraft-paper desk (`Desk`: noise + corrugated fibres) under torn paper scraps with a white fibre edge, newspaper clippings, tape strips, halftone cut-outs (people, robot, faces), rubber-stamp verdicts, star stickers, ransom-note letters cut from different "magazines" and red/cobalt marker scribbles; a `GRAIN` multiply overlay on top. Each chapter is a new coloured **torn sheet slapped over the frame** (`Sheet`). Palette `Q` (= `KLIPING`): kraft `#C8A27C`, paper `#FBF8F1`, ink `#151515`, pink `#FF7EB6`, cobalt `#2F4BFF`, mustard `#F2B705`, mint `#5ED6A6`, red `#F0442E`; newsprint neutrals `news #E4DED2`, `grey #B9B3A8`, `greyInk #7D776E` for "plain/boring" beats. Mint is too light as ink: use `#13A06C` for "BENAR" text and stamps. Signature moves: ransom letters landing one by one, scraps slapping down (scale 1.18 → 0.96 → 1 over two holds), a stamp slamming the verdict, marker circles/arrows drawing on, a sheet slap per chapter, photocopies bursting out, pieces torn off the page.

**Type.** `'Klip Fat'` Abril Fatface (clipping headlines, big words) + `'Klip Block'` Bungee (labels, stamps, numbers) + `'Klip Hand'` Kalam Bold (marker notes, captions). `Ransom` also borrows `'Geo Head'` Archivo and `'Arsip Type'` Courier Prime per letter; all are registered by `<StyleFonts />`.

**World and camera.** Everything visual runs on a **12 fps held clock**: `const h = makeHold(frame, fps)` once per frame, pass `h` to every kit piece, animate with `hp(h, a, b)`, and give `camera(h.tq, …)` / `shake(h.tq, …)` the held time too, so the camera also steps. Chapters: `<Sheet h at={landing} color from seed dots corner>` wraps a `World`. The sheet slides in during the two holds before `landing`. Render chapter *i* while `h.tq ∈ [landing_i − 3/12, landing_{i+1} + 2/12)`, in time order so the newest is on top. Inside a chapter, use a slow drift (s 1 → 1.04, r ±0.5) and, for a 2nd/3rd panel of the same sheet, a horizontal whip-pan (x += 1200 in 0.3–0.4 s, `World w={2400|3600}`). Change the sheet colour every chapter (paper, cobalt, pink, mustard, ink, red, mint, news).

**Kit (`src/styles/kliping/kit.tsx`).**
- Clock: `makeHold(frame, fps)` → `{t, tq, n, jig}` · `on(h, at)` / `since(h, at)` (rounded to the nearest hold) · `hp(h, a, b)` eased held progress · `slap(h, at, big)` · `glued(landing)` = landing − 0.5 for pieces carried by a sheet.
- Paper: `Desk` · `Sheet` · `Scrap` (`x y w hgt color rot seed halftone out z`, children centred) · `Tape` · `Clipping` (`head`, `photo` tint or `false`, `lines`, `grey`, `color`, children overlay e.g. a `Stamp`) · `TornBar` (strip growing to `L` over `dur`: bars, race lanes) · `Slip` (tiny news slip, cheap by the dozen) · `TextLines` · `Photo` · `Dots` (halftone pattern def) · `torn(w, h, seed)` · `GRAIN`.
- Words: `Ransom` (`text size x y seed per rot avoid out`; `per` = seconds per letter, 0 = all at once; `avoid` = the sheet colour so no letter vanishes) · `Note` (Kalam marker note) · `Caption`.
- Ink: `Ink` (full-size SVG layer; `w` for wide worlds) + `Marker` (`d at dur color width`) + `arrowHead(x, y, deg)` · `Stamp` (centred on x, y: `text color size rot round blend`) · `Burst` (star sticker).
- Cut-outs: `Cut` (generic slap-in holder) · `Person` (generic halftone bust: `w bg tone hair 0–4 glasses seed`) · `Face` (`kaget|takut|jijik|datar`) · `Robot` · `Phone` + `Bubble` (generic group chat, no app branding) · `PressCard` · `Badge` ("CEK FAKTA" n) · `Runner` (clipping on marker legs) · `Crowd` (block of tiny people) · `Scissors` · `Finger` · `StopSign` · `Stopwatch` · `Magnifier` (children shown in the lens) · `Off` (tears a group off in two holds at `out`; `z`) · `lerpPt`.

**Captions.** `Caption t pages top=1574`: a torn paper strip, Kalam Bold 58, the spoken word gets a mustard highlighter stripe, words not yet spoken at 35 %. It is **frame-exact** (`t`, never `h.tq`) and `nowrap`, so build pages with `pagesFor(words, 4, 22)`.

**Topic label.** "KLIPING · CEK FAKTA" on a small torn tag; a cited study gets a typewriter `Scrap` ("SUMBER: … · Jurnal, tahun").

**Sound.** `npm run style-sfx -- kliping` → `tape`, `tear`, `slap`, `snip`, `stamp`, `marker`, `crumple`, `paper`, `pop`, `ding`, `buzz`, `shutter`. Give `tear` to every sheet (landing − 0.16), `stamp` to verdicts and `slap` to big words; ~44/min was the ceiling on the demo. Bed: 86 BPM lo-fi boom-bap, swung hats, Rhodes, vinyl crackle, low-passed.

**Reference episode.** `references/examples/KLIPING_Hoaks-Lebih-Cepat.tsx` (69 s, 11 sheets) uses the demo workspace's `makeCues`/`EpisodeAudio`; in the starter use `at()/endOf()` from `src/lib/words.ts` and Main.tsx audio + `audio-plan.json` `sfxCues`. Do not copy its `draftNoAudio` input prop (the starter has `--silent-draft`).

**Pitfalls (learned on the demo).**
- **Two clocks.** Graphics, `hp`, camera and shake use `h.tq`; captions use exact `t`. A caption on `h.tq` stutters, and a piece on `t` glides and breaks the stop-motion. Build the hold from the frame number (`makeHold`), not `Math.floor(t * 12)`: float error gives 4- and 6-frame holds.
- **Sheets must carry their content.** A piece with `at={landing}` is invisible while its sheet slides in, so the chapter arrives as a blank colour field. Glue the headline and main objects with `at={glued(landing)}`, and let the spoken words add details (bars, stamps, runners). Unmount the old chapter one hold after landing.
- **z-order through transforms.** Any wrapper with a `transform` (`Off`, a moving or scaling div) is its own stacking context: z-indexes inside it only count inside, so two faces inside an `Off` disappeared BEHIND a `z=2` grey clipping outside. Give the wrapper the z (`<Off z={8}>`, or `zIndex` on the moving div).
- **Ransom words are wide**: about 0.85 × `size` per letter including paper padding. Two words on one line collided ("126RIBU", "SAMACEPAT") or cropped "70%". Check letters × 0.85 × size + x ≤ 960, or put the second word on its own line.
- **Stamps.** `blend` (multiply) vanishes on dark sheets and colour photos: use `blend={false}`, size ≥ 48, placed over the text lines rather than the photo.
- **Fill the frame.** A headline plus one object on a big sheet reads as broken. Glue the chart frame, labels, lanes and props at landing. Keep text out of x > 960 from y ≈ 900 down, because the app buttons sit there.
- **Seeds are ids.** `Scrap` halftone ids come from `seed` + colour and `Person` ids from `seed`. Reuse a seed only for identical pieces.
- **Holds are not blinks.** Holds are intentional (flicker-scan: 0 blinks on 4152 frames). A real blink means an `at`/`out` pair flips inside one hold.
- **Similes still need a prop (buyer test v1.8).** On "seperti gatal yang minta digaruk" a pink sheet carried only a note and one small shape. When the VO compares or explains in the abstract, glue one big literal cut-out (a hand scratching, a magnifier, a clipping) that fills the sheet; the words only add the note.

## LEMPUNG — claymation stop-motion (v1.9)

**Look.** Everything is modelled plasticine on a tabletop: a matte paper sweep (`Backdrop`, wall curving into the floor, warm key-light pool top-left, vignette, paper tooth) with contact shadows under every object (`Contact`) and stray clay crumbs (`Crumbs`). Clay letters are thumb-pressed onto the wall; puppets and props stand on the floor; a clay roller or a dough sheet changes the set. Palette `L`: cream `#FFF4E2`, tomato `#E2553B`, mustard `#F2B33D`, teal `#2E9C8F`, lilac `#9C7BD8`, cocoa `#6B4532`, ink `#3B2A20`, pink `#EE8E9C`, sky `#8CC7E8`, wood `#D7A06B`, skin `#EDAE86`/`#DC9068`; food colours in props: `DOUGH #F2DBAE`, `DOUGH_DK #E3C48E`, `YEAST #F6D06F`, `BUBBLE #E2F3F6`, `GLUTEN #E58F5A`, `CRUST #C27A3A`. Sets `SETS`: cream, peach, mint, butter, rose, micro (aqua, for "inside/tiny" worlds), night (dark teal, suspense), oven (dark cocoa, heat) — change the set per chapter. Signature moves: letters pressed on (1.34 → squash 1.2/0.8 → rebound), objects dropping with squash & stretch, popping out of the floor, puffing up (`puff`), being squashed flat away (`flatten`), dough really rising (`Dough rise`), a magnifier into the micro world, a rolling-pin wipe, a dough-sheet slap.

**Type.** `'Lem Head'` = Baloo 2 (variable 400–800): 800 for clay letters, numbers, labels; 700 for captions. Registered by `<StyleFonts />`; call `useLemFonts()` once in the root (delayRender until Baloo is loaded — otherwise the first frames render in a fallback font).

**World and camera.** All graphics step on a **12 fps held clock** (`hold = Math.floor(frame * 12 / fps)`, `tq = hold / 12`; `kAt(tq, at)` = holds since `at`); captions use the exact `t`; transitions step at 24 fps. Structure the episode as `<Timeline t scenes trs />`: each scene is a component `({t, tq, hold}) =>` that draws its own set inside `<Cam>` and its wall words outside it. `Cam` = focus point + scale (`s0 fx0 fy0`, `moves=[{from,to,s,fx,fy}]`, `from===to` = an instant stop-motion reframe), a slow `push`, and a two-hold nudge on `impacts`. Use a push-in to a window/lens for detail beats and cut back out before wall text must be read. Lay out for 1080×1920: wall words y 90–450, hero prop y 500–1450 standing on y ≈ 1440, caption at 1572.

**Quality — LITE is the default (no GPU needed).** Read from the input prop `clay` (`'full' | 'lite'`, wins if set), else from the shared `quality` prop only when it is explicitly `'full'` (the auto-detect in `renderQuality()` is deliberately ignored — FULL is ~2 s/frame without a GPU even on many-thread machines), or forced from code with `FORCE_CLAY` at the top of the kit. **LITE** uses no blur, turbulence or lighting filter and gets the clay feel from cheap layers: (1) **lumpy outlines that boil** — bodies are drawn as seeded wobbly paths (`blobEllipse`, `blobRect`, `wobPath`) re-seeded per 12 fps hold on a 3-drawing cycle (`useBoil()`); sized HTML clay (`Clay` with numeric `width/height`: slabs, boards, sticks) becomes such a blob automatically; (2) **matte surface grain** — a deterministic tile of fine, even dimples (a faint dark dot under a faint light dot), a few faint thumb smudges and two barely-visible thumbprint whorls (`lemTex` pattern, also `CLAY_TEX` as a CSS background) laid over every body by `ClayG` (it draws the group's shapes a second time with the pattern forced on by CSS); (3) **matte paint** — `cf(color)` = per-shape radial gradient with a broad soft light top-left and a darker lower rim (no glossy hot spot), HTML clay gets the CSS equivalent (`liteBody`); (4) hard inner rims (alpha shifted against itself) on body groups + one hard drop shadow per group; chunky hard text-shadows for clay letters. **FULL** = the real clay filter (turbulence boil + blurred-alpha diffuse/specular light) — only with a GPU: `npx remotion render src/index.ts <Comp> out.mp4 --gl=angle --props='{"clay":"full"}'` (≈ 35 ms/frame on Apple Silicon). The starter's `npm run render` cannot pass `--gl`/props, so it renders LITE; a GPU machine that wants FULL through it sets `FORCE_CLAY = 'full'`.

(5) **software-GL hygiene** (what made LITE fit a 2-core sandbox): the grain tile is one pre-rasterised PNG (a vector pattern of ~200 shapes cost ~0.85 s CPU/frame), the backdrop, the scene camera layer, yeast rows and the caption are their own compositor layers (`will-change: transform`) so frames inside a 12 fps hold reuse the raster, only characters boil (big props keep a static lumpy outline), crowd rows and the zoomed balloon cross-section are `ClayG flat` (no filter) and a crowd row changes pose together every 2 holds, and LITE has no slow camera push.

| Chrome CPU per frame (process tree; `gl: 'swangle'`, 2 workers, 60 frames, 1080×1920) | LITE before the CPU pass | LITE (shipped) |
|---|---|---|
| CO₂ close-up (yeast, bubbles, molecule) | 1750 ms | 417 ms |
| balloon cross-section at 2.2× zoom (≈80 balloons) | 3944 ms | 382 ms |
| oven (oven, dough, 4 working yeast, gauge) | 3490 ms | 459 ms |
| crowd of 35 yeast + gluten net | 2488 ms | 515 ms |
| kitchen / crust / kneading (typical scenes) | – | 337 / 299 / 487 ms |

On a 2-core sandbox wall ≈ CPU ÷ 2, so ≈ 0.15–0.26 s per frame and roughly 10–15 min of rendering for a 65 s episode (render-safe resumes chunk by chunk). FULL is ≈ 2 s+ per frame on software GL — only with a GPU. Measure with `out/w4/lempung/perf/one.mjs`-style CPU accounting, not wall clock: a many-core Mac spreads SwiftShader over all cores, and Remotion's default `gl` (none) uses the Mac's GPU.

**Kit (`src/styles/lempung/kit.tsx`).**
- Quality/paint: `CLAY` · `LITE` · `ClayDefs hold` (once per frame; filter ids `slabA slabB slabC` bodies, `big` hero shapes, `txtA txtB` letters/strands, `fine` small parts, `cap` caption) · `ClayG f tex flat` (use instead of `<g filter>`: adds the grain overlay in lite, `tex` defaults to on for slab/big/cap; `flat` = no filter in lite for big/zoomed/crowded groups) · `cf(color)` SVG fill · `ClayGrads` (gradients + `lemTex` pattern + the overlay CSS) · `CLAY_TEX` CSS grain tile · `liteBody(color, sh)` · `liteText(color, size)` · `mixColor/lighten/darken`.
- Lumpy geometry (lite wobble, full = clean): `useBoil(hero)` → 0/1/2 per hold (lite: only `hero=true` characters boil) · `blobEllipse(cx, cy, rx, ry, seed, boil, amp=0.05, n=10)` · `blobRect(x, y, w, h, r|[tl,tr,br,bl], seed, boil, ampPx)` · `wobPath(d, seed, boil, ampPx)` (absolute M/L/C/Q/Z paths; anchors drag their control points, so curves stay smooth).
- Clock + squash keyframes (return `SQ {x y sx sy r on}`): `HZ` · `kAt(tq, at)` · `drop(tq, at, fall)` lands ON `at` · `press(tq, at)` wall · `pop(tq, at)` out of the floor · `flatten(tq, at)` squash away · `puff(tq, at, [sx,sy], [sx,sy])` inflate · `mul(a, b)` · `jig(hold, id, amt)` per-hold animator's touch · `ID`.
- Set + bodies: `SETS` + `Backdrop set` · `Contact x y w s k` · `Crumbs seed colors top` · `Place x y w h s rot origin z` (squash around the base) · `Clay f style` (any HTML box as clay; pass `background` as a hex) · `Slab w h color f thumb radius` · `Label size color top` · `Pill tq at x y w h color ink size rot out z` · `Thumb x y r rot` (thumbprint) · `Star size color`.
- Words: `ClayLine text starts=[t per word] tq hold size y color x w f out seed shade` (unmounts before/after its life) · `ClayWord … at|ats mode='press'|'drop'|'pop'` (single glyphs like a giant "?" with `at={-10}` inside a `Place`) · `timesFor`.
- Camera/transitions: `Cam` · `Timeline t scenes trs` with `TR {a, b, kind: 'roll'|'slap', lip}` (`lip` = the NEW set's floor colour) · `RollingPin y` · `DoughLip x color` · `slapClip` · `Caption t pages` · `useLemFonts()`.
- Props (`src/styles/lempung/props.tsx`): `Yeast w mood arms look blush sweat dim color f` (moods `smile grin open chomp o sleep puff worry relief effort`; arms `down up waveL waveR side pump1 pump2`) · `YeastRow items f` (a whole crowd row in ONE svg: one body filter + one face filter) · `yeastBody/yeastFace` · `Bubble d face look tag` (CO2 tag) · `Molecule w` (O=C=O) · `BowlBack`/`BowlFront w` (dough goes between) · `Dough w rise score holes` · `Magnifier r handle tint children` · `WaterDrop w face color` · `Wisp h color phase` (steam/aroma/alcohol) · `SugarCube w` · `FlourSack w` · `Hand w flip` · `strand(...)` · `balloonNodes(cx, cy, rx, ry, step)` + `BALLOON_COLS` · `OVEN` + `OvenBody lamp` (draw the window interior in a clipped box at `OVEN.win`) · `Gauge d a` (no numbers) · `Loaf w bake` (0 raw → 1 golden) · `Slice w bite id`.

**Captions.** `Caption t pages`: Baloo 2 700 / 60 px on a rolled-dough pill (clay strip with a thumbprint), spoken word in tomato, unspoken at 38 %, frame-exact, inside x 64–960, top 1572. Build pages with `pagesFor(words, 4, 22)` (pills are `nowrap`).

**Topic label.** "SAINS DAPUR" (or "SAINS SEHARI-HARI") as a mustard `Pill` pressed on the wall.

**Sound.** `npm run style-sfx -- lempung` → `squish`, `plop`, `boing`, `pop`, `roll`, `slap`, `stretch`, `puff`, `sizzle`, `ding`, `bubble`, `thud`. `roll` at every rolling-pin start, `slap` on the sheet landing, `boing` on puffs/elastic, `ding` on keyword letters; ~43/min was right. Bed: 100 BPM toy piano + plucked bass + woodblock/brush, reed (clarinet) lines when calm, tiptoe staccato + ticks when tense.

**Reference episode.** `references/examples/LEMPUNG_Roti-Mengembang.tsx` (65 s, 7 sets, 6 clay transitions, crowd finale + end card) uses the demo workspace's `makeCues`/`EpisodeAudio`; in the starter use `at()/endOf()` from `src/lib/words.ts` and Main.tsx audio + `audio-plan.json` `sfxCues`. Do not copy its `draftNoAudio` input prop (the starter has `--silent-draft`).

**Pitfalls (learned on the demo).**
- **Never render FULL without a GPU.** 0.2–2 s per frame on software GL, and a zoomed camera multiplies it (filters are rasterised at screen scale: the 2.2× balloon close-up cost 2 s/frame). LITE is the default for that reason; judge FULL stills at scale 1 (light strength does not scale with the render scale, half-size stills look over-shaded).
- **`<ClayGrads/>` must be the last element of the root** (after captions): it emits the gradients for every `cf()` colour of that render plus the grain pattern and its CSS. Never `cf()` inside a `<mask>` (luminance) — use `#fff`/`#000` there; the grain overlay skips `text` and `fill="none"` strokes by design.
- **Lite looked like glossy vinyl** until outlines, grain and matte paint came back: a smooth gradient alone reads as plastic — and with big dark blotches it read as a spotted potato. Keep the grain fine and faint (dimples at ~0.04 opacity, smudges ~0.016, whorls ~0.02). Draw new props' bodies with `blobEllipse`/`blobRect`/`wobPath` + `useBoil()` and wrap them in `ClayG` (not a bare `<g filter>`), or they will look like vinyl next to the rest.
- **The grain lives in each SVG's user space**, so it scales with the viewBox: keep prop viewBoxes around 1 unit ≈ 1–2.5 px (a 200-unit yeast drawn at 470 px is the upper end). `wobPath` amplitudes are in the same units (3–5 for bodies). Mid-size crowd rows (`txtA`) skip grain and rims (cost; invisible at that size).
- **Software GL re-rasterises what changed, every frame it changes.** A 1080×1920 SVG (e.g. a crowd row drawn in a full-frame box) invalidates the whole frame when one yeast waves: size SVGs to their content and give animated groups their own layer. Avoid vector `<pattern>`s with many shapes (pre-rasterise to PNG), whole-frame camera drift and boiling big props; filters on big, zoomed or crowded groups → `ClayG flat`. A flat group loses its drop-shadow edge: give big flat shapes a darker stroke (the balloon dome) so they don't melt into the wall.
- **Layering across transitions.** `Cam` has a transform, so z-indexes inside it stay local, but screen-space items with `zIndex` (wall words, a giant "?", molecules outside `Cam`) leaked OVER the incoming scene during a slap; `Timeline` now isolates every scene — keep screen-space z-indexes inside the scene component.
- **Never land on an empty set.** A scene is revealed by the pin/sheet before its first word: give it its hero prop at scene start (yeast already standing, slabs present) and make the first beat a hop/puff, not an appearance; same after a magnifier/iris zoom (pop the first row one hold before the word).
- **Wall words in a zooming set get cropped.** Squash them away (`out`) before a push-in, or keep them screen-space when the camera only cuts. Every replaced line needs `out` (two lines at the same y overlap otherwise).
- **Baloo baseline ≈ 0.8 em** below the box top at `lineHeight: 1`: put contact shadows there and squash big glyphs around `origin={\`50% ${0.8 * size}px\`}`, or they float above their shadow.
- **Vertical frames leave a dead middle band.** Make heroes big (bowl 720 px, yeast 470 px, slice 700 px) or push the camera in (`s0 1.22`); long kneading sleeves must reach off-frame and tilt outward (a V), never cross.
- **Crowds:** one `YeastRow` per row (items must not overlap sideways), back rows small with `f="fine"`, front rows `txtA`/`slabC`; rows pop centre-out, one hold apart.
- **Facts:** draw a gauge or thermometer without numbers unless the script states one (label approximate values as such). Depict "dies/stops" gently (eyes close, colour dims, soft sparkles).
- **Holds are not blinks.** 0 blinks on 3926 frames (both qualities); a real blink means an `at`/`out` pair flips inside one hold. Avoid per-frame random — everything random is seeded by `hold`.

## KASET — a worn VHS tape of a 90s TV broadcast (v1.9)

**Look.** The video is a home-recorded VHS tape of a 90s TV special, built in three layers like the real signal chain.
- **Picture (taped).** Bold 90s TV graphics: tabs, DVE cards, chrome titles, stat rows, colour bars, studio sets with rays, floor grid and wireframe globe. One SVG filter (`VhsFilter`) degrades them: soft luma, chroma smeared 6 px and delayed 7 px right, a red/cyan fringe, lifted warm blacks. The picture also wobbles slightly.
- **Tape.** Streak grain at 30 Hz, dropouts, head-switching noise, and picture slices re-rendered as tracking bands, glitch cuts, FF/REW scrub bars and the pause band.
- **Deck + TV (crisp).** VCR OSD (PLAY ▶ / PAUSE ‖ / FF ▶▶ / REW ◀◀ / STOP ■, `SP` counter, two-line date stamp), Line-21 captions, scanlines, vignette and rounded tube corners.

Palette `K`: VHS blue `#1530C8`, navy `#0A1240`, ink `#05071A`, tungsten `#F2C38B`, TV red `#D8322B`, OSD white `#F4F4F4`, graphic yellow `#F6D64A`; prop colours are in `TONE`.

**The deck acts out the story.** Use REW for a replay or flashback, PAUSE on the big question, FF across years while the date stamp rolls, and STOP on an ending. After a CRT power squash the clock blinks `12:00`.

**Type.** `'Kas Head'` (Bebas Neue, capitals only) for all TV graphics; `'Kas OSD'` (Share Tech Mono) for the OSD, date stamp, captions and labels. Both are registered by `<StyleFonts />` and exported as `HEAD` and `OSD`. Neither font has ▶ ‖ ■ glyphs, so `Icon` draws them as SVG. Bebas has no true minus sign: write `-3`.

**World and camera.** The episode is a timeline `sceneAt(t)` of full-bleed broadcast scenes, composed as `<VhsFilter/> <PictureStack t scene={sceneAt} bands={bandsAt(t)} jitter/> <TapeLayer t/> <Osd …/> <CC t pages/> <Crt/>`. The OSD and CC sit outside `PictureStack`, so they never smear.
- **Transitions** live inside `sceneAt`: `VRoll`, `Push`, `Flip` (pass `under` = the incoming scene) and `Dive`. A cut gets `glitchBands` at a frame-aligned time (`Math.ceil(x * 60) / 60`).
- **Deck states are time remaps:**
  - PAUSE = `scene(T)` + jitter held 4 frames + `pauseBand`.
  - REW = `scene(s - (t - s) * 3)` + `scrubBands(-1)`.
  - FF = sped-up time + `scrubBands(1)`.
- **Inside a scene:** a slow push, or a vertical world pan between two panels (fade out the panel you leave).

**Kit (`src/styles/kaset/kit.tsx`, one file).**
- **Tokens and helpers:** `K`/`KASET`, `TONE`, `HEAD`, `OSD`, `cl`, `ext(n, c)` (extrusion), `slam(t, at, from)`, `slide(t, at, dx, dy, dur)`, `burst`, `STREAK`/`SNOW`/`GRAIN`, `VHS_QUALITY`, `lq(full, lite)`, `FRINGE`.
- **Graphics:** `Tab` (`bg fg size`), `Chrome` (`text size grad deep n glint`; with `GOLD`/`SILVER`/`RUBY`), `Big` (`size color deep`), `StatRow` (`label value w size accent`), `StationBug`.
- **Signal chain and deck:** `VhsFilter`, `PictureStack` (`t scene bands jitter bug`), band builders (`trackBand`, `glitchBands`, `hitBands`, `scrubBands`, `pauseBand`), `TapeLayer`, `Crt`, `Squash` (`k`), `Osd` (`mode pop counter line1 line2 line2On stampPop`), `Icon`, `hms`, `OSD_GLOW`, `CC`.
- **Transitions:** `VRoll`, `Push`, `Flip`, `Dive` (`q` = 0..1).
- **Drawings (generic; names only as plain label text):** `VhsTape`/`BetaTape` (`w label accent t amount sil`), `Vcr` (`w body accent label readout led`), `CrtTv` (`w screen={(sw, sh) => …}`), `BarsPattern`, `TestCard`, `Tank`, `Factory`, `LicenseDoc`, `PriceTag`, `Spine`, `FilmStrip`, `Belt`, `Rosette`, `Mark`, `Person` (`kind 0–2`), `Romulus`/`Suspect` (generic king and lineup silhouettes), `Sofa`, `Lamp`, `Globe`, `Floor`.

**Captions.** `<CC t pages top={1462} />`: Line-21 white Share Tech Mono 58 px capitals on black boxes, painted on word by word, frame-exact, left-anchored. Build pages with `pagesFor(words, 4, 22)`.

**Topic label.** In-picture tabs such as `SIARAN KHUSUS` / `BERITA KILAT`, plus the invented station bug `KANAL 9`. Line 1 of the date stamp doubles as a time label (`AKHIR 70-AN`, `TAHUN 1975`). Show only years the script gives (a year computed from the script is fine), never a month or day.

**Sound.** `npm run style-sfx -- kaset` → `click`, `whir`, `rew`, `ff`, `pause`, `static`, `beep`, `glitch`, `thunk`, `tvon`, `chime`, `whoosh`.
- Placement: deck states get `rew`/`ff`/`pause`, cuts get `glitch`, rolls get `static`, reveals get `tvon`, slams get `thunk`, title cards get `chime`. The demo used 48 cues in 67 s.
- Bed: 96 BPM 90s TV synth with a Rhodes-style EP, gated snare, synth bass and faint tape hiss; tense = dark pad + news-clock ticks.

**Reference episode.** `references/examples/KASET_VHS-vs-Betamax.tsx` (67 s): a boxing-broadcast TV special with an instant replay, three rounds with a score bug, FF to 2002, STOP, power squash and lesson. It uses the workspace's `makeCues`/`EpisodeAudio`; in the starter use `at()/endOf()`, Main.tsx audio and `audio-plan.json` `sfxCues`. Do NOT copy its `draftNoAudio` prop.

**Render quality.** `VHS_QUALITY` follows the shared `renderQuality()`: input prop `quality`, else software GL + ≤ 4 threads → lite. The starter passes `quality:'lite'` in chat sandboxes. The KASET prop `{"vhs":"full"|"lite"}` overrides both.

Lite keeps layout and timing but swaps the expensive parts:

| Full | Lite |
|---|---|
| SVG picture filter | hard `FRINGE` text-shadow on kit type + a flat warm overlay |
| bands re-render the scene | overlay strips |
| grain, rolling bar, blurred shadows | none (hard offsets instead; use `lq()` in scenes) |
| extrusion up to 16 layers | ≤ 6 layers |
| picture wobble | none (only the pause/search jitter) |
| rotating rays, floor, globe | static |
| overlays repainted every frame | static overlays on their own compositor layer |

Chrome CPU per frame (software GL `swangle`, 2 workers, 60 frames). A 2-core sandbox needs about CPU ÷ 2 of wall time.

| Scene | Lite v1 | Lite now |
|---|---|---|
| room | 3.13 s | 0.39 s |
| showroom | 2.13 s | 0.38 s |
| shelves | 1.72 s | 0.36 s |
| factory line + FF | 2.49 s | 0.64 s |
| winner | 2.19 s | 0.57 s |

So a 67 s video ≈ 12–20 min of sandbox wall time. Full needs a GPU (the 67 s draft took 9 min here). Remaining cost: FF/REW/PAUSE jitter still moves the whole picture on the frames it plays, and confetti/bobbing props repaint their own regions.

**Pitfalls (learned on the demo).**
- **Whole-frame motion forces a full re-raster every frame.** This was the single biggest cost on CPU-only renderers. A picture wobble, a slowly rotating ray fan or a drifting camera scale over a full-screen set all do it; dropping the wobble alone cut a scene from 1.50 to 0.67 s CPU/frame. In lite (or any CPU-bound look), let only the things that tell the story move and keep backgrounds still.
- **Crisp vs taped.** OSD and captions go outside `PictureStack`. Footage marks (in-picture `REC ●`, corner brackets) go inside, so they freeze on PAUSE.
- **Flicker:**
  - Hold random jitter, dropouts and glitch slices 3–4 frames.
  - A glitch cut whose base scene and slices switch on different frames made a 1-frame pop (scan score 74): frame-align the cut and use `glitchBands`.
  - Date and counter rolls tick at ≤ 20 Hz.
  - The roll, push seam, dive and slam turnarounds are flagged by the scanner but are monotonic motion: check frame strips.
- **Repeated cue phrases.** `at('yang menang')` hit "VHS yang menang" at 25 s, not the lesson at 61 s, and a scene was silently skipped. Use nth and read the word list.
- **Never an empty frame:**
  - Flip with `under`.
  - Put hero objects on stage as a silhouette with "?" and light them on the word.
  - Give late rows, bars and slots a dashed "?" placeholder.
  - Fade a panel you pan away from, or it parks under the OSD.
- **Chrome type.** `text-shadow` paints over `background-clip:text`, so `Chrome` uses a back copy. Use the `glint` prop for a sweep (an overlay div spills past the glyphs).
- **Contrast and colour.** The OSD needs `OSD_GLOW`'s dark outline on light pictures. The chroma smear eats small coloured type: keep in-picture text ≥ 40 px, light-on-dark or dark-on-light, red only in tabs with white text.
- **Never a black frame.** The CRT power-off `Squash` keeps a bright band while the OSD and CC stay on screen.
- **Generic hardware.** No maker logos or real product shapes.
- **Fonts.** `StyleFonts` loaded before frame 0 in every render here (no `delayRender` needed).

## PIKSEL — 16-bit RPG game UI in pixel art (v1.9)

**Look.** Crisp pixel art on a 270×480 logical grid scaled ×4: ONE `<svg width={1080} height={1920} viewBox="0 0 270 480" shapeRendering="crispEdges">` per frame, every position a whole logical pixel. Original palette `P` (PIKSEL-16): ink `#171A30`, plum `#63285F`, red `#BC4258`, orange `#F4865B`, yellow `#FFD47C`, lime `#B2F06C`, green `#3CBB6B`, teal `#27757F`, deep `#2B3A76`, blue `#4062D0`, sky `#46ACF4`, cyan `#80F1F0`, white `#F7F3EA`, greys `g1 #9BB3C5`, `g2 #5A6F8B`, `g3 #363E5C`. Shading is 2×2 dither (`d50`/`d25` pattern fills), never opacity or blur. Signature moves: RPG windows (notched ink outline, white rim, two-tone dithered fill) that open from their middle line, typewriter UI text at 20 cps, HP/XP gauges as segmented cells, damage numbers that arc (`-3`), gold LEVEL UP / OTOMATIS banners with sparkles, a party of tiny players, quest log with checkboxes, inventory = day tiles, pointer cursor bobbing 1 px, spiral battle wipe, pixel dissolve, `GAME OVER?` → `CONTINUE?`.

**Type.** `'Pik Head'` Press Start 2P (UI, titles, numbers; sizes 8/16/24/32/48/64 logical only) + `'Pik Text'` Pixelify Sans 600 (dialog captions). Both are registered by `<StyleFonts />`, but call `useFontsReady()` once in the comp (see pitfalls).

**World and camera.** Scenes are full-frame worlds: `FieldBg` (overworld with parallax hills/trees, a scrolling stone path and a foreground fence; `scroll` = walk speed × t, `dawn` for a sunrise finale), `MenuBg` (dotted menu), `LibraryBg` (lore/history), `RaysBg` (result screen), or your own world in a translated `<g>` (a tower whose camera is `translate(0, cam)`, cam snapped to integers). The camera never zooms or rotates (non-integer scale breaks the grid); it scrolls in whole pixels. Characters stay put and the ground scrolls under them. Top HUD (`Hud`) = chapter tab + progress pips; bottom = dialog box + console bezel. Content lives in y 52–344 logical.

**Kit (`src/styles/piksel/kit.tsx`, re-exports `sprites.ts`).**
- Engine: `P`, `CH` (1-char colour codes), `HEAD`/`TEXT`, `PxDefs` (put once in the svg), `d50(key)`/`d25(key)` dither fills, `Spr` (`m` pixel map, `x y s` integer scale, `flip`, `sub` per-instance colours, `tint`/`tintK` for hit-flash or silhouettes), `Tx` (`x y` = top-left of the cap box, `s c a sh ol` 1-px shadow/outline), `Win` (`x y w h open tone rim shadow`, tones blue/dark/red/plum/teal/paper/gold/page, children appear when open = 1), `Cells` (segmented gauge, `color(i)`), `Bar`, `sn` `clamp01` `step(t, fps)`.
- Timing: `typed(s, t, at, cps=20)` · `hop(t, at, h)` stepped pop (two 4-frame holds) · `opening(t, at, dur)` window-open progress · `tick(t)` 20 Hz counters · `pxShake(t, impacts, amp)` (15 Hz holds) · `alignWalk(x)`/`alignHop(x)` snap stop/start times to sprite cycles · `useFontsReady()`.
- Worlds: `FieldBg` (`t scroll dawn horizon sunY`) · `MenuBg` (`t id`) · `LibraryBg` · `RaysBg` (`cx cy t`) · `SkyBands` (`bands [[y,key]…] to`) · `Dome` (stepped hill).
- Characters: `Hero` (the player: `x y s t walk cheer flip tint`) · `Buddy` (calendar buddy = "the habit"/a mascot: `mood happy|sad|hurt`, `hopping`, `sub={{H, h}}` header colours) · sprites from `sprites.ts`: `MINI`/`MINI_B` (tiny party member, `sub={{h: hair, S: shirt}}`), `DOCTOR`, `PATIENT_WRAP`/`PATIENT_FACE`, `buildKing({crown, scepter, hood, flutter})` + `KING_A/B`, `EMPEROR`, `HOOD`, `THIEF_A/B`, `MONTH_HAPPY/SAD/HURT`.
- Props/icons: `BOOK_CLOSED/FLIP/OPEN`, `WATER`, `FRUIT`, `DUMBBELL`, `CRYSTAL` (save point), `FLAG_A/B`, `CHECK`, `CROSS`, `COIN`, `GEAR_A/B`, `HOURGLASS_A/B`, `MEDAL`, `STAR`, `HEART`, `MIRROR`, `TEMPLE`, `CYPRESS`, `TREE`, `BUSH`, `CLOUD`, `SUN`, `MOON`, `HILL`, `FOOTPRINT`, `CROWN_ICON`, `SCROLL_ICON`, `PIN_ICON`, `LOCK_ICON`, `SWEAT`, `SPARK_A/B`, `POINTER`, `DOWN_ARROW`. Make new ones with `Grid` (rect/ell painter) + `outline(fill)`.
- UI: `Tag` (`x y w text tone c s open`) · `Banner` (2-line size-16 window, `open tone l1 l2 c1 c2`) · `DayTile` (`n dim top`) · `Hud` (`chapter idx n t`) · `Pointer` · `Sparkle` (`at dur`) · `Shatter` (pixels of a small map fall apart).
- Transitions: `Trans kind="dissolve|squares|blinds|iris|slide" t a b id from to` · `SpiralWipe t cover reveal id` (battle wipe; draw it over the old scene, children = new scene).

**Captions.** `DialogFrame t pages name="NARATOR"` inside the svg (box y 358–426, red name tab, blinking ▼ when the page is done, A/B hints on a dark bezel) + `DialogText t pages` as an HTML overlay (Pixelify 60 px, 2 lines, spoken word yellow, digits auto-set in Press Start 2P). Each word types from its exact start frame and is complete by ~80 % of its duration; untyped letters are transparent, so lines never reflow. Pages are whole sentences: `buildPages(words, breaks)` with word-index breaks, ≤ ~48 characters (2 lines of ~26); a page stays until the next starts.

**Topic label.** The `Hud` chapter tab ("MITOS", "STUDI", "HASIL", "BOLOS?") with episode pips; a quest window title "QUEST: …"; a cited study as a report window ("LAPORAN STUDI" + gold "TERBIT 2010" tag).

**Sound.** `npm run style-sfx -- piksel` → `blip`, `select`, `confirm`, `hit`, `levelup`, `coin`, `jump`, `powerup`, `error`, `warp`, `step`, `heal`. Map: transitions → warp, banners/levels → levelup, slams and busted claims → hit, wrong/skipped → error, counters landing → coin, items/tabs → select, typed labels → blip, save/continue → confirm/heal; ~43/min worked on the demo. Bed: 132 BPM chiptune: pulse lead/arps, triangle bass, 1-bit noise drums; `tense` = slow minor arps.

**Reference episode.** `references/examples/PIKSEL_66-Hari.tsx` (62.6 s, 9 scenes) uses the demo workspace's `makeCues`/`EpisodeAudio`; in the starter use `at()/endOf()` from `src/lib/words.ts` and Main.tsx audio + `audio-plan.json` `sfxCues`. Do not copy its `draftNoAudio` input prop (the starter has `--silent-draft`).

**Pitfalls (learned on the demo).**
- **Fonts load late.** `StyleFonts` is a CSS `@font-face`; Remotion does not wait for it, so early frames can render in fallback monospace. `useFontsReady()` holds the frame (`delayRender`) until both families load.
- **Moving repeating texture strobes.** Sliding a scene with a regular pattern (book shelves, fence posts, bricks, a tile grid, rows of text) aliases into single-frame "blinks" on flicker-scan and on phones. Use `dissolve/squares/blinds/iris/SpiralWipe`, or `slide` only for a page without repeats; make panned textures irregular (seeded brick heights).
- **Fast falling pixels blink.** Anything with gravity eventually jumps a whole screen cell per frame: remove it after ~100 px (episode `gone()`), clip it to its window.
- **One-frame sprite poses.** A walk/hop cycle stopped mid-step shows one frame of the other pose. Snap every stop/start with `alignWalk`/`alignHop`; same for switching between walk and cheer.
- **First frames far away.** An object whose first visible frame is far from its path (a book "dropping" from high up, tiles flying off a gauge) reads as a flash: pop it in place first (hold 4 frames), then ease out (`pio`), ease-in for drops.
- **Rates.** Counters tick ≤ 20 Hz (`tick`), blinks ≤ 4 Hz (`step(t, 4)`), hit-flash = two 4-frame white tints, shakes only via `pxShake`. A digit roll every frame was 50 Hz → flagged.
- **Never empty.** Panels that fill later must already show placeholders: grey silhouettes (`tint={P.g3}`), dim `DayTile`s, "???", "?" in slots, a blinking caret. A blue window alone for 4 s read as broken.
- **Big PS2P numbers.** `Tx` y is the cap top and glyphs are 7/8 of the size; a slam offset pushes size-48/64 digits up into the label above — put labels beside big numbers, not above.
- **Pixelify digits.** 2 and 5 read as 8 and S at caption size; `DialogText` already sets digits in Press Start 2P — do the same for any Pixelify number you add.
- **Layering = document order.** Draw labels after the sprites they label (a tiny player covered "LEBAR BANGET!"); when one character overtakes another, put it on a nearer lane (y + 8) so it does not cover the face; HUD and dialog last.
- **Ids.** A scene rendered twice in a transition duplicates `<pattern>`/`<clipPath>` ids — give `MenuBg` its own `id` per scene and every `Trans`/`SpiralWipe` a unique `id`.
- **Grid discipline.** No rotation, opacity fades or non-integer scale (they blur the grid): use dither, window open/close and integer `s`. Safe area in logical px: text x 16–254, and x ≤ 240 when y > 225 (app buttons).
- **Facts.** Use numbered counters/tiles only for numbers the script says; illustrative streaks and party members stay unnumbered.
- **Performance.** Pure SVG rects, no filters: 3758 frames rendered in ~51 s at concurrency 4 on a laptop; `Shatter` draws one rect per pixel — use it on small maps only.

## TITIK — unit / particle data visualisation (v1.9)

**Look.** Calm, coded, premium: thousands of dots on an ink background where **1 dot = 1 unit** (say it in the HUD legend). Formations morph into each other with staggered, eased, slightly arced paths (never a stiff tween): sunflower → calendar → waffle → ring → glyph. Dots that leave a scene **sink into** the breathing background lattice and later **rise from it**. Palette `TK`: ink `#0B0D12` (soft `#151925` centre lift + faint 160 px rule grid), dots `#EDEBE6`, coral `#FF5A4E`, cyan `#4FD1E8`, lime `#B8F34A`, mute `#7D828C`. Give every accent ONE meaning and keep it (episode: white = day, cyan = person, coral = shared birthday / loss, lime = "all different"). Signature moves: arcing morphs with half-frame motion streaks, glyphs and words made of exactly N dots (`dotText`), halftone portraits from a drawn profile, thin leader-line callouts, counters that tick (≤ 20 Hz), pair lines between units, single expanding ping rings, a subtle canvas bloom (approved; keep it subtle, no other glows except the faint accent halo `drawDot` adds).

**Type.** `'Tik Head'` = Manrope (200–800): weight 300 for big display figures and titles (`Stat`), 800 for punch numbers and as the glyph source for `dotText`. `'Tik Mono'` = Martian Mono (100–800, `fontStretch` 75–112.5 %): labels, counters, callouts and captions, uppercase, `fontStretch: '87.5%'`, letter-spacing 3 (`lab` style).

**World and camera.** One full-frame `<DotCanvas>` draws the lattice and every dot each frame; DOM sits on top in three layers: `<DriftLayer>` for labels that point at dots (moves with the canvas drift), then screen-fixed `Stat` headers / `Hud` / `ShareBar` / `MonoCaption`. Camera = the kit's `drift(t)` (≈1 % zoom breathing), already applied by `DotCanvas` and `DriftLayer`; no cuts — a scene change is a morph. Layout zones: header 196–440, visual 470–1460, share bar 1388–1470, HUD rule 1500, caption 1584.

**Engine (reuse it for any statistic).**
- A dot is `{x, y, r, a, c}`; a `Formation` is `(i, t) => Dot` (may depend on t: breathing, a counter-driven fill, a queue that advances). `morph(i, t, start, steps)` folds `Step`s in array order: each `{at, dur, to, delay?(i), arc?, swirl?, ease?, only?(i)}` eases the dot from wherever the previous steps left it toward `to(i, t)`; `arc` bends the path sideways (fraction of its length; `swirl` = all bend the same way = a vortex), `only` limits a step to some dots, `delay` staggers (by index, by target x for a left→right pour, by angle for a sweep). Once a step completes its formation is used exactly, so the next step starts from a clean pose.
- One-by-one arrivals = ONE step with `at: 0, delay: i => land[i] - dur` (each dot drops at its own time). Steps that move a dot into a waiting pose (queue, hover) must come BEFORE that landing step in the array.
- Leaving dots: a formation at `snap(x), snap(y)` (lattice point), `r 1.6, a 0` → they vanish into the grid; a later step makes them rise from there. Never leave a scene empty in between: pour the old dots into the next element (episode: the 365 days pour down into the probability axis).
- Draw: `drawDot(ctx, morph(i, t, …), morph(i, t - 1/120, …), t)` (circle when still with a slow idle wave, a capsule streak when moving). 365 + 70 dots with ~15 steps and 253 lines cost nothing; the 65 s episode rendered in ~4.3 min at concurrency 4.
- `dotText(text, font, box, n, splitDot?)` → exactly `n` lattice points inside the glyphs (pitch searched, extras dropped evenly; `splitDot` returns the dot of "?"/"!" as `hole`). Map old → new dots by sorting both by x (left→right pour) or by angle around a centre (swirl without crossings).
- Portraits: `buildKing(outlineN)` draws a generic laurelled king profile with Path2D on a 600×700 offscreen canvas (gradient light, hair curls, ear, eye, jaw shadow, laurel on a separate mask), blurs it and samples a hex grid → `cells` (x, y, value, mask) + an outline resampled to N points (`crPoints` + `resample`). For another subject copy that pattern with a new silhouette; draw cells with radius ∝ √value and reveal them with a scan line.
- Glyph/portrait layouts need the fonts: build them with `useAsyncLayout(key, build)` (holds `delayRender` until `document.fonts.load` of the Tik fonts, cached per key) and pass `draw = null` to `DotCanvas` until it returns.

**Kit (`src/styles/titik/kit.tsx`).**
- Tokens: `TK`, `HEAD`, `MONO`, `rgb`/`mixRGB`/`css`, easings `SMOOTH` (in-out) `SNAP` (fast out) `YANK` (anticipation), `clamp01`, `fade(t, in0, in1, out0?, out1?)`, `lab` (mono label style), `BLOOM`.
- Engine: `Dot`, `Formation`, `Step`, `morph`, `dotText`/`DotText`, `buildKing`/`King`/`KING_HEAD`/`LAUREL`, `crPoints`, `resample`, `useAsyncLayout`.
- Layouts: `sunflower(k, x, y, pitch, spin)`, `gridPos(k, cols, x0, y0, s, sy?)` (waffle/unit bars), `onRing(k, n, cx, cy, R)`, `pairsOf(n)` (C(n,2) pairs, lexicographic), `YEAR` (`days`, `names` JAN…DES, `month[d]`, `day[d]` for d 0–364), `calendarPos(d, {s, x0, y0, gx, gy})` + `calendarBlock(m, L)` (3×4 wall calendar of 7-wide blocks), `LAT` + `snap()` (lattice).
- Canvas: `DotCanvas` (`t draw camera bloom`), `drawLattice(ctx, t)`, `drawDot(ctx, d, prev, t, glow)`, `ringStroke(ctx, x, y, r, color, dash, lw)`, `ping(ctx, t, t0, x, y, rgb, r0, grow, dur)`, `drift(t)`/`driftCss(t)`/`DriftLayer`.
- DOM: `Backdrop`, `Hud` (`topic legend live chapter chapters duration`; brand, ruler, progress rule, live dot count), `Legend` (dot swatch + "= 1 X"), `Stat` (`num label color size inAt outAt`; light figure + stacked mono label, enters from below, leaves up), `Callout` (`q from elbow to text color align left|right|below`), `ShareBar` (`v left right leftValue rightValue mid`), `MonoCaption`.
- Numbers: `tick(t, hz=20)` (held time for counters), `pctID(v, d)` → "50,73%".

**Exact numbers rule.** Every probability, share or count on screen is COMPUTED in code from its formula (e.g. P(all n birthdays differ) = Π_{k<n} (365−k)/365, pairs = n(n−1)/2) and must equal what the script says or a value you verified (state "tepatnya 97,04%" small next to a spoken "sekitar 97%"). Format with `pctID` at a fixed precision and never round across the claim (50,73 % is "lebih dari 50 %"; don't write 51 %). Live readouts show the exact value for the current discrete state (n landed people), while bars may ease between states (multiply eased factors so the bar is exact at rest). Illustrative dots that carry no number (a pile of "guesses") get no axis values; a count derived from what is drawn (22 lines from one dot) is fine.

**Captions.** `pagesFor(words, 4, 24)` → `<MonoCaption t pages accent />` (Martian Mono 46 px, one line, spoken word in accent + underline, unspoken at 30 %). Pass `accent(word)` to colour numbers by meaning (cyan for people counts, coral for shared/loss, lime for "escape/different").

**Topic label.** `Hud topic`: "PELUANG", "STATISTIK · FAKTA", or the unit ("KALENDER", "PEMILU"); legend `<Legend text="= 1 HARI" />` (+ a second chip when a second unit appears).

**Sound.** `npm run style-sfx -- titik` → `tick`, `pop`, `swish`, `ping`, `chime`, `swell`, `click`, `whoosh`, `drop`, `sparkle`, `hum`, `ding` (`swish`/`whoosh` on morphs, `drop` on landings, `ping` on collisions/highlights, `chime`/`ding` on landed numbers, `swell` under line bursts, `tick` on fast arrivals; ~40 cues/min). Bed: 84 BPM generative ambient — sine-pluck ostinato, warm pad, sub, data ticks; drone + sparse pings when `tense`.

**Reference.** `references/examples/TITIK_Paradoks-Ulang-Tahun.tsx` (65 s) uses the demo workspace's `makeCues().at` and `<EpisodeAudio>`; in the starter use `at()/endOf()` from `src/lib/words.ts`, Main.tsx audio and `audio-plan.json` `sfxCues`. Do NOT copy its `draftNoAudio` input prop (the starter has `--silent-draft`).

**Pitfalls (learned on the demo).**
- Draw the canvas only through `DotCanvas` (useLayoutEffect on `t`); a plain useEffect can miss the screenshot. Never `Math.random` or per-frame jitter: seeded `rnd(i * k)` only, so frames are reproducible and nothing strobes.
- `dotText`/portraits sampled before the font loads come out in a fallback face: always via `useAsyncLayout` and render `<StyleFonts />` in the same tree.
- Remotion's `interpolate` (so `p()`, `fade()`) throws on `Infinity`/`NaN`: guard "never happens" times (`Number.isFinite`) before easing toward them.
- Counters and live percentages must use `tick(t)`; a cascade of arrivals may land ≤ 20 per second. Pings only grow and fade (no one-frame flashes). flicker-scan found 0 blinks in 3912 frames with these rules.
- Empty frames hide in transitions: a formation that dissolves before the next one arrives leaves a near-empty frame (we had one at a scene change). Overlap them or pour old dots into the new element; also hand `Stat` headers off in ≤ 0.2 s (`inAt` of the next = `outAt` of the previous + 0.2).
- Dots spawning above the frame streak through the header and HUD: start them just above their target with `a: 0, r: 4` so they materialise.
- Labels inside dense formations collide with dots (month labels, ring numbers): put annotations in the gaps between blocks, outside rings (below, never in the right 120 px under y 900), or move the meaning into the `Stat` label / `Legend` (we replaced an overlapping "SAMA" callout with a coral legend chip).
- An arc between two units must not pass over a third: pick units on the outside (a column edge) and bulge outward.
- A complete graph on an odd number of units on a ring leaves an empty hole in the centre; that is geometry, not a bug. Draw 253 lines at α ≈ 0.3, 1.3 px, and dim them to 0.1 when one pair is highlighted.
- Keep exactly one accent meaning per colour across the video; numbers drawn in a colour must match their caption accent.

**Render cost / quality.** TITIK reads `renderQuality()` once through `titikQuality()` in the kit. FULL is the approved look, and its output is byte-identical to before this pass. LITE is used in the chat sandbox and on software GL. LITE drops three things:
- the CSS `drop-shadow` bloom on the canvas;
- the camera `drift` on both the canvas and the `DriftLayer`;
- the per-frame breathing lattice. `drawLattice` becomes a no-op and `Backdrop` paints the lattice once as a static CSS dot pattern (`will-change: transform`).

To stand in for the bloom, `drawDot` adds one faint halo disc per dot (r × 1.9 at about 7 % alpha, 10 % on accent dots). Everything else is unchanged: dots, motion streaks, lines, pings, text and timing.

Measured CPU per frame of the Chrome process tree, with swangle and 2 workers (`out/w4full/titik/perf/one.mjs`), on the final build:

| Range | FULL | LITE |
|---|---|---|
| Class | — | 275 ms |
| Calendar, frames 2400–2459 | 1118 ms | 303 ms |
| Ring + 253 lines | 1123 ms | 293 ms |
| Rain of 50 people | 1173 ms | 349 ms |
| End card | 1145 ms | 331 ms |
| `DemoTitik` | — | 262 ms |

That is about 3.5× less CPU; a 65 s video is roughly 3900 frames × 0.3 s ≈ 20 min of CPU in a 2-core sandbox. The cost is almost the same in every scene: it is a fixed per-frame cost, not a per-dot cost. The halo stand-in adds about 25–55 ms on top of the bare LITE path.

What each part cost in FULL (calendar range, removed one at a time):
- the bloom filter: about 730 ms;
- the drift: about 40 ms;
- redrawing the 1296-dot lattice every frame: about 70 ms.

Halving the canvas resolution saved only about 27 ms, so LITE keeps full resolution and crisp dots.

**Pitfalls (render cost).**
- A CSS `filter` (drop-shadow or blur) on a full-frame canvas is re-filtered on every frame. On software GL it cost more than everything else together. Never put a filter on the canvas in LITE. Fake glow inside the canvas instead: one extra low-alpha disc per dot is nearly free.
- Anything that moves the whole frame every frame (camera drift, a breathing background) makes Chrome re-rasterise the full 1080×1920. In LITE keep backgrounds static, as their own layer.
- Dot count is cheap. 435 dots with streaks, about 15 morph steps each and 253 lines fit in the LITE budget, so don't reduce the content to save time.
- Measure Chrome CPU per frame, not wall time. Wall time on a 12-core Mac hides most of the cost of software GL.
