// REFERENCE DEMO (ADSY MOTION GRAPH v2.0, MEDIS looks). Lived in src/medis/ of the demo project. Read for structure only; never copy its story or text.
import React from 'react';
import {AbsoluteFill} from 'remotion';
import {at} from '../lib/words';
import {p, pb, lerp, rnd, drawOn} from '../styles/shared';
import {SceneProps, StyleTag, Caps, enter} from '../styles/medis/kit';

// ============ 05 PAPER CUT ============
const PC = {bg: '#FBD7B9', l1: '#F6A879', l2: '#E9775A', l3: '#9B4E6C', sky: '#FFF1E2', ink: '#3E2140', green: '#5BAE8C', cream: '#FFF8EE'};
const paperShadow = 'drop-shadow(0 10px 0 #3e214033) drop-shadow(0 18px 18px #3e214033)';
const Person: React.FC<{x: number; inflate: number; color: string; seed: number; t: number}> = ({x, inflate, color, seed, t}) => {
  const bob = Math.sin(t * 3 + seed) * 4;
  const w = lerp(60, 118, inflate);
  return (
    <g transform={`translate(${x} ${bob})`}>
      <circle cx="0" cy="-250" r="38" fill={color} />
      <path d={`M${-w} -60 C${-w} -170 ${-w * 0.6} -205 0 -205 C${w * 0.6} -205 ${w} -170 ${w} -60 Z`} fill={color} />
      <rect x={-w * 0.55} y="-62" width={w * 0.4} height="70" rx="12" fill={color} />
      <rect x={w * 0.15} y="-62" width={w * 0.4} height="70" rx="12" fill={color} />
      {/* plate at feet */}
      <ellipse cx="0" cy="22" rx="46" ry="12" fill={PC.cream} />
      <circle cx="-8" cy="16" r="9" fill="#F6C12E" />
    </g>
  );
};
export const PaperCut: React.FC<SceneProps> = ({t, a, b}) => {
  const tO = at('otomatis'), tSe = at('semua'), tKe = at('kelebihan');
  const inflate = pb(t, tO + 0.2, tO + 0.8);
  const crowd = p(t, tSe - 0.2, tSe + 0.5);
  const scale = p(t, tKe, tKe + 0.4);
  const verdict = pb(t, b - 0.6, b - 0.3);
  const colors = [PC.l3, PC.l2, PC.ink, PC.l3, PC.l2, PC.ink];
  return (
    <AbsoluteFill style={{background: PC.sky, ...enter(t, a)}}>
      {/* layered paper hills */}
      <svg width={1080} height={1920} style={{position: 'absolute'}}>
        <circle cx="880" cy="700" r="90" fill="#FFD36E" style={{filter: paperShadow}} />
        <path d="M0 980 C200 860 380 940 540 880 C720 810 900 900 1080 850 V1920 H0Z" fill={PC.l1} style={{filter: paperShadow}} />
        <path d="M0 1120 C240 1040 460 1120 640 1060 C820 1000 960 1080 1080 1050 V1920 H0Z" fill={PC.l2} style={{filter: paperShadow}} />
        <path d="M0 1300 C300 1250 700 1320 1080 1260 V1920 H0Z" fill={PC.bg} style={{filter: paperShadow}} />
      </svg>
      <div style={{position: 'absolute', top: 210, left: 0, right: 0, textAlign: 'center'}}>
        <span style={{fontFamily: 'Pap Head', fontWeight: 800, fontSize: 40, letterSpacing: 6, color: PC.cream, background: PC.ink, padding: '8px 26px', borderRadius: 40}}>SIMULASI</span>
      </div>
      <div style={{position: 'absolute', top: 300, left: 80, right: 80, textAlign: 'center', fontFamily: 'Pap Head', fontWeight: 800, fontSize: 92, lineHeight: 1.02, color: PC.ink}}>
        Kalau sarapan<br />= otomatis gemuk…
      </div>
      <svg width={1080} height={600} style={{position: 'absolute', top: 820, filter: paperShadow}}>
        <g transform="translate(0 420)">
          {[140, 300, 460, 620, 780, 940].map((x, i) => (
            <g key={i} opacity={i === 2 || i === 3 ? 1 : crowd} transform={`translate(0 ${i === 2 || i === 3 ? 0 : (1 - crowd) * 60})`}>
              <Person x={x} inflate={Math.max(0, Math.min(1.1, inflate - (i === 2 || i === 3 ? 0 : (1 - crowd))))} color={colors[i]} seed={i * 1.7} t={t} />
            </g>
          ))}
        </g>
      </svg>
      {/* counter */}
      <div style={{position: 'absolute', top: 1290, left: 0, right: 0, textAlign: 'center', opacity: scale}}>
        <span style={{fontFamily: 'Pap Head', fontWeight: 800, fontSize: 56, color: PC.cream, background: PC.l3, padding: '10px 30px', borderRadius: 16, boxShadow: '0 8px 0 #3e214055'}}>
          {Math.round(lerp(0, 100, scale))}% orang kelebihan berat badan?
        </span>
      </div>
      {/* verdict */}
      <div style={{position: 'absolute', top: 640, left: 0, right: 0, display: 'flex', justifyContent: 'center', opacity: verdict}}>
        <div style={{fontFamily: 'Pap Head', fontWeight: 800, fontSize: 110, color: PC.cream, background: PC.green, padding: '6px 50px', borderRadius: 24, transform: `rotate(-5deg) scale(${lerp(0.4, 1, verdict)})`, boxShadow: '0 12px 0 #3e214055'}}>
          Nyatanya enggak!
        </div>
      </div>
      <StyleTag t={t} a={a} n={5} name="PAPER CUT" font="Pap Head" fg={PC.ink} bg={PC.sky} />
      <Caps t={t} y={1470} s={{font: 'Pap Head', weight: 800, size: 62, color: PC.ink, hl: PC.l3, bg: PC.cream, radius: 30, shadow: '0 10px 0 #3e214033'}} />
    </AbsoluteFill>
  );
};

// ============ 06 KOTA TUBUH ============
const KT = {bg: '#1E2240', block: '#2C3260', road: '#C8384B', roadEdge: '#8E2238', in: '#FFB547', out: '#4CD6B4', fat: '#F7E38A', text: '#F1EEFF', dim: '#8A8FC0'};
const Truck: React.FC<{x: number; y: number; c: number; color: string; label: string}> = ({x, y, color, label}) => (
  <g transform={`translate(${x} ${y})`}>
    <rect x="-46" y="-24" width="64" height="48" rx="8" fill={color} />
    <rect x="20" y="-18" width="30" height="42" rx="6" fill={color} opacity={0.75} />
    <text x="-14" y="10" textAnchor="middle" fontFamily="Kot Mono" fontWeight="700" fontSize="22" fill={KT.bg}>{label}</text>
  </g>
);
export const KotaTubuh: React.FC<SceneProps> = ({t, a}) => {
  const tTo = at('total'), tPe = at('pengeluaran'), tBu = at('bukan'), tWa = at('waktu');
  const inQ = p(t, tTo - 0.2, tTo + 0.5), outQ = p(t, tPe - 0.2, tPe + 0.5);
  const clocks = p(t, tWa - 0.3, tWa + 0.3);
  const fill = lerp(0.35, 0.55, p(t, tTo, tPe)) - lerp(0, 0.12, p(t, tPe, tBu));
  const kIn = Math.round(lerp(0, 2300, p(t, tTo, tTo + 1.4)));
  const kOut = Math.round(lerp(0, 2000, p(t, tPe, tPe + 1.4)));
  return (
    <AbsoluteFill style={{background: KT.bg, ...enter(t, a)}}>
      <svg width={1080} height={1920} style={{position: 'absolute'}}>
        {/* city blocks */}
        {Array.from({length: 40}, (_, i) => {
          const gx = i % 5, gy = Math.floor(i / 5);
          return <rect key={i} x={70 + gx * 192} y={330 + gy * 140} width={150} height={100} rx={14} fill={KT.block} opacity={0.5 + rnd(i) * 0.3} />;
        })}
        {/* vessel roads */}
        <path d="M-20 760 C200 760 300 860 460 860" fill="none" stroke={KT.roadEdge} strokeWidth="64" />
        <path d="M-20 760 C200 760 300 860 460 860" fill="none" stroke={KT.road} strokeWidth="48" />
        <path d="M620 860 C780 860 860 620 1100 620" fill="none" stroke={KT.roadEdge} strokeWidth="64" />
        <path d="M620 860 C780 860 860 620 1100 620" fill="none" stroke={KT.road} strokeWidth="48" />
        <path d="M620 900 C800 900 880 1140 1100 1140" fill="none" stroke={KT.roadEdge} strokeWidth="64" />
        <path d="M620 900 C800 900 880 1140 1100 1140" fill="none" stroke={KT.road} strokeWidth="48" />
        {/* warehouse = fat storage */}
        <g transform="translate(540 880)">
          <rect x="-120" y="-150" width="240" height="300" rx="20" fill="#3C437C" stroke={KT.fat} strokeWidth="6" />
          <rect x="-100" y={130 - 260 * fill} width="200" height={260 * fill} rx="12" fill={KT.fat} opacity={0.85} />
          <text x="0" y="-175" textAnchor="middle" fontFamily="Kot Head" fontWeight="700" fontSize="34" fill={KT.fat}>GUDANG LEMAK</text>
        </g>
        {/* buildings out */}
        {[['OTOT', 1000, 560], ['OTAK', 1000, 1080]].map(([n, x, y]) => (
          <g key={n as string} transform={`translate(${x} ${y})`}>
            <rect x="-70" y="-70" width="140" height="120" rx="14" fill={KT.out} opacity={0.25 + 0.75 * outQ} />
            <text x="0" y="0" textAnchor="middle" fontFamily="Kot Mono" fontWeight="700" fontSize="28" fill={KT.bg}>{n}</text>
          </g>
        ))}
        {/* trucks in */}
        {[0, 1, 2].map((k) => {
          const q = ((t - tTo) * 0.45 + k / 3) % 1;
          const x = lerp(-40, 440, q), y = lerp(760, 860, Math.max(0, (q - 0.3) / 0.7));
          return inQ > 0 && t > tTo - 0.2 ? <g key={k} opacity={inQ}><Truck x={x} y={y} c={0} color={KT.in} label="kkal" /></g> : null;
        })}
        {[0, 1, 2].map((k) => {
          const q = ((t - tPe) * 0.45 + k / 3) % 1;
          const up = k % 2 === 0;
          const x = lerp(640, 1060, q), y = up ? lerp(860, 620, q) : lerp(900, 1140, q);
          return outQ > 0 && t > tPe - 0.2 ? <g key={'o' + k} opacity={outQ}><Truck x={x} y={y} c={0} color={KT.out} label="E" /></g> : null;
        })}
      </svg>
      {/* ledger */}
      <div style={{position: 'absolute', top: 210, left: 70, right: 70, display: 'flex', justifyContent: 'space-between', fontFamily: 'Kot Mono', fontWeight: 700}}>
        <div style={{color: KT.in, fontSize: 30, opacity: inQ}}>MASUK<div style={{fontFamily: 'Kot Head', fontSize: 64}}>{kIn.toLocaleString('id-ID')}</div></div>
        <div style={{color: KT.out, fontSize: 30, textAlign: 'right', opacity: outQ}}>KELUAR<div style={{fontFamily: 'Kot Head', fontSize: 64}}>{kOut.toLocaleString('id-ID')}</div></div>
      </div>
      <div style={{position: 'absolute', top: 1230, left: 70, right: 70, fontFamily: 'Kot Mono', fontSize: 24, color: KT.dim, textAlign: 'center'}}>angka contoh · kkal per hari</div>
      {/* clocks: timing is not the decider */}
      <div style={{position: 'absolute', top: 1280, left: 0, right: 0, display: 'flex', justifyContent: 'center', gap: 26, opacity: clocks, transform: `translateY(${(1 - clocks) * 30}px)`}}>
        {['07:00', '12:00', '19:00'].map((c) => (
          <div key={c} style={{fontFamily: 'Kot Mono', fontWeight: 700, fontSize: 34, color: KT.text, border: `3px solid ${KT.dim}`, borderRadius: 40, padding: '8px 22px'}}>{c}</div>
        ))}
        <div style={{fontFamily: 'Kot Head', fontWeight: 800, fontSize: 34, color: KT.bg, background: KT.fat, borderRadius: 40, padding: '8px 22px'}}>= sama</div>
      </div>
      <StyleTag t={t} a={a} n={6} name="KOTA TUBUH" font="Kot Mono" fg={KT.text} bg={KT.bg} />
      <Caps t={t} y={1460} s={{font: 'Kot Head', weight: 700, size: 58, color: KT.text, hl: KT.fat, bg: '#12142ae6', radius: 22}} />
    </AbsoluteFill>
  );
};

// ============ 07 HERBARIUM ============
const HB = {paper: '#EFE3C6', paper2: '#E4D4AE', ink: '#3B3222', green: '#6E8B4E', yellow: '#E7C24A', purple: '#8C5A86', brown: '#9C6B3F', tape: '#F5EBD0cc'};
export const Herbarium: React.FC<SceneProps> = ({t, a}) => {
  const tBe = at('bergizi'), tPo = at('porsinya'), tPi = at('pilih', 0);
  const s1 = p(t, tPi - 0.4, tPi + 0.8), s2 = p(t, tPi + 0.2, tPi + 1.3), s3 = p(t, tBe - 0.2, tBe + 0.8);
  const wash = (q: number) => p(q, 0.55, 1);
  const portion = p(t, tPo, tPo + 0.6);
  const plate = (x: number, y: number, q: number, children: React.ReactNode, name: string, latin: string, rot: number) => (
    <g transform={`translate(${x} ${y}) rotate(${rot})`}>
      <rect x="-150" y="-190" width="300" height="380" fill="#F7EED7" stroke={HB.paper2} strokeWidth="4" />
      <rect x="-60" y="-205" width="120" height="34" fill={HB.tape} transform="rotate(-4)" />
      {children}
      <text x="0" y="140" textAnchor="middle" fontFamily="Her Head" fontStyle="italic" fontWeight="700" fontSize="36" fill={HB.ink} opacity={p(q, 0.4, 0.8)}>{name}</text>
      <text x="0" y="172" textAnchor="middle" fontFamily="Her Text" fontStyle="italic" fontSize="28" fill={HB.ink} opacity={p(q, 0.5, 0.9) * 0.8}>{latin}</text>
    </g>
  );
  return (
    <AbsoluteFill style={{background: HB.paper, ...enter(t, a)}}>
      <svg width={1080} height={1920} style={{position: 'absolute'}}>
        {Array.from({length: 60}, (_, i) => <circle key={i} cx={rnd(i) * 1080} cy={rnd(i + 99) * 1920} r={2 + rnd(i + 7) * 6} fill={HB.brown} opacity={0.08} />)}
      </svg>
      <div style={{position: 'absolute', top: 190, left: 80, right: 80, textAlign: 'center', fontFamily: 'Her Text', fontSize: 34, letterSpacing: 6, color: HB.ink}}>LEMBAR VII · SARAPAN BERGIZI</div>
      <div style={{position: 'absolute', top: 240, left: 80, right: 80, textAlign: 'center', fontFamily: 'Her Head', fontWeight: 700, fontSize: 96, color: HB.ink, lineHeight: 1}}>Pilih yang <i>bergizi</i></div>
      <svg width={1080} height={1050} style={{position: 'absolute', top: 380}}>
        {/* banana */}
        {plate(250, 260, s1, <>
          <path d="M-90 40 C-60 -90 40 -120 90 -110 C40 -60 -10 20 -90 40Z" fill={HB.yellow} opacity={wash(s1) * 0.85} />
          <path d="M-90 40 C-60 -90 40 -120 90 -110 C40 -60 -10 20 -90 40Z" fill="none" stroke={HB.ink} strokeWidth="4" {...drawOn(s1)} />
          <path d="M90 -110 l14 -16" stroke={HB.ink} strokeWidth="5" {...drawOn(s1)} />
        </>, 'Pisang', 'Musa paradisiaca', -3)}
        {/* sweet potato */}
        {plate(780, 300, s2, <>
          <path d="M-100 0 C-90 -70 40 -90 100 -30 C120 20 40 60 -40 50 C-80 45 -105 30 -100 0Z" fill={HB.purple} opacity={wash(s2) * 0.8} />
          <path d="M-100 0 C-90 -70 40 -90 100 -30 C120 20 40 60 -40 50 C-80 45 -105 30 -100 0Z" fill="none" stroke={HB.ink} strokeWidth="4" {...drawOn(s2)} />
          <path d="M100 -30 C130 -60 120 -100 140 -120" fill="none" stroke={HB.green} strokeWidth="4" {...drawOn(s2)} />
        </>, 'Ubi Jalar', 'Ipomoea batatas', 3)}
        {/* mung bean */}
        {plate(520, 760, s3, <>
          <path d="M0 80 C-10 0 0 -60 10 -120" fill="none" stroke={HB.green} strokeWidth="5" {...drawOn(s3)} />
          {[[-40, -40], [45, -70], [-35, -100], [40, -10]].map(([x, y], i) => (
            <g key={i}>
              <ellipse cx={x} cy={y} rx="38" ry="18" fill={HB.green} opacity={wash(s3) * 0.75} transform={`rotate(${x > 0 ? -25 : 25} ${x} ${y})`} />
              <ellipse cx={x} cy={y} rx="38" ry="18" fill="none" stroke={HB.ink} strokeWidth="3" transform={`rotate(${x > 0 ? -25 : 25} ${x} ${y})`} {...drawOn(s3)} />
            </g>
          ))}
          {[[-20, 60], [0, 70], [20, 58]].map(([x, y], i) => <ellipse key={i} cx={x} cy={y} rx="12" ry="9" fill="#7FA05A" stroke={HB.ink} strokeWidth="2" opacity={p(s3, 0.5, 0.9)} />)}
        </>, 'Kacang Hijau', 'Vigna radiata', -2)}
      </svg>
      {/* portion note */}
      <div style={{position: 'absolute', top: 1365, left: 90, right: 90, display: 'flex', justifyContent: 'center', opacity: portion, transform: `rotate(-2deg) translateY(${(1 - portion) * 30}px)`}}>
        <div style={{fontFamily: 'Her Head', fontStyle: 'italic', fontSize: 50, color: HB.ink, borderBottom: `3px solid ${HB.brown}`, padding: '0 10px'}}>porsi: secukupnya, sesuai kebutuhan</div>
      </div>
      <StyleTag t={t} a={a} n={7} name="HERBARIUM" font="Her Text" fg={HB.ink} bg={HB.paper} />
      <Caps t={t} y={1465} s={{font: 'Her Head', weight: 700, size: 60, color: HB.paper, hl: HB.yellow, bg: '#3B3222e8', radius: 4}} />
    </AbsoluteFill>
  );
};

// ============ 08 RONTGEN ============
const RO = {bg: '#05080F', bone: '#DDE8F2', glow: '#7FB7E6', dim: '#2B4A6E', alert: '#FF8A3D'};
export const Rontgen: React.FC<SceneProps> = ({t, a}) => {
  const tMe = at('melewatkan'), tGi = at('gimana');
  const scan = (t - a) / 1.6;
  const empty = p(t, tMe, tMe + 0.5);
  const q = pb(t, tGi - 0.1, tGi + 0.3);
  const batt = Math.round(lerp(60, 23, p(t, tMe, tGi)));
  const bone = {fill: 'none', stroke: RO.bone, strokeLinecap: 'round' as const};
  return (
    <AbsoluteFill style={{background: RO.bg, ...enter(t, a)}}>
      <svg width={1080} height={1920} style={{position: 'absolute'}} viewBox="0 0 1080 1920">
        <defs>
          <radialGradient id="ro-flesh" cx="50%" cy="45%" r="55%"><stop offset="0%" stopColor="#24456A" /><stop offset="100%" stopColor="#0A1424" /></radialGradient>
        </defs>
        {/* soft tissue */}
        <path d="M300 1400 C300 1000 320 820 420 760 L470 730 L610 730 L660 760 C760 820 780 1000 780 1400 Z" fill="url(#ro-flesh)" opacity={0.9} />
        <ellipse cx="540" cy="520" rx="140" ry="165" fill="url(#ro-flesh)" />
        {/* skull */}
        <path d="M430 560 C400 430 450 360 540 360 C630 360 680 430 650 560 C640 610 600 640 540 640 C480 640 440 610 430 560Z" {...bone} strokeWidth="14" opacity={0.85} />
        <ellipse cx="495" cy="520" rx="32" ry="26" fill={RO.bg} opacity={0.8} />
        <ellipse cx="585" cy="520" rx="32" ry="26" fill={RO.bg} opacity={0.8} />
        {/* spine */}
        {Array.from({length: 14}, (_, i) => <rect key={i} x="522" y={680 + i * 50} width="36" height="36" rx="8" fill={RO.bone} opacity={0.6} />)}
        {/* ribs */}
        {Array.from({length: 6}, (_, i) => (
          <g key={i} opacity={0.75}>
            <path d={`M525 ${820 + i * 52} C430 ${800 + i * 52} 370 ${850 + i * 52} 370 ${910 + i * 58}`} {...bone} strokeWidth="11" />
            <path d={`M555 ${820 + i * 52} C650 ${800 + i * 52} 710 ${850 + i * 52} 710 ${910 + i * 58}`} {...bone} strokeWidth="11" />
          </g>
        ))}
        <path d="M400 790 C460 760 500 770 525 785 M555 785 C580 770 620 760 680 790" {...bone} strokeWidth="12" />
        {/* pelvis */}
        <path d="M390 1330 C420 1260 500 1250 540 1300 C580 1250 660 1260 690 1330" {...bone} strokeWidth="14" opacity={0.8} />
        {/* stomach outline - empty */}
        <path d="M600 1060 C680 1060 690 1160 620 1200 C560 1230 500 1210 470 1170 C450 1140 490 1120 520 1130 C560 1140 580 1100 600 1060Z"
          fill={RO.alert} fillOpacity={0.08 + 0.1 * Math.sin(t * 6) * empty} stroke={RO.alert} strokeWidth="5" strokeDasharray="14 10" opacity={0.3 + 0.7 * empty} />
        <text x="720" y="1150" fontFamily="Ron Head" fontSize="46" fill={RO.alert} opacity={empty}>LAMBUNG KOSONG</text>
        <line x1="640" y1="1135" x2="712" y2="1135" stroke={RO.alert} strokeWidth="3" opacity={empty} />
        {/* scan bar */}
        <rect x="0" y={lerp(250, 1450, scan % 1)} width="1080" height="6" fill={RO.glow} opacity={0.5} />
        <rect x="0" y={lerp(250, 1450, scan % 1) - 60} width="1080" height="60" fill={RO.glow} opacity={0.07} />
      </svg>
      {/* question */}
      <div style={{position: 'absolute', top: 380, left: 0, right: 0, textAlign: 'center', fontFamily: 'Ron Head', fontSize: 330, color: RO.glow, opacity: q * 0.9, transform: `scale(${lerp(0.5, 1, q)})`, lineHeight: 1}}>?</div>
      {/* HUD */}
      <div style={{position: 'absolute', top: 200, right: 70, textAlign: 'right', fontFamily: 'Ron Mono', fontSize: 26, color: RO.glow, lineHeight: 1.5}}>
        PA · 110 kV<br />LAYER 08
      </div>
      <div style={{position: 'absolute', top: 1340, left: 70, display: 'flex', alignItems: 'center', gap: 18, fontFamily: 'Ron Head', fontSize: 46, color: batt < 40 ? RO.alert : RO.glow}}>
        <div style={{width: 120, height: 50, border: '4px solid currentColor', borderRadius: 8, padding: 4}}><div style={{width: `${batt}%`, height: '100%', background: 'currentColor', borderRadius: 3}} /></div>
        ENERGI {batt}%
      </div>
      <StyleTag t={t} a={a} n={8} name="RONTGEN" font="Ron Head" fg={RO.glow} bg={RO.bg} />
      <Caps t={t} y={1450} s={{font: 'Ron Head', weight: 600, size: 68, color: RO.bone, hl: RO.alert, bg: '#0b1626e6', radius: 6, border: `2px solid ${RO.dim}`, upper: true, spacing: 1}} />
    </AbsoluteFill>
  );
};
