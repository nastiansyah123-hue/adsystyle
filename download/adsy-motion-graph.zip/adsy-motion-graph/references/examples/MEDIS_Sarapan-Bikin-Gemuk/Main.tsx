// REFERENCE DEMO (ADSY MOTION GRAPH v2.0). Main.tsx of the MEDIS test reel. Read for structure only.
import React from 'react';
import {AbsoluteFill, Audio, staticFile, useCurrentFrame} from 'remotion';
import project from './project.json';
import {SfxTrack} from './components/SfxTrack';
import {FontFaces} from './Fonts';
import {at} from './lib/words';
import {MedisFonts} from './styles/medis/kit';
import {Poster, Monitor, Termal, RekamMedis} from './medis/scenesA';
import {PaperCut, KotaTubuh, Herbarium, Rontgen} from './medis/scenesB';
import {NeonSel, Mikroskop, Anatomi, Preparat} from './medis/scenesC';

const sound = project as {musicFile?: string | null; musicVolume?: number; musicAutomation?: Array<{frame: number; volume: number}>};
const musicGain = (frame: number): number => {
  const base = sound.musicVolume ?? 0.24;
  const pts = sound.musicAutomation ?? [];
  if (!pts.length) return base;
  if (frame <= pts[0].frame) return pts[0].volume;
  if (frame >= pts[pts.length - 1].frame) return pts[pts.length - 1].volume;
  let i = 1;
  while (pts[i].frame < frame) i++;
  const l = pts[i - 1], r = pts[i];
  return l.volume + (r.volume - l.volume) * ((frame - l.frame) / Math.max(1, r.frame - l.frame));
};

// Scene cuts sit in the pauses between spoken sentences (measured word timing).
const mid = (a: number, b: number) => (a + b) / 2;
const S = [
  0,
  mid(at('ya', 0) + 0.3, at('sebetulnya')),
  mid(at('sehari-hari') + 0.5, at('enggak', 0)),
  mid(at('siang') + 0.3, at('mitos')),
  mid(at('hari', 0) + 0.3, at('bayangin')),
  mid(at('badan', 0) + 0.3, at('yang bikin')),
  mid(at('makan', 3) + 0.3, at('jadi', 0)),
  mid(at('kebutuhan') + 0.5, at('kalau', 2)),
  mid(at('kamu', 6) + 0.2, at('sarapan bisa')),
  mid(at('hari', 2) + 0.3, at('jadi', 1)),
  mid(at('berlebihan', 1) + 0.5, at('ingat')),
  mid(at('makanannya') + 0.5, at('nah')),
  project.durationSeconds,
];
export const SCENE_STARTS = S;
const scenes = [Poster, Monitor, Termal, RekamMedis, PaperCut, KotaTubuh, Herbarium, Rontgen, NeonSel, Mikroskop, Anatomi, Preparat];

export const Main: React.FC = () => {
  const t = useCurrentFrame() / 60;
  let i = scenes.length - 1;
  while (i > 0 && t < S[i]) i--;
  const View = scenes[i];
  return (
    <AbsoluteFill style={{overflow: 'hidden', background: '#000'}}>
      <FontFaces />
      <MedisFonts />
      <View t={t} a={S[i]} b={S[i + 1]} />
      <SfxTrack />
      {sound.musicFile && <Audio src={staticFile(sound.musicFile)} volume={musicGain} />}
      {project.voiceoverFile && <Audio src={staticFile(project.voiceoverFile)} />}
    </AbsoluteFill>
  );
};
