// REFERENCE DEMO (ADSY MOTION GRAPH v2.0, MEDIS looks). Lived in src/medis/ of the demo project. Read for structure only; never copy its story or text.
import React from 'react';
import {AbsoluteFill} from 'remotion';
import {at} from '../lib/words';
import {p, pb, lerp, rnd, drawOn} from '../styles/shared';
import {SceneProps, StyleTag, Caps, enter} from '../styles/medis/kit';

// ============ 09 NEON SEL ============
const NS = {bg: '#04020F', cyan: '#35E7FF', mag: '#FF3FD0', warm: '#FFB25E', text: '#EAF6FF'};
const nodes = Array.from({length: 22}, (_, i) => ({x: 120 + rnd(i * 3.1) * 840, y: 380 + rnd(i * 5.7 + 2) * 900, r: 10 + rnd(i + 40) * 14}));
const links: Array<[number, number]> = [];
nodes.forEach((n, i) => {
  const near = nodes.map((m, j) => ({j, d: Math.hypot(m.x - n.x, m.y - n.y)})).filter((o) => o.j > i).sort((x, y) => x.d - y.d).slice(0, 2);
  near.forEach((o) => links.push([i, o.j]));
});
export const NeonSel: React.FC<SceneProps> = ({t, a}) => {
  const tKo = at('konsentrasi'), tSu = at('suasana'), tBa = at('baik');
  const focus = p(t, tKo - 0.4, tKo + 0.8);
  const mood = p(t, tSu - 0.2, tBa + 0.3);
  return (
    <AbsoluteFill style={{background: NS.bg, ...enter(t, a)}}>
      <svg width={1080} height={1920} style={{position: 'absolute'}}>
        {links.map(([i, j], k) => {
          const A = nodes[i], B = nodes[j];
          const on = p(focus, k / links.length * 0.7, k / links.length * 0.7 + 0.3);
          const col = k % 3 === 0 ? NS.mag : NS.cyan;
          const pulse = ((t * 0.9 + rnd(k)) % 1);
          return (
            <g key={k}>
              <line x1={A.x} y1={A.y} x2={B.x} y2={B.y} stroke={col} strokeWidth="14" opacity={0.08 + on * 0.12} />
              <line x1={A.x} y1={A.y} x2={B.x} y2={B.y} stroke={col} strokeWidth="3" opacity={0.25 + on * 0.75} />
              {on > 0.5 && <circle cx={lerp(A.x, B.x, pulse)} cy={lerp(A.y, B.y, pulse)} r="7" fill="#fff" opacity={on} />}
            </g>
          );
        })}
        {nodes.map((n, i) => {
          const on = p(focus, i / nodes.length * 0.7, i / nodes.length * 0.7 + 0.3);
          const warm = i % 4 === 0 ? mood : 0;
          return (
            <g key={i}>
              <circle cx={n.x} cy={n.y} r={n.r * 2.6} fill={warm > 0 ? NS.warm : NS.cyan} opacity={0.06 + on * 0.14 + warm * 0.2} />
              <circle cx={n.x} cy={n.y} r={n.r} fill={warm > 0.3 ? NS.warm : i % 3 === 0 ? NS.mag : NS.cyan} opacity={0.35 + on * 0.65} />
              <circle cx={n.x} cy={n.y} r={n.r * 0.4} fill="#fff" opacity={on} />
            </g>
          );
        })}
      </svg>
      <div style={{position: 'absolute', top: 1260, left: 70, right: 70, display: 'flex', gap: 22}}>
        {[['FOKUS', NS.cyan, focus], ['MOOD', NS.warm, mood]].map(([n, c, q]) => (
          <div key={n as string} style={{flex: 1, border: `3px solid ${c}`, borderRadius: 20, padding: '14px 20px', boxShadow: `0 0 30px ${c}55, inset 0 0 20px ${c}33`}}>
            <div style={{fontFamily: 'Neo Head', fontWeight: 800, fontSize: 32, letterSpacing: 4, color: c as string}}>{n}</div>
            <div style={{height: 16, background: '#ffffff18', borderRadius: 8, marginTop: 10}}><div style={{width: `${(q as number) * 100}%`, height: '100%', background: c as string, borderRadius: 8, boxShadow: `0 0 14px ${c}`}} /></div>
          </div>
        ))}
      </div>
      <StyleTag t={t} a={a} n={9} name="NEON SEL" font="Neo Head" fg={NS.cyan} bg={NS.bg} />
      <Caps t={t} y={1440} s={{font: 'Neo Head', weight: 800, size: 60, color: NS.text, hl: NS.cyan, bg: '#0a0620e6', radius: 26, border: `2px solid ${NS.mag}66`}} />
    </AbsoluteFill>
  );
};

// ============ 10 MIKROSKOP ============
const MK = {bg: '#0C0C0E', field: '#F3F0E4', ink: '#1C2420', good: '#2FA36B', bad: '#D5463A', ui: '#B9F1D2'};
export const Mikroskop: React.FC<SceneProps> = ({t, a}) => {
  const tTa = at('takut'), tSe = at('sehat', 0), tBe = at('berlebihan', 1);
  const focusQ = p(t, a, tTa + 0.2);
  const blur = lerp(14, 0, focusQ);
  const good = p(t, tSe - 0.2, tSe + 0.4);
  const bad = p(t, tBe - 0.2, tBe + 0.4);
  const mag = Math.round(lerp(10, 40, focusQ));
  const R = 430;
  const items: Array<{x: number; y: number; r: number; c: string; ok: boolean; name: string}> = [
    {x: -150, y: -120, r: 95, c: '#9FCF6A', ok: true, name: 'sayur'},
    {x: 140, y: -150, r: 80, c: '#F2D16B', ok: true, name: 'telur'},
    {x: -110, y: 150, r: 90, c: '#E9E2CE', ok: true, name: 'nasi'},
    {x: 150, y: 120, r: 85, c: '#E0864E', ok: false, name: 'gorengan ×5'},
  ];
  return (
    <AbsoluteFill style={{background: MK.bg, ...enter(t, a)}}>
      <svg width={1080} height={1920} style={{position: 'absolute'}}>
        <defs><clipPath id="mk-lens"><circle cx="540" cy="830" r={R} /></clipPath></defs>
        <circle cx="540" cy="830" r={R + 28} fill="#1d1d22" stroke="#3a3a44" strokeWidth="8" />
        <g clipPath="url(#mk-lens)">
          <rect x="0" y="300" width="1080" height="1100" fill={MK.field} />
          <g style={{filter: blur > 0.3 ? `blur(${blur}px)` : undefined}} transform="translate(540 830)">
            <circle r="330" fill="#fff" stroke="#d8d2c0" strokeWidth="10" />
            {items.map((it, i) => {
              const shrink = !it.ok ? lerp(1, 0.45, bad) : 1;
              return (
                <g key={i} transform={`translate(${it.x} ${it.y}) scale(${shrink})`}>
                  {Array.from({length: it.ok ? 1 : 5}, (_, k) => (
                    <ellipse key={k} cx={(k % 3 - 1) * 34} cy={(Math.floor(k / 3) - 0.3) * 40} rx={it.ok ? it.r : 46} ry={it.ok ? it.r * 0.8 : 30} fill={it.c} stroke={MK.ink} strokeWidth="3" opacity={0.95} />
                  ))}
                </g>
              );
            })}
          </g>
          {/* reticle */}
          <g stroke={MK.ink} strokeWidth="2" opacity={0.5}>
            <line x1="110" y1="830" x2="970" y2="830" /><line x1="540" y1="400" x2="540" y2="1260" />
            {Array.from({length: 17}, (_, i) => <line key={i} x1={540 - 400 + i * 50} y1="818" x2={540 - 400 + i * 50} y2="842" />)}
          </g>
          {/* labels */}
          {items.map((it, i) => {
            const q = it.ok ? good : bad;
            return (
              <g key={'l' + i} opacity={q} transform={`translate(${540 + it.x} ${830 + it.y})`}>
                <circle r="34" fill={it.ok ? MK.good : MK.bad} />
                {it.ok ? <path d="M-14 0 l10 11 l18 -22" fill="none" stroke="#fff" strokeWidth="7" strokeLinecap="round" strokeLinejoin="round" />
                  : <path d="M-12 -12 l24 24 M12 -12 l-24 24" stroke="#fff" strokeWidth="7" strokeLinecap="round" />}
                <text y="70" textAnchor="middle" fontFamily="Mik Mono" fontSize="30" fill={MK.ink}>{it.name}</text>
              </g>
            );
          })}
        </g>
        <circle cx="540" cy="830" r={R} fill="none" stroke="#000" strokeWidth="40" opacity={0.35} />
      </svg>
      <div style={{position: 'absolute', top: 1310, left: 70, right: 70, display: 'flex', justifyContent: 'space-between', fontFamily: 'Mik Mono', fontSize: 30, color: MK.ui}}>
        <span>OBJ ×{mag}</span><span>FOKUS {Math.round(focusQ * 100)}%</span><span>SAMPEL: MENU PAGI</span>
      </div>
      <StyleTag t={t} a={a} n={10} name="MIKROSKOP" font="Mik Mono" fg={MK.ui} bg={MK.bg} />
      <Caps t={t} y={1440} s={{font: 'Ter Head', weight: 700, size: 60, color: MK.ink, hl: MK.good, bg: MK.field, radius: 60}} />
    </AbsoluteFill>
  );
};

// ============ 11 ANATOMI ============
const AN = {paper: '#F6F1E7', ink: '#2A2420', red: '#B8473D', veg: '#5E9A55', fruit: '#E7A13A', carb: '#D9C27C', prot: '#B8473D', mute: '#8C8274'};
const arc = (r: number, a0: number, a1: number) => {
  const pt = (ang: number) => [Math.cos((ang - 90) * Math.PI / 180) * r, Math.sin((ang - 90) * Math.PI / 180) * r];
  const [x0, y0] = pt(a0), [x1, y1] = pt(a1);
  return `M0 0 L${x0} ${y0} A${r} ${r} 0 ${a1 - a0 > 180 ? 1 : 0} 1 ${x1} ${y1} Z`;
};
export const Anatomi: React.FC<SceneProps> = ({t, a}) => {
  const tKa = at('kapan'), tSb = at('seberapa'), tSi = at('seimbang');
  const strike = p(t, tKa + 0.2, tKa + 0.6);
  const segs = [
    {a0: 0, a1: 120, c: AN.veg, n: 'Sayur', f: '1/3'},
    {a0: 120, a1: 180, c: AN.fruit, n: 'Buah', f: '1/6'},
    {a0: 180, a1: 300, c: AN.carb, n: 'Makanan pokok', f: '1/3'},
    {a0: 300, a1: 360, c: AN.prot, n: 'Lauk-pauk', f: '1/6'},
  ];
  const R = 300;
  return (
    <AbsoluteFill style={{background: AN.paper, ...enter(t, a)}}>
      <div style={{position: 'absolute', top: 190, left: 80, right: 80, fontFamily: 'Ana Text', fontWeight: 600, fontSize: 28, letterSpacing: 4, color: AN.mute}}>GAMBAR 11 · KOMPOSISI PIRING</div>
      <div style={{position: 'absolute', top: 240, left: 80, right: 80, fontFamily: 'Ana Head', fontSize: 96, color: AN.ink, lineHeight: 1}}>Bukan <span style={{position: 'relative'}}>kapan<span style={{position: 'absolute', left: -6, right: -6, top: '52%', height: 9, background: AN.red, transform: `scaleX(${strike})`, transformOrigin: 'left'}} /></span>,<br />tapi <i style={{color: AN.veg}}>seimbang</i></div>
      <svg width={1080} height={900} style={{position: 'absolute', top: 470}}>
        <g transform="translate(470 430)">
          <circle r={R + 40} fill="#fff" stroke={AN.ink} strokeWidth="3" />
          {segs.map((s, i) => {
            const q = p(t, tSb + i * 0.25, tSb + i * 0.25 + 0.4);
            return <path key={i} d={arc(R * lerp(0.6, 1, q), s.a0, s.a0 + (s.a1 - s.a0) * Math.max(0.001, q))} fill={s.c} stroke={AN.ink} strokeWidth="3" opacity={q > 0 ? 0.92 : 0} />;
          })}
          {/* leader lines + labels */}
          {segs.map((s, i) => {
            const q = p(t, tSb + i * 0.25 + 0.3, tSb + i * 0.25 + 0.7);
            const mid = ((s.a0 + s.a1) / 2 - 90) * Math.PI / 180;
            const x0 = Math.cos(mid) * R * 0.7, y0 = Math.sin(mid) * R * 0.7;
            const side = Math.cos(mid) >= 0 ? 1 : -1;
            const x1 = side > 0 ? 400 : -380, y1 = Math.sin(mid) * (R + 60);
            return (
              <g key={'l' + i} opacity={q}>
                <circle cx={x0} cy={y0} r="7" fill={AN.ink} />
                <polyline points={`${x0},${y0} ${side > 0 ? 300 : -300},${y1} ${x1},${y1}`} fill="none" stroke={AN.ink} strokeWidth="2.5" {...drawOn(q)} />
                <text x={x1} y={y1 - 14} textAnchor={side > 0 ? 'end' : 'start'} fontFamily="Ana Head" fontSize="40" fill={AN.ink}>{s.n}</text>
                <text x={x1} y={y1 + 30} textAnchor={side > 0 ? 'end' : 'start'} fontFamily="Ana Text" fontWeight="600" fontSize="28" fill={AN.mute}>{s.f} piring</text>
              </g>
            );
          })}
        </g>
      </svg>
      <div style={{position: 'absolute', top: 1340, left: 80, right: 80, fontFamily: 'Ana Text', fontSize: 24, color: AN.mute, opacity: p(t, tSi, tSi + 0.4)}}>Acuan: pedoman Isi Piringku, Kemenkes RI</div>
      <StyleTag t={t} a={a} n={11} name="ANATOMI" font="Ana Text" fg={AN.ink} bg={AN.paper} />
      <Caps t={t} y={1440} s={{font: 'Ana Head', weight: 400, size: 66, color: AN.paper, hl: '#F2C46B', bg: AN.ink, radius: 4}} />
    </AbsoluteFill>
  );
};

// ============ 12 KACA PREPARAT ============
const KP = {bench: '#DCE4E8', glass: '#EEF6F8', edge: '#A9C2CB', stain1: '#B0457E', stain2: '#7B4FA8', label: '#FFFFFF', ink: '#1E2A33'};
export const Preparat: React.FC<SceneProps> = ({t, a}) => {
  const tFa = at('favorit');
  const samples = ['Nasi uduk', 'Bubur ayam', 'Roti telur', 'Oat pisang', '?'];
  const ask = pb(t, tFa - 0.2, tFa + 0.3);
  return (
    <AbsoluteFill style={{background: KP.bench, ...enter(t, a)}}>
      <svg width={1080} height={1920} style={{position: 'absolute', opacity: 0.25}}>
        {Array.from({length: 20}, (_, i) => <line key={i} x1="0" y1={i * 100} x2="1080" y2={i * 100 + 40} stroke="#fff" strokeWidth="2" />)}
      </svg>
      <div style={{position: 'absolute', top: 200, left: 80, right: 80, fontFamily: 'Pre Mono', fontSize: 28, letterSpacing: 3, color: KP.ink, opacity: 0.7}}>BAKI SAMPEL · SARAPAN</div>
      {samples.map((s, i) => {
        const q = pb(t, a + 0.1 + i * 0.16, a + 0.5 + i * 0.16);
        const last = i === samples.length - 1;
        return (
          <div key={s} style={{position: 'absolute', top: 280 + i * 190, left: 120, width: 840, height: 150, background: KP.glass, border: `3px solid ${KP.edge}`, borderRadius: 8,
            boxShadow: '0 10px 20px #1e2a3322', transform: `translateX(${(1 - q) * -900}px) rotate(${(i % 2 ? 1 : -1) * 1.2}deg)`, display: 'flex', alignItems: 'center', overflow: 'hidden'}}>
            <div style={{width: 260, height: '100%', background: last ? '#FFE27A' : KP.label, borderRight: `3px solid ${KP.edge}`, display: 'flex', flexDirection: 'column', justifyContent: 'center', paddingLeft: 22}}>
              <div style={{fontFamily: 'Pre Mono', fontSize: 20, color: '#6b7a85'}}>No. {String(i + 1).padStart(3, '0')}</div>
              <div style={{fontFamily: 'Pre Head', fontWeight: 800, fontSize: last ? 70 : 34, color: KP.ink, lineHeight: 1}}>{s}</div>
            </div>
            <svg width={560} height={150}>
              {!last && Array.from({length: 26}, (_, k) => (
                <circle key={k} cx={180 + rnd(i * 31 + k) * 220} cy={30 + rnd(i * 17 + k + 5) * 90} r={8 + rnd(k + i) * 16} fill={k % 3 ? KP.stain1 : KP.stain2} opacity={0.35 + rnd(k * 2 + i) * 0.4} />
              ))}
              {last && <text x="290" y="100" textAnchor="middle" fontFamily="Pre Head" fontWeight="800" fontSize="60" fill={KP.stain2} opacity={ask}>punyamu?</text>}
            </svg>
          </div>
        );
      })}
      <div style={{position: 'absolute', top: 1260, left: 0, right: 0, textAlign: 'center', fontFamily: 'Pre Head', fontWeight: 900, fontSize: 74, color: KP.ink, opacity: ask, transform: `scale(${lerp(0.7, 1, ask)})`}}>Tulis di komentar!</div>
      <StyleTag t={t} a={a} n={12} name="KACA PREPARAT" font="Pre Mono" fg={KP.ink} bg={KP.bench} />
      <Caps t={t} y={1440} s={{font: 'Pre Head', weight: 800, size: 62, color: '#fff', hl: '#FFE27A', bg: KP.stain2, radius: 12}} />
    </AbsoluteFill>
  );
};
