// REFERENCE DEMO (ADSY MOTION GRAPH v2.0, MEDIS looks). Lived in src/medis/ of the demo project. Read for structure only; never copy its story or text.
import React from 'react';
import {AbsoluteFill} from 'remotion';
import {at} from '../lib/words';
import {p, pb, lerp, rnd, drawOn} from '../styles/shared';
import {SceneProps, StyleTag, Caps, enter, iron} from '../styles/medis/kit';

// ============ 01 POSTER PUSKESMAS ============
const PZ = {paper: '#F4E6BF', red: '#D7372A', teal: '#127A78', navy: '#1C2A4D', yellow: '#F6C12E'};
export const Poster: React.FC<SceneProps> = ({t, a}) => {
  const tG = at('gemuk'), tK = at('kok');
  const needle = lerp(-50, 62, pb(t, tG - 0.15, tG + 0.35)) + Math.sin(t * 22) * 4 * (1 - p(t, tG + 0.35, tG + 1.2)) * p(t, tG - 0.1, tG);
  const stamp = pb(t, tK - 0.05, tK + 0.25);
  return (
    <AbsoluteFill style={{background: PZ.paper, ...enter(t, a)}}>
      {/* halftone dots */}
      <svg width={1080} height={1920} style={{position: 'absolute', opacity: 0.16}}>
        <defs><pattern id="pz-dots" width="22" height="22" patternUnits="userSpaceOnUse"><circle cx="11" cy="11" r="3.4" fill={PZ.navy} /></pattern></defs>
        <rect width={1080} height={1920} fill="url(#pz-dots)" />
      </svg>
      <div style={{position: 'absolute', inset: 40, border: `14px solid ${PZ.navy}`, borderRadius: 10}} />
      <div style={{position: 'absolute', top: 190, left: 0, right: 0, textAlign: 'center'}}>
        <span style={{fontFamily: 'Pos Text', fontWeight: 900, fontSize: 34, letterSpacing: 6, color: PZ.paper, background: PZ.teal, padding: '10px 26px'}}>PENYULUHAN KESEHATAN</span>
      </div>
      <div style={{position: 'absolute', top: 280, left: 80, right: 80, textAlign: 'center', fontFamily: 'Pos Head', fontSize: 196, lineHeight: 0.9, color: PZ.red}}>
        SARAPAN<br /><span style={{color: PZ.navy}}>BIKIN GEMUK?</span>
      </div>
      <svg width={1080} height={900} style={{position: 'absolute', top: 640}} viewBox="0 0 1080 900">
        {/* plate */}
        <g transform="translate(300 380)">
          <ellipse cx="0" cy="30" rx="210" ry="70" fill={PZ.navy} opacity={0.25} />
          <ellipse cx="0" cy="0" rx="210" ry="80" fill="#fff" stroke={PZ.navy} strokeWidth="10" />
          <ellipse cx="0" cy="0" rx="150" ry="54" fill="none" stroke={PZ.navy} strokeWidth="5" opacity={0.4} />
          <path d="M-120 -10 C-110 -60 -20 -70 0 -30 C20 -60 90 -40 80 0 C60 40 -90 40 -120 -10Z" fill="#fff" stroke={PZ.navy} strokeWidth="7" />
          <circle cx="-30" cy="-10" r="30" fill={PZ.yellow} stroke={PZ.navy} strokeWidth="6" />
          <rect x="40" y="-50" width="110" height="80" rx="18" fill="#E5A75A" stroke={PZ.navy} strokeWidth="7" transform="rotate(12 95 -10)" />
        </g>
        {/* arrow */}
        <path d="M520 380 L610 380" stroke={PZ.red} strokeWidth="22" strokeLinecap="round" />
        <path d="M590 340 L640 380 L590 420" fill="none" stroke={PZ.red} strokeWidth="22" strokeLinecap="round" strokeLinejoin="round" />
        {/* scale */}
        <g transform="translate(830 400)">
          <rect x="-170" y="-150" width="340" height="300" rx="50" fill={PZ.teal} stroke={PZ.navy} strokeWidth="10" />
          <path d="M-110 -40 A110 110 0 0 1 110 -40" fill={PZ.paper} stroke={PZ.navy} strokeWidth="8" />
          {[-60, -30, 0, 30, 60].map((d) => (
            <line key={d} x1="0" y1="-40" x2="0" y2="-130" stroke={PZ.navy} strokeWidth="5" strokeDasharray="0 70 20 100" transform={`rotate(${d} 0 -40)`} />
          ))}
          <line x1="0" y1="-40" x2="0" y2="-135" stroke={PZ.red} strokeWidth="10" strokeLinecap="round" transform={`rotate(${needle} 0 -40)`} />
          <circle cx="0" cy="-40" r="14" fill={PZ.navy} />
          <text x="0" y="90" textAnchor="middle" fontFamily="Pos Head" fontSize="70" fill={PZ.paper}>{Math.round(lerp(55, 80, p(t, tG - 0.15, tG + 0.35)))} KG</text>
        </g>
      </svg>
      {/* question stamp */}
      <div style={{position: 'absolute', top: 1110, left: 110, width: 230, height: 230, borderRadius: 115, border: `12px solid ${PZ.red}`,
        display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'Pos Head', fontSize: 210, color: PZ.red, paddingTop: 20,
        transform: `rotate(${lerp(-40, -12, stamp)}deg) scale(${lerp(2.2, 1, stamp)})`, opacity: stamp, background: '#F4E6BFcc'}}>?</div>
      <div style={{position: 'absolute', top: 1340, left: 0, right: 0, textAlign: 'center', fontFamily: 'Pos Text', fontWeight: 800, fontSize: 30, letterSpacing: 4, color: PZ.navy, opacity: 0.75}}>MITOS ATAU FAKTA</div>
      <StyleTag t={t} a={a} n={1} name="POSTER PUSKESMAS" font="Pos Text" fg={PZ.navy} bg={PZ.paper} />
      <Caps t={t} y={1520} s={{font: 'Pos Head', weight: 400, size: 76, color: PZ.paper, hl: PZ.yellow, bg: PZ.red, radius: 4, spacing: 2}} />
    </AbsoluteFill>
  );
};

// ============ 02 MONITOR ============
const MO = {bg: '#03100C', grid: '#0C3B2A', green: '#38F28A', cyan: '#3BD8F5', amber: '#FFC23D', red: '#FF4D5E'};
const ecg = (ph: number) => {
  const x = ph % 1;
  if (x < 0.1) return Math.sin((x / 0.1) * Math.PI) * 0.12;
  if (x < 0.16) return 0;
  if (x < 0.19) return -0.2 * ((x - 0.16) / 0.03);
  if (x < 0.22) return lerp(-0.2, 1, (x - 0.19) / 0.03);
  if (x < 0.26) return lerp(1, -0.35, (x - 0.22) / 0.04);
  if (x < 0.29) return lerp(-0.35, 0, (x - 0.26) / 0.03);
  if (x < 0.45) return 0;
  if (x < 0.6) return Math.sin(((x - 0.45) / 0.15) * Math.PI) * 0.22;
  return 0;
};
export const Monitor: React.FC<SceneProps> = ({t, a}) => {
  const tS = at('sarapan', 1), tE = at('energi'), tA = at('aktivitas');
  const energy = lerp(18, 96, p(t, tS, tE + 0.6));
  const W = 940;
  const pts = (amp: number, speed: number, per: number, fn: (x: number) => number) => Array.from({length: 160}, (_, i) => {
    const x = (i / 159) * W;
    return `${x.toFixed(1)},${(-fn((x / W) * per - t * speed) * amp).toFixed(1)}`;
  }).join(' ');
  const hr = Math.round(lerp(64, 82, p(t, tE, tA)));
  const ready = p(t, tA, tA + 0.3);
  const plate = pb(t, tS - 0.1, tS + 0.3);
  return (
    <AbsoluteFill style={{background: MO.bg, ...enter(t, a)}}>
      <svg width={1080} height={1920} style={{position: 'absolute'}}>
        <defs><pattern id="mo-grid" width="40" height="40" patternUnits="userSpaceOnUse"><path d="M40 0H0V40" fill="none" stroke={MO.grid} strokeWidth="1.5" /></pattern></defs>
        <rect width={1080} height={1920} fill="url(#mo-grid)" opacity={0.6} />
        <g transform="translate(70 420)">
          <text x="0" y="-80" fontFamily="Mon Mono" fontSize="34" fill={MO.green}>II  EKG · 25 mm/s</text>
          <polyline points={pts(110, 1.1, 3, ecg)} fill="none" stroke={MO.green} strokeWidth="14" opacity={0.18} />
          <polyline points={pts(110, 1.1, 3, ecg)} fill="none" stroke={MO.green} strokeWidth="5" />
        </g>
        <g transform="translate(70 720)">
          <text x="0" y="-60" fontFamily="Mon Mono" fontSize="34" fill={MO.cyan}>PLETH</text>
          <polyline points={pts(50, 1.1, 3, (x) => Math.max(0, Math.sin(((x % 1) / 0.5) * Math.PI)) * ((x % 1) < 0.5 ? 1 : 0))} fill="none" stroke={MO.cyan} strokeWidth="5" />
        </g>
      </svg>
      {/* vitals column */}
      <div style={{position: 'absolute', top: 260, right: 70, textAlign: 'right', fontFamily: 'Mon Head', color: MO.green}}>
        <div style={{fontFamily: 'Mon Mono', fontSize: 30}}>HR</div>
        <div style={{fontSize: 120, lineHeight: 0.9}}>{hr}</div>
      </div>
      {/* energy panel */}
      <div style={{position: 'absolute', top: 860, left: 70, right: 70, height: 470, border: `3px solid ${MO.amber}`, borderRadius: 18, padding: 36}}>
        <div style={{display: 'flex', justifyContent: 'space-between', fontFamily: 'Mon Mono', fontSize: 34, color: MO.amber}}>
          <span>ENERGI TUBUH</span><span>{energy < 40 ? 'RENDAH' : energy < 80 ? 'NAIK' : 'PENUH'}</span>
        </div>
        <div style={{fontFamily: 'Mon Head', fontSize: 200, lineHeight: 1, color: energy < 40 ? MO.red : MO.amber, marginTop: 10}}>{Math.round(energy)}<span style={{fontSize: 90}}>%</span></div>
        <div style={{display: 'flex', gap: 10, marginTop: 24}}>
          {Array.from({length: 20}, (_, i) => (
            <div key={i} style={{flex: 1, height: 70, borderRadius: 4, background: (i + 1) * 5 <= energy ? (energy < 40 ? MO.red : MO.amber) : '#2a2510'}} />
          ))}
        </div>
      </div>
      {/* breakfast input event */}
      <div style={{position: 'absolute', top: 1360, left: 70, display: 'flex', gap: 18, alignItems: 'center', opacity: plate, transform: `translateY(${(1 - plate) * 30}px)`}}>
        <div style={{fontFamily: 'Mon Mono', fontSize: 34, color: MO.bg, background: MO.green, padding: '8px 18px', borderRadius: 6}}>+ SARAPAN MASUK</div>
        <div style={{fontFamily: 'Mon Mono', fontSize: 34, color: MO.green, opacity: ready}}>▶ SIAP AKTIVITAS</div>
      </div>
      <StyleTag t={t} a={a} n={2} name="MONITOR" font="Mon Mono" fg={MO.green} bg={MO.bg} />
      <Caps t={t} y={1500} s={{font: 'Mon Mono', weight: 400, size: 58, color: MO.green, hl: MO.amber, bg: '#000000d9', radius: 8, border: `2px solid ${MO.green}`, upper: true}} />
    </AbsoluteFill>
  );
};

// ============ 03 TERMAL ============
export const Termal: React.FC<SceneProps> = ({t, a}) => {
  const tL = at('kelaparan'), tM = at('makan', 0), tSi = at('siang');
  const hunger = p(t, tL - 0.3, tL + 0.8);
  const big = pb(t, tM - 0.1, tM + 0.4);
  const clock = p(t, tSi - 0.4, tSi + 0.1);
  const hh = Math.round(lerp(7, 12, clock));
  const flick = 0.03 * Math.sin(t * 9);
  return (
    <AbsoluteFill style={{background: iron(0.04), ...enter(t, a)}}>
      <svg width={1080} height={1920} style={{position: 'absolute'}} viewBox="0 0 1080 1920">
        <defs>
          <radialGradient id="tm-body" cx="50%" cy="40%" r="60%">
            <stop offset="0%" stopColor={iron(0.72)} /><stop offset="55%" stopColor={iron(0.5)} /><stop offset="100%" stopColor={iron(0.3)} />
          </radialGradient>
          <radialGradient id="tm-gut">
            <stop offset="0%" stopColor={iron(0.98)} /><stop offset="35%" stopColor={iron(0.86)} /><stop offset="70%" stopColor={iron(0.66)} /><stop offset="100%" stopColor={iron(0.5)} stopOpacity={0} />
          </radialGradient>
          <radialGradient id="tm-food">
            <stop offset="0%" stopColor={iron(1)} /><stop offset="50%" stopColor={iron(0.85)} /><stop offset="100%" stopColor={iron(0.6)} stopOpacity={0} />
          </radialGradient>
          <clipPath id="tm-clip"><path d="M290 1400 C290 1000 320 800 420 730 L470 700 L610 700 L660 730 C760 800 790 1000 790 1400 Z" /><circle cx="540" cy="520" r="125" /><rect x="490" y="610" width="100" height="110" /></clipPath>
        </defs>
        <g transform={`translate(${lerp(0, -160, big)} 0) scale(${lerp(1, 0.86, big)})`} style={{transformOrigin: '540px 960px'}}>
          <g clipPath="url(#tm-clip)">
            <rect width={1080} height={1920} fill="url(#tm-body)" />
            <ellipse cx="540" cy="540" rx="80" ry="90" fill={iron(0.8)} opacity={0.7} />
            <circle cx="540" cy="1080" r={lerp(90, 240, hunger) * (1 + flick)} fill="url(#tm-gut)" />
          </g>
          {/* crosshair on gut */}
          <g stroke="#fff" strokeWidth="4" fill="none" opacity={hunger}>
            <rect x="420" y="960" width="240" height="240" strokeDasharray="40 160" strokeDashoffset="20" />
            <text x="680" y="955" fill="#fff" stroke="none" fontFamily="Ter Mono" fontSize="40">{(lerp(36.4, 38.9, hunger)).toFixed(1)}°C</text>
            <text x="680" y="1005" fill={iron(0.9)} stroke="none" fontFamily="Ter Head" fontWeight="700" fontSize="44">LAPAR!</text>
          </g>
        </g>
        {/* lunch pile heat signature */}
        <g opacity={big} transform={`translate(${lerp(1100, 800, big)} 1150)`}>
          <ellipse cx="0" cy="90" rx="230" ry="60" fill={iron(0.45)} />
          <circle cx="-90" cy="20" r="110" fill="url(#tm-food)" />
          <circle cx="70" cy="0" r="130" fill="url(#tm-food)" />
          <circle cx="0" cy="-100" r="110" fill="url(#tm-food)" />
          <text x="0" y="230" textAnchor="middle" fontFamily="Ter Head" fontWeight="700" fontSize="50" fill={iron(0.95)}>PORSI SIANG ×2</text>
        </g>
        {/* temperature scale */}
        <g transform="translate(985 520)" opacity={1 - 0.8 * big}>
          {Array.from({length: 40}, (_, i) => <rect key={i} x="0" y={i * 18} width="34" height="18" fill={iron(1 - i / 39)} />)}
          <text x="-12" y="-14" textAnchor="end" fontFamily="Ter Mono" fontSize="28" fill="#fff">40°</text>
          <text x="-12" y="730" textAnchor="end" fontFamily="Ter Mono" fontSize="28" fill="#fff">30°</text>
        </g>
      </svg>
      <div style={{position: 'absolute', top: 190, right: 70, fontFamily: 'Ter Mono', fontSize: 64, color: '#fff', fontWeight: 700}}>
        {String(hh).padStart(2, '0')}:00
        <div style={{fontSize: 28, opacity: 0.7, textAlign: 'right', fontWeight: 400}}>{hh < 12 ? 'TANPA SARAPAN' : 'JAM MAKAN SIANG'}</div>
      </div>
      <div style={{position: 'absolute', top: 1380, left: 70, fontFamily: 'Ter Mono', fontSize: 28, color: '#ffffffaa'}}>IR · ε 0.98 · REC ●</div>
      <StyleTag t={t} a={a} n={3} name="TERMAL" font="Ter Head" fg="#fff" bg={iron(0.04)} />
      <Caps t={t} y={1460} s={{font: 'Ter Head', weight: 700, size: 60, color: '#fff', hl: iron(0.88), bg: '#0b0420e0', radius: 10}} />
    </AbsoluteFill>
  );
};

// ============ 04 REKAM MEDIS ============
const RK = {desk: '#C9D3DC', folder: '#E8C67F', folderDark: '#C9A55C', paper: '#FFFEF8', ink: '#20324A', line: '#B9C8D8', red: '#C8312B', hl: '#FFF15C', blue: '#2353A8'};
const typed = (s: string, t: number, a: number, cps = 26) => s.slice(0, Math.max(0, Math.floor((t - a) * cps)));
export const RekamMedis: React.FC<SceneProps> = ({t, a}) => {
  const tMi = at('mitos'), tAs = at('asumsi'), tKa = at('kalori'), tPa = at('pagi', 0);
  const open = p(t, a, a + 0.6);
  const hl = p(t, tAs, tAs + 0.45);
  const stamp = pb(t, tPa + 0.2, tPa + 0.45);
  const row = (label: string, val: React.ReactNode, y: number, show: number) => (
    <div style={{position: 'absolute', top: y, left: 60, right: 60, borderBottom: `3px solid ${RK.line}`, paddingBottom: 12, opacity: show}}>
      <div style={{fontFamily: 'Rek Mono', fontSize: 26, color: '#7a8798', letterSpacing: 2}}>{label}</div>
      <div style={{fontFamily: 'Rek Mono', fontSize: 44, color: RK.ink, marginTop: 6, minHeight: 56}}>{val}</div>
    </div>
  );
  return (
    <AbsoluteFill style={{background: RK.desk, ...enter(t, a)}}>
      {/* folder back */}
      <div style={{position: 'absolute', top: 250, left: 60, width: 960, height: 1170, background: RK.folderDark, borderRadius: 24, transform: 'rotate(-2deg)'}} />
      <div style={{position: 'absolute', top: 222, left: 90, width: 300, height: 70, background: RK.folderDark, borderRadius: '20px 20px 0 0', transform: 'rotate(-2deg)'}} />
      {/* sheet */}
      <div style={{position: 'absolute', top: 290, left: 100, width: 880, height: 1100, background: RK.paper, borderRadius: 8, boxShadow: '0 20px 40px #20324a33',
        transform: `rotate(${lerp(-6, 1, open)}deg) translateY(${(1 - open) * 120}px)`}}>
        <div style={{position: 'absolute', top: 40, left: 60, right: 60, display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', borderBottom: `5px solid ${RK.ink}`, paddingBottom: 18}}>
          <div style={{fontFamily: 'Rek Mono', fontSize: 46, color: RK.ink}}>LEMBAR PEMERIKSAAN</div>
          <div style={{fontFamily: 'Rek Mono', fontSize: 26, color: '#7a8798'}}>No. RM 04-0716</div>
        </div>
        {row('NAMA KASUS', typed('Mitos: sarapan bikin gemuk', t, tMi), 150, 1)}
        {row('SUMBER KLAIM', <span style={{background: `linear-gradient(90deg, ${RK.hl} ${hl * 100}%, transparent ${hl * 100}%)`, padding: '0 8px'}}>{t > tAs - 0.1 ? 'ASUMSI' : ''}</span>, 300, p(t, tAs - 0.6, tAs - 0.3))}
        {row('DUGAAN', typed('Kalori ekstra di pagi hari', t, tKa - 0.3), 450, p(t, tKa - 0.6, tKa - 0.3))}
        {row('BUKTI PENDUKUNG', t > tPa ? '—' : '', 600, p(t, tPa - 0.3, tPa))}
        {/* handwriting note */}
        <div style={{position: 'absolute', top: 790, left: 90, fontFamily: 'Rek Hand', fontSize: 64, color: RK.blue, transform: 'rotate(-4deg)', opacity: p(t, tPa + 0.1, tPa + 0.5)}}>
          Perlu dicek dulu ya!
        </div>
        <svg width={880} height={200} style={{position: 'absolute', top: 870}}>
          <path d="M90 40 C250 70 450 20 620 45" fill="none" stroke={RK.blue} strokeWidth="6" strokeLinecap="round" {...drawOn(p(t, tPa + 0.4, tPa + 0.9))} />
        </svg>
        {/* stamp */}
        <div style={{position: 'absolute', top: 920, right: 70, border: `8px solid ${RK.red}`, color: RK.red, fontFamily: 'Rek Mono', fontSize: 60, padding: '10px 26px', borderRadius: 12,
          transform: `rotate(-14deg) scale(${lerp(2, 1, stamp)})`, opacity: stamp * 0.88}}>BELUM TERBUKTI</div>
      </div>
      {/* paperclip */}
      <svg width={120} height={240} style={{position: 'absolute', top: 230, left: 780}}>
        <path d="M40 220 V50 a30 30 0 0 1 60 0 V190 a18 18 0 0 1 -36 0 V70" fill="none" stroke="#8D98A6" strokeWidth="10" strokeLinecap="round" />
      </svg>
      <StyleTag t={t} a={a} n={4} name="REKAM MEDIS" font="Rek Mono" fg={RK.ink} bg={RK.desk} />
      <Caps t={t} y={1500} s={{font: 'Rek Mono', weight: 600, size: 54, color: RK.ink, hl: RK.red, bg: RK.paper, radius: 6, shadow: '0 10px 24px #20324a33', border: `3px solid ${RK.ink}`}} />
    </AbsoluteFill>
  );
};
export {rnd};
