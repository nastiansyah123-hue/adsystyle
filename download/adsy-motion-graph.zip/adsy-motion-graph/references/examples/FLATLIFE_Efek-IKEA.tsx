// REFERENCE DEMO (ADSY MOTION GRAPH v1.8) — read for structure only: scenes, camera moves, word-pinned beats, SFX cues.
// Do NOT copy this story, its text or its layout into a buyer video. Written in the author's demo workspace, so a few
// imports differ from the starter: `makeCues(words)` ≈ the starter's `at()/endOf()` from src/lib/words.ts, and
// `EpisodeAudio` ≈ Main.tsx audio (musicFile + auto-duck) + <SfxTrack /> fed by src/audio-plan.json sfxCues.
// The `getInputProps()` draft switch below was a workspace-only shortcut: do not copy it (the starter has --silent-draft).
import React from 'react';
import {AbsoluteFill, Easing, getInputProps} from 'remotion';
import {makeCues} from '../../lib/cues';
import {camera, lerp, p, pagesFor, pb, pio, shake, StyleFonts, useTime} from '../../styles/shared';
import {
  armAt, Backdrop, Beaker, Burst, BurstStar, Caption, CheckCard, Clock, Dimas, DizzyStars, DropWord, F, FALL, FlatBox, Frog, Hammer, HEAD, Heart, IrisScene, keyAt, land, Look,
  LOOKS, Magnifier, Manual, Medal, Mood, PaperFold, Person, Pill, Plant, Plaster, popIO, PriceTag, Puffs, QMark, Screw, Shelf, shelfPoint, SparkleField, SpotStage, squash,
  Stage, stepAt, StorageBox, SvgPill, Table,
} from '../../styles/flatlife/kit';
import {EpisodeAudio, Sfx} from '../../styles/audio';
import wordsFile from './words.json';

// FLATLIFE episode — "Efek IKEA": Dimas builds a crooked bookshelf and loves it anyway. The 2011 experiment plays out
// with generic researcher characters, podiums are the price bars, sweat drops flow into the price tag, and the end card
// holds on Dimas hugging his shelf. Scenes change with the style's iris wipe; every beat lands on its spoken word.

const C = makeCues(wordsFile);
const a = C.at;
const PAGES = pagesFor(C.words, 4, 22);
export const FLATLIFE_DURATION = C.duration + 1.4;

const FLOOR = 1390;
/** Scene starts (the iris begins here). */
const T = {
  clock: a('dua jam') - 0.22,
  thumb: a('satu jempol') - 0.25,
  stand: a('palu') + 0.35,
  title: a('para peneliti') - 0.25,
  lab: a('tahun') - 0.22,
  groups: a('sebagian') - 0.25,
  price: a('sekitar') - 0.2,
  fold: a('di percobaan') - 0.2,
  critics: a('orang lain') - 0.25,
  value: a('tapi pembuatnya') - 0.2,
  effort: a('usaha') - 0.2,
  rule: a('tapi ada') - 0.2,
  end: a('jadi kalau') - 0.2,
};
const MEDAL_AT = (x: number, s: number) => shelfPoint(x, FLOOR, s, -70, -420, 6); // medal pinned on the 6°-racked shelf
const CRITIC2: Look = {...LOOKS.labNeat, coat: false, shirt: F.teal, stripe: '#0F8577'};

// ---------- S1 · "Kenalin, ini Dimas" ----------
const PARTS = [
  {k: 'plank', x: 610, y: 1446, r: -5, d: 0, w: 300},
  {k: 'plank', x: 930, y: 1472, r: 6, d: 0.06, w: 250},
  {k: 'plank', x: 740, y: 1500, r: -2, d: 0.12, w: 320},
  {k: 'screw', x: 470, y: 1488, r: 80, d: 0.03},
  {k: 'screw', x: 1010, y: 1430, r: -70, d: 0.09},
  {k: 'screw', x: 850, y: 1520, r: 100, d: 0.15},
  {k: 'manual', x: 500, y: 1450, r: -10, d: 0.22},
];
const Intro: React.FC<{t: number}> = ({t}) => {
  const tName = a('ini dimas'), tDim2 = a('dimas', 1), tRak = a('rak buku'), tYang = a('yang harus'), tHarus = a('harus dirakit'), tRakit = a('dirakit'), tSendiri = a('sendiri');
  const cam = camera(t, {x: 390, y: 1000, s: 1.32, r: 0}, [
    {from: 0.2, to: 1.9, x: 430, y: 990, s: 1.18},
    {from: tDim2, to: tRak + 0.3, x: 600, y: 990, s: 1.0},
    {from: tYang, to: tRakit + 0.4, x: 610, y: 1060, s: 1.1},
  ]);
  const wave = Math.sin(t * 13) * 22;
  const armR = armAt(t, [[0, {a: 150, e: 20 + wave}], [tDim2, {a: 78, e: -12}], [tYang, {a: 14, e: 6}], [tRakit, {a: 120, e: 60}], [tSendiri, {a: 14, e: 6}]]);
  const armL = armAt(t, [[0, {a: 14, e: 6}], [tRakit, {a: 120, e: 60}], [tSendiri, {a: 160, e: 30}]]);
  const mood = stepAt<Mood>(t, [[0, 'happy'], [tYang, 'curious'], [tRakit, 'shock'], [tSendiri, 'curious']]);
  const box = land(t, tRak - 0.3, 1000);
  const boxRot = t > tYang && t < tHarus ? Math.sin(t * 46) * 2.5 : 0;
  const open = pio(t, tHarus - 0.05, tHarus + 0.35);
  return (
    <AbsoluteFill>
      <Stage pose={cam}>
        <Backdrop t={t} />
        <Plant x={95} y={FLOOR} s={1.05} t={t} />
        <SvgPill x={330} y={470} q={popIO(t, tName, tRakit - 0.2)} text="DIMAS" bg={F.coral} size={50} rot={-4} />
        <Dimas t={t} x={330} y={FLOOR} s={1.5} mood={mood} armL={armL} armR={armR} lookX={keyAt(t, [[0, 0], [tDim2, 1], [tRakit, 0.6]])} lookY={keyAt(t, [[0, 0], [tRakit, -1], [tSendiri, 0]])} tilt={keyAt(t, [[0, 0], [tSendiri, 8]])} />
        {box.on && <FlatBox x={800} y={FLOOR + box.dy} s={1.25} sx={box.sx} sy={box.sy} open={open} rot={boxRot} />}
        {PARTS.map((pt, i) => {
          const at = tRakit + pt.d;
          if (t < at) return null;
          const k = p(t, at, at + 0.6, Easing.linear);
          const x = lerp(800, pt.x, Easing.out(Easing.quad)(k)), y = lerp(860, pt.y, k) - Math.sin(k * Math.PI) * 420;
          const r = pt.r + (1 - k) * 540 * (i % 2 ? 1 : -1);
          if (pt.k === 'plank') return <g key={i} transform={`translate(${x} ${y}) rotate(${r})`}><rect x={-(pt.w ?? 280) / 2} y={-14} width={pt.w ?? 280} height={28} rx={6} fill={F.wood} /><rect x={-(pt.w ?? 280) / 2} y={6} width={pt.w ?? 280} height={8} rx={3} fill={F.woodDark} /></g>;
          if (pt.k === 'screw') return <Screw key={i} x={x} y={y} s={1.1} rot={r} />;
          return <Manual key={i} x={x} y={y} rot={r} s={0.9} />;
        })}
      </Stage>
      <Pill x={540} y={300} q={popIO(t, tRak + 0.05, tRakit - 0.1)} bg={F.sun} color={F.navy} text="RAK BUKU BARU" size={56} />
      <Pill x={540} y={300} q={popIO(t, tRakit, 99)} bg={F.coral} text="HARUS DIRAKIT SENDIRI!" size={52} rot={-3} />
    </AbsoluteFill>
  );
};

// ---------- S2 · "Dua jam. Tiga baut sisa." ----------
const ClockScene: React.FC<{t: number}> = ({t}) => {
  const tDua = a('dua jam'), tJam = a('jam'), tTiga = a('tiga'), tBaut = a('baut'), tSisa = a('sisa');
  const cam = camera(t, {x: 540, y: 960, s: 1.05, r: 0}, [{from: T.clock, to: tTiga, s: 1.0}, {from: tTiga - 0.2, to: tSisa + 0.4, x: 560, y: 1040, s: 1.1}]);
  const screwAts = [tTiga, tBaut, tSisa];
  return (
    <Stage pose={cam}>
      <Backdrop t={t} circle="#FFE2A8" cx={700} cy={620} r={340} sun={null} seed={2} />
      <Clock x={700} y={620} r={200} hours={2 * pio(t, tDua - 0.05, tJam + 0.35)} q={pb(t, T.clock + 0.1, T.clock + 0.45)} />
      <Shelf x={800} y={FLOOR} s={1.05} build={lerp(0.45, 0.66, p(t, T.clock, tTiga))} />
      <Dimas t={t} x={300} y={FLOOR} s={1.4} sweat={1 - p(t, tTiga, tTiga + 0.3)} mood={stepAt<Mood>(t, [[0, 'sad'], [tTiga, 'shock'], [tSisa, 'curious']])}
        armR={armAt(t, [[0, {a: 70 + Math.sin(t * 12) * 12, e: -40, tool: 'screwdriver'}], [tTiga, {a: 18, e: 8, tool: 'screwdriver'}]])}
        armL={armAt(t, [[0, {a: 30, e: -30}], [tSisa, {a: 160, e: 30}]])} lookX={1} lookY={keyAt(t, [[0, 0], [tTiga, 1]])} tilt={keyAt(t, [[0, 0], [tSisa, 8]])} />
      {screwAts.map((at, i) => {
        if (t < at - 0.05) return null;
        const k = p(t, at - 0.05, at + 0.3, Easing.linear);
        const tx = 520 + i * 135;
        const sq = squash(t, at + 0.3, 0.25);
        return (
          <g key={i} transform={`translate(${lerp(800, tx, k)} ${lerp(1060, 1352, k) - Math.sin(k * Math.PI) * 260}) scale(${sq.sx} ${sq.sy})`}>
            <Screw x={0} y={0} s={1.5} rot={(1 - k) * 360} />
          </g>
        );
      })}
      <QMark x={440} y={560} s={pb(t, tSisa + 0.1, tSisa + 0.4)} rot={12} />
    </Stage>
  );
};

// ---------- S3 · "Satu jempol kena palu." ----------
const ThumbScene: React.FC<{t: number}> = ({t}) => {
  const tJem = a('jempol'), tKena = a('kena'), tPalu = a('palu');
  const hit = t >= tKena;
  const kr = p(t, tKena, tKena + 0.28, Easing.linear);
  const ang = t < tJem ? -38 + Math.sin(t * 3) * 2
    : t < tKena - 0.18 ? lerp(-38, 12, p(t, tJem, tJem + 0.3))
      : t < tKena ? lerp(12, -90, p(t, tKena - 0.18, tKena, Easing.in(Easing.quad)))
        : -90 + 14 * Math.sin(kr * Math.PI) + 6 * p(t, tKena + 0.28, tKena + 0.5);
  const swell = pb(t, tKena, tKena + 0.3);
  const thumbS = 1 + 0.5 * swell + (hit ? Math.sin(t * 16) * 0.05 : 0);
  const punch = 0.1 * (pb(t, tKena, tKena + 0.12) - p(t, tKena + 0.12, tKena + 0.7));
  const pose = {x: 520, y: 1000, s: 1 + punch + 0.03 * p(t, T.thumb, T.thumb + 2), r: 0};
  return (
    <Stage pose={pose} off={shake(t, [tKena], 28, 0.45)}>
      <rect x={-1200} y={-1200} width={3480} height={4320} fill="#FFE7B8" />
      {Array.from({length: 16}).map((_, i) => <path key={i} d="M 0 0 L 2400 -200 L 2400 200 Z" fill="#FFD98A" transform={`translate(480 1000) rotate(${(i / 16) * 360 + t * 8})`} />)}
      <circle cx={480} cy={1000} r={260} fill="#FFF3E2" opacity={0.6} />
      {/* workbench board */}
      <rect x={-400} y={1150} width={1900} height={200} fill={F.wood} />
      <rect x={-400} y={1150} width={1900} height={14} fill="#ffffff55" />
      {[0, 1, 2].map((i) => <path key={i} d={`M -400 ${1200 + i * 40} q 300 -14 600 0 t 600 0 t 600 0`} stroke={F.woodDark} strokeWidth={5} fill="none" opacity={0.5} />)}
      <rect x={-400} y={1350} width={1900} height={900} fill={F.floor} />
      <rect x={-400} y={1350} width={1900} height={16} fill="#22325A22" />
      {/* screw held upright, falls over after the miss */}
      <g transform={`rotate(${68 * p(t, tKena + 0.05, tKena + 0.45, Easing.out(Easing.back(1.6)))} 575 1150)`}><Screw x={575} y={1040} s={1.4} /></g>
      {/* hand */}
      <rect x={-200} y={1078} width={360} height={170} rx={60} fill={F.teal} />
      <rect x={-200} y={1150} width={360} height={26} fill="#0F8577" />
      <rect x={110} y={1108} width={240} height={116} rx={56} fill={F.skin} />
      <ellipse cx={370} cy={1172} rx={118} ry={84} fill={F.skin} />
      {[0, 1, 2].map((i) => <rect key={i} x={400} y={1112 + i * 42} width={130 - i * 10} height={40} rx={20} fill={F.skin} stroke="#E19A6C" strokeWidth={3} />)}
      <g transform={`translate(470 1120) scale(${thumbS}) translate(-470 -1120)`}>
        <rect x={440} y={1000} width={62} height={140} rx={31} fill={F.skin} />
        <rect x={440} y={1000} width={62} height={140} rx={31} fill={F.red} opacity={0.85 * swell} />
        <ellipse cx={471} cy={1022} rx={18} ry={14} fill="#fff" opacity={0.55} />
      </g>
      {/* hammer swinging from its grip */}
      <g transform={`translate(960 780) rotate(${ang})`}><Hammer x={0} y={-480} s={2} /></g>
      {hit && <circle cx={470} cy={990} r={60 + 260 * p(t, tKena, tKena + 0.3)} fill="#fff" opacity={0.7 * (1 - p(t, tKena, tKena + 0.3))} />}
      {hit && Array.from({length: 7}).map((_, i) => {
        const an = (-160 + i * 23) * (Math.PI / 180), r0 = 70 * thumbS, r1 = r0 + 34 + Math.sin(t * 18 + i) * 8;
        return <line key={i} x1={470 + Math.cos(an) * r0} y1={1000 + Math.sin(an) * r0} x2={470 + Math.cos(an) * r1} y2={1000 + Math.sin(an) * r1} stroke={F.navy} strokeWidth={9} strokeLinecap="round" opacity={swell} />;
      })}
      <BurstStar x={270} y={770} s={pb(t, tKena, tKena + 0.22)} text="BONK!" rot={-12} />
      <DizzyStars t={t} x={470} y={900} q={p(t, tPalu, tPalu + 0.3)} rx={120} />
    </Stage>
  );
};
/** Running tally "2 JAM · 3 BAUT SISA · 1 JEMPOL" (screen space, spans S2–S3). */
const Tally: React.FC<{t: number}> = ({t}) => {
  const rows = [{at: a('jam'), text: '2 JAM', bg: F.navy}, {at: a('sisa'), text: '3 BAUT SISA', bg: F.coral}, {at: a('jempol'), text: '1 JEMPOL', bg: F.red}];
  const out = T.stand + 0.15;
  return (
    <>
      {rows.map((r, i) => {
        const q = pb(t, r.at, r.at + 0.3) * (1 - p(t, out + i * 0.06, out + 0.25 + i * 0.06));
        if (q <= 0.01) return null;
        return (
          <div key={i} style={{position: 'absolute', left: 64, top: 170 + i * 98, transformOrigin: '0 50%', transform: `scale(${q}) rotate(${i % 2 ? 2 : -2}deg)`, background: r.bg, color: '#fff', borderRadius: 999,
            padding: '10px 32px', fontFamily: HEAD, fontWeight: 700, fontSize: 54, letterSpacing: 2, boxShadow: '0 8px 0 #22325A33', whiteSpace: 'nowrap', lineHeight: 1.15}}>{r.text}</div>
        );
      })}
    </>
  );
};

// ---------- S4 · "Akhirnya berdiri juga. Agak miring, sih. … rak terbaik di dunia." + "Kenapa bisa begitu?" ----------
const StandScene: React.FC<{t: number}> = ({t}) => {
  const tAkh = a('akhirnya'), tBer = a('berdiri'), tJuga = a('juga'), tAgak = a('agak'), tMir = a('miring'), tTapi = a('tapi buat'), tRakT = a('rak terbaik'), tTerb = a('terbaik'), tDun = a('dunia'), tKen = a('kenapa'), tBisa = a('bisa'), tBeg = a('begitu');
  const cam = camera(t, {x: 540, y: 980, s: 1.0, r: 0}, [{from: tTapi, to: tTapi + 0.8, x: 560, y: 990, s: 1.07}, {from: tKen - 0.1, to: tKen + 0.5, x: 540, y: 1000, s: 0.98}]);
  const landAt = tBer + 0.12;
  const lying = 1 - p(t, tAkh + 0.1, landAt, Easing.bezier(0.45, 0, 0.35, 1.3));
  const sq = squash(t, landAt, 0.07);
  const tilt = 6 * p(t, tMir - 0.15, tMir + 0.55, Easing.out(Easing.back(2.6)));
  const k = Math.tan((tilt * Math.PI) / 180);
  const cheer = Math.sin(p(t, tJuga, tJuga + 0.45, Easing.linear) * Math.PI) * 60;
  const pain = t < tAkh ? Math.abs(Math.sin(t * 9)) * 36 : 0;
  const md = MEDAL_AT(740, 1.4);
  const mk = p(t, tRakT - 0.05, tTerb + 0.1, Easing.out(Easing.cubic));
  const mSwing = t > tTerb + 0.1 ? Math.sin((t - tTerb - 0.1) * 8) * 14 * Math.exp(-(t - tTerb - 0.1) * 2.5) : -30 * (1 - mk);
  const plumb = p(t, tMir, tMir + 0.4) * (1 - p(t, tTapi - 0.2, tTapi + 0.1));
  return (
    <AbsoluteFill>
      <Stage pose={cam}>
        <Backdrop t={t} seed={1} />
        <Plant x={95} y={FLOOR} s={1.05} t={t} />
        <g transform={`translate(740 ${FLOOR}) scale(${sq.sx} ${sq.sy}) translate(-740 ${-FLOOR})`}>
          <Shelf x={740} y={FLOOR} s={1.4} build={1} books={p(t, landAt, landAt + 0.6)} plant={pb(t, landAt + 0.3, landAt + 0.7)} lying={lying} tilt={tilt} />
        </g>
        <Puffs t={t} at={landAt} x={740} y={FLOOR} spread={200} />
        {plumb > 0 && (
          <g opacity={plumb}>
            <line x1={530} y1={FLOOR - 640} x2={530} y2={FLOOR} stroke={F.navy} strokeWidth={6} strokeDasharray="18 14" />
            <path d={`M 530 ${FLOOR - 520} A 120 120 0 0 1 ${530 + 120 * Math.sin(Math.atan(k))} ${FLOOR - 640 + 120 * Math.cos(Math.atan(k))}`} stroke={F.coral} strokeWidth={8} fill="none" strokeLinecap="round" />
          </g>
        )}
        {mk > 0 && <Medal x={lerp(1150, md.x, mk)} y={lerp(250, md.y, mk) - Math.sin(mk * Math.PI) * 120} s={0.9 * pb(t, tRakT - 0.05, tRakT + 0.3)} rot={mSwing} />}
        <SparkleField t={t} from={tTerb} until={tKen} x={740} y={1020} rx={300} ry={380} n={7} />
        <Burst t={t} at={tDun} x={740} y={760} n={26} seed={4} />
        <Dimas t={t} x={310} y={FLOOR} s={1.45} hop={pain + cheer}
          mood={stepAt<Mood>(t, [[0, 'pain'], [tAkh, 'happy'], [tJuga, 'proud'], [tAgak, 'curious'], [tTapi, 'proud'], [tKen, 'curious']])}
          thumbSwell={0.6 * (1 - p(t, tAkh, tAkh + 0.3))} bandage={t > tAkh + 0.15}
          armL={armAt(t, [[0, {a: 150, e: 40}], [tAkh, {a: 14, e: 6}], [tJuga, {a: 160, e: 15}], [tAgak + 0.1, {a: 14, e: 8}], [tTapi, {a: 40, e: -100}], [tKen, {a: 160, e: 30}]])}
          armR={armAt(t, [[0, {a: 30, e: -30}], [tAkh, {a: 82, e: -10}], [tJuga, {a: 160, e: 15}], [tAgak + 0.1, {a: 14, e: 8}], [tTapi, {a: 40, e: -100}], [tKen, {a: 14, e: 8}]])}
          tilt={keyAt(t, [[0, 0], [tAgak, 12], [tTapi, -6], [tKen, 4]])} lookX={keyAt(t, [[0, 0], [tAkh, 1], [tTapi, 0]])} lookY={keyAt(t, [[0, 0], [tKen, -1]])} />
        <DizzyStars t={t} x={310} y={600} q={1 - p(t, tAkh - 0.1, tAkh + 0.2)} rx={130} />
        {[{at: tKen, x: 150, y: 640, r: -14}, {at: tBisa, x: 500, y: 580, r: 12}, {at: tBeg, x: 330, y: 500, r: -4}].map((q, i) => (
          <QMark key={i} x={q.x} y={q.y + Math.sin(t * 5 + i) * 10} s={pb(t, q.at, q.at + 0.3)} rot={q.r} color={i === 1 ? F.coral : F.sun} />
        ))}
      </Stage>
      <Pill x={540} y={300} q={popIO(t, tMir, tTapi - 0.1)} bg={F.lilac} text="AGAK MIRING" size={60} rot={-5} />
      <Pill x={540} y={300} q={popIO(t, tTerb, tKen - 0.1)} bg={F.sun} color={F.navy} text="RAK TERBAIK DI DUNIA" size={56} />
      <Pill x={540} y={300} q={popIO(t, tKen, 99)} bg={F.navy} text="KENAPA BISA BEGITU?" size={54} />
    </AbsoluteFill>
  );
};

// ---------- S5 · "Para peneliti menyebutnya… efek IKEA." ----------
const TitleScene: React.FC<{t: number}> = ({t}) => {
  const tPen = a('peneliti'), tMen = a('menyebutnya'), tEfek = a('efek'), tIkea = a('ikea');
  const cam = camera(t, {x: 540, y: 1000, s: 1.04, r: 0}, [{from: T.title, to: tEfek, y: 980, s: 1.0}]);
  const mx = keyAt(t, [[T.title, 1250], [T.title + 0.1, 400], [tMen + 0.2, 760], [tEfek - 0.1, 1300]], 0.6);
  const my = keyAt(t, [[T.title, 1100], [T.title + 0.1, 820], [tMen + 0.2, 1000], [tEfek - 0.1, 640]], 0.6);
  const md = MEDAL_AT(740, 1.2);
  return (
    <AbsoluteFill>
      <Stage pose={cam}>
        <SpotStage t={t} />
        <Shelf x={740} y={FLOOR + 10} s={1.2} build={1} books={1} plant={1} tilt={6} />
        <Medal x={md.x} y={md.y + 10} s={0.75} rot={Math.sin(t * 2) * 4} />
        <Dimas t={t} x={330} y={FLOOR + 10} s={1.25} bandage mood={stepAt<Mood>(t, [[0, 'proud'], [tPen, 'curious'], [tEfek, 'shock'], [tIkea + 0.3, 'happy']])}
          armL={armAt(t, [[0, {a: 40, e: -100}], [tEfek, {a: 150, e: 20}]])} armR={armAt(t, [[0, {a: 40, e: -100}], [tEfek, {a: 150, e: 20}]])}
          lookX={keyAt(t, [[0, 0], [tPen, 1]])} lookY={keyAt(t, [[0, 0], [tEfek, -1]])} hop={Math.sin(p(t, tIkea, tIkea + 0.4, Easing.linear) * Math.PI) * 40} />
        {[{x: 160, y: 640, d: 0}, {x: 940, y: 700, d: 0.25}, {x: 560, y: 560, d: 0.5}].map((q, i) => (
          <QMark key={i} x={q.x} y={q.y + Math.sin(t * 4 + i) * 12} s={pb(t, tPen + q.d, tPen + q.d + 0.3) * (1 - p(t, tEfek - 0.3, tEfek))} rot={i % 2 ? 12 : -12} size={130} />
        ))}
        <Magnifier x={mx} y={my} s={1.1} rot={-30 + Math.sin(t * 3) * 6} />
      </Stage>
      <DropWord t={t} at={tEfek - 0.18} text="EFEK" size={220} top={210} color={F.sun} />
      <DropWord t={t} at={tIkea - 0.2} text="IKEA" size={220} top={430} color={F.coral} />
      <svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0}}>
        <path d="M 290 690 Q 540 650 800 684" stroke={F.sun} strokeWidth={16} fill="none" strokeLinecap="round" pathLength={1} strokeDasharray="1 2" strokeDashoffset={1 - p(t, tIkea + 0.25, tIkea + 0.6)} opacity={t > tIkea + 0.25 ? 1 : 0} />
        <SparkleField t={t} from={tIkea + 0.2} x={540} y={450} rx={430} ry={260} n={6} />
        <Burst t={t} at={tIkea + 0.25} x={540} y={520} n={24} seed={7} />
      </svg>
    </AbsoluteFill>
  );
};

// ---------- S6 · "Tahun 2011, Michael Norton, Daniel Mochon, dan Dan Ariely mengadakan percobaan." ----------
const LabScene: React.FC<{t: number}> = ({t}) => {
  const tTahun = a('tahun'), t2011 = a('2011'), tMeng = a('mengadakan');
  const cam = camera(t, {x: 540, y: 560, s: 1.45, r: 0}, [{from: t2011 + 0.3, to: a('michael') - 0.12, x: 540, y: 975, s: 1.02}, {from: tMeng, to: tMeng + 1.2, y: 985, s: 1.0}]);
  const R = [
    {x: 230, look: LOOKS.labGlasses, at: a('michael') - 0.3, name: 'Michael Norton', seed: 11},
    {x: 540, look: LOOKS.labNeat, at: a('daniel') - 0.3, name: 'Daniel Mochon', seed: 12},
    {x: 850, look: LOOKS.labCurly, at: a('dan ariely') - 0.3, name: 'Dan Ariely', seed: 13},
  ];
  const cal = pb(t, tTahun - 0.05, tTahun + 0.3);
  const tableY = lerp(1800, 1190, pio(t, tMeng - 0.1, tMeng + 0.35));
  return (
    <Stage pose={cam}>
      <Backdrop t={t} bg={F.lilac} circle="#A797F6" cy={700} r={430} sun={null} confetti={['#ffffff55', F.sun, '#ffffff33']} seed={3} />
      {cal > 0.01 && (
        <g transform={`translate(540 380) scale(${cal}) rotate(${-3 + Math.sin(t * 1.5) * 1.5})`}>
          <rect x={-200} y={-136} width={400} height={290} rx={26} fill="#22325A33" transform="translate(10 12)" />
          <rect x={-200} y={-136} width={400} height={290} rx={26} fill="#fff" />
          <path d="M -200 -110 Q -200 -136 -174 -136 L 174 -136 Q 200 -136 200 -110 L 200 -60 L -200 -60 Z" fill={F.coral} />
          {[-110, 110].map((rx) => <rect key={rx} x={rx - 10} y={-160} width={20} height={48} rx={10} fill={F.navy} />)}
          <text x={0} y={-84} textAnchor="middle" fill="#fff" style={{fontFamily: HEAD, fontWeight: 700, fontSize: 44, letterSpacing: 4}}>TAHUN</text>
          {'2011'.split('').map((d, i) => {
            const q = pb(t, t2011 - 0.1 + i * 0.07, t2011 + 0.2 + i * 0.07);
            return <text key={i} x={-120 + i * 80} y={100 + (1 - q) * -60} textAnchor="middle" opacity={Math.min(1, q * 2)} fill={F.navy} style={{fontFamily: HEAD, fontWeight: 700, fontSize: 150}}>{d}</text>;
          })}
        </g>
      )}
      {[250, 830].map((wx, i) => (
        <g key={wx}>
          <rect x={wx - 120} y={640} width={240} height={18} rx={6} fill={F.brown} />
          {[-90, 90].map((bx) => <path key={bx} d={`M ${wx + bx} 658 l 0 34 l ${bx > 0 ? -24 : 24} -34 Z`} fill="#6D4329" />)}
          <Beaker x={wx - 50} y={632} t={t + i} s={0.5} c={i ? F.coral : F.teal} />
          <Beaker x={wx + 40} y={632} t={t + i * 2 + 1} s={0.4} c={i ? F.sun : F.coral} />
          <rect x={wx + 76} y={584} width={18} height={56} rx={4} fill={i ? F.teal : F.lilac} /><rect x={wx + 96} y={594} width={16} height={46} rx={4} fill={F.navy} />
        </g>
      ))}
      <SvgPill x={540} y={610} q={pb(t, tMeng + 0.2, tMeng + 0.5)} text="PERCOBAAN" bg={F.coral} size={48} />
      {R.map((r, i) => {
        const wave = Math.sin(t * 13 + i) * 22;
        return (
          <React.Fragment key={i}>
            <Person t={t} x={r.x} y={FLOOR} s={1.05} look={r.look} seed={r.seed} at={r.at} mood={stepAt<Mood>(t, [[0, 'happy'], [tMeng, i === 1 ? 'curious' : 'happy']])}
              armL={armAt(t, [[0, {a: 14, e: 6}], [r.at + 0.35, {a: 150, e: 20 + wave}], [r.at + 1.2, {a: 14, e: 6}]])}
              armR={armAt(t, [[0, {a: 14, e: 6}], [tMeng + i * 0.1, {a: 40, e: -80, tool: 'clipboard', toolRot: -40}]])} lookX={i === 0 ? 0.6 : i === 2 ? -0.6 : 0} />
            <SvgPill x={r.x} y={772} q={pb(t, r.at + 0.2, r.at + 0.5)} text={r.name} bg={F.navy} size={34} upper={false} />
          </React.Fragment>
        );
      })}
      {tableY < 1790 && (
        <g>
          <Table x={540} y={tableY} w={960} legs={260} />
          <g transform={`translate(0 ${tableY - 1190})`}>
            <StorageBox x={290} y={1182} s={0.62} fold={0.1} />
            <Beaker x={540} y={1180} t={t} s={0.8} />
            <StorageBox x={790} y={1182} s={0.62} fold={1} />
          </g>
        </g>
      )}
    </Stage>
  );
};

// ---------- S7 · two groups: build it yourself vs. get it finished; "mau bayar berapa?" ----------
const GroupsScene: React.FC<{t: number}> = ({t}) => {
  const tSeb = a('sebagian'), tMer = a('merakit'), tKot = a('kotak'), tPeny = a('penyimpanan'), tSeb2 = a('sebagian lagi'), tDik = a('dikasih'), tJadi = a('sudah jadi');
  const tSem = a('semuanya'), tMau = a('mau bayar'), tYm = a('yang merakit'), tBerani = a('berani');
  const slide = pio(t, tSeb2 - 0.15, tSeb2 + 0.4);
  const fold = pio(t, tKot - 0.1, tPeny + 0.5);
  const work = t < tPeny + 0.5 ? Math.sin(t * 9) * 6 : 0;
  const dim = 0.35 * p(t, tYm - 0.1, tYm + 0.3);
  const boxB = land(t, tDik - 0.25, 900);
  const tagL = 0.8 * pb(t, tMau, tMau + 0.3) * (1 + 0.4 * pb(t, tBerani, tBerani + 0.35));
  const tagR = 0.8 * pb(t, tMau + 0.12, tMau + 0.42) * (1 - 0.1 * p(t, tBerani, tBerani + 0.3));
  const drift = Math.sin(t * 0.6) * 6;
  const leftW = 1080 - 540 * slide;
  return (
    <AbsoluteFill>
      {/* left panel: builds it */}
      <div style={{position: 'absolute', left: 0, top: 0, width: leftW, height: 1920, overflow: 'hidden', background: F.sun}}>
        <svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0, overflow: 'visible'}}>
          <g transform={`translate(${-270 * slide + drift} 0)`}>
            <circle cx={540} cy={760} r={400} fill="#FFD66E" />
            <rect x={-600} y={FLOOR} width={2280} height={700} fill={F.floor} />
            <rect x={-600} y={FLOOR} width={2280} height={10} fill="#22325A18" />
            <Table x={690} y={1160} w={250} legs={230} color={F.brown} />
            <Person t={t} x={430} y={FLOOR} s={1.4} look={LOOKS.bunCoral} seed={21} at={tSeb - 0.25}
              mood={stepAt<Mood>(t, [[0, 'curious'], [tPeny + 0.5, 'happy'], [tSem, 'curious'], [tYm, 'proud']])}
              armR={armAt(t, [[0, {a: 75 + work, e: -30}], [tPeny + 0.6, {a: 14, e: 6}], [tYm, {a: 40, e: -100}]])}
              armL={armAt(t, [[0, {a: -30, e: -30 - work}], [tPeny + 0.6, {a: 14, e: 6}], [tYm, {a: 40, e: -100}]])} lookX={keyAt(t, [[0, 1], [tPeny + 0.6, 0]])} lookY={keyAt(t, [[0, 0.6], [tPeny + 0.6, 0]])} />
            <StorageBox x={690} y={1152} s={1.1} fold={fold} />
            <QMark x={590} y={600} s={pb(t, tSem, tSem + 0.3) * (1 - p(t, tMau - 0.1, tMau + 0.1))} rot={10} size={130} />
            <PriceTag x={690} y={680} s={tagL} swing={Math.sin(t * 2.4) * 6} string={300} text="?" color={F.cream} size={90} />
            <SvgPill x={540} y={360} q={pb(t, tMer, tMer + 0.3)} text="RAKIT SENDIRI" bg={F.coral} size={46} />
          </g>
        </svg>
      </div>
      {/* right panel: gets it finished */}
      {slide > 0 && (
        <div style={{position: 'absolute', left: 540, top: 0, width: 540, height: 1920, overflow: 'hidden', background: F.sky, transform: `translateX(${540 * (1 - slide)}px)`}}>
          <svg width={540} height={1920} style={{position: 'absolute', left: 0, top: 0, overflow: 'visible'}}>
            <g transform={`translate(${-drift} 0)`}>
              <circle cx={270} cy={760} r={300} fill="#D5EFF7" />
              <rect x={-300} y={FLOOR} width={1200} height={700} fill={F.floor} />
              <rect x={-300} y={FLOOR} width={1200} height={10} fill="#22325A18" />
              <Table x={140} y={1160} w={230} legs={230} color={F.brown} />
              {boxB.on && <StorageBox x={140} y={1152 + boxB.dy} s={1.1 * boxB.sx} fold={1} />}
              <Person t={t} x={385} y={FLOOR} s={1.35} look={LOOKS.shortLilac} seed={22} mood={stepAt<Mood>(t, [[0, 'happy'], [tSem, 'curious'], [tYm, 'meh']])}
                armL={armAt(t, [[0, {a: 14, e: 6}], [tDik, {a: 70, e: -20}], [tJadi + 0.4, {a: 14, e: 6}]])} lookX={keyAt(t, [[0, -1], [tJadi + 0.4, 0]])} />
              <QMark x={200} y={640} s={pb(t, tSem + 0.12, tSem + 0.42) * (1 - p(t, tMau - 0.1, tMau + 0.1))} rot={-10} size={130} />
              <PriceTag x={140} y={680} s={tagR} swing={Math.sin(t * 2.1 + 1) * 6} string={300} text="?" color={F.cream} size={90} />
              <SvgPill x={270} y={360} q={pb(t, tJadi, tJadi + 0.3)} text="SUDAH JADI" bg={F.navy} size={46} />
              {dim > 0 && <rect x={-100} y={-100} width={800} height={2200} fill={F.navy} opacity={dim} />}
            </g>
          </svg>
        </div>
      )}
      {slide > 0 && <div style={{position: 'absolute', left: 1080 - 540 * slide - 6, top: 0, width: 12, height: 1920, background: '#fff'}} />}
      <Pill x={540} y={210} q={popIO(t, tMau, 99)} bg={F.navy} text="MAU BAYAR BERAPA?" size={56} />
    </AbsoluteFill>
  );
};

// ---------- S7b · "…sekitar 60% lebih mahal… untuk kotak yang sama persis." ----------
const PriceScene: React.FC<{t: number}> = ({t}) => {
  const tSek = a('sekitar'), t60 = a('60'), tKot = a('kotak', 2), tSama = a('sama persis');
  const cam = camera(t, {x: 540, y: 980, s: 1.04, r: 0}, [{from: T.price, to: tSama + 0.8, x: 540, y: 960, s: 1.0}]);
  const hL = 624 * pb(t, T.price + 0.15, tSek + 0.55), hR = 384 * pb(t, T.price + 0.25, tSek + 0.65);
  const vL = 0.78 * p(t, T.price + 0.2, tSek + 0.7), vR = 0.48 * p(t, T.price + 0.3, tSek + 0.8);
  const badge = pb(t, t60 - 0.05, t60 + 0.3);
  const sqB = squash(t, t60 + 0.2, 0.2);
  const eq = pb(t, tKot - 0.05, tKot + 0.3);
  const yL = FLOOR - hL, yR = FLOOR - hR;
  const people = [
    {x: 300, y: yL, look: LOOKS.bunCoral, mood: 'proud' as Mood, seed: 21},
    {x: 780, y: yR, look: LOOKS.shortLilac, mood: (t > tKot ? 'happy' : 'meh') as Mood, seed: 22},
  ];
  return (
    <AbsoluteFill>
      <Stage pose={cam}>
        <Backdrop t={t} seed={5} />
        {[{x: 300, h: hL, c: F.coral, l: 'RAKIT SENDIRI', v: vL}, {x: 780, h: hR, c: F.lilac, l: 'SUDAH JADI', v: vR}].map((pd, i) => pd.h > 1 && (
          <g key={i}>
            <rect x={pd.x - 190} y={FLOOR - pd.h} width={380} height={pd.h + 6} rx={18} fill={pd.c} />
            <rect x={pd.x - 190} y={FLOOR - pd.h} width={380} height={22} rx={10} fill="#ffffff55" />
            <text x={pd.x} y={FLOOR - pd.h + 84} textAnchor="middle" fill="#fff" opacity={p(pd.h, 100, 140)} style={{fontFamily: HEAD, fontWeight: 700, fontSize: 40, letterSpacing: 2}}>{pd.l}</text>
            <text x={pd.x} y={FLOOR - pd.h + 196} textAnchor="middle" fill="#fff" opacity={p(pd.h, 220, 270)} style={{fontFamily: HEAD, fontWeight: 700, fontSize: 104}}>${pd.v.toFixed(2)}</text>
          </g>
        ))}
        {people.map((pp, i) => (
          <React.Fragment key={i}>
            <Person t={t} x={pp.x} y={pp.y} s={0.9} look={pp.look} seed={pp.seed} mood={pp.mood} armL={{a: 25, e: -95}} armR={{a: 25, e: -95}} />
            <StorageBox x={pp.x} y={pp.y - 0.9 * 140} s={0.66} fold={1} />
          </React.Fragment>
        ))}
        {/* same box: dashed link + "=" */}
        {eq > 0.01 && (
          <g>
            <line x1={340} y1={yL - 0.9 * 140 - 50} x2={740} y2={yR - 0.9 * 140 - 50} stroke={F.navy} strokeWidth={6} strokeDasharray="14 12" opacity={Math.min(1, eq)} />
            <g transform={`translate(540 ${(yL + yR) / 2 - 0.9 * 140 - 50}) scale(${eq * (1 - p(t, tSama - 0.12, tSama + 0.05))})`}>
              <circle r={56} fill={F.sun} stroke={F.navy} strokeWidth={6} />
              <text y={30} textAnchor="middle" fill={F.navy} style={{fontFamily: HEAD, fontWeight: 700, fontSize: 90}}>=</text>
            </g>
          </g>
        )}
        <SvgPill x={540} y={(yL + yR) / 2 - 0.9 * 140 - 50} q={pb(t, tSama - 0.02, tSama + 0.3)} text="SAMA PERSIS" bg={F.navy} size={46} />
      </Stage>
      {badge > 0.01 && (
        <svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0}}>
          <g transform={`translate(560 290) scale(${badge * sqB.sx} ${badge * sqB.sy}) rotate(-6)`}>
            <circle r={150} fill={F.sun} />
            <circle r={126} fill={F.coral} />
            <text y={34} textAnchor="middle" fill="#fff" style={{fontFamily: HEAD, fontWeight: 700, fontSize: 104}}>+60%</text>
          </g>
          <SparkleField t={t} from={t60 + 0.2} x={560} y={290} rx={200} ry={170} n={5} />
        </svg>
      )}
    </AbsoluteFill>
  );
};

// ---------- S8 · "Di percobaan lain, orang melipat origami sendiri. Hasilnya? Jelek!" ----------
const FoldScene: React.FC<{t: number}> = ({t}) => {
  const tDiP = a('di percobaan'), tMel = a('melipat'), tOri = a('origami'), tSen = a('sendiri', 3), tHas = a('hasilnya'), tJel = a('jelek');
  const cam = camera(t, {x: 540, y: 960, s: 1.0, r: 0}, [{from: tHas - 0.1, to: tJel, x: 620, y: 950, s: 1.1}]);
  const punch = 0.05 * (pb(t, tJel, tJel + 0.12) - p(t, tJel + 0.12, tJel + 0.6));
  const fold1 = pio(t, tMel - 0.05, tMel + 0.35), fold2 = pio(t, tOri + 0.1, tOri + 0.45);
  const paperS = 1.2 * pb(t, T.fold + 0.2, T.fold + 0.5) * (1 - p(t, tJel - 0.25, tJel - 0.02)) * (1 + 0.15 * Math.sin(p(t, tHas, tJel, Easing.linear) * Math.PI * 3));
  const spin = 360 * pio(t, tHas, tJel - 0.05);
  const hopS = Math.sin(p(t, tSen, tSen + 0.4, Easing.linear) * Math.PI) * 30;
  return (
    <AbsoluteFill>
      <Stage pose={{...cam, s: cam.s + punch}}>
        <Backdrop t={t} circle="#FFD9CB" cx={640} cy={860} r={420} seed={6} />
        <Table x={720} y={1110} w={380} legs={280} />
        <Person t={t} x={270} y={FLOOR} s={1.45} look={LOOKS.curlySun} seed={31} hop={hopS}
          mood={stepAt<Mood>(t, [[0, 'curious'], [tSen, 'happy'], [tHas, 'curious'], [tJel, 'proud']])}
          armR={armAt(t, [[0, {a: 95, e: -15}], [tHas, {a: 30, e: -10}], [tJel, {a: 150, e: 20}]])}
          armL={armAt(t, [[0, {a: -40, e: -40}], [tHas, {a: 14, e: 6}], [tJel, {a: 150, e: 20}]])} lookX={keyAt(t, [[0, 1], [tJel, 0.4]])} lookY={keyAt(t, [[0, 0.3], [tJel, 0]])} />
        {paperS > 0.01 && <PaperFold x={720} y={880} s={paperS} fold1={fold1} fold2={fold2} rot={spin} />}
        <Frog x={720} y={1100} s={1.25 * pb(t, tJel, tJel + 0.3)} crumple={1} seed={5} />
        {[{x: 560, y: 740, d: 0}, {x: 900, y: 700, d: 0.2}].map((q, i) => <QMark key={i} x={q.x} y={q.y} s={pb(t, tHas + q.d, tHas + q.d + 0.3) * (1 - p(t, tJel - 0.1, tJel + 0.05))} rot={i ? 12 : -12} size={120} />)}
        <SvgPill x={760} y={720} q={pb(t, tJel + 0.05, tJel + 0.3)} text="JELEK!" bg={F.red} size={96} rot={-9} />
      </Stage>
      <Pill x={540} y={300} q={popIO(t, tDiP + 0.05, tOri - 0.05)} bg={F.navy} text="PERCOBAAN LAIN" size={56} />
      <Pill x={540} y={300} q={popIO(t, tOri, tHas - 0.05)} bg={F.teal} text="LIPAT ORIGAMI SENDIRI" size={52} />
      <Pill x={540} y={300} q={popIO(t, tHas, 99)} bg={F.sun} color={F.navy} text="HASILNYA?" size={58} />
    </AbsoluteFill>
  );
};

// ---------- S9 · "Orang lain menganggapnya hampir nggak ada harganya." ----------
const CriticsScene: React.FC<{t: number}> = ({t}) => {
  const tOr = a('orang lain'), tHam = a('hampir nggak'), tNg = a('nggak'), tHarg = a('harganya');
  const cam = camera(t, {x: 540, y: 1000, s: 1.06, r: 0}, [{from: T.critics, to: tHarg + 0.6, x: 540, y: 980, s: 1.0}]);
  const shakeHead = t > tNg - 0.1 && t < tHarg + 0.5 ? Math.sin(t * 16) * 10 : 0;
  const tagY = lerp(-200, 760, pb(t, tHam - 0.1, tHam + 0.3));
  return (
    <AbsoluteFill>
      <Stage pose={cam}>
        <Backdrop t={t} circle="#DCD5FB" seed={8} />
        <Table x={540} y={1170} w={320} legs={220} />
        <Frog x={540} y={1162} s={1.05} crumple={1} seed={5} />
        {t > tHam - 0.1 && <PriceTag x={540} y={tagY} s={0.85} swing={Math.sin((t - tHam) * 6) * 12 * Math.exp(-(t - tHam) * 1.5)} string={420} text="$0.05" color={F.cream} size={64} />}
        <Person t={t} x={190} y={FLOOR} s={1.35} look={LOOKS.shortLilac} seed={41} at={T.critics + 0.05} mood={stepAt<Mood>(t, [[0, 'meh'], [tNg, 'sad']])} armL={{a: 25, e: -125}} armR={{a: 25, e: -125}} lookX={1} lookY={0.5} tilt={shakeHead} />
        <Person t={t} x={890} y={FLOOR} s={1.35} look={CRITIC2} seed={42} at={T.critics + 0.18} mood="meh" armL={{a: 25, e: -125}} armR={armAt(t, [[0, {a: 25, e: -125}], [tHam, {a: 60, e: 40}], [tHarg + 0.4, {a: 25, e: -125}]])} lookX={-1} lookY={0.5} tilt={-shakeHead} />
      </Stage>
      <Pill x={540} y={300} q={popIO(t, tOr, tHam - 0.05)} bg={F.navy} text="MENURUT ORANG LAIN" size={52} />
      <Pill x={540} y={300} q={popIO(t, tHam, 99)} bg={F.coral} text="HAMPIR NGGAK ADA HARGANYA" size={44} />
    </AbsoluteFill>
  );
};

// ---------- S10 · "Tapi pembuatnya menghargai origami itu… hampir semahal origami buatan ahli." ----------
const ValueScene: React.FC<{t: number}> = ({t}) => {
  const tPem = a('pembuatnya'), tMengh = a('menghargai'), tOit = a('origami itu'), tHs = a('hampir semahal'), tSem = a('semahal'), tBuat = a('buatan ahli'), tAhli = a('ahli');
  const cam = camera(t, {x: 470, y: 945, s: 1.05, r: 0}, [{from: tHs - 0.25, to: tSem + 0.3, x: 540, y: 980, s: 1.0}]);
  const h1 = 115 * pb(t, T.value + 0.15, T.value + 0.55), h2 = 529 * pb(t, tMengh - 0.05, tMengh + 0.55), h3 = 621 * pb(t, tSem - 0.05, tSem + 0.55);
  const pods = [
    {x: 190, h: h1, c: F.navy, v: '$0.05', l: ''},
    {x: 520, h: h2, c: F.coral, v: '$0.23', l: 'PEMBUAT'},
    {x: 850, h: h3, c: F.teal, v: '$0.27', l: 'AHLI'},
  ];
  const y2 = FLOOR - h2;
  return (
    <AbsoluteFill>
      <Stage pose={cam}>
        <Backdrop t={t} seed={9} />
        {pods.map((pd, i) => pd.h > 1 && (
          <g key={i}>
            <rect x={pd.x - 135} y={FLOOR - pd.h} width={270} height={pd.h + 6} rx={16} fill={pd.c} />
            <rect x={pd.x - 135} y={FLOOR - pd.h} width={270} height={20} rx={10} fill="#ffffff55" />
            {pd.l && <text x={pd.x} y={FLOOR - pd.h + 74} textAnchor="middle" fill="#fff" opacity={p(pd.h, 90, 130)} style={{fontFamily: HEAD, fontWeight: 700, fontSize: 40, letterSpacing: 2}}>{pd.l}</text>}
            <text x={pd.x} y={FLOOR - pd.h + (i === 0 ? 76 : 164)} textAnchor="middle" fill="#fff" opacity={i === 0 ? p(pd.h, 80, 105) : p(pd.h, 190, 240)} style={{fontFamily: HEAD, fontWeight: 700, fontSize: i === 0 ? 56 : 84}}>{pd.v}</text>
          </g>
        ))}
        {/* critics' view: the ugly frog on a short podium */}
        <Frog x={190} y={FLOOR - h1} s={0.68} crumple={1} seed={5} />
        <SvgPill x={190} y={FLOOR - h1 - 190} q={pb(t, T.value + 0.3, T.value + 0.6)} text="ORANG LAIN" bg={F.navy} size={34} />
        {/* the maker hugs the same frog, lifted by his own valuation */}
        <Person t={t} x={520} y={y2} s={0.8} look={LOOKS.curlySun} seed={31} at={T.value + 0.05} mood={stepAt<Mood>(t, [[0, 'happy'], [tMengh, 'love']])} armL={{a: 25, e: -95}} armR={{a: 25, e: -95}} />
        <Frog x={520} y={y2 - 0.8 * 120} s={0.42 * pb(t, T.value + 0.35, T.value + 0.6)} crumple={1} seed={5} happy />
        <Heart x={650} y={y2 - 0.8 * 470} s={0.55 * pb(t, tOit, tOit + 0.3) * (1 + Math.sin(t * 8) * 0.06)} rot={10} />
        <Frog x={850} y={FLOOR - h3} s={0.75 * pb(t, tSem, tSem + 0.35)} crumple={0} happy />
        <SparkleField t={t} from={tBuat} x={850} y={FLOOR - h3 - 70} rx={160} ry={110} n={5} />
        {(() => {
          const q = pb(t, tAhli - 0.05, tAhli + 0.3);
          return q > 0.01 ? (
            <g transform={`translate(685 ${FLOOR - 640}) scale(${q})`}>
              <circle r={52} fill={F.sun} stroke={F.navy} strokeWidth={6} />
              <text y={30} textAnchor="middle" fill={F.navy} style={{fontFamily: HEAD, fontWeight: 700, fontSize: 84}}>≈</text>
            </g>
          ) : null;
        })()}
      </Stage>
      <Pill x={540} y={300} q={popIO(t, tPem, tHs - 0.05)} bg={F.coral} text="MENURUT PEMBUATNYA" size={52} />
      <Pill x={540} y={300} q={popIO(t, tHs, 99)} bg={F.teal} text="HAMPIR SEMAHAL BUATAN AHLI" size={44} />
    </AbsoluteFill>
  );
};

// ---------- S11 · "Usaha bikin kita merasa memiliki. Capeknya ikut masuk ke harga." ----------
const EffortScene: React.FC<{t: number}> = ({t}) => {
  const tUs = a('usaha'), tMer = a('merasa'), tMil = a('memiliki'), tCap = a('capeknya'), tHar = a('harga');
  const cam = camera(t, {x: 540, y: 980, s: 1.02, r: 0}, [{from: tCap - 0.2, to: tCap + 0.6, x: 600, y: 990, s: 1.07}]);
  const md = MEDAL_AT(750, 1.4);
  const drops = [0, 1, 2, 3].map((i) => tCap + 0.05 + i * 0.28);
  const hits = drops.reduce((n, d) => n + pb(t, d + 0.35, d + 0.55), 0);
  const tagS = (0.6 + 0.16 * hits) * pb(t, tCap - 0.1, tCap + 0.2) * (1 + 0.12 * (pb(t, tHar, tHar + 0.15) - p(t, tHar + 0.15, tHar + 0.5)));
  const TAG = {x: 650, y: 965};
  return (
    <AbsoluteFill>
      <Stage pose={cam}>
        <Backdrop t={t} seed={1} />
        <Plant x={95} y={FLOOR} s={1.05} t={t} />
        <Shelf x={750} y={FLOOR} s={1.4} build={1} books={1} plant={1} tilt={6} />
        <Medal x={md.x} y={md.y} s={0.85} rot={Math.sin(t * 2) * 4} />
        <Dimas t={t} x={320} y={FLOOR} s={1.45} bandage sweat={t < tMil - 0.1 || t > tCap ? 1 : 0} lean={keyAt(t, [[0, 0], [tMil - 0.2, 7], [tCap, 0]])}
          mood={stepAt<Mood>(t, [[0, 'pain'], [tMil - 0.1, 'love'], [tCap, 'pain'], [tHar, 'proud']])}
          armR={armAt(t, [[0, {a: 88 + Math.sin(t * 14) * 10, e: -18, tool: 'screwdriver'}], [tMil - 0.2, {a: 100, e: 10}], [tCap, {a: 30, e: -30}], [tHar, {a: 150, e: 15}]])}
          armL={armAt(t, [[0, {a: 20, e: 10}], [tMil - 0.2, {a: 40, e: -100}], [tCap, {a: 165, e: 70}], [tHar, {a: 40, e: -100}]])} lookX={keyAt(t, [[0, 1], [tCap, 1]])} />
        <Heart x={560} y={600} s={0.7 * pb(t, tMil - 0.05, tMil + 0.3) * (1 + Math.sin(t * 8) * 0.05)} rot={-8} />
        {tagS > 0.01 && (
          <g>
            <PriceTag x={TAG.x} y={TAG.y} s={tagS} swing={Math.sin(t * 3) * 5} string={190} text="" color={F.sun} />
            <Heart x={TAG.x} y={TAG.y + 92 * tagS} s={0.42 * tagS} />
          </g>
        )}
        {drops.map((d, i) => {
          if (t < d || t > d + 0.38) return null;
          const k = p(t, d, d + 0.35, Easing.linear);
          const x = lerp(400, TAG.x, k), y = lerp(720, TAG.y + 80, k) - Math.sin(k * Math.PI) * 240;
          return <path key={i} d="M 0 -26 Q 22 8 0 26 Q -22 8 0 -26 Z" fill={F.sky} stroke={F.navy} strokeWidth={5} transform={`translate(${x} ${y}) rotate(${lerp(-40, 60, k)}) scale(1.5)`} />;
        })}
        <SparkleField t={t} from={tHar} x={TAG.x} y={TAG.y + 90} rx={170} ry={150} n={5} />
      </Stage>
      <Pill x={540} y={300} q={popIO(t, tUs, tMer - 0.05)} bg={F.navy} text="USAHA" size={64} />
      <Pill x={540} y={300} q={popIO(t, tMer, tCap - 0.05)} bg={F.coral} text="MERASA MEMILIKI" size={56} />
      <Pill x={540} y={300} q={popIO(t, tCap, 99)} bg={F.sun} color={F.navy} text="CAPEKNYA MASUK KE HARGA" size={46} />
    </AbsoluteFill>
  );
};

// ---------- S12 · "Tapi ada syaratnya: harus selesai. Kalau rakitannya gagal, atau dibongkar lagi… efeknya hilang." ----------
const RuleScene: React.FC<{t: number}> = ({t}) => {
  const tTA = a('tapi ada'), tSy = a('syaratnya'), tSel = a('selesai'), tKal = a('kalau rakitannya'), tGag = a('gagal'), tDib = a('dibongkar'), tEfn = a('efeknya'), tHil = a('hilang');
  const cam = camera(t, {x: 540, y: 980, s: 1.03, r: 0}, [{from: tKal, to: tGag + 0.4, x: 600, y: 1010, s: 1.08}, {from: tEfn - 0.2, to: tHil + 0.4, x: 560, y: 990, s: 1.02}]);
  const card = land(t, tSy - 0.2, 700);
  const collapse = p(t, tGag, tGag + 0.75);
  const into = pio(t, tDib, tDib + 0.5);
  const boxQ = pb(t, tDib - 0.15, tDib + 0.15);
  const md = MEDAL_AT(760, 1.3);
  const mFall = p(t, tGag + 0.05, tGag + 0.5, FALL);
  const heartS = 0.75 * pb(t, T.rule + 0.3, T.rule + 0.6) * (1 - p(t, tHil, tHil + 0.3));
  return (
    <AbsoluteFill>
      <Stage pose={cam} off={shake(t, [tGag + 0.45], 14, 0.35)}>
        <SpotStage t={t} />
        <g opacity={1 - p(t, tDib + 0.3, tDib + 0.5)} transform={`translate(${lerp(0, 0, into)} ${lerp(0, -380, into)}) translate(760 ${FLOOR}) scale(${lerp(1, 0.25, into)}) translate(-760 ${-FLOOR})`}>
          <Shelf x={760} y={FLOOR} s={1.3} build={1} books={1} plant={1} tilt={6} collapse={collapse} />
        </g>
        {boxQ > 0.01 && <FlatBox x={760} y={FLOOR} s={1.05 * boxQ} open={1 - p(t, tDib + 0.5, tDib + 0.8)} />}
        {t < tGag + 0.6 && <Medal x={md.x - mFall * 80} y={md.y + mFall * 520} s={0.75} rot={Math.sin(t * 2) * 4 + mFall * -90} />}
        <Heart x={560} y={660} s={heartS} crack={p(t, tGag + 0.15, tGag + 0.45)} deflate={p(t, tEfn, tEfn + 0.45)} rot={Math.sin(t * 2) * 4} />
        <Dimas t={t} x={320} y={FLOOR} s={1.3} bandage mood={stepAt<Mood>(t, [[0, 'proud'], [tKal, 'curious'], [tGag + 0.1, 'shock'], [tDib, 'sad']])}
          armL={armAt(t, [[0, {a: 40, e: -100}], [tKal, {a: 14, e: 6}], [tGag + 0.1, {a: 150, e: 30}], [tDib, {a: 10, e: 4}]])}
          armR={armAt(t, [[0, {a: 40, e: -100}], [tKal, {a: 14, e: 6}], [tGag + 0.1, {a: 150, e: 30}], [tDib, {a: 10, e: 4}]])}
          lookX={keyAt(t, [[0, 0], [tKal, 1]])} tilt={keyAt(t, [[0, -4], [tDib, 8]])} />
      </Stage>
      <svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0}}>
        {card.on && <g transform={`translate(0 ${card.dy})`}><CheckCard x={540} y={440} s={1} text="HARUS SELESAI" tick={p(t, tSel, tSel + 0.35)} cross={p(t, tGag + 0.05, tGag + 0.35)} w={660} /></g>}
      </svg>
      <Pill x={540} y={250} q={popIO(t, tTA, tHil - 0.05)} bg={F.sun} color={F.navy} text="SYARATNYA:" size={54} />
      <Pill x={540} y={250} q={popIO(t, tHil, 99)} bg={F.coral} text="EFEKNYA HILANG" size={56} rot={-3} />
    </AbsoluteFill>
  );
};

// ---------- S13 · "Jadi kalau kamu sayang banget … itu wajar. Itu bukan cuma barang. Itu jerih payahmu." + end card ----------
const EndScene: React.FC<{t: number}> = ({t}) => {
  const tSay = a('sayang'), tWaj = a('itu wajar'), tBuk = a('itu bukan'), tJer = a('jerih');
  const cam = camera(t, {x: 560, y: 1000, s: 1.0, r: 0}, [{from: T.end, to: tJer - 0.2, x: 570, y: 990, s: 1.06}, {from: tJer - 0.2, to: tJer + 0.7, x: 540, y: 970, s: 1.0}]);
  const md = MEDAL_AT(760, 1.45);
  const heartBase = pb(t, tSay - 0.05, tSay + 0.3) * (1 + 0.15 * pb(t, tJer + 0.3, tJer + 0.6));
  const HX = 640, HY = 585;
  const icons = [
    {x: 250, y: 470, at: tBuk + 0.15, k: 'clock'},
    {x: 600, y: 400, at: tBuk + 0.4, k: 'plaster'},
    {x: 900, y: 480, at: tBuk + 0.65, k: 'screw'},
  ];
  const wave = Math.sin(t * 12) * 22;
  return (
    <AbsoluteFill>
      <Stage pose={cam}>
        <Backdrop t={t} circle="#FFDF96" cy={780} r={470} sun={null} seed={10} />
        <Plant x={95} y={FLOOR} s={1.05} t={t} />
        <Shelf x={760} y={FLOOR} s={1.45} build={1} books={1} plant={1} tilt={6} />
        <Medal x={md.x} y={md.y} s={0.85} rot={Math.sin(t * 2) * 4} />
        <Dimas t={t} x={350} y={FLOOR} s={1.5} bandage lean={keyAt(t, [[0, 6], [tJer + 0.4, 0]])} mood={stepAt<Mood>(t, [[0, 'love'], [tWaj, 'happy'], [tSay + 0.0, 'love'], [tJer + 0.4, 'proud']])}
          armR={armAt(t, [[0, {a: 100, e: 5}], [tJer + 0.4, {a: 40, e: -100}]])}
          armL={armAt(t, [[0, {a: 20, e: 10}], [tJer + 0.6, {a: 150, e: 20 + wave}]])} tilt={keyAt(t, [[0, 8], [tJer + 0.4, -4]])} />
        <SparkleField t={t} from={tSay} x={HX} y={HY} rx={190} ry={150} n={6} />
        <Heart x={HX} y={HY} s={heartBase * (1 + Math.sin(t * 7) * 0.05)} />
        {icons.map((ic, i) => {
          const q = pb(t, ic.at, ic.at + 0.3);
          if (q <= 0.01) return null;
          const fly = pio(t, tJer - 0.05 + i * 0.08, tJer + 0.35 + i * 0.08);
          if (fly >= 1) return null;
          const x = lerp(ic.x, HX, fly), y = lerp(ic.y + Math.sin(t * 3 + i) * 8, HY, fly), sc = q * (1 - 0.8 * fly);
          return (
            <g key={i} transform={`translate(${x} ${y}) scale(${sc})`}>
              <circle r={78} fill="#fff" stroke={F.navy} strokeWidth={6} />
              {ic.k === 'clock' && <Clock x={0} y={0} r={52} hours={2} />}
              {ic.k === 'plaster' && <Plaster x={0} y={0} s={0.8} rot={-25} />}
              {ic.k === 'screw' && <Screw x={0} y={-30} s={1.1} rot={-20} />}
            </g>
          );
        })}
        <Burst t={t} at={tJer + 0.35} x={HX} y={HY} n={28} seed={12} />
      </Stage>
      <Pill x={540} y={290} q={popIO(t, tWaj, tBuk - 0.05)} bg={F.teal} text="ITU WAJAR" size={60} />
      <Pill x={540} y={290} q={popIO(t, tBuk, tJer - 0.15)} bg={F.navy} text="BUKAN CUMA BARANG" size={54} />
      <DropWord t={t} at={tJer - 0.05} text="JERIH" size={160} top={150} color={F.coral} shadow="0 10px 0 #22325A26" />
      <DropWord t={t} at={a('payahmu') - 0.12} text="PAYAHMU" size={160} top={310} color={F.navy} stagger={0.05} shadow="0 10px 0 #22325A26" />
      <Pill x={540} y={1480} q={pb(t, C.duration + 0.05, C.duration + 0.4)} bg={F.lilac} text="EFEK IKEA" size={48} />
    </AbsoluteFill>
  );
};

// Draft renders before music/SFX exist: `--props='{"silentDraft":true}'` skips the audio assets (Remotion fetches them even with --muted).
const SILENT_DRAFT = (getInputProps() as {silentDraft?: boolean}).silentDraft === true;

export const EfekIkeaEpisode: React.FC = () => {
  const {t} = useTime();
  const dark = (t >= T.title + 0.25 && t < T.lab + 0.25) || (t >= T.rule + 0.25 && t < T.end + 0.25);
  return (
    <AbsoluteFill style={{background: F.bg, overflow: 'hidden'}}>
      <StyleFonts />
      {!SILENT_DRAFT && <EpisodeAudio vo="audio/vo/flatlife.mp3" words={C.words} music="audio/music/flatlife.wav" bed={0.5} duck={0.18} sfx={FLATLIFE_SFX} />}
      <IrisScene t={t} from={0} to={T.clock}><Intro t={t} /></IrisScene>
      <IrisScene t={t} from={T.clock} to={T.thumb} cx={700} cy={620}><ClockScene t={t} /></IrisScene>
      <IrisScene t={t} from={T.thumb} to={T.stand} cx={480} cy={1000}><ThumbScene t={t} /></IrisScene>
      <IrisScene t={t} from={T.stand} to={T.title} cx={540} cy={1100}><StandScene t={t} /></IrisScene>
      <IrisScene t={t} from={T.title} to={T.lab} cx={540} cy={900}><TitleScene t={t} /></IrisScene>
      <IrisScene t={t} from={T.lab} to={T.groups} cx={540} cy={380}><LabScene t={t} /></IrisScene>
      <IrisScene t={t} from={T.groups} to={T.price} cx={540} cy={1000}><GroupsScene t={t} /></IrisScene>
      <IrisScene t={t} from={T.price} to={T.fold} cx={540} cy={900}><PriceScene t={t} /></IrisScene>
      <IrisScene t={t} from={T.fold} to={T.critics} cx={720} cy={880}><FoldScene t={t} /></IrisScene>
      <IrisScene t={t} from={T.critics} to={T.value} cx={540} cy={1100}><CriticsScene t={t} /></IrisScene>
      <IrisScene t={t} from={T.value} to={T.effort} cx={520} cy={900}><ValueScene t={t} /></IrisScene>
      <IrisScene t={t} from={T.effort} to={T.rule} cx={560} cy={700}><EffortScene t={t} /></IrisScene>
      <IrisScene t={t} from={T.rule} to={T.end} cx={540} cy={440}><RuleScene t={t} /></IrisScene>
      <IrisScene t={t} from={T.end} to={999} cx={600} cy={620}><EndScene t={t} /></IrisScene>
      {t >= T.clock && t < T.stand + 0.6 && <Tally t={t} />}
      <Caption t={t} pages={PAGES} dark={dark} />
    </AbsoluteFill>
  );
};

const s = (t: number, src: string, vol = 0.55): Sfx => ({t: Math.max(0, t), src: `audio/sfx/flatlife/${src}.wav`, vol});
export const FLATLIFE_SFX: Sfx[] = [
  // S1 intro
  s(a('ini dimas'), 'pop', 0.5), s(a('rak buku'), 'boing', 0.7), s(a('dirakit'), 'boing', 0.55),
  // S2–S3 two hours, three screws, one thumb
  s(T.clock, 'iris', 0.45), s(a('jam') + 0.3, 'ding', 0.5), s(a('tiga'), 'pop', 0.5), s(a('baut'), 'pop', 0.5), s(a('sisa'), 'pop', 0.55),
  s(a('kena') - 0.2, 'whoosh', 0.55), s(a('kena'), 'bonk', 0.85), s(a('palu'), 'squeak', 0.5),
  // S4 it stands, a bit crooked, best shelf in the world
  s(T.stand, 'iris', 0.45), s(a('berdiri') + 0.12, 'boing', 0.65), s(a('miring') - 0.1, 'creak', 0.6), s(a('terbaik') + 0.05, 'ding', 0.55), s(a('dunia'), 'sparkle', 0.55),
  // S5 title
  s(T.title, 'iris', 0.45), s(a('efek'), 'boing', 0.7), s(a('ikea') + 0.2, 'sparkle', 0.6),
  // S6 researchers
  s(T.lab, 'iris', 0.45), s(a('michael'), 'step', 0.5), s(a('daniel'), 'step', 0.5), s(a('dan ariely'), 'step', 0.5),
  // S7 two groups
  s(T.groups, 'iris', 0.45), s(a('kotak'), 'fold', 0.5), s(a('sebagian lagi'), 'whoosh', 0.5), s(a('dikasih'), 'pop', 0.55), s(a('mau bayar'), 'pop', 0.45),
  // S7b +60%
  s(T.price, 'iris', 0.45), s(a('60'), 'kaching', 0.8), s(a('sama persis'), 'ding', 0.5),
  // S8 origami
  s(T.fold, 'iris', 0.45), s(a('melipat'), 'fold', 0.55), s(a('origami') + 0.1, 'fold', 0.5), s(a('jelek'), 'boing', 0.6), s(a('jelek') + 0.08, 'bonk', 0.55),
  // S9–S10 valuations
  s(T.critics, 'iris', 0.45), s(a('hampir nggak'), 'squeak', 0.5), s(a('menghargai'), 'boing', 0.55), s(a('semahal'), 'whoosh', 0.45), s(a('ahli'), 'ding', 0.55),
  // S11 effort into price
  s(a('memiliki'), 'pop', 0.5), s(a('capeknya') + 0.68, 'clink', 0.45), s(a('harga'), 'kaching', 0.7),
  // S12 the condition
  s(T.rule, 'iris', 0.45), s(a('selesai'), 'ding', 0.55), s(a('gagal'), 'creak', 0.55), s(a('gagal') + 0.45, 'bonk', 0.6), s(a('dibongkar'), 'whoosh', 0.5), s(a('efeknya'), 'squeak', 0.55),
  // S13 warm ending
  s(T.end, 'iris', 0.45), s(a('sayang'), 'pop', 0.5), s(a('wajar'), 'ding', 0.5), s(a('itu bukan') + 0.15, 'pop', 0.45), s(a('jerih') + 0.3, 'sparkle', 0.6),
];
