// REFERENCE DEMO (ADSY MOTION GRAPH v1.9) — read for structure only: scenes, camera moves, word-pinned beats, SFX cues.
// Do NOT copy this story, its text or its layout into a buyer video. Written in the author's demo workspace, so a few
// imports differ from the starter: `makeCues(words)` ≈ the starter's `at()/endOf()` from src/lib/words.ts, and
// `EpisodeAudio` ≈ Main.tsx audio (musicFile + auto-duck) + <SfxTrack /> fed by src/audio-plan.json sfxCues.
// A `getInputProps()` draft switch, if present, was a workspace-only shortcut: do not copy it (the starter has --silent-draft).
import React, {useMemo} from 'react';
import {AbsoluteFill, Easing, getInputProps} from 'remotion';
import {makeCues} from '../../lib/cues';
import {lerp, p, pagesFor, pb, rnd, StyleFonts, useTime} from '../../styles/shared';
import {EpisodeAudio, Sfx} from '../../styles/audio';
import {
  Backdrop, calendarBlock, calendarPos, Callout, clamp01, css, Dot, DotCanvas, dotText, DotText, drawDot, drawLattice, DriftLayer, fade, Formation, HEAD, Hud, lab,
  Legend, mixRGB, MONO, MonoCaption, morph, onRing, pairsOf, pctID, ping, Pt, rgb, ringStroke, ShareBar, snap, SNAP, Stat, Step, tick, TK, useAsyncLayout, YEAR,
} from '../../styles/titik/kit';
import wordsFile from './words.json';

// TITIK episode — "Paradoks ulang tahun". 1 dot = 1 day (365, white) and 1 big dot = 1 person (cyan).
// A class of 23 fills its seats → guesses pile up at "small" → the year blooms as a calendar → the answer
// lands past the half mark → 23 people on a ring, 253 pair lines → people drop onto their birthdays one by one
// while the exact "all different" product Π(365−k)/365 shrinks under ½ → 50 and 70 people rain in with
// collisions (coral) → "you" vs all pairs → back to the class → every dot pours into MATEMATIKA.

const C = makeCues(wordsFile);
const a = C.at;
export const TITIK_DURATION = C.duration + 1.4;
const PAGES = pagesFor(C.words, 4, 24);

const T = {
  n23: a('23'), berapa: a('berapa'), dua: a('ada dua'), sama: a('sama'), keb: a('kebanyakan'), menebak: a('menebak'), kecil: a('kecil'),
  toh: a('toh'), setahun: a('setahun'), n365: a('365'), jawab: a('jawabannya'), lebih: a('lebih dari'), n50: a('50'), persen: a('persen'),
  rahasia: a('rahasianya'), bukan: a('bukan di'), jOrang: a('jumlah orang'), tapi: a('tapi di'), jPas: a('jumlah pasangan'), pasangan: a('pasangan'),
  n23b: a('23', 1), membentuk: a('membentuk'), n253: a('253'), setiap: a('setiap pasangan'), kesempatan: a('kesempatan'), tabrak: a('bertabrakan'),
  bayangkan: a('bayangkan'), satuPer: a('satu per'), kedua: a('kedua'), beda: a('beda'), ketiga: a('ketiga'), tapiSetiap: a('tapi setiap'),
  menghindari: a('menghindari'), terisi: a('terisi'), lolos: a('lolosnya'), makin: a('makin kecil'), diOrang: a('di orang'), ke23: a('ke-23'),
  semuanya: a('semuanya'), turun: a('turun'), setengah: a('setengah'), n50b: a('50', 1), n97: a('97'), n70: a('70'), hampirPasti: a('hampir pasti', 1),
  n999: a('99,9'), otak: a('otak'), jago: a('jago'), diri: a('diri'), tapi2: a('tapi payah'), payah: a('payah'), pas4: a('pasangan', 3), jadi: a('jadi kalau'),
  adaYang: a('ada yang ulang'), sama2: a('sama', 1), itu: a('itu bukan'), kebetulan: a('kebetulan'), aneh: a('aneh'), itu2: a('itu matematika'), mat: a('matematika'),
};
const END = TITIK_DURATION;

const WH = rgb(TK.dot), CO = rgb(TK.coral), CY = rgb(TK.cyan), LI = rgb(TK.lime);
const pct = pctID;

// ---------- the year ----------
const {days: DAYS, names: MON, month: MOF, day: KOF} = YEAR;
const CAL = {s: 31, r: 8.4, x0: 157, y0: 592, gx: 290, gy: 216};
const cal = (d: number): Pt => calendarPos(d, CAL);
const calBlock = (m: number): Pt => calendarBlock(m, CAL);

// ---------- the people (70: a class of 23, then up to 70) ----------
const NP = 70;
const COLLIDE: Array<[number, number]> = [[26, 8], [37, 13], [45, 29], [54, 19], [60, 40], [67, 2]]; // ≈3.4 colliding pairs expected at 50, ≈6.6 at 70
const BDAY: number[] = (() => {
  const out: number[] = [];
  const taken = new Set<number>();
  for (let i = 0; i < NP; i++) {
    let d = Math.floor(rnd(i * 17.13 + 3.7) * 365);
    if (i < 23) while (out.some((x) => Math.abs(x - d) < 5)) d = (d + 7) % 365;
    else while (taken.has(d)) d = (d + 11) % 365;
    out.push(d);
    taken.add(d);
  }
  for (const [i, j] of COLLIDE) out[i] = out[j];
  return out;
})();
const DROP = 0.42;
const LAND: number[] = Array.from({length: NP}, (_, i) => {
  if (i === 0) return T.satuPer + 0.05;
  if (i === 1) return T.kedua + 0.02;
  if (i === 2) return T.ketiga + 0.02;
  if (i < 22) return T.tapiSetiap + 0.1 + (39.42 - T.tapiSetiap - 0.1) * (1 - Math.pow(1 - (i - 3) / 18, 1.3));
  if (i === 22) return T.turun + 0.02;
  if (i < 50) return T.n50b - 0.05 + (i - 23) * 0.05;
  return T.n70 - 0.12 + (i - 50) * 0.05;
});
/** time a person turns coral (their birthday is shared by someone already on the calendar) */
const COLL_T: number[] = BDAY.map((d, i) => {
  let tt = Infinity;
  BDAY.forEach((e, j) => {
    if (j !== i && e === d) tt = Math.min(tt, Math.max(LAND[i], LAND[j]));
  });
  return tt;
});
const SECOND = BDAY.map((d, i) => BDAY.slice(0, i).includes(d));
/** exact P(all n birthdays different) = Π_{k<n} (365−k)/365 */
const PDIFF = (() => {
  const o = [1];
  for (let n = 1; n <= NP; n++) o.push(o[n - 1] * ((366 - n) / 365));
  return o;
})();
const landedAt = (t: number, upto = NP) => {
  let n = 0;
  for (let i = 0; i < upto; i++) if (t >= LAND[i]) n++;
  return n;
};
/** smooth "all different" probability for the bar (exact at rest) */
const pdiffSmooth = (t: number) => {
  let v = 1;
  for (let k = 0; k < NP; k++) v *= lerp(1, (365 - k) / 365, p(t, LAND[k] - 0.05, LAND[k] + (k === 22 ? 0.62 : 0.32), Easing.inOut(Easing.cubic)));
  return v;
};

// layouts
const SEAT = (k: number): Pt => (k < 20 ? [540 + ((k % 5) - 2) * 150, 690 + Math.floor(k / 5) * 150] : [540 + (k - 21) * 150, 690 + 4 * 150]);
const RING = {x: 540, y: 990, R: 360};
const ringPos = (k: number): Pt => onRing(k, 23, RING.x, RING.y, RING.R);
const QUEUE_Y = 484;
const AX = {y: 1210, x0: 110, x1: 970};
const ax = (v: number) => AX.x0 + (AX.x1 - AX.x0) * v;
const BINS = [9, 7, 4, 2, 0, 1];
const GUESS: Pt[] = (() => {
  const out: Pt[] = [];
  BINS.forEach((n, b) => {
    for (let l = 0; l < n; l++) out.push([ax(0.025 + b * 0.05), AX.y - 26 - l * 36]);
  });
  return out;
})();
const HL: [number, number] = [4, 19]; // the pair that shares a birthday in the class (#05 and #20, right column)
const MAT_BOX = {cx: 540, cy: 1030, w: 900, h: 150};
const CURVE = {x0: 110, x1: 970, y0: 890, h: 330};
const curvePos = (i: number): Pt => [CURVE.x0 + (i * (CURVE.x1 - CURVE.x0)) / 69, CURVE.y0 - CURVE.h * (1 - PDIFF[i + 1])];

// pairs among the 23
const PAIRS = pairsOf(23); // C(23, 2) = 253
const FIRST6: Array<[number, number]> = [[0, 9], [3, 15], [7, 19], [11, 21], [5, 13], [16, 22]];
const FIRST6_KEY = new Set(FIRST6.map(([i, j]) => i * 23 + j));
const SWEEP: Array<[number, number]> = [[2, 14], [9, 20], [7, 12], HL];

// ---------- formations: days ----------
const fDHidden: Formation = (i) => {
  const [x, y] = cal(i);
  return {x: snap(x), y: snap(y), r: 1.6, a: 0, c: WH};
};
const fDCal: Formation = (i) => {
  const [x, y] = cal(i);
  return {x, y, r: CAL.r, a: 1, c: WH};
};
const fDAxis: Formation = (i) => ({x: ax(i / 364), y: AX.y, r: 2.4, a: 0.9, c: WH});
const fDAxisGone: Formation = (i) => ({x: ax(i / 364), y: AX.y, r: 1.5, a: 0, c: WH});
const fDCalDim: Formation = (i) => {
  const [x, y] = cal(i);
  return {x, y, r: CAL.r - 0.8, a: 0.4, c: WH};
};

// ---------- formations: people ----------
const hiddenAbove = (i: number): Dot => ({x: cal(BDAY[i])[0], y: cal(BDAY[i])[1] - 150, r: 4, a: 0, c: CY});
const fPStart: Formation = (i, t) => {
  if (i >= 23) return hiddenAbove(i);
  const [x, y] = SEAT(i);
  const at = -0.25 + i * 0.066;
  const g = SNAP(clamp01((t - at) / 0.35));
  return {x, y: y + (1 - g) * 26, r: 30 * (0.4 + 0.6 * g), a: g, c: CY};
};
const fPSeat: Formation = (i) => {
  if (i >= 23) return hiddenAbove(i);
  const [x, y] = SEAT(i);
  return {x, y, r: 30, a: 1, c: CY};
};
const fPSeatHL: Formation = (i) => ({...fPSeat(i, 0), c: CO});
const fPGuess: Formation = (i) => ({x: GUESS[i][0], y: GUESS[i][1], r: 15, a: 1, c: CY});
const fPQueue: Formation = (i, t) => {
  let slot = i;
  for (let j = 0; j < i; j++) slot -= p(t, LAND[j] - DROP, LAND[j] + 0.2);
  return {x: 122 + slot * 38, y: QUEUE_Y, r: 10, a: 1, c: CY};
};
const fPRing: Formation = (i) => {
  const [x, y] = ringPos(i);
  return {x, y, r: 22, a: 1, c: CY};
};
const fPCollide: Formation = (i) => {
  const [x0, y0] = ringPos(HL[0]), [x1, y1] = ringPos(HL[1]);
  const s = i === HL[0] ? -1 : 1;
  return {x: (x0 + x1) / 2 + s * 11, y: (y0 + y1) / 2 - s * 4, r: 22, a: 1, c: CO};
};
const fPHover: Formation = () => ({x: 540, y: QUEUE_Y, r: 20, a: 1, c: CY});
const fPDay: Formation = (i, t) => {
  const [x, y] = cal(BDAY[i]);
  const o = SECOND[i] ? 8 : 0;
  return {x: x + o, y: y - o, r: 12, a: 1, c: Number.isFinite(COLL_T[i]) ? mixRGB(CY, CO, p(t, COLL_T[i], COLL_T[i] + 0.25)) : CY};
};
const fPFade: Formation = (i, t) => ({...fPDay(i, t), a: 0, r: 4});
const fPRingJ: Formation = (i) => {
  const [x, y] = ringPos(i);
  return {x, y, r: i === 0 ? 30 : 20, a: 1, c: CY};
};

const isHL = (i: number) => i === HL[0] || i === HL[1];
const cls = (i: number) => i < 23;

const buildScore = (mat: DotText) => {
  // MATEMATIKA: the 365 days pour in left → right; the 70 people become the curve P(n), n = 1…70
  const order = mat.pts.map((_, k) => k).sort((u, v) => mat.pts[u][0] - mat.pts[v][0]);
  const rank = new Array<number>(365);
  order.forEach((slot, r) => (rank[slot] = r));
  const fDMat: Formation = (i) => ({x: mat.pts[i][0], y: mat.pts[i][1], r: mat.s * 0.4, a: 1, c: WH});
  const matDelay = (i: number) => (rank[i] / 365) * 0.32;
  const fPMat: Formation = (i) => {
    const [x, y] = curvePos(i);
    return {x, y, r: 8, a: 1, c: i >= 22 ? CO : CY};
  };

  const days: Step[] = [
    {at: T.setahun - 0.25, dur: 0.6, to: fDCal, delay: (i) => MOF[i] * 0.04 + KOF[i] * 0.003, arc: 0.2, swirl: true},
    // the year pours down into the probability axis, then hands over to the drawn axis line
    {at: T.jawab - 0.25, dur: 0.55, to: fDAxis, delay: (i) => i * 0.0008, arc: 0.1},
    {at: T.jawab + 0.75, dur: 0.3, to: fDAxisGone},
    {at: T.bayangkan - 0.15, dur: 0.6, to: fDCalDim, delay: (i) => MOF[i] * 0.035 + KOF[i] * 0.003, arc: 0.2, swirl: true},
    {at: T.otak - 0.2, dur: 0.55, to: fDHidden, delay: (i) => rnd(i * 2.3) * 0.25},
    {at: T.itu2 - 0.18, dur: 0.6, to: fDMat, delay: matDelay, arc: 0.12, swirl: true},
  ];
  const people: Step[] = [
    {at: T.dua - 0.08, dur: 0.3, to: fPSeatHL, only: isHL, ease: SNAP},
    {at: T.keb - 0.25, dur: 0.6, to: fPGuess, only: cls, delay: (i) => i * 0.022, arc: 0.22, swirl: true},
    {at: T.toh - 0.1, dur: 0.55, to: fPQueue, only: cls, delay: (i) => i * 0.012, arc: 0.12},
    {at: T.jawab + 0.05, dur: 0.6, to: fPGuess, only: cls, delay: (i) => i * 0.014, arc: 0.12},
    {at: T.rahasia - 0.1, dur: 0.7, to: fPRing, only: cls, delay: (i) => i * 0.014, arc: 0.2, swirl: true},
    {at: T.tabrak - 0.4, dur: 0.45, to: fPCollide, only: isHL, ease: SNAP, arc: 0.05},
    {at: T.bayangkan - 0.1, dur: 0.6, to: fPQueue, only: cls, delay: (i) => i * 0.012, arc: 0.12},
    {at: T.ke23 - 0.1, dur: 0.5, to: fPHover, only: (i) => i === 22},
    {at: 0, dur: DROP, to: fPDay, delay: (i) => LAND[i] - DROP, ease: Easing.bezier(0.5, 0, 0.3, 1.18), arc: 0.1},
    {at: T.otak - 0.15, dur: 0.7, to: fPRingJ, only: cls, delay: (i) => i * 0.012, arc: 0.18, swirl: true},
    {at: T.otak - 0.15, dur: 0.5, to: fPFade, only: (i) => i >= 23, delay: (i) => rnd(i * 3.1) * 0.2},
    {at: T.jadi - 0.1, dur: 0.65, to: fPSeat, only: cls, delay: (i) => i * 0.012, arc: 0.15},
    {at: T.adaYang - 0.1, dur: 0.3, to: fPSeatHL, only: isHL, ease: SNAP},
    {at: T.itu2 - 0.18, dur: 0.6, to: fPMat, delay: (i) => i * 0.005, arc: 0.12, swirl: true},
  ];
  return {days, people};
};
type Score = ReturnType<typeof buildScore>;

// ---------- pair lines ----------
type LineSt = {f: number; a: number; c: [number, number, number]; w: number};
const lineAt = (i: number, j: number, q: number, t: number): LineSt | null => {
  // scene D/E: a few pairs, then all 253, then one pair at a time
  if (t > T.jPas - 0.1 && t < T.bayangkan + 0.4) {
    const out = 1 - p(t, T.bayangkan - 0.1, T.bayangkan + 0.3);
    const k6 = FIRST6.findIndex(([u, v]) => u === i && v === j);
    const f = k6 >= 0 ? p(t, T.jPas + k6 * 0.07, T.jPas + k6 * 0.07 + 0.3) : p(t, T.membentuk - 0.1 + q * 0.0026, T.membentuk - 0.1 + q * 0.0026 + 0.2);
    if (f <= 0) return null;
    const sw = SWEEP.findIndex(([u, v]) => u === i && v === j);
    const sOn = sw >= 0 ? p(t, T.setiap - 0.05 + sw * 0.55, T.setiap + 0.1 + sw * 0.55) * (sw === 3 ? 1 : 1 - p(t, T.setiap + 0.45 + sw * 0.55, T.setiap + 0.6 + sw * 0.55)) : 0;
    const dim = p(t, T.setiap - 0.15, T.setiap + 0.15);
    const base = k6 >= 0 && t < T.membentuk ? 0.6 : 0.3;
    return {f, a: (lerp(base, 0.1, dim) * (1 - sOn) + sOn) * out, c: mixRGB(WH, CO, sOn), w: 1.3 + sOn * 2.2};
  }
  // scene J: you → everyone, then everyone ↔ everyone
  if (t > T.jago - 0.1 && t < T.jadi + 0.4) {
    const out = 1 - p(t, T.jadi - 0.1, T.jadi + 0.3);
    if (i === 0) {
      const f = p(t, T.jago + (j - 1) * 0.04, T.jago + (j - 1) * 0.04 + 0.25);
      return f > 0 ? {f, a: 0.8 * out, c: CY, w: 2.2} : null;
    }
    const q2 = q - 22;
    const f = p(t, T.payah - 0.05 + q2 * 0.0033, T.payah - 0.05 + q2 * 0.0033 + 0.2);
    return f > 0 ? {f, a: 0.28 * out, c: WH, w: 1.3} : null;
  }
  return null;
};
const linesDrawn = (t: number) => {
  let n = 0;
  PAIRS.forEach(([i, j], q) => {
    const s = lineAt(i, j, q, t);
    if (s && s.f >= 0.999) n++;
  });
  return n;
};

// ---------- canvas (DotCanvas clears and applies the drift before calling this) ----------
const drawFrame = (ctx: CanvasRenderingContext2D, t: number, S: Score) => {
  drawLattice(ctx, t);

  // desks + board (the class)
  const desks = fade(t, -0.5, 0.2, T.keb - 0.4, T.keb) + fade(t, T.jadi - 0.1, T.jadi + 0.4, T.itu2 - 0.2, T.itu2 + 0.1);
  if (desks > 0.01) {
    ctx.strokeStyle = css(WH, 0.22 * desks);
    ctx.lineWidth = 1.5;
    for (let k = 0; k < 23; k++) {
      const [x, y] = SEAT(k);
      ctx.beginPath();
      ctx.roundRect(x - 52, y + 38, 104, 22, 6);
      ctx.stroke();
    }
    ctx.strokeStyle = css(WH, 0.4 * desks);
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(300, 560);
    ctx.lineTo(780, 560);
    ctx.stroke();
  }

  // calendar furniture: filled dates flagged while newcomers must avoid them
  const flag = fade(t, T.menghindari - 0.1, T.menghindari + 0.4, T.diOrang - 0.2, T.diOrang + 0.3);
  if (flag > 0.01)
    for (let i = 0; i < 22; i++) {
      if (t < LAND[i]) continue;
      const [x, y] = cal(BDAY[i]);
      const fq = flag * p(t, LAND[i], LAND[i] + 0.3);
      ctx.fillStyle = css(CO, 0.16 * fq);
      ctx.beginPath();
      ctx.arc(x, y, 18, 0, 6.2832);
      ctx.fill();
      ringStroke(ctx, x, y, 18, css(CO, 0.95 * fq), [5, 4], 2.5);
    }

  // people positions (needed for the pair lines)
  const P: Dot[] = [];
  const PP: Dot[] = [];
  for (let i = 0; i < NP; i++) {
    P.push(morph(i, t, fPStart, S.people));
    PP.push(morph(i, t - 1 / 120, fPStart, S.people));
  }

  // class pair arc (scene A and K)
  const arcQ = fade(t, T.dua - 0.05, T.dua + 0.5, T.keb - 0.35, T.keb - 0.05) + fade(t, T.adaYang - 0.05, T.adaYang + 0.5, T.itu2 - 0.25, T.itu2);
  if (arcQ > 0.01) {
    const [x0, y0] = [P[HL[0]].x, P[HL[0]].y], [x1, y1] = [P[HL[1]].x, P[HL[1]].y];
    const mx = Math.max(x0, x1) + 110, my = (y0 + y1) / 2;
    ctx.strokeStyle = css(CO, 0.95);
    ctx.lineWidth = 3;
    ctx.setLineDash([1400 * arcQ, 2000]);
    ctx.beginPath();
    ctx.moveTo(x0, y0);
    ctx.quadraticCurveTo(mx, my, x1, y1);
    ctx.stroke();
    ctx.setLineDash([]);
  }

  // pair lines
  PAIRS.forEach(([i, j], q) => {
    const s = lineAt(i, j, q, t);
    if (!s || s.a <= 0.004) return;
    ctx.strokeStyle = css(s.c, s.a);
    ctx.lineWidth = s.w;
    ctx.beginPath();
    ctx.moveTo(P[i].x, P[i].y);
    ctx.lineTo(lerp(P[i].x, P[j].x, s.f), lerp(P[i].y, P[j].y, s.f));
    ctx.stroke();
  });

  // days
  for (let i = 0; i < 365; i++) drawDot(ctx, morph(i, t, fDHidden, S.days), morph(i, t - 1 / 120, fDHidden, S.days), t, false);

  // people (numbers on the big ones)
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  for (let i = 0; i < NP; i++) {
    const d = P[i];
    drawDot(ctx, d, PP[i], t);
    if (i < 23 && d.r > 15 && d.a > 0.3) {
      ctx.fillStyle = css(rgb(TK.ink), 0.9 * d.a);
      ctx.font = `600 ${Math.round(d.r * 0.68)}px 'Tik Mono'`;
      ctx.fillText(String(i + 1).padStart(2, '0'), d.x, d.y + 1);
    }
  }

  // pings: arrivals, collisions
  for (let i = 0; i < NP; i++) {
    const [x, y] = cal(BDAY[i]);
    ping(ctx, t, LAND[i], x, y, CY, 12, i < 23 ? 30 : 18, i < 23 ? 0.5 : 0.35, 2);
    if (Number.isFinite(COLL_T[i]) && SECOND[i]) ping(ctx, t, COLL_T[i], x + 4, y - 4, CO, 14, 64, 0.7, 3);
  }
  const [cx0, cy0] = ringPos(HL[0]), [cx1, cy1] = ringPos(HL[1]);
  ping(ctx, t, T.tabrak + 0.05, (cx0 + cx1) / 2, (cy0 + cy1) / 2, CO, 24, 110, 0.8, 3);
  ping(ctx, t, T.dua, P[HL[0]].x, P[HL[0]].y, CO, 30, 40, 0.5);
  ping(ctx, t, T.dua + 0.08, P[HL[1]].x, P[HL[1]].y, CO, 30, 40, 0.5);
  ping(ctx, t, T.adaYang, SEAT(HL[0])[0], SEAT(HL[0])[1], CO, 30, 40, 0.5);
  ping(ctx, t, T.adaYang + 0.08, SEAT(HL[1])[0], SEAT(HL[1])[1], CO, 30, 40, 0.5);
  // sweep highlight: endpoints of the pair in focus
  SWEEP.forEach(([i, j], sw) => {
    const on = fade(t, T.setiap - 0.05 + sw * 0.55, T.setiap + 0.1 + sw * 0.55, sw === 3 ? T.tabrak - 0.4 : T.setiap + 0.45 + sw * 0.55, sw === 3 ? T.tabrak - 0.3 : T.setiap + 0.6 + sw * 0.55);
    if (on > 0.01) for (const k of [i, j]) ringStroke(ctx, P[k].x, P[k].y, 31, css(CO, on), [], 2.5);
  });
  // the 50% line on the axis gets a shock when the answer lands
  ping(ctx, t, T.n50, ax(0.5073), AX.y, CO, 10, 60, 0.6);
};

// ---------- overlays ----------
const Abs: React.FC<{x: number; y: number; o?: number; style?: React.CSSProperties; children: React.ReactNode}> = ({x, y, o = 1, style, children}) =>
  o > 0.005 ? <div style={{position: 'absolute', left: x, top: y, opacity: o, ...style}}>{children}</div> : null;

/** The "all different" vs "someone shares" bar: the bar eases between arrivals, the texts show the exact product. */
const SplitBar: React.FC<{t: number; o: number}> = ({t, o}) => {
  const n = landedAt(t);
  const exact = PDIFF[n];
  const under = t > T.turun + 0.3 && n >= 23;
  return <ShareBar v={pdiffSmooth(t)} o={o} left="SEMUA BEDA" right="ADA YANG SAMA" leftValue={pct(exact)} rightValue={pct(1 - exact)} mid={under ? 'DI BAWAH ½' : '½'} midColor={under ? TK.coral : TK.dot} />;
};

const ACCENT = (w: string) => (/^(23|ke-23|253)/.test(w) ? TK.cyan : /^(beda|lolosnya)/.test(w) ? TK.lime : TK.coral);

export const UlangTahunEpisode: React.FC = () => {
  const {t} = useTime();
  const L = useAsyncLayout('ulang-tahun', buildMat);
  const S = useMemo(() => (L ? buildScore(L.mat) : null), [L]);
  const draft = (getInputProps() as {draftNoAudio?: boolean}).draftNoAudio === true;

  // live count of lit dots, ticking at 15 Hz
  const tq = tick(t, 15);
  let live = 0;
  if (S) {
    for (let i = 0; i < 365; i++) if (morph(i, tq, fDHidden, S.days).a > 0.3) live++;
    for (let i = 0; i < NP; i++) {
      const d = morph(i, tq, fPStart, S.people);
      if (d.a > 0.5 && d.y > 0) live++;
    }
  }
  const t20 = tick(t, 20);
  const seated = Math.min(23, Math.max(0, Math.floor((t20 + 0.25) / 0.066) + 1));
  const yearN = Math.round(365 * clamp01((t20 - T.setahun + 0.2) / 1.25));
  const drawn = linesDrawn(t20);
  const nLand = landedAt(t);
  const cur = t >= T.ke23 - 0.1 && nLand < 23 ? 23 : Math.max(1, nLand);
  const chapter = t < T.jawab - 0.2 ? 1 : t < T.rahasia - 0.2 ? 2 : t < T.bayangkan - 0.2 ? 3 : t < T.n50b - 0.2 ? 4 : t < T.otak - 0.2 ? 5 : t < T.jadi - 0.2 ? 6 : 7;
  const H = {
    peluang: T.berapa - 0.05, kecil: T.keb - 0.05, n365: T.setahun - 0.1, jawab: T.jawab - 0.05, lebih: T.lebih - 0.1, rahasia: T.rahasia - 0.05, pas: T.tapi - 0.05,
    n23: T.n23b - 0.05, n253: T.membentuk - 0.1, satu: T.setiap - 0.05, sama: T.tabrak - 0.05, datang: T.bayangkan - 0.05, n50: T.n50b - 0.1, n70: T.n70 - 0.1,
    otak: T.otak - 0.05, payah: T.tapi2 - 0.05, kelasmu: T.jadi - 0.05, aneh: T.itu - 0.05, mat: T.itu2 - 0.1,
  };
  const live23 = PDIFF[Math.min(70, landedAt(t))];

  return (
    <AbsoluteFill style={{background: TK.ink, overflow: 'hidden'}}>
      <StyleFonts />
      {!draft && <EpisodeAudio vo="audio/vo/titik.mp3" words={C.words} music="audio/music/titik.wav" bed={0.5} duck={0.18} sfx={TITIK_SFX} />}
      <Backdrop />
      <DotCanvas t={t} draw={S ? (ctx, tt) => drawFrame(ctx, tt, S) : null} />

      {/* ===== world-anchored annotations (move with the camera drift) ===== */}
      <DriftLayer t={t}>
        {/* class */}
        <Abs x={300} y={520} o={0.55 * (fade(t, -0.5, 0.2, T.keb - 0.4, T.keb) + fade(t, T.jadi - 0.1, T.jadi + 0.4, T.itu2 - 0.2, T.itu2 + 0.1))} style={{width: 480, textAlign: 'center', ...lab, fontSize: 18, color: TK.dot}}>PAPAN TULIS</Abs>
        <Abs x={SEAT(HL[0])[0] + 58} y={(SEAT(HL[0])[1] + SEAT(HL[1])[1]) / 2 - 44} o={fade(t, T.sama - 0.2, T.sama + 0.2, T.keb - 0.35, T.keb - 0.05) + fade(t, T.sama2 - 0.2, T.sama2 + 0.2, T.itu2 - 0.25, T.itu2)}
          style={{fontFamily: HEAD, fontWeight: 800, fontSize: 76, lineHeight: 1, color: TK.coral}}>?</Abs>
        {/* guesses on the probability axis */}
        {(() => {
          const o = fade(t, T.keb - 0.2, T.keb + 0.3, T.toh - 0.2, T.toh + 0.15) + fade(t, T.jawab + 0.2, T.jawab + 0.6, T.rahasia - 0.2, T.rahasia + 0.15);
          if (o < 0.01) return null;
          const mark = p(t, T.lebih - 0.05, T.n50 + 0.05);
          const band = p(t, T.n50 - 0.1, T.persen + 0.2);
          return (
            <div style={{position: 'absolute', left: 0, top: 0, width: 1080, height: 1920, opacity: o}}>
              <svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0}}>
                <rect x={AX.x0} y={AX.y - 5} width={(ax(0.5073) - AX.x0) * band} height={10} fill={TK.coral} opacity={0.85} />
                <line x1={AX.x0} y1={AX.y} x2={AX.x1} y2={AX.y} stroke={TK.dot} strokeOpacity={0.6} strokeWidth={2} />
                {[0, 0.25, 0.5, 0.75, 1].map((v) => (
                  <g key={v}>
                    <line x1={ax(v)} y1={AX.y} x2={ax(v)} y2={AX.y + 14} stroke={TK.dot} strokeOpacity={0.6} strokeWidth={2} />
                    <text x={ax(v)} y={AX.y + 48} textAnchor="middle" fill={TK.dot} fillOpacity={0.6} style={{...lab, fontSize: 20}}>{Math.round(v * 100)}%</text>
                  </g>
                ))}
                <line x1={ax(0.5)} y1={AX.y} x2={ax(0.5)} y2={AX.y - 560} stroke={TK.dot} strokeOpacity={0.3} strokeWidth={1.5} strokeDasharray="4 6" />
                {mark > 0 && (
                  <>
                    <line x1={ax(0.5073)} y1={AX.y} x2={ax(0.5073)} y2={AX.y - 560 * mark} stroke={TK.coral} strokeWidth={4} />
                    <circle cx={ax(0.5073)} cy={AX.y - 560 * mark} r={14 * pb(t, T.n50 - 0.1, T.n50 + 0.25)} fill={TK.coral} />
                  </>
                )}
                {/* bracket over the guesses */}
                <path d={`M ${ax(0)} ${AX.y - 370} L ${ax(0)} ${AX.y - 384} L ${ax(0.3)} ${AX.y - 384} L ${ax(0.3)} ${AX.y - 370}`} fill="none" stroke={TK.cyan} strokeWidth={2} opacity={fade(t, T.kecil - 0.15, T.kecil + 0.25)} />
              </svg>
              <Abs x={ax(0.62)} y={AX.y - 640} o={0.13 * (1 - p(t, T.lebih - 0.2, T.lebih + 0.2))} style={{fontFamily: HEAD, fontWeight: 300, fontSize: 420, lineHeight: 1, color: TK.dot}}>?</Abs>
              <Abs x={ax(0)} y={AX.y - 432} o={fade(t, T.kecil - 0.15, T.kecil + 0.3)} style={{...lab, fontSize: 21, color: TK.cyan}}>TEBAKAN: KECIL</Abs>
              <Abs x={ax(0.5073) + 26} y={AX.y - 590} o={p(t, T.n50 - 0.05, T.n50 + 0.35)} style={{transform: `translateY(${(1 - p(t, T.n50 - 0.05, T.n50 + 0.35)) * 20}px)`}}>
                <div style={{...lab, fontSize: 21, color: TK.coral}}>JAWABAN · 23 ORANG</div>
                <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 118, lineHeight: 1, letterSpacing: -4, color: TK.coral, marginTop: 6}}>50,73%</div>
              </Abs>
              <Abs x={ax(0.5) - 14} y={AX.y - 590} o={p(t, T.n50 + 0.2, T.n50 + 0.6)} style={{transform: 'translateX(-100%)', ...lab, fontSize: 19, color: TK.dot, textAlign: 'right', lineHeight: 1.4}}>
                <div>½</div>
                <div style={{opacity: 0.6}}>SETENGAH</div>
              </Abs>
            </div>
          );
        })()}

        {/* calendar labels */}
        {MON.map((m, i) => {
          const q = fade(t, T.setahun - 0.1 + i * 0.04, T.setahun + 0.3 + i * 0.04, T.jawab - 0.3, T.jawab) + fade(t, T.bayangkan + i * 0.035, T.bayangkan + 0.4 + i * 0.035, T.otak - 0.3, T.otak);
          if (q < 0.01) return null;
          const [x, y] = calBlock(i);
          return (
            <div key={m} style={{position: 'absolute', left: x - CAL.r, top: y - 40, width: 6 * CAL.s + 2 * CAL.r, display: 'flex', justifyContent: 'space-between', ...lab, fontSize: 18, letterSpacing: 2, color: 'rgba(237,235,230,0.6)', opacity: q}}>
              <span>{String(i + 1).padStart(2, '0')} {m}</span>
              <span>{DAYS[i]}</span>
            </div>
          );
        })}
        {/* queue label */}
        <Abs x={122 - 10} y={QUEUE_Y - 52} o={fade(t, T.toh + 0.2, T.toh + 0.6, T.jawab - 0.3, T.jawab) + fade(t, T.bayangkan + 0.3, T.bayangkan + 0.7, T.ke23 - 0.3, T.ke23)} style={{...lab, fontSize: 19, color: TK.cyan}}>
          {t < T.jawab ? '23 ORANG · ANTRE' : `ANTRE · ${String(Math.max(0, 23 - nLand)).padStart(2, '0')} LAGI`}
        </Abs>
        <Abs x={540} y={QUEUE_Y - 58} o={fade(t, T.ke23 - 0.05, T.ke23 + 0.35, T.turun - 0.1, T.turun + 0.1)} style={{transform: 'translateX(-50%)', ...lab, fontSize: 20, color: TK.cyan}}>ORANG KE-23</Abs>

        {/* ring labels */}
        <Abs x={540} y={ringPos(0)[1] - 84} o={fade(t, T.jago - 0.2, T.jago + 0.2, T.jadi - 0.2, T.jadi + 0.1)} style={{transform: 'translateX(-50%)', ...lab, fontSize: 24, color: TK.cyan}}>KAMU</Abs>
        <Callout q={fade(t, T.tabrak + 0.1, T.tabrak + 0.55, T.bayangkan - 0.2, T.bayangkan)} from={[(cx(HL[0]) + cx(HL[1])) / 2 + 30, (cy(HL[0]) + cy(HL[1])) / 2]} elbow={[700, 1400]} to={[840, 1400]} text={['TABRAKAN =', 'ULANG TAHUN SAMA']} color={TK.coral} align="below" />
      </DriftLayer>

      {/* ===== screen-fixed: headers, readouts, captions ===== */}
      <Hud t={t} duration={END} live={live} topic="PELUANG" chapter={chapter} chapters={7}
        legend={<><Legend color={TK.cyan} text="1 ORANG" /><span style={{width: 10}} /><Legend size={8} text="1 HARI" />{t > COLL_T[26] && t < T.otak && <><span style={{width: 10}} /><Legend color={TK.coral} text="SAMA" opacity={p(t, COLL_T[26], COLL_T[26] + 0.3)} /></>}</>} />

      {/* 1 — class & guesses */}
      <Stat t={t} inAt={-0.45} outAt={H.peluang - 0.2} num={String(seated).padStart(2, '0')} label={['ORANG', 'SATU KELAS']} color={TK.cyan} />
      <Stat t={t} inAt={H.peluang} outAt={H.kecil - 0.2} num="Peluang?" size={150} label={['2 ORANG', 'ULANG TAHUN SAMA']} />
      <Stat t={t} inAt={H.kecil} outAt={H.n365 - 0.2} num="Kecil" label={['TEBAKAN', 'KEBANYAKAN ORANG']} />
      <Stat t={t} inAt={H.n365} outAt={H.jawab - 0.2} num={String(yearN).padStart(3, '0')} label={['HARI', 'SETAHUN']} />
      {/* 2 — the answer */}
      <Stat t={t} inAt={H.jawab} outAt={H.lebih - 0.2} num="Jawabannya" size={130} label={['PELUANG', 'SEBENARNYA']} />
      <Stat t={t} inAt={H.lebih} outAt={H.rahasia - 0.2} num=">50%" color={TK.coral} label={['ADA 2 ORANG', 'ULANG TAHUN SAMA']} />
      {/* 3 — pairs */}
      <Stat t={t} inAt={H.rahasia} outAt={H.pas - 0.2} num="Orang" label={['BUKAN DI', 'JUMLAH']} />
      {(() => {
        const q = p(t, T.jOrang + 0.1, T.jOrang + 0.45) * (1 - p(t, H.pas - 0.2, H.pas));
        return q > 0.01 ? <svg width={1080} height={400} style={{position: 'absolute', left: 0, top: 196}}><line x1={60} y1={95} x2={60 + 560 * q} y2={95} stroke={TK.coral} strokeWidth={8} /></svg> : null;
      })()}
      <Stat t={t} inAt={H.pas} outAt={H.n23 - 0.2} num="Pasangan" size={176} label={['TAPI DI', 'JUMLAH']} color={TK.cyan} />
      <Stat t={t} inAt={H.n23} outAt={H.n253 - 0.2} num="23" label={['ORANG', 'BISA MEMBENTUK…']} color={TK.cyan} />
      <Stat t={t} inAt={H.n253} outAt={H.satu - 0.2} num={String(Math.min(253, drawn)).padStart(3, '0')} label={['PASANGAN', '23 × 22 ÷ 2']} />
      <Stat t={t} inAt={H.satu} outAt={H.sama - 0.2} num="1" label={['PASANGAN =', '1 KESEMPATAN']} />
      <Stat t={t} inAt={H.sama} outAt={H.datang - 0.2} num="Tabrakan" size={176} color={TK.coral} label={['ULANG TAHUN', 'SAMA']} />
      {/* 4 — one by one */}
      <Stat t={t} inAt={H.datang} outAt={H.n50 - 0.2} num={String(Math.min(23, nLand)).padStart(2, '0')} color={TK.cyan} label={['ORANG', 'DI KALENDER']} />
      {(() => {
        const q = fade(t, LAND[0] - 0.25, LAND[0] + 0.15, H.n50 - 0.2, H.n50);
        if (q < 0.01) return null;
        const n = cur;
        return (
          <div style={{position: 'absolute', right: 64, top: 200, textAlign: 'right', opacity: q}}>
            <div style={{...lab, fontSize: 20, color: TK.dot, opacity: 0.75}}>ORANG BARU #{String(n).padStart(2, '0')} · LOLOS</div>
            <div style={{fontFamily: HEAD, fontWeight: 300, fontSize: 92, lineHeight: 1.05, letterSpacing: -3, color: TK.lime, fontVariantNumeric: 'tabular-nums'}}>{366 - n}/365</div>
            <div style={{...lab, fontSize: 22, color: TK.lime}}>= {pct((366 - n) / 365)}</div>
          </div>
        );
      })()}
      <SplitBar t={t} o={fade(t, T.bayangkan + 0.2, T.bayangkan + 0.6, T.otak - 0.25, T.otak + 0.05)} />
      {/* 5 — 50 and 70 */}
      <Stat t={t} inAt={H.n50} outAt={H.n70 - 0.2} num="50" color={TK.cyan} label={['ORANG', '']} />
      <Stat t={t} inAt={H.n70} outAt={H.otak - 0.2} num="70" color={TK.cyan} label={['ORANG', '']} />
      {(() => {
        const q = fade(t, H.n50, H.n50 + 0.35, H.otak - 0.2, H.otak);
        if (q < 0.01) return null;
        const big = t >= T.n999 - 0.1 ? 2 : t >= T.n70 - 0.1 ? 0 : t >= T.n97 - 0.1 ? 1 : 0;
        const pop = big === 1 ? pb(t, T.n97 - 0.1, T.n97 + 0.25) : big === 2 ? pb(t, T.n999 - 0.1, T.n999 + 0.25) : 1;
        const exact = big === 1 ? '97,04%' : big === 2 ? '99,92%' : '';
        return (
          <div style={{position: 'absolute', right: 64, top: 196, textAlign: 'right', opacity: q}}>
            <div style={{...lab, fontSize: 20, color: TK.coral}}>{t > T.hampirPasti - 0.05 && t < T.n999 - 0.1 ? 'HAMPIR PASTI…' : 'ADA YANG SAMA'}</div>
            {big === 0 ? (
              <div style={{fontFamily: HEAD, fontWeight: 300, fontSize: 104, lineHeight: 1.05, letterSpacing: -3, color: TK.coral, fontVariantNumeric: 'tabular-nums'}}>{pct(1 - live23, 1)}</div>
            ) : (
              <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 150, lineHeight: 0.95, letterSpacing: -6, color: TK.coral, transform: `scale(${0.85 + 0.15 * pop})`, transformOrigin: '100% 50%'}}>{big === 1 ? '≈97%' : '99,9%'}</div>
            )}
            {exact && <div style={{...lab, fontSize: 21, color: TK.dot, opacity: 0.8, marginTop: 4}}>TEPATNYA {exact}</div>}
          </div>
        );
      })()}
      {/* 6 — you vs pairs */}
      <Stat t={t} inAt={H.otak} outAt={H.payah - 0.2} num="Diri sendiri" size={140} color={TK.cyan} label={['OTAK KITA', 'JAGO']} />
      <Stat t={t} inAt={H.payah} outAt={H.kelasmu - 0.2} num="Pasangan" size={176} label={['TAPI', 'PAYAH']} />
      <Abs x={64} y={1418} o={fade(t, T.jago, T.jago + 0.3, T.jadi - 0.2, T.jadi + 0.1)} style={{...lab, fontSize: 22, color: TK.dot}}>
        GARIS <span style={{color: t < T.payah - 0.05 ? TK.cyan : TK.dot}}>{String(drawn).padStart(3, '0')}</span>
        <span style={{opacity: 0.55, marginLeft: 18}}>{t < T.payah - 0.05 ? 'YANG KITA BAYANGKAN' : 'YANG SEBENARNYA ADA'}</span>
      </Abs>
      {/* 7 — your class, maths */}
      <Stat t={t} inAt={H.kelasmu} outAt={H.aneh - 0.2} num="Kelasmu" color={TK.cyan} size={176} label={['23 ORANG', 'ADA YANG SAMA?']} />
      {(() => {
        const qi = p(t, H.aneh, H.aneh + 0.45), qo = p(t, H.mat - 0.2, H.mat);
        if (qi < 0.01 || qo > 0.99) return null;
        const strike = p(t, T.aneh - 0.05, T.aneh + 0.35);
        return (
          <div style={{position: 'absolute', left: 64, top: 214, opacity: qi * (1 - qo), transform: `translateY(${(1 - qi) * 46 - qo * 40}px)`}}>
            <div style={{...lab, fontSize: 24, color: TK.dot, opacity: 0.8}}>ITU BUKAN</div>
            <div style={{position: 'relative', display: 'inline-block', fontFamily: HEAD, fontWeight: 300, fontSize: 132, lineHeight: 1, letterSpacing: -5, color: TK.dot, marginTop: 6}}>
              kebetulan aneh
              <div style={{position: 'absolute', left: -6, top: '54%', height: 8, width: `${104 * strike}%`, background: TK.coral}} />
            </div>
          </div>
        );
      })()}
      {/* end card */}
      {(() => {
        const q = p(t, H.mat, H.mat + 0.45);
        if (q < 0.01) return null;
        const s1 = p(t, T.mat - 0.1, T.mat + 0.4);
        const s2 = p(t, T.mat + 0.4, T.mat + 0.9);
        return (
          <>
            <div style={{position: 'absolute', left: 64, top: 200, opacity: q, transform: `translateY(${(1 - q) * 40}px)`}}>
              <div style={{...lab, fontSize: 22, color: TK.dot, opacity: 0.75}}>ITU MATEMATIKA · 23 ORANG</div>
              <div style={{fontFamily: MONO, fontWeight: 500, fontStretch: '87.5%', fontSize: 30, color: TK.dot, marginTop: 16, whiteSpace: 'nowrap'}}>
                1 − <span style={{color: TK.lime}}>365/365 × 364/365 × … × 343/365</span>
              </div>
              <div style={{display: 'flex', alignItems: 'flex-end', gap: 22, marginTop: 10}}>
                <div style={{fontFamily: HEAD, fontWeight: 300, fontSize: 150, lineHeight: 0.9, letterSpacing: -6, color: TK.coral}}>= 50,73%</div>
              </div>
            </div>
            <svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0, opacity: s1}}>
              <line x1={CURVE.x0 - 20} y1={CURVE.y0} x2={CURVE.x1 + 20} y2={CURVE.y0} stroke={TK.dot} strokeOpacity={0.5} strokeWidth={1.5} />
              <line x1={CURVE.x0 - 20} y1={CURVE.y0 - CURVE.h / 2} x2={CURVE.x1 + 20} y2={CURVE.y0 - CURVE.h / 2} stroke={TK.dot} strokeOpacity={0.35} strokeWidth={1.5} strokeDasharray="4 6" />
              <line x1={CURVE.x0 - 20} y1={CURVE.y0 - CURVE.h} x2={CURVE.x1 + 20} y2={CURVE.y0 - CURVE.h} stroke={TK.dot} strokeOpacity={0.18} strokeWidth={1.5} strokeDasharray="4 6" />
              {[23, 50, 70].map((n) => {
                const [x, y] = curvePos(n - 1);
                return (
                  <g key={n}>
                    <line x1={x} y1={y + 14} x2={x} y2={CURVE.y0 + 10} stroke={TK.coral} strokeOpacity={0.7} strokeWidth={1.5} />
                    <text x={x} y={CURVE.y0 + 38} textAnchor="middle" fill={TK.cyan} style={{...lab, fontSize: 19}}>{n}</text>
                  </g>
                );
              })}
              <text x={CURVE.x0 - 20} y={CURVE.y0 - CURVE.h / 2 - 10} fill={TK.dot} fillOpacity={0.6} style={{...lab, fontSize: 17}}>½</text>
              <text x={CURVE.x0 - 20} y={CURVE.y0 - CURVE.h - 10} fill={TK.dot} fillOpacity={0.6} style={{...lab, fontSize: 17}}>100% · PELUANG ADA YANG SAMA</text>
              <text x={CURVE.x0 - 20} y={CURVE.y0 + 38} fill={TK.dot} fillOpacity={0.5} style={{...lab, fontSize: 17}}>ORANG →</text>
            </svg>
            <div style={{position: 'absolute', left: 64, right: 64, top: 1196, display: 'flex', justifyContent: 'space-between', opacity: s2, transform: `translateY(${(1 - s2) * 30}px)`}}>
              {[['23', '50,73%'], ['50', '97,04%'], ['70', '99,92%']].map(([n, v]) => (
                <div key={n} style={{width: 290, borderTop: '1.5px solid rgba(237,235,230,0.3)', paddingTop: 18}}>
                  <div style={{...lab, fontSize: 20, color: TK.cyan}}>{n} ORANG</div>
                  <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 70, lineHeight: 1.1, letterSpacing: -2, color: TK.coral}}>{v}</div>
                  <div style={{...lab, fontSize: 17, color: TK.dot, opacity: 0.55}}>ADA YANG SAMA</div>
                </div>
              ))}
            </div>
          </>
        );
      })()}

      <MonoCaption t={t} pages={PAGES} accent={ACCENT} />
    </AbsoluteFill>
  );
};

const cx = (k: number) => ringPos(k)[0];
const cy = (k: number) => ringPos(k)[1];
const buildMat = () => ({mat: dotText('MATEMATIKA', (px) => `800 ${px}px 'Tik Head'`, MAT_BOX, 365)});

// ---------- sound: cues on visual events (names from the TITIK set only) ----------
const s = (t: number, name: string, vol = 0.6): Sfx => ({t: Math.max(0, t), src: `audio/sfx/titik/${name}.wav`, vol});
export const TITIK_SFX: Sfx[] = [
  s(0, 'hum', 0.35), s(T.n23, 'pop', 0.55), s(T.dua, 'ping', 0.55),
  s(T.keb - 0.1, 'swish', 0.45), s(T.menebak, 'drop', 0.45),
  s(T.setahun - 0.2, 'swell', 0.5), s(T.n365, 'pop', 0.6),
  s(T.jawab - 0.15, 'whoosh', 0.5), s(T.n50, 'ding', 0.8),
  s(T.rahasia - 0.1, 'swish', 0.5), s(T.jOrang + 0.1, 'click', 0.55), s(T.pasangan, 'ping', 0.5),
  s(T.membentuk - 0.1, 'swell', 0.55), s(T.n253, 'chime', 0.75), s(T.setiap, 'ping', 0.5), s(T.setiap + 0.55, 'tick', 0.4),
  s(T.tabrak + 0.03, 'drop', 0.7), s(T.tabrak + 0.05, 'ding', 0.6),
  s(T.bayangkan - 0.1, 'swish', 0.5), s(LAND[0], 'drop', 0.55), s(LAND[1], 'drop', 0.55), s(LAND[2], 'drop', 0.55),
  ...[4, 9, 14, 19].map((i) => s(LAND[i], 'tick', 0.42)), s(T.terisi, 'click', 0.5),
  s(T.ke23 - 0.05, 'pop', 0.55), s(T.turun, 'drop', 0.65), s(T.setengah, 'ding', 0.8),
  s(T.n50b - 0.1, 'whoosh', 0.6), s(COLL_T[26], 'ping', 0.55), s(T.n97, 'chime', 0.75),
  s(T.n70 - 0.15, 'whoosh', 0.6), s(COLL_T[54], 'ping', 0.5), s(T.n999, 'sparkle', 0.7),
  s(T.otak - 0.1, 'swish', 0.5), s(T.jago, 'tick', 0.45), s(T.payah - 0.05, 'swell', 0.55), s(T.pas4, 'chime', 0.6),
  s(T.jadi - 0.1, 'swish', 0.5), s(T.adaYang, 'ping', 0.55), s(T.aneh, 'click', 0.6),
  s(T.itu2 - 0.15, 'whoosh', 0.55), s(T.mat, 'sparkle', 0.7),
];
