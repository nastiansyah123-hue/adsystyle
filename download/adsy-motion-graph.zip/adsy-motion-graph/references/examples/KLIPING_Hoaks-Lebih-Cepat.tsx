// REFERENCE DEMO (ADSY MOTION GRAPH v1.8) — read for structure only: scenes, camera moves, word-pinned beats, SFX cues.
// Do NOT copy this story, its text or its layout into a buyer video. Written in the author's demo workspace, so a few
// imports differ from the starter: `makeCues(words)` ≈ the starter's `at()/endOf()` from src/lib/words.ts, and
// `EpisodeAudio` ≈ Main.tsx audio (musicFile + auto-duck) + <SfxTrack /> fed by src/audio-plan.json sfxCues.
// The `getInputProps()` draft switch below was a workspace-only shortcut: do not copy it (the starter has --silent-draft).
import React from 'react';
import {AbsoluteFill, getInputProps} from 'remotion';
import {makeCues} from '../../lib/cues';
import {camera, lerp, Move, pagesFor, Pose, rnd, roughEllipse, roughLine, shake, StyleFonts, useTime, World} from '../../styles/shared';
import {EpisodeAudio, Sfx} from '../../styles/audio';
import {
  arrowHead, Badge, BLOCK, Bubble, Burst, Caption, Clipping, Crowd, Cut, Desk, Face, FAT, Finger, GRAIN, HAND, Hold, hp, Ink,
  Magnifier, makeHold, Marker, Note, Off, on, Person, Phone, Photo, PressCard, Q, Ransom, Robot, Runner, Scissors, Scrap, Sheet, Slip, Stamp,
  StopSign, Stopwatch, Tape, TextLines, TornBar, TYPE,
} from '../../styles/kliping/kit';
import wordsFile from './words.json';

// KLIPING episode — "Hoaks lebih cepat": a zine collage on a kraft desk, animated in stop-motion (12 fps holds).
// Each chapter is a new torn sheet slapped onto the desk; facts from Vosoughi, Roy & Aral (Science, 2018).

const C = makeCues(wordsFile);
const a = C.at;
const PAGES = pagesFor(C.words, 4, 22);
export const KLIPING_DURATION = C.duration + 1.4;

// chapter landings (a sheet slides in during the two holds before each)
const T = {
  study: a('tahun') - 0.1,
  check: a('semuanya') - 0.1,
  result: a('hasilnya') - 0.1,
  race: a('untuk') - 0.1,
  bot: a('siapa') - 0.1,
  crowd: a('yang bikin hoaks') - 0.1,
  why: a('kenapa') - 0.1,
  plain: a('sementara') - 0.1,
  hold: a('jadi sebelum') - 0.1,
  end: a('karena di grup') - 0.1,
};
/** Glued onto a chapter's sheet before it slides in (so it travels with the sheet). */
const G = (landing: number) => landing - 0.5;
const live = (h: Hold, from: number, to: number) => h.tq >= from - 3 / 12 && h.tq < to + 2 / 12;
const HIT = [a('2018'), a('126'), a('benar'), a('bohong'), a('70'), a('kali'), a('bukan'), a('manusia'), a('tahan'), a('penerbitnya')];
const TRUE_INK = '#13A06C';

/** Stop-motion camera: pose and impact shake are both sampled on the held clock. */
const Cam: React.FC<{h: Hold; start?: Partial<Pose>; moves?: Move[]; w?: number; children: React.ReactNode}> = ({h, start, moves = [], w = 1080, children}) => {
  const pose = camera(h.tq, {x: 540, y: 960, s: 1, r: 0, ...start}, moves);
  return <World pose={pose} offset={shake(h.tq, HIT, 11, 0.3)} w={w}>{children}</World>;
};
const Txt: React.FC<{f: string; s: number; c?: string; children: React.ReactNode; style?: React.CSSProperties}> = ({f, s, c = Q.ink, children, style}) => (
  <div style={{fontFamily: f, fontSize: s, color: c, lineHeight: 1, whiteSpace: 'nowrap', ...style}}>{children}</div>
);
/** One-line mini ransom inside a chat bubble. */
const MiniMsg: React.FC<{h: Hold; at: number; seed: number; size?: number}> = ({h, at, seed, size = 19}) => (
  <div style={{position: 'relative', height: size * 1.35}}><Ransom h={h} at={at} text="SEBARKAN SEBELUM DIHAPUS!" size={size} x={0} y={0} seed={seed} per={0} z={1} /></div>
);
const Headline: React.FC<{w: number}> = ({w}) => <div><div style={{height: 18, width: w * 0.92, background: Q.ink, marginBottom: 8}} /><div style={{height: 18, width: w * 0.6, background: Q.ink}} /></div>;

// ───────────────────────── 1 · cold open: the forwarded message ─────────────────────────
const FAMILY = [
  {x: 30, y: 560, w: 190, hair: 0, bg: Q.pink, name: 'Om', r: -8},
  {x: 870, y: 690, w: 180, hair: 2, bg: Q.mint, name: 'Tante', r: 7},
  {x: 20, y: 1040, w: 200, hair: 3, bg: Q.cobalt, name: 'Pakde', r: 5},
  {x: 880, y: 1150, w: 170, hair: 1, bg: Q.mustard, name: 'Bude', r: -6},
];
const Chat: React.FC<{h: Hold}> = ({h}) => {
  const tP = a('pernah');
  return (
    <Cam h={h} start={{x: 540, y: 735, s: 1.62, r: -2}} moves={[{from: tP - 0.06, to: tP + 0.7, x: 540, y: 930, s: 1, r: 0}, {from: tP + 0.7, to: T.study, s: 1.06, y: 900, r: 0.8}]}>
      {FAMILY.map((p, i) => (
        <Cut key={i} h={h} at={a('pesan') + i * 0.21} x={p.x} y={p.y} rot={p.r} z={2} seed={i}>
          <Person w={p.w} bg={p.bg} hair={p.hair} seed={10 + i} />
          <div style={{position: 'absolute', left: p.w * 0.1, top: p.w * 1.12, background: Q.paper, padding: '2px 14px', fontFamily: HAND, fontWeight: 700, fontSize: 34, color: Q.ink, transform: 'rotate(-4deg)', boxShadow: '3px 4px 0 rgba(0,0,0,0.2)'}}>{p.name}</div>
        </Cut>
      ))}
      <Phone h={h} at={0} x={230} y={330} w={620} hgt={1180} rot={-1.5} seed={3}>
        <Bubble h={h} at={0} x={20} y={22} w={300} name="Om Heri" nameColor={Q.cobalt} seed={1}>
          <div style={{fontFamily: HAND, fontWeight: 700, fontSize: 30, color: Q.ink}}>Selamat pagi semua</div>
        </Bubble>
        <Bubble h={h} at={0} x={20} y={128} w={520} name="Tante Rina" fwd seed={2}>
          <div style={{position: 'relative', height: 200}}>
            <Ransom h={h} at={-0.12} text="SEBARKAN" size={46} x={4} y={4} seed={1} per={1 / 16} z={1} />
            <Ransom h={h} at={a('sebelum')} text="SEBELUM" size={46} x={30} y={70} seed={2} per={1 / 24} z={1} />
            <Ransom h={h} at={a('dihapus')} text="DIHAPUS!" size={46} x={8} y={136} seed={3} per={1 / 20} z={1} />
          </div>
        </Bubble>
        <Bubble h={h} at={a('begini')} x={40} y={436} w={480} name="Pakde" nameColor="#B5179E" fwd seed={3}><MiniMsg h={h} at={a('begini')} seed={4} /></Bubble>
        <Bubble h={h} at={a('di')} x={20} y={566} w={480} name="Bude" nameColor={Q.red} fwd seed={4}><MiniMsg h={h} at={a('di')} seed={5} /></Bubble>
        <Bubble h={h} at={a('keluarga')} x={40} y={696} w={480} name="Om Heri" nameColor={Q.cobalt} fwd seed={5}><MiniMsg h={h} at={a('keluarga')} seed={6} /></Bubble>
        <div style={{position: 'absolute', left: 18, right: 18, bottom: 18, height: 64, borderRadius: 32, background: Q.paper, border: `3px solid ${Q.ink}`, display: 'flex', alignItems: 'center', padding: '0 24px', fontFamily: TYPE, fontSize: 26, color: Q.greyInk}}>Ketik pesan…</div>
      </Phone>
      <Scrap h={h} at={a('grup')} x={150} y={150} w={780} hgt={140} color={Q.pink} rot={-2} seed={71} halftone={Q.red} z={8}>
        <Txt f={BLOCK} s={74}>GRUP KELUARGA</Txt>
      </Scrap>
      <Tape h={h} at={a('grup')} x={110} y={140} rot={-24} seed={71} />
      <Tape h={h} at={a('grup')} x={790} y={150} rot={18} seed={72} />
      <Burst h={h} at={a('pasti')} x={800} y={1330} size={340} color={Q.mustard} text={<><div>PASTI</div><div style={{fontSize: 62}}>PERNAH.</div></>} fontSize={52} rot={-10} />
      <Ink><Marker h={h} at={a('pernah', 1)} d={roughEllipse(540, 742, 330, 170, 4, 0.06, 1.12)} width={12} dur={0.35} /></Ink>
    </Cam>
  );
};

// ───────────────────────── 2 · the study: 2018, 126 ribu, 2006–2017 ─────────────────────────
/** A faint newspaper page behind the collage (columns, headline bars, two press photos). */
const Newsprint: React.FC<{x0: number; seed: number}> = ({x0, seed}) => (
  <div style={{position: 'absolute', left: x0 + 60, top: 100, width: 960, opacity: 0.42}}>
    <div style={{height: 12, background: Q.ink, marginBottom: 6}} /><div style={{height: 3, background: Q.ink, marginBottom: 26}} />
    <div style={{display: 'flex', gap: 34}}>
      {[0, 1, 2].map((c) => (
        <div key={c} style={{width: 297}}>
          <div style={{height: 30, width: '86%', background: '#8f897e', marginBottom: 10}} />
          <div style={{height: 30, width: '58%', background: '#8f897e', marginBottom: 18}} />
          {c !== 1 && <div style={{marginBottom: 18, opacity: 0.8}}><Photo w={297} hgt={c === 0 ? 300 : 220} tint="#C9C3B8" seed={seed + c} grey /></div>}
          <TextLines n={c === 1 ? 44 : 32} w={297} seed={seed + c * 50} color="#ABA59A" gap={30} thick={9} />
        </div>
      ))}
    </div>
  </div>
);
const RESEARCHERS = [
  {x: 80, r: -4, bg: Q.cobalt, pc: Q.mustard, hair: 0, name: 'Vosoughi', glasses: true},
  {x: 400, r: 3, bg: Q.pink, pc: Q.mint, hair: 4, name: 'Roy', glasses: false},
  {x: 720, r: -2, bg: Q.mint, pc: Q.pink, hair: 3, name: 'Aral', glasses: false},
];
const Study: React.FC<{h: Hold}> = ({h}) => {
  const P2 = 1200, P3 = 2400;
  const tCut = a('membedah') - 0.1;
  const tPan1 = a('sekitar'), tPan2 = a('dari') - 0.17;
  const cutQ = hp(h, tCut, tPan1 - 0.05);
  const sx = lerp(1000, 140, cutQ);
  const spread = hp(h, a('menyebar'), a('menyebar') + 0.45);
  const yrs = Array.from({length: 12}).map((_, i) => 2006 + i);
  const rAt = [a('tiga'), a('peneliti'), a('peneliti') + 0.25];
  return (
    <Sheet h={h} at={T.study} color={Q.paper} from="right" seed={101} dots={Q.cobalt} corner="br">
      <Cam h={h} w={3600} moves={[
        {from: T.study, to: tPan1, s: 1.03, r: -0.3},
        {from: tPan1, to: tPan1 + 0.4, x: 540 + P2, s: 1, r: 0},
        {from: tPan1 + 0.4, to: tPan2, s: 1.035, r: 0.3},
        {from: tPan2, to: tPan2 + 0.4, x: 540 + P3, s: 1, r: 0},
        {from: tPan2 + 0.4, to: T.check, s: 1.04, r: -0.3},
      ]}>
        <Newsprint x0={0} seed={3} /><Newsprint x0={P2} seed={9} /><Newsprint x0={P3} seed={17} />

        {/* panel 1 — 2018, three researchers, the scissors */}
        <Ransom h={h} at={G(T.study)} text="TAHUN" size={84} x={90} y={170} seed={21} per={0} />
        <Scrap h={h} at={a('2018')} x={70} y={290} w={620} hgt={250} color={Q.mustard} rot={-3} seed={201} halftone={Q.red} z={5}>
          <Txt f={BLOCK} s={180} style={{textShadow: `8px 8px 0 ${Q.paper}`}}>2018</Txt>
        </Scrap>
        <Tape h={h} at={a('2018')} x={40} y={290} rot={-30} seed={21} />
        <Burst h={h} at={a('2018') + 0.5} x={850} y={420} size={270} color={Q.pink} text={<><div style={{fontFamily: HAND, fontSize: 30}}>terbit di</div><div>SCIENCE</div></>} fontSize={33} rot={10} />
        {RESEARCHERS.map((r, i) => (
          <React.Fragment key={i}>
            <Scrap h={h} at={G(T.study)} x={r.x} y={630} w={270} hgt={330} color={r.bg} rot={r.r} seed={210 + i} z={4} halftone={Q.paper} />
            <Cut h={h} at={rAt[i]} x={r.x + 25} y={690} rot={r.r} z={5} seed={i} big={1.2}><Person w={220} bg={r.pc} hair={r.hair} seed={220 + i} glasses={r.glasses} /></Cut>
            <Scrap h={h} at={rAt[i] + 0.083} x={r.x + 30} y={930} w={210} hgt={74} color={Q.paper} rot={-r.r * 1.5} seed={230 + i} z={6}>
              <Txt f={HAND} s={42} style={{fontWeight: 700}}>{r.name}</Txt>
            </Scrap>
          </React.Fragment>
        ))}
        <Scrap h={h} at={a('mit')} x={80} y={1060} w={900} hgt={124} color={Q.ink} rot={-1.5} seed={240} z={7}>
          <Txt f={BLOCK} s={60} c={Q.paper}>PENELITI <span style={{color: Q.mustard}}>MIT</span> · 2018</Txt>
        </Scrap>
        <Tape h={h} at={a('mit')} x={30} y={1070} rot={-60} w={130} seed={24} />
        <Ink><Marker h={h} at={a('2018') + 0.25} d={roughEllipse(385, 418, 350, 155, 9, 0.05, 1.12)} width={11} dur={0.4} /></Ink>
        {/* the clipping being dissected ("membedah") */}
        <Scrap h={h} at={G(T.study)} x={70} y={1250} w={940} hgt={170} color={Q.news} rot={-1} seed={250} z={3}>
          <div style={{position: 'absolute', left: 30, top: 22, right: 30}}><div style={{height: 22, width: '62%', background: Q.ink, marginBottom: 14}} /><TextLines n={4} w={880} seed={7} color="#A9A397" gap={24} thick={10} /></div>
        </Scrap>
        <Ink w={3600}>
          <path d={`M 1010 1340 L ${sx} ${1340 + (1010 - sx) * 0.012}`} stroke={Q.red} strokeWidth={5} strokeDasharray="16 12" fill="none" opacity={on(h, tCut) ? 1 : 0} />
        </Ink>
        {on(h, tCut - 0.15) && !on(h, tPan1 + 0.5) && <div style={{position: 'absolute', left: sx - 150, top: 1185, zIndex: 31, transform: `rotate(${-4 + (h.n % 2) * 3}deg)`}}><Scissors w={300} open={h.n % 2} /></div>}

        {/* panel 2 — ~126 ribu kabar */}
        <Note h={h} at={a('sekitar')} x={P2 + 90} y={170} text="± sekitar" size={58} color={Q.red} rot={-5} />
        <Ransom h={h} at={a('126')} text="126" size={240} x={P2 + 80} y={250} seed={26} rot={-3} />
        <Ransom h={h} at={a('ribu')} text="RIBU" size={124} x={P2 + 520} y={520} seed={27} rot={4} z={12} />
        {Array.from({length: 44}).map((_, i) => {
          const bx = P2 + 60 + rnd(i * 3.3 + 1) * 830, by = 660 + rnd(i * 5.1 + 2) * 600;
          const x = bx + (bx - P2 - 540) * 0.16 * spread, y = by + (by - 960) * 0.12 * spread;
          const at = i < 20 ? G(T.study) : a('126') + 0.12 + (i - 20) * 0.05;
          return <Slip key={i} h={h} at={at} x={x} y={y} rot={(rnd(i * 7.7) - 0.5) * 44} color={[Q.paper, Q.paper, Q.paper, Q.pink, Q.mint, Q.mustard, Q.news][Math.floor(rnd(i * 9.1) * 7)]} seed={300 + i} />;
        })}
        <Note h={h} at={a('kabar')} x={P2 + 120} y={600} text="kabar!" size={80} color={Q.cobalt} rot={-6} z={14} shadow={`3px 3px 0 ${Q.paper}`} />
        <Scrap h={h} at={a('twitter')} x={P2 + 470} y={1340} w={460} hgt={130} color={Q.ink} rot={4} seed={260} z={14}>
          <Txt f={FAT} s={78} c={Q.paper}>di Twitter</Txt>
        </Scrap>

        {/* panel 3 — the 2006–2017 timeline strip */}
        <Ransom h={h} at={a('dari')} text="DARI TAHUN" size={86} x={P3 + 90} y={200} seed={28} />
        <Ransom h={h} at={a('2006')} text="2006" size={116} x={P3 + 60} y={480} seed={29} rot={-4} />
        <Note h={h} at={a('sampai')} x={P3 + 400} y={640} text="sampai" size={50} color={Q.red} rot={-8} />
        <Ransom h={h} at={a('2017')} text="2017" size={116} x={P3 + 560} y={480} seed={30} rot={3} />
        <Scrap h={h} at={G(T.study)} x={P3 + 50} y={780} w={980} hgt={170} color={Q.mustard} rot={-1} seed={270} z={4}>
          <div style={{position: 'absolute', left: 50, top: 30, display: 'flex', gap: 0}}>
            {yrs.map((y) => <div key={y} style={{width: 78, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8}}><div style={{width: 5, height: 40, background: Q.ink}} /><Txt f={TYPE} s={28} style={{fontWeight: 700}}>{`'${String(y).slice(2)}`}</Txt></div>)}
          </div>
        </Scrap>
        <Tape h={h} at={G(T.study)} x={P3 + 10} y={770} rot={-70} w={140} seed={31} />
        <Tape h={h} at={G(T.study)} x={P3 + 950} y={780} rot={70} w={140} seed={32} />
        <Ink w={3600}>
          <Marker h={h} at={a('2006') + 0.1} d={roughLine([P3 + 128, 820], [P3 + 990, 812], 7, 4) + arrowHead(P3 + 992, 812, 0, 36)} color={Q.red} width={12} dur={a('2017') - a('2006') + 0.1} />
        </Ink>
        {yrs.map((y, i) => <Slip key={y} h={h} at={a('2006') + 0.1 + i * 0.085} x={P3 + 55 + i * 78} y={990 + rnd(i * 2.1) * 80} rot={(rnd(i * 5.5) - 0.5) * 50} color={i % 3 ? Q.paper : Q.pink} seed={400 + i} w={112} />)}
        <Scrap h={h} at={a('sampai') + 0.25} x={P3 + 90} y={1250} w={860} hgt={150} color={Q.paper} rot={-1.5} seed={280} z={12}>
          <div style={{textAlign: 'left', width: '100%', padding: '0 36px'}}>
            <Txt f={TYPE} s={34} style={{fontWeight: 700}}>SUMBER: Vosoughi, Roy &amp; Aral</Txt>
            <Txt f={TYPE} s={34} c={Q.greyInk} style={{marginTop: 10}}>Science, 2018</Txt>
          </div>
        </Scrap>
        <Tape h={h} at={a('sampai') + 0.25} x={P3 + 820} y={1230} rot={25} w={140} seed={33} />
      </Cam>
    </Sheet>
  );
};

// ───────────────────────── 3 · six fact-checkers: BENAR / BOHONG ─────────────────────────
const GRID = [0, 1, 2, 3, 4, 5].map((i) => ({x: 66 + (i % 3) * 322, y: 680 + Math.floor(i / 3) * 410, r: (rnd(i * 3.7) - 0.5) * 9}));
const VERDICT = ['BENAR', 'BOHONG', 'BOHONG', 'BENAR', 'BENAR', 'BOHONG'];
const Check: React.FC<{h: Hold}> = ({h}) => {
  let nb = 0, nh = 0;
  return (
    <Sheet h={h} at={T.check} color={Q.cobalt} from="left" seed={111} dots={Q.paper} corner="tl" rot={0.6}>
      <Cam h={h} moves={[{from: T.check, to: T.result, s: 1.045, y: 945, r: -0.5}]}>
        <Note h={h} at={G(T.check)} x={96} y={150} text="semuanya…" size={62} color={Q.paper} rot={-4} />
        <Ransom h={h} at={a('dicek')} text="DICEK!" size={118} x={430} y={150} seed={41} rot={-3} avoid={Q.cobalt} />
        {[0, 1, 2, 3, 4, 5].map((i) => <Badge key={i} h={h} at={a('enam') + i * 0.083} x={140 + i * 160} y={410} r={70} n={i + 1} color={[Q.paper, Q.mustard, Q.pink, Q.mint, Q.paper, Q.mustard][i]} />)}
        <Scrap h={h} at={a('pemeriksa')} x={70} y={520} w={940} hgt={104} color={Q.mustard} rot={-1.2} seed={121} z={9}>
          <Txt f={BLOCK} s={50}>6 LEMBAGA PEMERIKSA FAKTA</Txt>
        </Scrap>
        {GRID.map((g, i) => {
          const isTrue = VERDICT[i] === 'BENAR';
          const at = isTrue ? a('benar') + nb++ * 0.083 : a('bohong') + nh++ * 0.083;
          return (
            <React.Fragment key={i}>
              <Clipping h={h} at={G(T.check)} x={g.x} y={g.y} w={300} hgt={370} seed={130 + i} rot={g.r} head={<Headline w={240} />} photo={[Q.pink, Q.mustard, Q.mint, Q.red, Q.cobalt, Q.mustard][i]} lines={5} />
              <Stamp h={h} at={at} x={g.x + 150} y={g.y + 262} text={VERDICT[i]} color={isTrue ? TRUE_INK : Q.red} size={isTrue ? 56 : 49} rot={(rnd(i * 9.3) - 0.5) * 26} blend={false} />
            </React.Fragment>
          );
        })}
      </Cam>
    </Sheet>
  );
};

// ───────────────────────── 4 · 70% more likely to be shared ─────────────────────────
const Result: React.FC<{h: Hold}> = ({h}) => (
  <Sheet h={h} at={T.result} color={Q.pink} from="bottom" seed={141} dots={Q.red} corner="br" rot={-0.5}>
    <Cam h={h} moves={[{from: T.result, to: a('70'), s: 1.02}, {from: a('70'), to: T.race, s: 1.05, r: 0.5, y: 950}]}>
      <Ransom h={h} at={G(T.result)} text="HASILNYA?" size={104} x={80} y={150} seed={51} per={0} rot={-2} avoid={Q.pink} />
      <Clipping h={h} at={G(T.result)} x={70} y={330} w={340} hgt={430} seed={151} rot={-6} head={<Txt f={FAT} s={58} c={Q.red}>Bohong</Txt>} photo={Q.mustard} lines={6}>
        <Stamp h={h} at={G(T.result)} x={175} y={300} text="BOHONG" color={Q.red} size={44} rot={-18} blend={false} />
      </Clipping>
      <Ink><Marker h={h} at={a('bohong', 1)} d={roughEllipse(240, 545, 215, 270, 12, 0.05, 1.1)} color={Q.ink} width={9} dur={0.35} /></Ink>
      <Burst h={h} at={G(T.result)} x={730} y={535} size={420} color={Q.mustard} text="?" fontSize={230} rot={8} out={a('70')} z={3} />
      <Scrap h={h} at={a('70')} x={440} y={310} w={580} hgt={450} color={Q.mustard} rot={4} seed={152} halftone={Q.red} z={5} />
      <Ransom h={h} at={a('70')} text="70%" size={200} x={470} y={410} seed={52} per={1 / 24} rot={-3} avoid={Q.mustard} z={12} />
      {/* torn-strip bar chart: chance of being re-shared */}
      <Scrap h={h} at={G(T.result)} x={70} y={820} w={940} hgt={104} color={Q.ink} rot={-1} seed={157} z={8}>
        <Txt f={BLOCK} s={44} c={Q.paper}>PELUANG <span style={{color: Q.mustard}}>DISEBARKAN ULANG</span></Txt>
      </Scrap>
      <Scrap h={h} at={G(T.result)} x={70} y={990} w={240} hgt={120} color={Q.mint} rot={-2} seed={153} z={6}><Txt f={BLOCK} s={48}>BENAR</Txt></Scrap>
      <Scrap h={h} at={G(T.result)} x={70} y={1170} w={240} hgt={120} color={Q.red} rot={1.5} seed={154} z={6}><Txt f={BLOCK} s={46} c={Q.paper}>BOHONG</Txt></Scrap>
      <TornBar h={h} at={a('lebih') + 0.05} x={340} y={994} L={360} hgt={112} color={Q.paper} seed={155} halftone={TRUE_INK} dur={0.5} />
      <TornBar h={h} at={a('mungkin')} x={340} y={1174} L={612} hgt={112} color={Q.ink} seed={156} dur={0.6} />
      <Ink>
        <Marker h={h} at={a('disebarkan') - 0.1} d={roughLine([700, 970], [704, 1300], 3, 4)} color={Q.ink} width={5} dur={0.2} />
        <Marker h={h} at={a('disebarkan')} d={roughLine([712, 1330], [944, 1332], 5, 3) + arrowHead(946, 1332, 0, 28)} color={Q.ink} width={9} dur={0.25} />
        <Marker h={h} at={a('disebarkan') - 0.05} d={roughLine([470, 905], [960, 902], 8, 4)} color={Q.mustard} width={8} dur={0.3} />
        <Marker h={h} at={a('ulang')} d={roughEllipse(778, 1405, 172, 84, 27, 0.06, 1.15)} color={Q.ink} width={8} dur={0.3} />
      </Ink>
      <Note h={h} at={a('disebarkan') + 0.15} x={640} y={1350} text="+70%" size={110} color={Q.red} rot={-5} shadow={`4px 4px 0 ${Q.paper}`} />
    </Cam>
  </Sheet>
);

// ───────────────────────── 5 · the race to 1.500 people ─────────────────────────
const Race: React.FC<{h: Hold}> = ({h}) => {
  const t0 = a('untuk') + 0.15, tArr = a('orang') + 0.25;
  const fake = hp(h, t0, tArr);
  const trueQ = Math.min(0.62, Math.max(0, (h.tq - t0) / ((tArr - t0) * 6)));
  const fx = 80 + 560 * fake, tx = 80 + 560 * trueQ;
  const ruler = a('enam', 1);
  return (
    <Sheet h={h} at={T.race} color={Q.mustard} from="right" seed={161} dots={Q.paper} corner="tl" rot={0.4}>
      <Cam h={h} moves={[{from: T.race, to: T.bot, s: 1.04, r: -0.4, y: 950}]}>
        <Note h={h} at={G(T.race)} x={90} y={150} text="untuk menjangkau…" size={58} rot={-3} />
        <Ransom h={h} at={a('seribu')} text="1.500" size={150} x={80} y={230} seed={61} per={1 / 18} rot={-3} avoid={Q.mustard} />
        <Ransom h={h} at={a('orang')} text="ORANG" size={92} x={570} y={390} seed={62} rot={4} avoid={Q.mustard} />
        {/* lanes + finish + the audience */}
        <TornBar h={h} at={G(T.race)} x={60} y={560} L={760} hgt={150} color={Q.paper} seed={163} dur={0.01} />
        <TornBar h={h} at={G(T.race)} x={60} y={760} L={760} hgt={150} color={Q.paper} seed={164} dur={0.01} />
        <svg width={44} height={420} style={{position: 'absolute', left: 806, top: 530, zIndex: 5}}>
          {Array.from({length: 2 * 15}).map((_, i) => <rect key={i} x={(i % 2) * 22} y={Math.floor(i / 2) * 28} width={22} height={28} fill={(i + Math.floor(i / 2)) % 2 ? Q.ink : Q.paper} />)}
        </svg>
        <Crowd h={h} at={a('seribu')} x={862} y={520} cols={5} rows={10} size={30} per={1 / 24} />
        <Ink>
          {fake > 0.05 && fake < 1 && [0, 1, 2].map((k) => <path key={k} d={`M ${fx - 20 - k * 40} ${630 + k * 22} l -60 0`} stroke={Q.ink} strokeWidth={6} strokeLinecap="round" />)}
          <Marker h={h} at={tArr} d={roughEllipse(935, 740, 120, 250, 15, 0.05, 1.1)} color={Q.red} width={9} dur={0.3} />
          <Marker h={h} at={a('benar', 1)} d={`M ${tx + 100} 690 q -8 30 0 60` + arrowHead(tx + 100, 750, 90, 22)} color={Q.red} width={8} dur={0.25} />
        </Ink>
        <Runner h={h} x={fx} y={590} label="BOHONG" color={Q.red} seed={167} running={h.tq < tArr && h.tq >= t0} />
        <Runner h={h} x={tx} y={790} label="BENAR" color={TRUE_INK} seed={168} running={h.tq >= t0} />
        {/* time rulers: 1× vs 6× */}
        <Cut h={h} at={G(T.race)} x={50} y={1070} rot={-6} z={7}><Stopwatch w={180} tick={h.n} /></Cut>
        <Ink><Marker h={h} at={a('butuh')} d={roughEllipse(140, 1175, 128, 132, 18, 0.05, 1.12)} color={Q.red} width={9} dur={0.3} /></Ink>
        <Scrap h={h} at={G(T.race)} x={250} y={1080} w={160} hgt={80} color={Q.paper} rot={-2} seed={169} z={6}><Txt f={BLOCK} s={30} c={Q.red}>BOHONG</Txt></Scrap>
        <Scrap h={h} at={G(T.race)} x={250} y={1220} w={160} hgt={80} color={Q.paper} rot={2} seed={179} z={6}><Txt f={BLOCK} s={32} c={TRUE_INK}>BENAR</Txt></Scrap>
        <Scrap h={h} at={tArr} x={430} y={1074} w={88} hgt={86} color={Q.red} rot={-2} seed={170} z={6}><Txt f={BLOCK} s={36} c={Q.paper}>1×</Txt></Scrap>
        {[0, 1, 2, 3, 4, 5].map((i) => (
          <Scrap key={i} h={h} at={ruler + i * 0.06} x={430 + i * 94} y={1214} w={86} hgt={86} color={Q.mint} rot={(rnd(i * 2.2) - 0.5) * 6} seed={171 + i} z={6}><Txt f={BLOCK} s={40}>{i + 1}</Txt></Scrap>
        ))}
        <Ransom h={h} at={a('kali')} text="6×" size={124} x={640} y={1000} seed={63} rot={-6} avoid={Q.mustard} z={12} />
        <Scrap h={h} at={a('lebih lama')} x={250} y={1350} w={560} hgt={110} color={Q.ink} rot={-2} seed={178} z={8}><Txt f={BLOCK} s={54} c={Q.paper}>LEBIH LAMA</Txt></Scrap>
      </Cam>
    </Sheet>
  );
};

// ───────────────────────── 6 · who did it? not the bots ─────────────────────────
const Bot: React.FC<{h: Hold}> = ({h}) => {
  const tMove = a('bot', 1);
  const qm = hp(h, tMove - 0.05, tMove + 0.4);
  const rx = lerp(330, 84, qm), ry = lerp(560, 560, qm), rs = lerp(1, 0.84, qm);
  const nervous = on(h, a('ternyata')) && !on(h, a('bukan')) ? 2.6 : 1;
  const j = h.jig(77, nervous);
  return (
    <Sheet h={h} at={T.bot} color={Q.ink} from="top" seed={181} dots="#3a3a3a" corner="bl" rot={-0.4}>
      <Cam h={h} moves={[{from: T.bot, to: a('bukan'), s: 1.05}, {from: a('bukan'), to: a('bukan') + 0.4, s: 1.0}, {from: a('bukan') + 0.4, to: T.crowd, s: 1.035, r: 0.5}]}>
        <Off h={h} out={tMove} dy={-1600} r={-25}>
          <div style={{position: 'absolute', left: 0, top: 330, width: 1080, textAlign: 'center', fontFamily: FAT, fontSize: 1000, lineHeight: 1, color: Q.mustard, WebkitTextStroke: `10px ${Q.paper}`, transform: `rotate(${8 + h.jig(78).r * 2}deg)`, opacity: 0.95}}>?</div>
          <Ransom h={h} at={a('siapa') - 0.1} text="SIAPA" size={150} x={80} y={170} seed={71} per={1 / 30} rot={-3} avoid={Q.ink} />
          <Ransom h={h} at={a('pelakunya')} text="PELAKUNYA?" size={96} x={60} y={370} seed={72} per={1 / 40} rot={2} avoid={Q.ink} />
          <Scrap h={h} at={a('bot')} x={700} y={560} w={270} hgt={140} color={Q.pink} rot={8} seed={182} z={12}><Txt f={BLOCK} s={84}>BOT?</Txt></Scrap>
          <Note h={h} at={a('ternyata')} x={90} y={1270} text="ternyata…" size={90} color={Q.paper} rot={-4} />
        </Off>
        <div style={{position: 'absolute', left: rx + j.x, top: ry + j.y, transform: `rotate(${j.r * 2}deg) scale(${rs})`, transformOrigin: '0 0', zIndex: 8}}>
          <Cut h={h} at={a('bot')} x={0} y={0} big={1.2}><Robot w={420} eye={h.n} /></Cut>
          <Stamp h={h} at={a('bukan')} x={215} y={330} text="BUKAN" size={128} rot={-17} blend={false} z={20} />
        </div>
        {/* bots spread true and false equally fast */}
        <Scrap h={h} at={a('menyebarkan')} x={70} y={170} w={640} hgt={104} color={Q.paper} rot={-2} seed={183} z={9}><Txt f={BLOCK} s={46}>BOT MENYEBARKAN</Txt></Scrap>
        <Clipping h={h} at={a('benar', 2)} x={610} y={330} w={380} hgt={330} seed={184} rot={4} head={<Txt f={FAT} s={62} c={TRUE_INK}>Benar</Txt>} photo={Q.mint} lines={3} z={7} />
        <Clipping h={h} at={a('bohong', 2)} x={610} y={820} w={380} hgt={330} seed={185} rot={-3} head={<Txt f={FAT} s={62} c={Q.red}>Bohong</Txt>} photo={Q.pink} lines={3} z={7} />
        <Ink>
          <Marker h={h} at={a('benar', 2) + 0.08} d={roughLine([410, 700], [590, 520], 31, 5) + arrowHead(592, 518, -48, 34)} color={Q.paper} width={11} dur={0.25} />
          <Marker h={h} at={a('bohong', 2) + 0.08} d={roughLine([410, 860], [590, 980], 32, 5) + arrowHead(592, 982, 29, 34)} color={Q.paper} width={11} dur={0.25} />
        </Ink>
        <Cut h={h} at={a('sama') + 0.1} x={735} y={640} rot={-4} z={9}><Txt f={BLOCK} s={170} c={Q.mustard} style={{textShadow: `6px 6px 0 ${Q.paper}`}}>=</Txt></Cut>
        <Ransom h={h} at={a('sama')} text="SAMA" size={120} x={80} y={1210} seed={73} rot={-3} avoid={Q.ink} />
        <Ransom h={h} at={a('cepatnya')} text="CEPAT!" size={116} x={240} y={1370} seed={74} rot={2} avoid={Q.ink} />
      </Cam>
    </Sheet>
  );
};

// ───────────────────────── 7 · it's us: humans ─────────────────────────
const CROWD = Array.from({length: 14}).map((_, i) => {
  const row = i < 5 ? 0 : i < 9 ? 1 : 2;
  const col = row === 0 ? i : row === 1 ? i - 5 : i - 9;
  return {x: (row === 1 ? 140 : 30) + col * 205 + (rnd(i * 3.1) - 0.5) * 30, y: 700 + row * 210 + (rnd(i * 1.9) - 0.5) * 24, row, i};
});
const Humans: React.FC<{h: Hold}> = ({h}) => {
  const tm = a('melesat');
  const q = hp(h, tm - 0.05, tm + 0.38);
  return (
    <Sheet h={h} at={T.crowd} color={Q.red} from="left" seed={191} dots={Q.ink} corner="tr" rot={0.5}>
      <Cam h={h} moves={[{from: T.crowd, to: a('ya') - 0.1, s: 1.03}, {from: a('ya') - 0.1, to: T.why, s: 1.0, y: 975, r: -0.4}]}>
        <Note h={h} at={G(T.crowd)} x={90} y={170} text="yang bikin hoaks…" size={64} color={Q.paper} rot={-3} />
        <Ink z={4}>{[0, 1, 2].map((k) => <Marker key={k} h={h} at={tm + 0.12} d={roughLine([420 + k * 50, 1160 + k * 8], [760 + k * 50, 330 + k * 8], 40 + k, 8)} color={Q.paper} width={9 - k * 2} dur={0.3} />)}</Ink>
        <Burst h={h} at={G(T.crowd)} x={690} y={1250} size={480} color={Q.mustard} text="?" fontSize={250} rot={-8} out={a('ya') + 0.17} z={3} />
        <div style={{position: 'absolute', left: lerp(300, 650, q), top: lerp(800, 110, q), zIndex: 12, transform: `rotate(${lerp(-6, 12, q)}deg) scale(${lerp(1, 0.62, q)})`, transformOrigin: '0 0'}}>
          <Clipping h={h} at={G(T.crowd)} x={0} y={0} w={480} hgt={370} seed={192} head={<Txt f={FAT} s={104} c={Q.red}>HOAKS!</Txt>} photo={Q.mustard} lines={2} />
        </div>
        <Ransom h={h} at={a('kita')} text="KITA." size={160} x={80} y={340} seed={81} rot={-4} avoid={Q.red} />
        <Ransom h={h} at={a('manusia')} text="MANUSIA." size={100} x={70} y={555} seed={82} per={1 / 32} rot={2} avoid={Q.red} z={14} />
        {CROWD.map((c) => (
          <Cut key={c.i} h={h} at={a('ya') + c.row * 0.15 + (c.i % 5) * 0.042} x={c.x} y={c.y} rot={(rnd(c.i * 2.7) - 0.5) * 12} z={6 + c.row} seed={c.i}>
            <Person w={200} bg={[Q.pink, Q.cobalt, Q.mustard, Q.mint, Q.paper][c.i % 5]} tone={['#F2E3CF', '#E3C6A6', '#C99C76', '#F0D8BE'][c.i % 4]} hair={c.i % 5} seed={500 + c.i} glasses={c.i % 6 === 2} />
          </Cut>
        ))}
        <Ink z={20}><Marker h={h} at={a('manusia') + 0.3} d={'M 950 1130 Q 1030 700 900 400' + arrowHead(900, 400, -110, 40)} color={Q.paper} width={12} dur={0.35} /></Ink>
      </Cam>
    </Sheet>
  );
};

// ───────────────────────── 8 · why: new, shocking, scary, gross → share ─────────────────────────
const FACES = [
  {mood: 'kaget' as const, x: 55, y: 960, bg: Q.mustard, label: 'KAGET', lc: Q.mustard, fg: Q.ink, at: a('kaget')},
  {mood: 'takut' as const, x: 385, y: 1000, bg: '#9DB0FF', label: 'TAKUT', lc: Q.cobalt, fg: Q.paper, at: a('takut')},
  {mood: 'jijik' as const, x: 715, y: 960, bg: Q.mint, label: 'JIJIK', lc: Q.pink, fg: Q.ink, at: a('jijik')},
];
const COPIES = [[40, 560], [770, 620], [30, 1120], [760, 1180], [600, 1330], [610, 140], [70, 300], [790, 960]];
const OLD = [{x: 40, y: 1010, r: -7}, {x: 370, y: 1060, r: 4}, {x: 700, y: 1000, r: -3}];
const Why: React.FC<{h: Hold}> = ({h}) => {
  const tOut = a('dan yang') - 0.05;
  const k2 = a('kaget', 1);
  const qm = hp(h, tOut, tOut + 0.45);
  const tB = a('langsung');
  return (
    <Sheet h={h} at={T.why} color={Q.mint} from="bottom" seed={201} dots={Q.cobalt} corner="tl" rot={-0.5}>
      <Cam h={h} moves={[{from: T.why, to: tOut, s: 1.035, r: 0.4}, {from: tOut, to: tB, s: 1.06, r: -0.3, y: 990}, {from: tB, to: T.plain, s: 1.0, r: 0, y: 960}]}>
        <Off h={h} out={tOut} dy={-1500} r={-18} z={10}>
          <Ransom h={h} at={a('kenapa')} text="KENAPA?" size={112} x={80} y={150} seed={91} rot={-3} avoid={Q.mint} />
          <Note h={h} at={a('terasa')} x={90} y={800} text="terasa…" size={64} rot={-8} />
        </Off>
        {/* yesterday's (grey) news underneath: the hoax is the only thing that feels new */}
        {OLD.map((o, i) => <Clipping key={i} h={h} at={G(T.why)} x={o.x} y={o.y} w={330} hgt={380} seed={240 + i} rot={o.r} color="#E3DED4" head={<div style={{height: 20, width: 260, background: Q.grey}} />} photo={Q.grey} grey lines={5} z={2} />)}
        <Clipping h={h} at={G(T.why)} x={280} y={330} w={520} hgt={420} seed={202} rot={3} head={<Txt f={FAT} s={96} c={Q.red}>HOAKS</Txt>} photo={Q.pink} lines={3} z={4} />
        <Burst h={h} at={a('baru')} x={810} y={350} size={280} color={Q.pink} text="BARU!" fontSize={60} rot={14} />
        {FACES.map((f, i) => {
          const keep = i === 0;
          const x = keep ? lerp(f.x, 290, qm) : f.x, y = keep ? lerp(f.y, 790, qm) : f.y, s = keep ? lerp(1, 1.5, qm) : 1;
          return (
            <Off key={i} h={h} out={keep ? undefined : tOut} dx={i === 1 ? 300 : 1300} dy={i === 1 ? 1400 : 200} r={25} z={8}>
              <div style={{position: 'absolute', left: x, top: y, transform: `scale(${s})`, transformOrigin: '0 0', zIndex: 8}}>
                <Cut h={h} at={f.at} x={0} y={0} rot={(i - 1) * 6} big={1.25}><Face w={310} mood={f.mood} bg={f.bg} n={h.n} /></Cut>
                <Scrap h={h} at={f.at + 0.083} x={35} y={300} w={240} hgt={88} color={f.lc} rot={(1 - i) * 4} seed={210 + i} z={9}><Txt f={BLOCK} s={50} c={f.fg}>{f.label}</Txt></Scrap>
              </div>
            </Off>
          );
        })}
        <Note h={h} at={k2} x={790} y={880} text="!!" size={170} color={Q.red} rot={12} />
        <Ink><Marker h={h} at={k2 + 0.1} d={roughEllipse(520, 1030, 300, 290, 21, 0.06, 1.15)} color={Q.red} width={12} dur={0.4} /></Ink>
        {/* the shock gets copied and flies everywhere */}
        {COPIES.map(([cx, cy], i) => {
          const at = tB + i / 24;
          if (!on(h, at)) return null;
          const k = hp(h, at, at + 0.2);
          return (
            <div key={i} style={{position: 'absolute', left: lerp(450, cx, k), top: lerp(980, cy, k), zIndex: 14, transform: `rotate(${lerp(0, (rnd(i * 4.1) - 0.5) * 40, k)}deg) scale(${lerp(0.3, 1, k)})`}}>
              <Clipping h={h} at={at} x={0} y={0} w={220} hgt={170} seed={220 + i} head={<Txt f={FAT} s={44} c={Q.red}>HOAKS</Txt>} photo={false} lines={2} />
            </div>
          );
        })}
        <Ransom h={h} at={a('dibagi')} text="DIBAGI!" size={124} x={110} y={1380} seed={92} per={1 / 30} rot={-4} avoid={Q.mint} z={20} />
      </Cam>
    </Sheet>
  );
};

// ───────────────────────── 9 · the truth sounds… ordinary ─────────────────────────
const Plain: React.FC<{h: Hold}> = ({h}) => {
  const flat = Array.from({length: 33}).map((_, i) => `${i ? 'L' : 'M'} ${230 + i * 20} ${1130 + (i % 2 ? -1 : 1) * (i > 12 && i < 18 ? 10 : 2)}`).join(' ');
  return (
    <Sheet h={h} at={T.plain} color={Q.news} from="right" seed={231} dots={Q.grey} corner="br" rot={0.4}>
      <Cam h={h} moves={[{from: T.plain, to: T.hold, s: 1.05, y: 940}]}>
        <Clipping h={h} at={G(T.plain)} x={150} y={370} w={780} hgt={840} seed={232} rot={-1.5} color="#E9E5DD" head={<div><div style={{height: 28, width: 600, background: Q.grey, marginBottom: 12}} /><div style={{height: 28, width: 400, background: Q.grey}} /></div>} photo={Q.grey} grey lines={9} />
        <Scrap h={h} at={a('kebenaran')} x={190} y={240} w={560} hgt={110} color={Q.paper} rot={-2} seed={233} z={8}>
          <Txt f={TYPE} s={62} c={Q.greyInk} style={{fontWeight: 700, letterSpacing: 6}}>KEBENARAN</Txt>
        </Scrap>
        <Tape h={h} at={a('kebenaran')} x={150} y={230} rot={-20} w={140} seed={234} />
        <Note h={h} at={a('sering')} x={600} y={160} text="sering…" size={58} color={Q.greyInk} rot={-4} />
        <Ink><Marker h={h} at={a('terdengar')} d={flat} color={Q.greyInk} width={8} dur={0.6} /></Ink>
        <Note h={h} at={a('terdengar') + 0.1} x={220} y={1040} text="terdengar…" size={50} color={Q.greyInk} rot={-2} />
        <Cut h={h} at={a('aja')} x={140} y={1230} rot={-8} z={9}><Face w={230} mood="datar" bg={Q.grey} /></Cut>
        <Note h={h} at={a('biasa')} x={410} y={1260} text="biasa aja." size={108} color={Q.greyInk} rot={-4} />
      </Cam>
    </Sheet>
  );
};

// ───────────────────────── 10 · hold 3 seconds, check the source, compare ─────────────────────────
const Hold3: React.FC<{h: Hold}> = ({h}) => {
  const P2 = 1200;
  const tPan = a('cek') - 0.14;
  const tTahan = a('tahan');
  const approach = hp(h, a('jadi sebelum'), a('teruskan') + 0.1);
  const back = hp(h, tTahan, tTahan + 0.3);
  const tip: [number, number] = [lerp(lerp(900, 520, approach), 700, back), lerp(lerp(1640, 1225, approach), 1430, back)];
  const lens = hp(h, a('sumbernya') - 0.1, a('sumbernya') + 0.55);
  const others = [{x: P2 + 650, y: 900, r: 6, at: a('beritanya'), tint: Q.cobalt}, {x: P2 + 50, y: 1010, r: -7, at: a('tempat'), tint: Q.mint}, {x: P2 + 400, y: 1160, r: 3, at: a('lain'), tint: Q.mustard}];
  const cards = [{d: '3', c: Q.mustard, x: 60, at: a('3')}, {d: '2', c: Q.pink, x: 290, at: a('3') + 0.3}, {d: '1', c: Q.mint, x: 520, at: a('3') + 0.6}];
  return (
    <Sheet h={h} at={T.hold} color={Q.paper} from="left" seed={241} dots={Q.cobalt} corner="tr" rot={-0.4}>
      <Cam h={h} w={2400} moves={[{from: T.hold, to: tPan, s: 1.03, r: 0.3}, {from: tPan, to: tPan + 0.32, x: 540 + P2, s: 1, r: 0}, {from: tPan + 0.32, to: T.end, s: 1.04, r: -0.4}]}>
        {/* panel 1 — the forward button, a stop sign, 3-2-1 */}
        <Note h={h} at={a('sebelum', 1)} x={90} y={170} text="sebelum tekan…" size={70} rot={-3} out={a('3')} />
        <Phone h={h} at={G(T.hold)} x={190} y={300} w={540} hgt={1000} rot={-3} seed={242} z={5}>
          <Bubble h={h} at={G(T.hold)} x={16} y={24} w={440} name="Tante Rina" fwd seed={7} fs={24}>
            <div style={{position: 'relative', height: 90}}>
              <Ransom h={h} at={G(T.hold)} text="SEBARKAN" size={27} x={0} y={0} seed={8} per={0} z={1} />
              <Ransom h={h} at={G(T.hold)} text="SEBELUM DIHAPUS!" size={27} x={0} y={44} seed={9} per={0} z={1} />
            </div>
          </Bubble>
          <Bubble h={h} at={G(T.hold)} x={36} y={210} w={420} name="Om Heri" nameColor={Q.cobalt} fwd seed={8} fs={22}><MiniMsg h={h} at={G(T.hold)} seed={10} size={16} /></Bubble>
          <Bubble h={h} at={G(T.hold)} x={16} y={330} w={420} name="Bude" nameColor={Q.red} fwd seed={9} fs={22}><MiniMsg h={h} at={G(T.hold)} seed={11} size={16} /></Bubble>
          <Bubble h={h} at={G(T.hold)} x={36} y={450} w={420} name="Pakde" nameColor="#B5179E" fwd seed={10} fs={22}><MiniMsg h={h} at={G(T.hold)} seed={13} size={16} /></Bubble>
          <div style={{position: 'absolute', left: 30, right: 30, top: 690, height: 100, borderRadius: 50, background: Q.cobalt, border: `4px solid ${Q.ink}`, boxShadow: '4px 6px 0 rgba(0,0,0,0.25)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: BLOCK, fontSize: 44, color: Q.paper}}>TERUSKAN ➜</div>
        </Phone>
        <Ink><Marker h={h} at={a('teruskan')} d={roughEllipse(462, 1170, 270, 86, 51, 0.05, 1.12)} color={Q.red} width={10} dur={0.3} /></Ink>
        {on(h, a('jadi sebelum')) && (
          <div style={{position: 'absolute', left: tip[0] - 75, top: tip[1] - 8, transform: 'rotate(-38deg)', transformOrigin: '75px 8px', zIndex: 18}}><Finger w={160} /></div>
        )}
        <StopSign h={h} at={tTahan} x={790} y={620} size={330} text="TAHAN!" rot={-8} />
        {cards.map((k, i) => (
          <Scrap key={k.d} h={h} at={k.at} x={k.x} y={130 + (i % 2) * 24} w={200} hgt={210} color={k.c} rot={(i - 1) * 5} seed={250 + i} halftone={Q.ink} z={12}>
            <Txt f={BLOCK} s={170} style={{textShadow: `6px 6px 0 ${Q.paper}`}}>{k.d}</Txt>
          </Scrap>
        ))}
        <Note h={h} at={a('detik')} x={760} y={190} text="detik!" size={70} color={Q.red} rot={-6} />

        {/* panel 2 — magnify the source, find it elsewhere */}
        <Ransom h={h} at={a('cek')} text="CEK" size={130} x={P2 + 80} y={140} seed={101} rot={-4} />
        <Ransom h={h} at={a('sumbernya')} text="SUMBERNYA" size={84} x={P2 + 110} y={310} seed={102} per={1 / 30} rot={2} />
        <Clipping h={h} at={G(T.hold)} x={P2 + 160} y={450} w={580} hgt={480} seed={260} rot={-3} head={<Txt f={FAT} s={80} c={Q.red}>HOAKS</Txt>} photo={Q.pink} lines={3} z={4}>
          <div style={{position: 'absolute', left: 40, bottom: 34, fontFamily: TYPE, fontWeight: 700, fontSize: 34, color: Q.greyInk}}>sumber: ???</div>
        </Clipping>
        {on(h, a('cek')) && (
          <div style={{position: 'absolute', left: lerp(P2 + 680, P2 + 210, lens), top: lerp(1200, 760, lens), zIndex: 22, transform: `rotate(${h.jig(5).r * 4}deg)`}}>
            <Magnifier size={250}><Txt f={TYPE} s={64} c={Q.red} style={{fontWeight: 700}}>???</Txt></Magnifier>
          </div>
        )}
        {others.map((o, i) => (
          <Clipping key={i} h={h} at={o.at} x={o.x} y={o.y} w={340} hgt={300} seed={270 + i} rot={o.r} head={<Headline w={270} />} photo={o.tint} lines={3} z={10 + i}>
            <Stamp h={h} at={o.at + 0.25} x={260} y={230} text="✓" color={TRUE_INK} size={64} rot={8} round blend={false} z={30} />
          </Clipping>
        ))}
        <Note h={h} at={a('tempat')} x={P2 + 620} y={800} text="tempat lain!" size={58} color={Q.cobalt} rot={-6} z={30} />
      </Cam>
    </Sheet>
  );
};

// ───────────────────────── 11 · you are the publisher (end card) ─────────────────────────
const KIN = [{x: 0, y: 260, w: 150, bg: Q.pink, hr: 2}, {x: 450, y: 400, w: 140, bg: Q.mustard, hr: 0}, {x: -10, y: 900, w: 150, bg: Q.mint, hr: 3}, {x: 455, y: 960, w: 130, bg: Q.paper, hr: 1}];
const Publisher: React.FC<{h: Hold}> = ({h}) => (
  <Sheet h={h} at={T.end} color={Q.cobalt} from="top" seed={281} dots={Q.paper} corner="br" rot={0.3}>
    <Cam h={h} start={{x: 330, y: 720, s: 1.22, r: -1}} moves={[
      {from: a('grup', 1), to: a('kamu') + 0.05, x: 540, y: 960, s: 1, r: 0},
      {from: a('kamu') + 0.05, to: a('penerbitnya'), s: 1.04, y: 980, r: -0.4},
      {from: a('penerbitnya'), to: C.duration + 1.4, s: 1.07, y: 990, r: 0.2},
    ]}>
      {KIN.map((p, i) => <Cut key={i} h={h} at={G(T.end)} x={p.x} y={p.y} rot={(i % 2 ? 1 : -1) * 8} z={3} seed={30 + i}><Person w={p.w} bg={p.bg} hair={p.hr} seed={600 + i} /></Cut>)}
      <Phone h={h} at={G(T.end)} x={90} y={300} w={440} hgt={820} rot={-5} seed={282} title="Grup Keluarga" z={5}>
        {['Bude', 'Pakde', 'Om Heri', 'Tante Rina'].map((n, i) => (
          <Bubble key={n} h={h} at={G(T.end)} x={i % 2 ? 30 : 12} y={14 + i * 128} w={340} name={n} nameColor={[Q.red, '#B5179E', Q.cobalt, Q.red][i]} fwd seed={11 + i} fs={20}><MiniMsg h={h} at={G(T.end)} seed={12 + i} size={13} /></Bubble>
        ))}
      </Phone>
      <Ransom h={h} at={a('kamu')} text="KAMU" size={124} x={570} y={260} seed={111} rot={-3} avoid={Q.cobalt} />
      <Note h={h} at={a('bukan', 1)} x={580} y={440} text="bukan cuma" size={56} color={Q.paper} rot={-4} />
      <Scrap h={h} at={a('pembaca')} x={560} y={520} w={440} hgt={124} color={Q.paper} rot={3} seed={283} z={8}><Txt f={FAT} s={88}>pembaca.</Txt></Scrap>
      <Tape h={h} at={a('pembaca')} x={890} y={505} rot={30} w={120} seed={284} />
      <Cut h={h} at={a('kamu')} x={640} y={900} rot={4} z={4} seed={7}><Person w={300} bg={Q.mustard} hair={2} seed={640} /></Cut>
      <Clipping h={h} at={a('kamu') + 0.083} x={560} y={1150} w={400} hgt={300} seed={641} rot={-6} head={<Headline w={330} />} photo={Q.pink} lines={3} z={6} />
      <Note h={h} at={a('juga')} x={760} y={680} text="juga…" size={66} color={Q.mustard} rot={-6} z={14} />
      <PressCard h={h} at={a('kamu', 1)} x={130} y={800} w={820} hgt={660} rot={-3} name="KAMU">
        <Stamp h={h} at={a('penerbitnya')} x={470} y={505} text="PENERBIT" size={86} rot={-11} blend={false} z={30} />
      </PressCard>
    </Cam>
  </Sheet>
);

export const HoaksEpisode: React.FC = () => {
  const {t, frame, fps} = useTime();
  const h = makeHold(frame, fps);
  const tq = h.tq;
  const tLine = C.duration + 0.42;
  return (
    <AbsoluteFill style={{background: Q.kraft, overflow: 'hidden'}}>
      <StyleFonts />
      {/* music + SFX are generated later from plans/kliping.json and KLIPING_SFX; a picture-only draft skips audio with --props='{"draftNoAudio":true}' */}
      {!(getInputProps() as {draftNoAudio?: boolean}).draftNoAudio && (
        <EpisodeAudio vo="audio/vo/kliping.mp3" words={C.words} music="audio/music/kliping.wav" bed={0.5} duck={0.18} sfx={KLIPING_SFX} />
      )}
      <Desk />
      {tq < T.study + 2 / 12 && <Chat h={h} />}
      {live(h, T.study, T.check) && <Study h={h} />}
      {live(h, T.check, T.result) && <Check h={h} />}
      {live(h, T.result, T.race) && <Result h={h} />}
      {live(h, T.race, T.bot) && <Race h={h} />}
      {live(h, T.bot, T.crowd) && <Bot h={h} />}
      {live(h, T.crowd, T.why) && <Humans h={h} />}
      {live(h, T.why, T.plain) && <Why h={h} />}
      {live(h, T.plain, T.hold) && <Plain h={h} />}
      {live(h, T.hold, T.end) && <Hold3 h={h} />}
      {live(h, T.end, 999) && <Publisher h={h} />}
      <AbsoluteFill style={{backgroundImage: GRAIN, opacity: 0.14, mixBlendMode: 'multiply', pointerEvents: 'none'}} />
      <Caption t={t} pages={PAGES} />
      {/* end card line, once the last caption has gone */}
      {on(h, tLine) && (
        <div style={{position: 'absolute', left: 0, right: 0, top: 1556, display: 'flex', justifyContent: 'center', zIndex: 61}}>
          <div style={{background: Q.paper, padding: '10px 30px', transform: `rotate(-2deg) scale(${tq - tLine < 1 / 12 ? 1.12 : 1})`, boxShadow: '4px 6px 0 rgba(0,0,0,0.25)', fontFamily: HAND, fontWeight: 700, fontSize: 50, color: Q.ink}}>
            tahan 3 detik · <span style={{background: `linear-gradient(transparent 45%, ${Q.mustard} 45%, ${Q.mustard} 90%, transparent 90%)`}}>cek sumbernya</span>.
          </div>
        </div>
      )}
    </AbsoluteFill>
  );
};

const s = (t: number, name: string, vol = 0.55): Sfx => ({t: Math.max(0, t), src: `audio/sfx/kliping/${name}.wav`, vol});
const tear = (at: number) => s(at - 0.16, 'tear', 0.6);
export const KLIPING_SFX: Sfx[] = [
  s(0, 'slap', 0.45), s(a('dihapus'), 'pop', 0.45), s(a('pernah') - 0.04, 'paper', 0.45), s(a('grup'), 'tape', 0.45), s(a('pasti'), 'slap', 0.6),
  tear(T.study), s(a('2018'), 'slap', 0.65), s(a('mit'), 'tape', 0.5), s(a('membedah') - 0.05, 'snip', 0.55), s(a('membedah') + 0.3, 'snip', 0.5),
  s(a('126'), 'slap', 0.65), s(a('twitter'), 'tape', 0.45), s(a('2017'), 'pop', 0.5),
  tear(T.check), s(a('benar'), 'stamp', 0.7), s(a('bohong'), 'stamp', 0.75),
  tear(T.result), s(a('70'), 'slap', 0.85), s(a('disebarkan'), 'tape', 0.5),
  tear(T.race), s(a('seribu'), 'pop', 0.55), s(a('orang') + 0.25, 'ding', 0.6), s(a('kali'), 'slap', 0.7),
  tear(T.bot), s(a('bot'), 'slap', 0.6), s(a('bot') + 0.05, 'buzz', 0.35), s(a('bukan'), 'stamp', 0.85),
  s(a('bot', 1) - 0.05, 'crumple', 0.5), s(a('bohong', 2), 'slap', 0.5), s(a('sama'), 'pop', 0.55),
  tear(T.crowd), s(a('melesat'), 'paper', 0.55), s(a('manusia'), 'slap', 0.75),
  tear(T.why), s(a('baru'), 'slap', 0.6), s(a('kaget'), 'pop', 0.55), s(a('takut'), 'pop', 0.5), s(a('jijik'), 'crumple', 0.45),
  s(a('langsung'), 'shutter', 0.55), s(a('dibagi'), 'slap', 0.6),
  tear(T.plain), s(a('terdengar'), 'marker', 0.35),
  tear(T.hold), s(a('tahan'), 'stamp', 0.75), s(a('3'), 'slap', 0.55), s(a('3') + 0.6, 'slap', 0.6), s(a('tempat'), 'slap', 0.45),
  tear(T.end), s(a('kamu', 1), 'slap', 0.6), s(a('penerbitnya'), 'stamp', 0.85), s(a('penerbitnya') + 0.16, 'ding', 0.55),
];
