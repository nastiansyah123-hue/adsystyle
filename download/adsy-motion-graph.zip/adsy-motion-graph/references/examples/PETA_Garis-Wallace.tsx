// REFERENCE DEMO (ADSY MOTION GRAPH v1.8) — read for structure only: scenes, camera moves, word-pinned beats, SFX cues.
// Do NOT copy this story, its text or its layout into a buyer video. Written in the author's demo workspace, so a few
// imports differ from the starter: `makeCues(words)` ≈ the starter's `at()/endOf()` from src/lib/words.ts, and
// `EpisodeAudio` ≈ Main.tsx audio (musicFile + auto-duck) + <SfxTrack /> fed by src/audio-plan.json sfxCues.
// The `getInputProps()` draft switch below was a workspace-only shortcut: do not copy it (the starter has --silent-draft).
import React from 'react';
import {AbsoluteFill, getInputProps} from 'remotion';
import {makeCues} from '../../lib/cues';
import {lerp, pagesFor, pb, StyleFonts, useTime} from '../../styles/shared';
import {EpisodeAudio, Sfx} from '../../styles/audio';
import {
  Badge, Boat, Caption, Card, ClockIcon, Cross, Explorer, Ferry, flyCam, geoPath, Grain, Headline, Hl, inOut, IslandFill, Kicker, LABEL, LevelGauge,
  LL, LowerThird, MapFx, MapLabel, MapView, Measure, PETA as M, pg, Pin, ScaleBar, SERIF, shot, Spectrum, StraitSection, toScreen, TopVeil, AnimalKind,
} from '../../styles/peta/kit';
import wordsFile from './words.json';

// PETA episode — "Garis Wallace": one camera over a real Natural Earth map of Nusantara. Strait close-up (10m coast),
// fauna on both sides, the line drawn, the sea drained to the 200 m shelves, back to the strait, out to two continents.

const C = makeCues(wordsFile);
const a = C.at;
const PAGES = pagesFor(C.words, 5, 30);
export const PETA_DURATION = C.duration + 1.4;

const T = {
  bali: a('bali'), lombok: a('lombok'), cuma: a('cuma'), selat: a('selat'), km35: a('35'),
  tapi1: a('tapi'), ahli: a('ahli'), ini: a('ini'), garis1: a('garis'), batas1: a('batas'), paling: a('paling'), dunia1: a('dunia'),
  tahun: a('tahun'), y1856: a('1856'), naturalis: a('naturalis'), alfred: a('alfred'), menyeberang: a('menyeberang'), lombok2: a('lombok', 1),
  duaPulau: a('dua pulau'), saling: a('saling'), kelihatan: a('kelihatan'), tapi2: a('tapi burung-burungnya'), burung: a('burung-burungnya'), beda: a('beda'),
  diLombok: a('di lombok'), kakatua1: a('kakatua'), jawa1: a('jawa'), sumatera1: a('sumatera'), kalimantan1: a('kalimantan'), nggak1: a('nggak'),
  barat: a('barat'), harimau: a('harimau'), badak: a('badak'), gajah: a('gajah'), orangutan: a('orangutan'), hewanAsia: a('hewan-hewan'), asia1: a('asia'),
  timur: a('timur'), makin: a('makin'), mirip: a('mirip'), australia1: a('australia'), kakatua2: a('kakatua', 1), kuskus: a('kuskus'), kanguru: a('kanguru'), papua1: a('papua'),
  batasItu: a('batas itu'), garisW: a('garis wallace'),
  tapi3: a('tapi kenapa'), kenapa: a('kenapa'), persis: a('persis'), jawabannya: a('jawabannya'), bawahAir: a('bawah air'),
  waktu: a('waktu'), zaman: a('zaman'), surut: a('surut'), lebih: a('lebih'), n100: a('100'), meter: a('meter'),
  sumatera2: a('sumatera', 1), jawa2: a('jawa', 1), kalimantan2: a('kalimantan', 1), bali3: a('bali', 2), tersambung1: a('tersambung'), asia2: a('asia', 1),
  papua2: a('papua', 1), tersambung2: a('tersambung', 1), australia2: a('australia', 1),
  tapi4: a('tapi selat'), selatLombok: a('selat lombok'), terlalu: a('terlalu'), dalam: a('dalam'), nggak2: a('nggak pernah'),
  jadi: a('jadi'), jutaan: a('jutaan'), duaDunia: a('dua dunia'), berkembang: a('berkembang'), dipisahkan2: a('dipisahkan', 1), diseberangi: a('diseberangi'), beberapa: a('beberapa'), jam: a('jam'),
  indonesia: a('indonesia'), duaSamudra: a('dua samudra'), diSini: a('di sini'), duaBenua: a('dua benua'), benua: a('benua'), bertemu: a('bertemu'),
};

// ---------- camera ----------
const START = shot(115.75, -8.15, 8.0);
const MOVES = [
  {at: T.km35 - 0.55, dur: 1.0, to: shot(115.87, -8.3, 12.0)}, // push in on the 35 km gap
  {at: T.tapi1 - 0.05, dur: 1.4, to: shot(115.85, -8.0, 7.0)}, // a little out: the boundary
  {at: T.tahun - 0.25, dur: 1.4, to: shot(115.8, -8.4, 9.2)}, // 1856 crossing
  {at: T.duaPulau - 0.25, dur: 1.1, to: shot(115.95, -8.25, 8.4)},
  {at: T.kakatua1 + 0.35, dur: 1.6, to: shot(108.0, -2.3, 0.95)}, // out to the west
  {at: T.barat - 0.45, dur: 1.1, to: shot(106.5, -1.5, 1.0)},
  {at: T.timur - 0.45, dur: 1.6, to: shot(129.0, -5.0, 0.92)}, // east
  {at: T.batasItu - 0.5, dur: 1.6, to: shot(118.3, -2.8, 1.05)}, // the line
  {at: T.tapi3 + 0.02, dur: 1.5, to: shot(116.6, -6.3, 1.9)}, // why there?
  {at: T.bawahAir + 0.7, dur: 1.5, to: shot(109.5, -0.8, 0.72)}, // Sunda shelf
  {at: T.papua2 - 0.45, dur: 1.3, to: shot(133.5, -8.5, 0.72)}, // Sahul shelf
  {at: T.tapi4 - 0.35, dur: 1.5, to: shot(115.85, -7.3, 6.0)}, // the strait again
  {at: T.jadi - 0.35, dur: 1.6, to: shot(118.6, -3.6, 0.8)}, // two worlds
  {at: T.dipisahkan2 - 0.25, dur: 1.6, to: shot(115.82, -8.5, 9.5)}, // ferry
  {at: T.indonesia - 0.3, dur: 2.0, to: shot(121.0, -8.0, 0.47), drift: 0.01}, // two oceans, two continents
];

// Wallace line (approx., brief) with a short southern lead-in and a fade-out in the Celebes Sea
const WALLACE: LL[] = [[115.62, -10.2], [115.7, -9.2], [115.75, -8.4], [117.6, -5.0], [118.4, -2.5], [119.3, 0.5], [120.5, 3.5], [121.3, 5.4]];
const STRAIT_PART = 0.16;
// dry-shelf tint regions: Sunda = west of the Wallace line, Sahul = Australia + New Guinea shelf; Wallacea stays neutral
const SUNDA: LL[] = [[86, -48], [115.7, -48], [115.7, -9.2], [115.75, -8.4], [117.6, -5.0], [118.4, -2.5], [119.3, 0.5], [120.5, 3.5], [119.5, 6.3], [117.2, 7.3], [116.0, 9.0], [119.0, 16.0], [122.5, 22.0], [124, 48], [86, 48]];
const SAHUL: LL[] = [[112, -48], [160, -48], [160, 1], [130.6, 1], [130.6, -1.5], [132.2, -4.6], [131.5, -6.4], [128, -8.9], [125.6, -10.6], [122, -14], [112, -20]]; // fraction of the line drawn in the opening (the strait only)
// closest Bali–Lombok mainland coast points in ne_10m_land are 35.4 km apart (scripts/make-map-id.mjs)
const PLACE: Record<string, LL> = {BaliE: [115.7142, -8.3752], LombokW: [116.0279, -8.445], Padangbai: [115.51, -8.53], Lembar: [116.07, -8.73]};
const ll = (name: string): LL => PLACE[name];

// quadratic route helper (screen space)
const quad = (p0: number[], c: number[], p1: number[], u: number) => [
  (1 - u) * (1 - u) * p0[0] + 2 * (1 - u) * u * c[0] + u * u * p1[0],
  (1 - u) * (1 - u) * p0[1] + 2 * (1 - u) * u * c[1] + u * u * p1[1],
];

export const GarisWallaceEpisode: React.FC = () => {
  const {t} = useTime();
  const cam = flyCam(t, START, MOVES);
  const S = (lon: number, lat: number) => toScreen(cam, lon, lat);
  const win = (from: number, to: number) => t >= from && t < to;

  // ---------- map effects ----------
  const crossQ = pg(t, T.nggak1 - 0.05, T.nggak1 + 0.9); // ✕ phase greys the western islands
  const westTint = pg(t, T.hewanAsia - 0.1, T.hewanAsia + 0.6) * (1 - pg(t, T.indonesia - 0.2, T.indonesia + 0.5)) + 0.75 * pg(t, T.duaBenua - 0.1, T.duaBenua + 0.5);
  const eastTint = pg(t, T.papua1 - 0.1, T.papua1 + 0.5) * (1 - pg(t, T.indonesia - 0.2, T.indonesia + 0.5)) + 0.75 * pg(t, T.duaBenua - 0.1, T.duaBenua + 0.5);
  const ausTint = pg(t, T.australia1 - 0.1, T.australia1 + 0.5) * (1 - 0.6 * pg(t, T.indonesia, T.indonesia + 0.6)) + 0.6 * pg(t, T.benua - 0.1, T.benua + 0.5);
  const named = (at: number) => pg(t, at - 0.1, at + 0.35);
  const westIsl = ['Sumatera', 'Jawa', 'Kalimantan'] as const;
  const fills: IslandFill[] = [];
  // kakatua phase: Lombok yellow, then the three western islands light up and turn grey under the ✕
  const kakatuaPhase = 1 - pg(t, T.barat - 0.3, T.barat + 0.3);
  fills.push({name: 'Lombok', color: M.yellow, o: 0.8 * pg(t, T.diLombok - 0.1, T.diLombok + 0.4) * (1 - pg(t, T.timur, T.timur + 0.5))});
  const westNamed = [T.jawa1, T.sumatera1, T.kalimantan1];
  westIsl.forEach((n) => {
    const at = westNamed[westIsl.indexOf(n) === 0 ? 1 : westIsl.indexOf(n) === 1 ? 0 : 2];
    fills.push({name: n, color: M.yellow, o: 0.75 * named(at) * (1 - crossQ) * kakatuaPhase});
    fills.push({name: n, color: M.grey, o: 0.45 * crossQ * kakatuaPhase});
  });
  ['Sumatera', 'Jawa', 'Kalimantan', 'Bali'].forEach((n) => fills.push({name: n, color: M.west, o: 0.75 * Math.min(1, westTint)}));
  fills.push({name: 'Asia', color: M.west, o: 0.38 * pg(t, T.hewanAsia, T.hewanAsia + 0.6) * (1 - pg(t, T.timur, T.timur + 0.6)) + 0.38 * pg(t, T.asia2 - 0.2, T.asia2 + 0.4) * (1 - pg(t, T.papua2, T.papua2 + 0.6)) + 0.5 * pg(t, T.duaBenua - 0.1, T.duaBenua + 0.5)});
  ['Lombok', 'Sumbawa', 'Flores', 'Sulawesi', 'Timor'].forEach((n) => fills.push({name: n, color: M.east, o: 0.3 * pg(t, T.kakatua2 - 0.2, T.kakatua2 + 0.5) * (1 - pg(t, T.indonesia - 0.2, T.indonesia + 0.5) * (1 - 0.6 * pg(t, T.duaBenua, T.duaBenua + 0.5)))}));
  fills.push({name: 'Papua', color: M.east, o: 0.75 * Math.min(1, eastTint)});
  fills.push({name: 'Australia', color: M.east, o: 0.45 * Math.min(1, ausTint)});

  const shelf = 340 * pg(t, T.surut - 0.05, T.meter + 0.5) * (1 - pg(t, T.dipisahkan2 - 0.1, T.dipisahkan2 + 1.3));
  const fx: MapFx = {
    deep: pg(t, T.bawahAir - 0.1, T.bawahAir + 0.3),
    sonar: t < T.bawahAir + 2.2 ? {lon: 115.8, lat: -8.6, r: 2800 * pg(t, T.bawahAir - 0.05, T.bawahAir + 1.9)} : undefined,
    shelf,
    shelfTints: [
      {region: SUNDA, color: M.west, o: 0.45 * pg(t, T.tersambung1 - 0.1, T.tersambung1 + 0.7) * (1 - 0.5 * pg(t, T.dipisahkan2, T.dipisahkan2 + 1))},
      {region: SAHUL, color: M.east, o: 0.45 * pg(t, T.tersambung2 - 0.1, T.tersambung2 + 0.7)},
    ],
    fills,
    countries: [{name: 'Indonesia', color: M.yellow, o: 0.85 * pg(t, T.indonesia - 0.05, T.indonesia + 0.6) * (1 - 0.55 * pg(t, T.duaBenua - 0.1, T.duaBenua + 0.5))}],
  };

  // ---------- Wallace line ----------
  const lineDraw = lerp(0, STRAIT_PART, pg(t, T.garis1 - 0.1, T.batas1 + 0.5)) + (1 - STRAIT_PART) * pg(t, T.batasItu - 0.05, T.garisW + 0.15);
  const linePulse = Math.max(pb(t, T.garisW, T.garisW + 0.5) * (1 - pg(t, T.garisW + 0.5, T.garisW + 1.2)), pb(t, T.bertemu - 0.1, T.bertemu + 0.4) * (1 - pg(t, T.bertemu + 0.5, T.bertemu + 1.4)), 0.6 * pg(t, T.berkembang, T.berkembang + 0.4) * (1 - pg(t, T.dipisahkan2 - 0.3, T.dipisahkan2)));
  const wPath = geoPath(cam, WALLACE);
  const [gx0, gy0] = S(...WALLACE[WALLACE.length - 3]);
  const [gx1, gy1] = S(...WALLACE[WALLACE.length - 1]);

  // ---------- veil for headlines ----------
  const veil = Math.max(
    inOut(t, -0.5, T.tapi1 + 0.1), inOut(t, T.ahli - 0.15, T.tahun - 0.05), inOut(t, T.tahun - 0.15, T.menyeberang - 0.1),
    inOut(t, T.tapi2 - 0.15, T.diLombok + 0.2), inOut(t, T.diLombok - 0.1, T.barat - 0.2), inOut(t, T.barat - 0.1, T.timur - 0.3), inOut(t, T.timur - 0.2, T.batasItu - 0.1),
    inOut(t, T.batasItu - 0.1, T.tapi3 - 0.05), inOut(t, T.tapi3, T.bawahAir + 0.6), inOut(t, T.waktu - 0.2, T.sumatera2 - 0.1), inOut(t, T.selatLombok - 0.2, T.jadi - 0.1),
    inOut(t, T.jadi - 0.1, T.indonesia - 0.1), pg(t, T.bertemu - 0.2, T.bertemu + 0.4),
  );

  // ---------- badges ----------
  type B = {kind: AnimalKind; at: number; anchor: LL; off: [number, number]; out: number};
  const west: B[] = [
    {kind: 'harimau', at: T.harimau, anchor: [99.6, 2.0], off: [-40, -160], out: T.timur - 0.6},
    {kind: 'badak', at: T.badak, anchor: [106.4, -6.85], off: [-20, 180], out: T.timur - 0.6},
    {kind: 'gajah', at: T.gajah, anchor: [103.2, -3.6], off: [-150, 140], out: T.timur - 0.6},
    {kind: 'orangutan', at: T.orangutan, anchor: [113.4, 0.4], off: [-20, -190], out: T.timur - 0.6},
  ];
  const east: B[] = [
    {kind: 'kakatua', at: T.kakatua2, anchor: [121.0, -3.6], off: [0, 0], out: T.batasItu - 0.4},
    {kind: 'kuskus', at: T.kuskus, anchor: [129.6, -3.2], off: [0, 0], out: T.batasItu - 0.4},
    {kind: 'kanguru', at: T.kanguru, anchor: [136.6, -4.0], off: [0, 0], out: T.batasItu - 0.4},
  ];
  // two worlds (symbolic clusters either side of the line)
  const worldsQ = (i: number, side: number) => pb(t, T.duaDunia + side * 0.3 + i * 0.09, T.duaDunia + side * 0.3 + i * 0.09 + 0.45) * (1 - pg(t, T.dipisahkan2 - 0.3, T.dipisahkan2 + 0.1));
  const worldsW: Array<[AnimalKind, number, number]> = [['harimau', 160, 790], ['orangutan', 345, 740], ['gajah', 170, 1030], ['badak', 350, 990]];
  const worldsE: Array<[AnimalKind, number, number]> = [['kakatua', 770, 780], ['kuskus', 905, 960], ['kanguru', 750, 1150]];
  const indep = (i: number) => (t > T.berkembang ? Math.sin((t - T.berkembang) * (3 + i * 0.7) + i) * 10 * pg(t, T.berkembang, T.berkembang + 0.4) : 0);

  // ---------- routes ----------
  const route = (q: number, from: LL, to: LL, bend: number) => {
    const p0 = S(...from), p1 = S(...to);
    const c = [(p0[0] + p1[0]) / 2, (p0[1] + p1[1]) / 2 + bend];
    return {p0, p1, c, at: (u: number) => quad(p0, c, p1, u), q};
  };
  const r1856 = route(pg(t, T.menyeberang - 0.05, T.lombok2 + 0.35), ll('Padangbai'), ll('Lembar'), 70);
  const rFerry = route(pg(t, T.diseberangi - 0.1, T.jam + 0.3), ll('Padangbai'), ll('Lembar'), 50);
  const Route: React.FC<{r: ReturnType<typeof route>; o: number; children: React.ReactNode}> = ({r, o, children}) => {
    if (o <= 0.01) return null;
    const dots = 26;
    const pos = r.at(r.q);
    const bob = Math.sin(t * 5) * 3;
    return (
      <g opacity={o}>
        {Array.from({length: dots + 1}).map((_, i) => {
          const u = i / dots;
          if (u > r.q) return null;
          const [x, y] = r.at(u);
          return <circle key={i} cx={x} cy={y} r={4.5} fill={M.ink} />;
        })}
        <circle cx={r.p0[0]} cy={r.p0[1]} r={10} fill={M.card} stroke={M.ink} strokeWidth={4} />
        <circle cx={r.p1[0]} cy={r.p1[1]} r={10} fill={r.q > 0.98 ? M.red : M.card} stroke={M.ink} strokeWidth={4} />
        <g transform={`translate(${pos[0]} ${pos[1] - 6 + bob}) rotate(${Math.sin(t * 3) * 3})`}>{children}</g>
      </g>
    );
  };

  // ---------- island labels ----------
  const lbl = (text: string, lon: number, lat: number, q: number, size = 34, color: string = M.ink) => {
    const [x, y] = S(lon, lat);
    return <MapLabel key={text + lon} x={x} y={y} text={text} q={q} size={size} color={color} />;
  };
  const stripLabels = 1 - pg(t, T.kakatua1 + 0.3, T.kakatua1 + 0.9);

  return (
    <AbsoluteFill style={{background: M.sea, overflow: 'hidden'}}>
      <StyleFonts />
      {/* music + SFX files are generated later from plans/peta.json and PETA_SFX; a muted draft can skip all audio with --props='{"draftNoAudio":true}' */}
      {!(getInputProps() as {draftNoAudio?: boolean}).draftNoAudio && (
        <EpisodeAudio vo="audio/vo/peta.mp3" words={C.words} music="audio/music/peta.wav" bed={0.5} duck={0.18} sfx={PETA_SFX} />
      )}
      <MapView cam={cam} fx={fx} />

      {/* ===== screen-space marks over the map ===== */}
      <svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0}}>
        <defs>
          <linearGradient id="wl-fade" gradientUnits="userSpaceOnUse" x1={gx0} y1={gy0} x2={gx1} y2={gy1}>
            <stop offset={0} stopColor={M.red} stopOpacity={1} />
            <stop offset={1} stopColor={M.red} stopOpacity={0} />
          </linearGradient>
          <linearGradient id="wl-halo" gradientUnits="userSpaceOnUse" x1={gx0} y1={gy0} x2={gx1} y2={gy1}>
            <stop offset={0} stopColor={M.card} stopOpacity={0.95} />
            <stop offset={1} stopColor={M.card} stopOpacity={0} />
          </linearGradient>
          <linearGradient id="east-arrow" x1="0" x2="1" y1="0" y2="0">
            <stop offset={0} stopColor={M.west} />
            <stop offset={1} stopColor={M.east} />
          </linearGradient>
        </defs>

        {/* strait labels (opening) */}
        {lbl('BALI', 115.08, -8.42, pg(t, -0.3, 0.25) * stripLabels, 50)}
        {lbl('LOMBOK', 116.38, -8.52, pg(t, T.lombok - 0.05, T.lombok + 0.35) * stripLabels, 50)}
        {(() => {
          const [x, y] = S(116.02, -9.2);
          return <MapLabel x={x} y={y} text={'Selat\nLombok'} q={pg(t, T.selat - 0.05, T.selat + 0.4) * (1 - pg(t, T.tahun - 0.3, T.tahun))} size={34} serif italic color={M.seaText} halo={M.sea} />;
        })()}

        {/* 35 km measure */}
        <Measure a={S(...ll('BaliE'))} b={S(...ll('LombokW'))} q={pg(t, T.km35 - 0.25, T.km35 + 0.45) * (1 - pg(t, T.tapi1 + 0.1, T.tapi1 + 0.5))} label="±35 KM" labelQ={pg(t, T.km35 + 0.05, T.km35 + 0.45) * (1 - pg(t, T.tapi1 + 0.1, T.tapi1 + 0.4))} />

        {/* the Wallace line */}
        {lineDraw > 0.002 && (
          <g opacity={t > T.indonesia - 0.3 && t < T.diSini ? 0.9 : 1}>
            <path d={wPath} fill="none" stroke="url(#wl-halo)" strokeWidth={16 + 14 * linePulse} strokeLinecap="round" pathLength={1} strokeDasharray="1 2" strokeDashoffset={1 - lineDraw} />
            {linePulse > 0.02 && <path d={wPath} fill="none" stroke={M.red} strokeWidth={30} strokeLinecap="round" opacity={0.22 * linePulse} pathLength={1} strokeDasharray="1 2" strokeDashoffset={1 - lineDraw} />}
            <path d={wPath} fill="none" stroke="url(#wl-fade)" strokeWidth={7 + 3 * linePulse} strokeLinecap="round" pathLength={1} strokeDasharray="1 2" strokeDashoffset={1 - lineDraw} />
          </g>
        )}

        {/* 1856 crossing */}
        <Route r={r1856} o={r1856.q > 0 ? 1 - pg(t, T.duaPulau - 0.1, T.duaPulau + 0.3) : 0}><Boat /></Route>

        {/* sightline: two islands that see each other */}
        {(() => {
          const q = pg(t, T.saling - 0.3, T.kelihatan + 0.2) * (1 - pg(t, T.burung, T.burung + 0.4));
          if (q <= 0.01) return null;
          const [x0, y0] = S(115.6, -8.3), [x1, y1] = S(116.15, -8.36);
          const Eye: React.FC<{x: number; y: number; flip?: boolean}> = ({x, y, flip}) => (
            <g transform={`translate(${x} ${y - 46}) scale(${flip ? -1 : 1} 1)`}>
              <path d="M -26 0 Q 0 -22 26 0 Q 0 22 -26 0 Z" fill={M.card} stroke={M.ink} strokeWidth={4} />
              <circle cx={4} cy={0} r={8} fill={M.ink} />
            </g>
          );
          return (
            <g opacity={Math.min(1, q * 2)}>
              <line x1={x0} y1={y0 - 46} x2={lerp(x0, x1, q)} y2={lerp(y0, y1, q) - 46} stroke={M.ink} strokeWidth={4} strokeDasharray="10 9" />
              <line x1={x1} y1={y1 - 46} x2={lerp(x1, x0, q)} y2={lerp(y1, y0, q) - 46} stroke={M.ink} strokeWidth={4} strokeDasharray="10 9" opacity={0.5} />
              <Eye x={x0} y={y0} />
              <Eye x={x1} y={y1} flip />
              <g transform={`translate(${(x0 + x1) / 2} ${(y0 + y1) / 2 - 110})`} opacity={pg(t, T.saling, T.saling + 0.3)}>
                <rect x={-150} y={-30} width={300} height={56} fill={M.ink} />
                <text x={0} y={10} textAnchor="middle" fill="#fff" style={{fontFamily: LABEL, fontWeight: 800, fontSize: 32, letterSpacing: 5}}>SALING KELIHATAN</text>
              </g>
            </g>
          );
        })()}

        {/* west islands named, then crossed out */}
        {win(T.jawa1 - 0.3, T.barat + 0.3) && (
          <g opacity={1 - pg(t, T.barat - 0.3, T.barat + 0.2)}>
            {lbl('JAWA', 110.0, -9.3, named(T.jawa1), 34)}
            {lbl('SUMATERA', 101.6, -2.6, named(T.sumatera1), 34)}
            {lbl('KALIMANTAN', 113.9, -2.4, named(T.kalimantan1), 34)}
            <Cross x={S(110.0, -7.2)[0]} y={S(110.0, -7.2)[1]} q={pg(t, T.nggak1 - 0.05, T.nggak1 + 0.3)} size={34} />
            <Cross x={S(101.4, 0.2)[0]} y={S(101.4, 0.2)[1]} q={pg(t, T.nggak1 + 0.25, T.nggak1 + 0.6)} size={34} />
            <Cross x={S(113.8, 0.4)[0]} y={S(113.8, 0.4)[1]} q={pg(t, T.nggak1 + 0.55, T.nggak1 + 0.9)} size={34} />
          </g>
        )}
        {/* kakatua on Lombok */}
        {(() => {
          const q = pb(t, T.kakatua1 - 0.15, T.kakatua1 + 0.3) * (1 - pg(t, T.barat - 0.3, T.barat + 0.1));
          const [x, y] = S(116.22, -8.78);
          return <Badge x={x - 40} y={y + 200} q={q} kind="kakatua" anchor={[x, y]} t={t} r={64} />;
        })()}
        {/* west animals */}
        {west.map((b, i) => {
          const q = pb(t, b.at - 0.15, b.at + 0.3) * (1 - pg(t, b.out, b.out + 0.4));
          const [x, y] = S(...b.anchor);
          return <Badge key={i} x={x + b.off[0]} y={y + b.off[1]} q={q} kind={b.kind} anchor={[x, y]} t={t} r={62} ring={M.west} />;
        })}
        {/* east: makin mirip Australia arrow */}
        {(() => {
          const q = pg(t, T.makin - 0.1, T.australia1 + 0.2) * (1 - pg(t, T.batasItu - 0.5, T.batasItu));
          if (q <= 0.01) return null;
          const d = geoPath(cam, [[118.6, -9.6], [123.5, -9.4], [128.5, -7.6], [133.0, -6.6]]);
          const tip = S(133.0, -6.6), pre = S(132.2, -6.75);
          const ang = (Math.atan2(tip[1] - pre[1], tip[0] - pre[0]) * 180) / Math.PI;
          return (
            <g>
              <path d={d} fill="none" stroke={M.card} strokeWidth={20} strokeLinecap="round" pathLength={1} strokeDasharray="1 2" strokeDashoffset={1 - q} />
              <path d={d} fill="none" stroke="url(#east-arrow)" strokeWidth={10} strokeLinecap="round" pathLength={1} strokeDasharray="1 2" strokeDashoffset={1 - q} />
              <path d="M -6 -20 L 26 0 L -6 20 Z" fill={M.east} transform={`translate(${tip[0]} ${tip[1]}) rotate(${ang})`} opacity={pg(t, T.mirip, T.mirip + 0.3)} />
            </g>
          );
        })()}
        {east.map((b, i) => {
          const q = pb(t, b.at - 0.15, b.at + 0.3) * (1 - pg(t, b.out, b.out + 0.4));
          const [x, y] = S(...b.anchor);
          return <Badge key={i} x={x} y={y} q={q} kind={b.kind} t={t} r={62} ring={M.east} />;
        })}
        {lbl('AUSTRALIA', 133.0, -15.8, pg(t, T.australia1 - 0.1, T.australia1 + 0.4) * (1 - pg(t, T.batasItu - 0.5, T.batasItu)), 44, '#A2532E')}
        {lbl('PAPUA', 137.0, -8.8, pg(t, T.papua1 - 0.1, T.papua1 + 0.4) * (1 - pg(t, T.batasItu - 0.5, T.batasItu)), 40, '#A2532E')}

        {/* the named line: side tags */}
        {(() => {
          const q = pg(t, T.garisW + 0.3, T.garisW + 0.8) * (1 - pg(t, T.tapi3, T.tapi3 + 0.4));
          if (q <= 0.01) return null;
          const [lx, ly] = S(117.6, -5.0);
          return (
            <g opacity={q}>
              <g transform={`translate(${lx - 60 - 30 * (1 - q)} ${ly + 120})`}>
                <rect x={-230} y={-30} width={230} height={56} fill={M.west} />
                <text x={-115} y={10} textAnchor="middle" fill="#fff" style={{fontFamily: LABEL, fontWeight: 800, fontSize: 32, letterSpacing: 5}}>◂ ASIA</text>
              </g>
              <g transform={`translate(${lx + 60 + 30 * (1 - q)} ${ly + 120})`}>
                <rect x={0} y={-30} width={300} height={56} fill={M.east} />
                <text x={150} y={10} textAnchor="middle" fill="#fff" style={{fontFamily: LABEL, fontWeight: 800, fontSize: 32, letterSpacing: 5}}>AUSTRALIA ▸</text>
              </g>
            </g>
          );
        })()}

        {/* "persis di situ" pin + sonar ring */}
        {(() => {
          const [x, y] = S(115.78, -8.45);
          return <Pin x={x} y={y} q={pb(t, T.persis - 0.1, T.persis + 0.3) * (1 - pg(t, T.bawahAir + 0.6, T.bawahAir + 1.0))} t={t} color={M.red} dot={M.card} />;
        })()}
        {(() => {
          const k = pg(t, T.bawahAir - 0.05, T.bawahAir + 1.9);
          if (k <= 0 || k >= 1) return null;
          const [x, y] = S(115.8, -8.6);
          return <circle cx={x} cy={y} r={2800 * k * cam.s} fill="none" stroke="#5E8C99" strokeWidth={5} opacity={1 - k} />;
        })()}

        {/* ice age: islands named, arrows to the continents */}
        {win(T.sumatera2 - 0.3, T.tapi4 + 0.3) && (
          <g opacity={1 - pg(t, T.tapi4 - 0.3, T.tapi4 + 0.1)}>
            {lbl('SUMATERA', 101.8, -0.3, named(T.sumatera2) * (1 - pg(t, T.papua2 - 0.4, T.papua2)), 32)}
            {lbl('JAWA', 110.0, -9.2, named(T.jawa2) * (1 - pg(t, T.papua2 - 0.4, T.papua2)), 32)}
            {lbl('KALIMANTAN', 113.9, 0.8, named(T.kalimantan2) * (1 - pg(t, T.papua2 - 0.4, T.papua2)), 32)}
            {lbl('BALI', 115.2, -9.9, named(T.bali3) * (1 - pg(t, T.papua2 - 0.4, T.papua2)), 32)}
            {(() => {
              const [x, y] = S(108.3, -4.6);
              return <MapLabel x={x} y={y} text={'Paparan\nSunda'} q={pg(t, T.tersambung1, T.tersambung1 + 0.5)} size={36} serif italic color="#3F6375" halo={M.shelf} />;
            })()}
            {(() => {
              const q = pg(t, T.tersambung1 + 0.1, T.asia2 + 0.2);
              if (q <= 0.01) return null;
              const d = geoPath(cam, [[106.5, -1.8], [105.0, 4.5], [103.8, 10.5]]);
              const tip = S(103.8, 10.5), pre = S(104.0, 9.6);
              const ang = (Math.atan2(tip[1] - pre[1], tip[0] - pre[0]) * 180) / Math.PI;
              return (
                <g>
                  <path d={d} fill="none" stroke={M.card} strokeWidth={18} strokeLinecap="round" pathLength={1} strokeDasharray="1 2" strokeDashoffset={1 - q} />
                  <path d={d} fill="none" stroke={M.west} strokeWidth={9} strokeLinecap="round" pathLength={1} strokeDasharray="1 2" strokeDashoffset={1 - q} />
                  <path d="M -6 -20 L 26 0 L -6 20 Z" fill={M.west} transform={`translate(${tip[0]} ${tip[1]}) rotate(${ang})`} opacity={q > 0.9 ? 1 : 0} />
                </g>
              );
            })()}
            {lbl('ASIA', 103.6, 14.6, pg(t, T.asia2 - 0.15, T.asia2 + 0.3), 56, '#3F6375')}
            {lbl('PAPUA', 138.6, -4.2, named(T.papua2), 40, '#A2532E')}
            {(() => {
              const [x, y] = S(135.4, -10.4);
              return <MapLabel x={x} y={y} text={'Paparan\nSahul'} q={pg(t, T.tersambung2, T.tersambung2 + 0.5)} size={36} serif italic color="#8A4A2A" halo={M.shelf} />;
            })()}
            {lbl('AUSTRALIA', 134.0, -22.0, pg(t, T.australia2 - 0.15, T.australia2 + 0.3), 56, '#A2532E')}
          </g>
        )}

        {/* strait again: small island names */}
        {lbl('BALI', 115.08, -8.42, inOut(t, T.selatLombok, T.jadi - 0.1) + inOut(t, T.dipisahkan2 + 1.0, T.indonesia - 0.1), 40)}
        {lbl('LOMBOK', 116.42, -8.5, inOut(t, T.selatLombok + 0.15, T.jadi - 0.1) + inOut(t, T.dipisahkan2 + 1.1, T.indonesia - 0.1), 40)}

        {/* two worlds */}
        {worldsW.map(([k, x, y], i) => <Badge key={k} x={x} y={y + indep(i)} q={worldsQ(i, 0)} kind={k} t={t} r={54} ring={M.west} />)}
        {worldsE.map(([k, x, y], i) => <Badge key={k} x={x} y={y + indep(i + 4)} q={worldsQ(i, 1)} kind={k} t={t} r={54} ring={M.east} />)}

        {/* ferry */}
        <Route r={rFerry} o={rFerry.q > 0 ? 1 - pg(t, T.indonesia - 0.3, T.indonesia + 0.1) : 0}><Ferry /></Route>

        {/* finale: Indonesia, two oceans, two continents */}
        {t > T.indonesia - 0.3 && (
          <g>
            {lbl('INDONESIA', 111.0, -1.2, pg(t, T.indonesia + 0.7, T.indonesia + 1.2) * (1 - pg(t, T.diSini - 0.3, T.diSini + 0.1)), 44, M.ink)}
            {(() => {
              const [hx, hy] = S(102.5, -21.0), [px, py] = S(135.0, 10.0);
              const qh = pg(t, T.duaSamudra - 0.1, T.duaSamudra + 0.5), qp = pg(t, T.duaSamudra + 0.2, T.duaSamudra + 0.8);
              const wave = (x: number, y: number, q: number) => q > 0.01 && (
                <path d={`M ${x - 60} ${y} q 15 -12 30 0 t 30 0 t 30 0 t 30 0`} fill="none" stroke={M.seaText} strokeWidth={4} strokeLinecap="round" opacity={q} transform={`translate(${Math.sin(t * 2) * 6} 0)`} />
              );
              return (
                <>
                  <MapLabel x={hx} y={hy} text={'Samudra\nHindia'} q={qh} size={50} serif italic color={M.seaText} halo={M.sea} />
                  {wave(hx, hy + 92, qh)}
                  <MapLabel x={px} y={py} text={'Samudra\nPasifik'} q={qp} size={50} serif italic color={M.seaText} halo={M.sea} />
                  {wave(px, py + 92, qp)}
                </>
              );
            })()}
            {(() => {
              const [x, y] = S(115.75, -8.4);
              return <Pin x={x} y={y} q={pb(t, T.diSini - 0.1, T.diSini + 0.3)} t={t} color={M.red} dot={M.card} scale={0.9} />;
            })()}
            {lbl('ASIA', 106.0, 10.0, pb(t, T.duaBenua - 0.1, T.duaBenua + 0.3), 64, '#3F6375')}
            {lbl('AUSTRALIA', 133.5, -24.0, pb(t, T.benua - 0.1, T.benua + 0.3), 64, '#A2532E')}
          </g>
        )}
      </svg>

      {/* ===== headlines & cards ===== */}
      <TopVeil o={veil} />
      {/* S1 */}
      <Headline q={pg(t, -0.4, 0.2) * (1 - pg(t, T.tapi1 - 0.15, T.tapi1 + 0.15))} kicker="BALI · LOMBOK" size={100}>
        <div style={{opacity: pg(t, T.cuma - 0.1, T.cuma + 0.3)}}>Cuma dipisahkan</div>
        <div style={{opacity: pg(t, T.selat - 0.1, T.selat + 0.3)}}>selat <span style={{color: M.red, opacity: pg(t, T.km35 - 0.1, T.km35 + 0.3)}}>±35 km</span></div>
      </Headline>
      {/* S2 */}
      <Headline q={pg(t, T.ahli - 0.15, T.ahli + 0.25) * (1 - pg(t, T.tahun - 0.4, T.tahun - 0.1))} kicker="BAGI AHLI BIOLOGI" size={86}>
        <div style={{opacity: pg(t, T.ini - 0.1, T.ini + 0.3)}}>Salah satu garis batas</div>
        <div style={{opacity: pg(t, T.paling - 0.2, T.paling + 0.2)}}><Hl q={pg(t, T.paling, T.dunia1)}>paling aneh</Hl> di dunia</div>
      </Headline>
      {/* S3: 1856 */}
      <Headline q={pg(t, T.tahun - 0.1, T.tahun + 0.3) * (1 - pg(t, T.menyeberang - 0.3, T.menyeberang))} kicker="TAHUN" size={250}>
        <div style={{display: 'flex', alignItems: 'flex-end', gap: 30}}>
          <span style={{display: 'inline-block', transform: `scale(${0.85 + 0.15 * pb(t, T.y1856 - 0.1, T.y1856 + 0.35)})`, transformOrigin: '0 80%', opacity: pg(t, T.y1856 - 0.15, T.y1856 + 0.1)}}>1856</span>
        </div>
        <svg width={520} height={24} style={{display: 'block', marginTop: -6}}><line x1={6} y1={12} x2={6 + 500 * pg(t, T.y1856 + 0.1, T.y1856 + 0.7)} y2={12} stroke={M.red} strokeWidth={10} strokeLinecap="round" /></svg>
      </Headline>
      <LowerThird q={pg(t, T.naturalis - 0.15, T.naturalis + 0.55) * (1 - pg(t, T.duaPulau - 0.3, T.duaPulau))} top={1270} title="Alfred Russel Wallace" sub="NATURALIS INGGRIS · 1856" size={62} icon={<Explorer size={112} />} />
      {/* S4: birds differ */}
      <Card q={pg(t, T.tapi2 - 0.15, T.tapi2 + 0.35) * (1 - pg(t, T.diLombok - 0.4, T.diLombok - 0.08))} top={200} pad="30px 40px 30px">
        <Kicker>BURUNG-BURUNGNYA</Kicker>
        <div style={{display: 'flex', alignItems: 'center', justifyContent: 'space-around', marginTop: 16}}>
          {(['burung', 'kakatua'] as AnimalKind[]).map((k, i) => (
            <React.Fragment key={k}>
              {i === 1 && (
                <div style={{fontFamily: SERIF, fontSize: 190, color: M.red, lineHeight: 1, transform: `scale(${1.6 - 0.6 * Math.min(1, pb(t, T.beda - 0.1, T.beda + 0.25))}) rotate(-6deg)`, opacity: pg(t, T.beda - 0.15, T.beda + 0.05)}}>≠</div>
              )}
              <div style={{textAlign: 'center', opacity: pg(t, T.burung - 0.1 + i * 0.35, T.burung + 0.25 + i * 0.35)}}>
                <svg width={270} height={270} viewBox="-135 -135 270 270" style={{display: 'block'}}>
                  <Badge x={0} y={-4} q={Math.min(1, pb(t, T.burung - 0.1 + i * 0.35, T.burung + 0.35 + i * 0.35))} kind={k} label={false} r={118} ring={i ? M.east : M.west} t={t} />
                </svg>
                <div style={{fontFamily: LABEL, fontWeight: 800, fontSize: 40, letterSpacing: 10, color: M.ink, marginTop: 4}}>{i ? 'LOMBOK' : 'BALI'}</div>
              </div>
            </React.Fragment>
          ))}
        </div>
      </Card>
      {/* S5: kakatua */}
      <Headline q={pg(t, T.diLombok - 0.02, T.diLombok + 0.3) * (1 - pg(t, T.barat - 0.35, T.barat - 0.05))} kicker="KAKATUA" size={96}>
        <div>Di Lombok: <span style={{color: '#A2532E'}}>ada.</span></div>
        <div style={{opacity: pg(t, T.jawa1 - 0.1, T.jawa1 + 0.3)}}>Di barat? <span style={{color: M.red, opacity: pg(t, T.nggak1 - 0.1, T.nggak1 + 0.2)}}>Nggak ada.</span></div>
      </Headline>
      {/* S6: west */}
      <Headline q={pg(t, T.barat - 0.1, T.barat + 0.3) * (1 - pg(t, T.timur - 0.4, T.timur - 0.1))} size={104}>
        <div>Di barat:</div>
        <div style={{opacity: pg(t, T.hewanAsia - 0.15, T.hewanAsia + 0.25)}}>hewan-hewan <Hl q={pg(t, T.asia1 - 0.1, T.asia1 + 0.4)} color="#A9C3D1">Asia</Hl></div>
      </Headline>
      {/* S7: east */}
      <Headline q={pg(t, T.timur - 0.1, T.timur + 0.3) * (1 - pg(t, T.batasItu - 0.4, T.batasItu - 0.1))} size={104}>
        <div>Di timur:</div>
        <div style={{fontSize: 62, lineHeight: 1.08, marginTop: 8, opacity: pg(t, T.makin - 0.1, T.makin + 0.3)}}>makin jauh, makin mirip <Hl q={pg(t, T.australia1 - 0.1, T.australia1 + 0.4)} color="#F0C3A8">Australia</Hl></div>
        <div style={{marginTop: 44}}>
          <Spectrum q={pg(t, T.makin - 0.1, T.makin + 0.5)} u={lerp(0.12, 0.92, pg(t, T.makin, T.australia1 + 0.3))} left="MIRIP ASIA" right="MIRIP AUSTRALIA" width={860} />
        </div>
      </Headline>
      {/* S8: Garis Wallace */}
      <Headline q={pg(t, T.batasItu - 0.05, T.batasItu + 0.3) * (1 - pg(t, T.tapi3 - 0.3, T.tapi3))} kicker="BATAS ITU KINI DIKENAL SEBAGAI" size={150}>
        <div style={{opacity: pg(t, T.garisW - 0.12, T.garisW + 0.08), transform: `scale(${1.15 - 0.15 * pb(t, T.garisW - 0.1, T.garisW + 0.3)})`, transformOrigin: '0 50%'}}>
          Garis <Hl q={pg(t, T.garisW + 0.3, T.garisW + 0.9)}>Wallace</Hl>
        </div>
      </Headline>
      {/* S9: why there? → under water */}
      <Headline q={pg(t, T.tapi3 - 0.05, T.tapi3 + 0.3) * (1 - pg(t, T.jawabannya - 0.3, T.jawabannya - 0.05))} kicker="PERTANYAANNYA" size={104}>
        <div style={{opacity: pg(t, T.kenapa - 0.1, T.kenapa + 0.3)}}>Kenapa <span style={{color: M.red}}>persis</span></div>
        <div style={{opacity: pg(t, T.persis - 0.1, T.persis + 0.3)}}>di situ?</div>
      </Headline>
      <Headline q={pg(t, T.jawabannya - 0.05, T.jawabannya + 0.3) * (1 - pg(t, T.waktu - 0.35, T.waktu - 0.05))} kicker="JAWABANNYA" size={104}>
        <div>ada <Hl q={pg(t, T.bawahAir - 0.1, T.bawahAir + 0.5)} color="#A9C3D1">di bawah air</Hl></div>
      </Headline>
      {/* depth legend (bathymetry, then the exposed shelf) */}
      {(() => {
        const q = pg(t, T.bawahAir + 0.3, T.bawahAir + 0.8) * (1 - pg(t, T.jadi - 0.3, T.jadi));
        if (q <= 0.01) return null;
        const shelfQ = pg(t, T.surut + 0.3, T.surut + 0.8);
        return (
          <div style={{position: 'absolute', left: 70, top: 1440, opacity: q, transform: `translateY(${(1 - q) * 20}px)`, background: `${M.card}EE`, padding: '12px 18px', boxShadow: '0 10px 30px rgba(31,42,51,0.14)', fontFamily: LABEL, fontWeight: 800, fontSize: 24, letterSpacing: 3, color: M.ink}}>
            <div style={{display: 'flex', gap: 22, alignItems: 'center'}}>
              <span style={{display: 'flex', alignItems: 'center', gap: 8}}><span style={{width: 26, height: 18, background: M.sea, border: `2px solid ${M.ink}40`}} />DANGKAL &lt; 200 M</span>
              <span style={{display: 'flex', alignItems: 'center', gap: 8}}><span style={{width: 26, height: 18, background: M.deep, border: `2px solid ${M.ink}40`}} />DALAM</span>
            </div>
            {shelfQ > 0.01 && (
              <div style={{display: 'flex', alignItems: 'center', gap: 8, marginTop: 8, opacity: shelfQ}}>
                <span style={{width: 26, height: 18, background: `repeating-linear-gradient(45deg, ${M.shelf} 0 5px, ${M.hatch} 5px 7px)`, border: `2px solid ${M.ink}40`}} />
                PAPARAN DANGKAL, KERING SAAT ZAMAN ES (PERKIRAAN)
              </div>
            )}
          </div>
        );
      })()}
      {/* S10: ice age card */}
      <Card q={pg(t, T.waktu - 0.15, T.waktu + 0.3) * (1 - pg(t, T.sumatera2 - 0.35, T.sumatera2 - 0.05))} top={200} source="BATIMETRI: NATURAL EARTH · KONTUR 200 M">
        <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center'}}>
          <div>
            <Kicker>ZAMAN ES</Kicker>
            <div style={{fontFamily: SERIF, fontSize: 92, lineHeight: 1.02, color: M.ink, marginTop: 10, opacity: pg(t, T.zaman - 0.1, T.zaman + 0.3)}}>Laut surut</div>
            <div style={{fontFamily: LABEL, fontWeight: 800, fontSize: 30, letterSpacing: 6, color: M.grey, marginTop: 10, opacity: pg(t, T.lebih - 0.1, T.lebih + 0.2)}}>LEBIH DARI</div>
            <div style={{fontFamily: SERIF, fontSize: 120, lineHeight: 1, color: M.red, opacity: pg(t, T.n100 - 0.15, T.n100 + 0.05), transform: `translateY(${-36 * (1 - pb(t, T.n100 - 0.15, T.n100 + 0.3))}px)`}}>
              100 m
            </div>
          </div>
          <LevelGauge level={-120 * pg(t, T.surut - 0.05, T.meter + 0.4)} h={300} />
        </div>
      </Card>
      {/* S11: cross-section */}
      <Card q={pg(t, T.selatLombok - 0.15, T.selatLombok + 0.35) * (1 - pg(t, T.jadi - 0.3, T.jadi))} top={180} pad="28px 34px 22px" source="SKEMATIS · AMBANG SELAT ±250–350 M">
        <Kicker>PENAMPANG SELAT LOMBOK</Kicker>
        <div style={{display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 6}}>
          <div style={{fontFamily: SERIF, fontSize: 84, lineHeight: 1.02, color: M.ink, opacity: pg(t, T.terlalu - 0.2, T.terlalu + 0.15)}}>Terlalu <span style={{color: M.red}}>dalam</span></div>
          {(() => {
            const k = pg(t, T.nggak2 - 0.1, T.nggak2 + 0.25);
            return (
              <div style={{border: `5px solid ${M.red}`, color: M.red, fontFamily: LABEL, fontWeight: 800, fontSize: 34, lineHeight: 1.05, letterSpacing: 4, padding: '8px 14px 6px', textAlign: 'center', marginRight: 6,
                opacity: Math.min(1, k * 2), transform: `rotate(-7deg) scale(${1.7 - 0.7 * Math.min(1, k * 1.3)})`}}>NGGAK PERNAH<br />KERING</div>
            );
          })()}
        </div>
        <div style={{marginTop: 14}}>
          <StraitSection level={-120 * pg(t, T.terlalu - 0.1, T.dalam + 0.4)} drop={pg(t, T.terlalu - 0.1, T.dalam + 0.3)} t={t} />
        </div>
      </Card>
      {/* S12: millions of years vs a few hours */}
      <Card q={pg(t, T.jadi - 0.05, T.jadi + 0.35) * (1 - pg(t, T.indonesia - 0.4, T.indonesia - 0.1))} top={200} pad="28px 40px 26px">
        <div style={{display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', opacity: pg(t, T.jadi + 0.05, T.jadi + 0.4)}}>
          <div style={{fontFamily: SERIF, fontSize: 96, lineHeight: 1, color: M.ink}}>Jutaan tahun</div>
          <div style={{fontFamily: LABEL, fontWeight: 800, fontSize: 30, letterSpacing: 5, color: M.red}}>TERPISAH</div>
        </div>
        <div style={{overflow: 'hidden', maxHeight: 180 * pg(t, T.beberapa - 0.2, T.beberapa + 0.3)}}>
          <div style={{borderTop: `2px solid ${M.ink}22`, marginTop: 20, paddingTop: 20, display: 'flex', alignItems: 'center', justifyContent: 'space-between'}}>
            <div style={{display: 'flex', alignItems: 'center', gap: 20}}>
              <ClockIcon t={t} size={74} />
              <div style={{fontFamily: SERIF, fontSize: 96, lineHeight: 1, color: M.ink}}>Beberapa jam</div>
            </div>
            <div style={{fontFamily: LABEL, fontWeight: 800, fontSize: 30, letterSpacing: 5, color: M.west, textAlign: 'right'}}>DENGAN<br />KAPAL</div>
          </div>
        </div>
      </Card>
      {/* end card */}
      <Card q={pg(t, T.bertemu - 0.1, T.bertemu + 0.45)} top={180} pad="28px 40px 22px" source="PETA: NATURAL EARTH · WALLACE (1859–1860)">
        <Kicker>GARIS WALLACE</Kicker>
        <div style={{fontFamily: SERIF, fontSize: 70, lineHeight: 1.04, color: M.ink, marginTop: 8}}>
          Di sini, <Hl q={pg(t, T.bertemu + 0.3, T.bertemu + 1.0)}>dua benua</Hl> bertemu.
        </div>
      </Card>

      {/* HUD */}
      <div style={{position: 'absolute', left: 70, top: 108, display: 'flex', alignItems: 'center', gap: 12, fontFamily: LABEL, fontWeight: 800, fontSize: 24, letterSpacing: 6, color: M.ink, opacity: 0.85}}>
        <div style={{width: 26, height: 6, background: M.red}} />GARIS WALLACE
      </div>
      <ScaleBar cam={cam} x={940} y={128} o={0.9} />
      <Grain />
      <Caption t={t} pages={PAGES} />
    </AbsoluteFill>
  );
};

const s = (t: number, name: string, vol = 0.55): Sfx => ({t: Math.max(0, t), src: `audio/sfx/peta/${name}.wav`, vol});
export const PETA_SFX: Sfx[] = [
  // strait
  s(0.0, 'paper', 0.5), s(T.km35 - 0.25, 'draw', 0.55), s(T.km35 + 0.1, 'click', 0.5),
  s(T.tapi1 - 0.05, 'swoosh', 0.4), s(T.garis1 - 0.1, 'draw', 0.6), s(T.paling, 'tick', 0.4),
  // 1856
  s(T.tahun - 0.2, 'swoosh', 0.4), s(T.y1856 - 0.05, 'stamp', 0.65), s(T.naturalis - 0.1, 'paper', 0.45), s(T.menyeberang - 0.05, 'wave', 0.45), s(T.lombok2 + 0.3, 'thud', 0.4),
  s(T.saling - 0.25, 'draw', 0.45), s(T.tapi2 - 0.1, 'paper', 0.45), s(T.burung - 0.05, 'pop', 0.45), s(T.beda - 0.08, 'stamp', 0.6),
  // kakatua, west
  s(T.kakatua1 - 0.12, 'pin', 0.55), s(T.kakatua1 + 0.35, 'swoosh', 0.5),
  s(T.nggak1 - 0.03, 'stamp', 0.6), s(T.nggak1 + 0.27, 'stamp', 0.5), s(T.nggak1 + 0.57, 'stamp', 0.5),
  s(T.harimau - 0.1, 'pin', 0.5), s(T.badak - 0.1, 'pin', 0.45), s(T.gajah - 0.1, 'pin', 0.45), s(T.orangutan - 0.1, 'pin', 0.5), s(T.hewanAsia, 'ding', 0.4),
  // east
  s(T.timur - 0.45, 'swoosh', 0.5), s(T.makin - 0.05, 'draw', 0.45), s(T.kakatua2 - 0.1, 'pin', 0.5), s(T.kuskus - 0.1, 'pin', 0.45), s(T.kanguru - 0.1, 'pin', 0.5),
  // the line
  s(T.batasItu - 0.5, 'swoosh', 0.45), s(T.batasItu, 'draw', 0.7), s(T.garisW - 0.08, 'stamp', 0.8),
  s(T.persis - 0.1, 'pin', 0.5), s(T.bawahAir - 0.05, 'wave', 0.75),
  // ice age
  s(T.waktu - 0.1, 'paper', 0.45), s(T.surut - 0.05, 'rumble', 0.75), s(T.n100, 'ding', 0.5),
  s(T.sumatera2 - 0.05, 'pop', 0.35), s(T.tersambung1, 'draw', 0.5), s(T.asia2 - 0.1, 'thud', 0.55),
  s(T.papua2 - 0.45, 'swoosh', 0.45), s(T.australia2 - 0.1, 'thud', 0.55),
  // the strait is too deep
  s(T.tapi4 - 0.35, 'swoosh', 0.5), s(T.terlalu - 0.1, 'rumble', 0.55), s(T.nggak2 - 0.08, 'stamp', 0.65),
  // two worlds, a ferry
  s(T.jadi - 0.35, 'swoosh', 0.45), s(T.duaDunia - 0.05, 'pop', 0.45), s(T.duaDunia + 0.3, 'pop', 0.45),
  s(T.dipisahkan2 - 0.25, 'swoosh', 0.5), s(T.diseberangi - 0.1, 'wave', 0.45), s(T.beberapa - 0.15, 'click', 0.5),
  // two oceans, two continents
  s(T.indonesia - 0.3, 'swoosh', 0.55), s(T.duaSamudra - 0.05, 'wave', 0.45), s(T.diSini - 0.1, 'pin', 0.55),
  s(T.duaBenua - 0.08, 'thud', 0.65), s(T.benua - 0.08, 'thud', 0.6), s(T.bertemu - 0.1, 'ding', 0.6),
];
