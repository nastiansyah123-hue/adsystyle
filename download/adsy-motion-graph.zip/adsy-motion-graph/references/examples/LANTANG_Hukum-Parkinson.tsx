// REFERENCE DEMO (ADSY MOTION GRAPH v1.8) — read for structure only: scenes, camera moves, word-pinned beats, SFX cues.
// Do NOT copy this story, its text or its layout into a buyer video. Written in the author's demo workspace, so a few
// imports differ from the starter: `makeCues(words)` ≈ the starter's `at()/endOf()` from src/lib/words.ts, and
// `EpisodeAudio` ≈ Main.tsx audio (musicFile + auto-duck) + <SfxTrack /> fed by src/audio-plan.json sfxCues.
// The `getInputProps()` draft switch below was a workspace-only shortcut: do not copy it (the starter has --silent-draft).
import React from 'react';
import {AbsoluteFill, Easing, getInputProps} from 'remotion';
import {makeCues} from '../../lib/cues';
import {lerp, p, pb, pio, StyleFonts, useTime} from '../../styles/shared';
import {EpisodeAudio, Sfx} from '../../styles/audio';
import {
  Card, Chips, Countdown, Echo, fillWdth, fit, fl, Folio, Gap, Ghost, Grain, L, Line, lineW, Marquee, ps, punch, Roll, Rule, SpanBar, Stack, Tag, TimeRow, Txt, W, Walls,
} from '../../styles/lantang/kit';
import wordsFile from './words.json';

// LANTANG episode — "Hukum Parkinson": pure kinetic typography. Every spoken word is on screen; size and width
// carry the meaning (TUGAS stretches to fill SEMINGGU and squeezes into BESOK, MEMUAI floods the frame,
// LONGGAR loosens, PENDEK is squeezed heavy, HARIMU gets walled in).

const C = makeCues(wordsFile);
export const LANTANG_DURATION = C.duration + 1.4;
const a = C.at;
/** start of the k-th word of the nth occurrence of a phrase (for repeated filler words like "yang") */
const w = (phrase: string, k = 0, nth = 0) => {
  const s = a(phrase, nth);
  const i = C.words.findIndex((x) => x.start === s);
  return C.words[i + k].start;
};
const END = LANTANG_DURATION;
/** filler line at a fixed width axis: as big as `size`, but never wider than the column */
const sm = (texts: string[], size: number, wdth = 100) => ({size: Math.min(size, fit(texts, wdth)), wdth});

// Card starts: each card wipes in just before its first word.
const K = {
  hook: 0,
  tugas: a('tugas') - 0.12,
  selesai: a('selesainya') - 0.12,
  padahal: a('padahal') - 0.12,
  itu: a('itu ada') - 0.12,
  hukum: a('hukum') - 0.14,
  tahun: a('tahun') - 0.12,
  sejarawan: a('sejarawan') - 0.12,
  pekerjaan: a('pekerjaan') - 0.12,
  sampai: a('sampai') - 0.1,
  contoh: a('contohnya') - 0.12,
  nenek: a('seorang') - 0.12,
  bisa: a('bisa') - 0.1,
  sejam: a('sejam') - 0.12,
  sibuk: C.endOf('atau nggak') + 0.1,
  kita: a('kita juga') - 0.12,
  longgar: a('waktu yang longgar') - 0.12,
  pile: a('merapikan') - 0.14,
  balik: a('jadi balik') - 0.12,
  jangan: a('jangan') - 0.1,
  tentukan: a('tentukan') - 0.1,
  timebox: a('25') - 0.12,
  karena: a('karena') - 0.12,
  payoff: a('pekerjaanmu') - 0.12,
};
const STARTS = Object.values(K).sort((x, y) => x - y);
/** a card stays under the next one until that wipe has finished */
const until = (start: number) => {
  const nx = STARTS.find((s) => s > start + 0.01);
  return nx === undefined ? END + 1 : nx + 0.45;
};
const FOLIO = K.tahun;
/** a card's first line starts rising just before its wipe, so no wipe ever lands on an empty card */
const LEAD = 0.1;

// --- fixed geometry used by more than one card ---
const BESOK_W = lineW(['BESOK,'], 52, 210, 0.01, 760);
const MEM_FILL = fillWdth('MEMUAI', 340);
const HAR_SIZE = 320;
const HAR_FILL = fillWdth('HARIMU.', HAR_SIZE, W - 120, 0.01, 780);
const PEND_SIZE = 330;
const PEND_FILL = fillWdth('PENDEK.', PEND_SIZE, W - 90, 0.01, 780);

export const ParkinsonEpisode: React.FC = () => {
  const {t} = useTime();
  const folio = (color: string) => <Folio t={t} dur={C.duration} color={color} label="HUKUM PARKINSON" show={FOLIO} />;
  const card = (start: number) => ({t, start, until: until(start)});

  const sh = punch(t, [a('sadar'), a('hukum'), a('1955'), K.sampai, a('nenek'), K.sibuk + 0.05, a('kita juga'), a('menunda') + 0.3, a('susah'), a('pendek'), a('kerjakan')], 14, 0.42);

  // TUGAS bar: grows to the full SEMINGGU span, then squeezes into BESOK
  const grow = pio(t, a('selesainya') + 0.1, a('seminggu', 1) + 0.35);
  const squeeze = ps(t, a('besok') - 0.04, a('besok') + 0.5);
  // MEMUAI: stretches to fill the line, then keeps swelling past the frame as the next card floods in
  const mq = ps(t, a('memuai') - 0.04, a('memuai') + 0.45);
  const over = p(t, a('memuai') + 0.62, K.sampai + 0.12, Easing.in(Easing.cubic));
  const memW = lerp(lerp(50, MEM_FILL, mq), 150, over);
  const memS = lerp(230, 340, mq);
  // PENDEK: squeezed between two walls (the timebox you set)
  const pendQ = ps(t, a('pendek') + 0.05, a('pendek') + 0.5);
  const pendW = lerp(PEND_FILL, 50, pendQ);
  // HARIMU: walls close from the frame edges and the word is squeezed with them
  const wallQ = ps(t, a('harimu') + 0.3, a('harimu') + 0.85);
  const harW = lerp(HAR_FILL, 50, wallQ);

  return (
    <AbsoluteFill style={{background: L.ink, overflow: 'hidden'}}>
      <StyleFonts />
      {/* --props '{"noAudio":true}' renders a picture-only draft before the music/SFX files exist */}
      {!(getInputProps() as {noAudio?: boolean}).noAudio && (
        <EpisodeAudio vo="audio/vo/lantang.mp3" words={C.words} music="audio/music/lantang.wav" bed={0.5} duck={0.18} sfx={LANTANG_SFX} />
      )}
      <AbsoluteFill style={{transform: `translate(${sh.x}px, ${sh.y}px)`}}>
        {/* 1 — hook: three justified lines */}
        <Card {...card(K.hook)} bg={L.ink} wipe="cut">
          <Ghost t={t} at={a('nggak') + 0.2} ch="?" color="#FF4A1C24" />
          <Stack gap={18}>
            <Line t={t} words={[{text: 'PERNAH', at: -0.2}]} {...fl('PERNAH', 330)} />
            <Line t={t} words={[{text: 'SADAR', at: a('sadar'), color: L.hot}]} {...fl('SADAR', 330)} mode="slam" />
            <Line t={t} words={[{text: 'NGGAK', at: a('nggak'), outline: L.paper}, {text: '?', at: a('nggak') + 0.4, color: L.hot}]} {...fl(['NGGAK', '?'], 330)} mode="pop" />
          </Stack>
        </Card>

        {/* 2 — a task given a week */}
        <Card {...card(K.tugas)} bg={L.paper} wipe="up">
          <Stack gap={18}>
            <Line t={t} words={[{text: 'TUGAS', at: K.tugas, color: L.hot}]} {...fl('TUGAS', 350)} />
            <Line t={t} words={[{text: 'YANG', at: w('yang dikasih')}, {text: 'DIKASIH', at: a('dikasih')}, {text: 'WAKTU', at: a('waktu')}]} {...fl(['YANG', 'DIKASIH', 'WAKTU'], 140)} color={L.ink} />
            <Gap h={18} />
            <Line t={t} words={[{text: 'SEMINGGU,', at: a('seminggu')}]} {...fl('SEMINGGU,', 230)} color={L.ink} mode="stretch" fromWdth={58} />
            <Chips t={t} at={a('seminggu') + 0.12} items={['SEN', 'SEL', 'RAB', 'KAM', 'JUM', 'SAB', 'MIN']} bg={L.ink} color={L.paper} step={0.06} h={92} size={46} />
          </Stack>
        </Card>

        {/* 3 — ...and it takes exactly a week: TUGAS stretches to fill the span */}
        <Card {...card(K.selesai)} bg={L.ink} wipe="left">
          <Stack gap={18}>
            <Line t={t} words={[{text: 'SELESAINYA', at: K.selesai - LEAD}]} {...fl('SELESAINYA', 210)} />
            <Line t={t} words={[{text: 'JUGA', at: a('juga')}, {text: 'PAS', at: a('pas'), color: L.hot}]} {...fl(['JUGA', 'PAS'], 210)} />
            <Gap h={46} />
            <Line t={t} words={[{text: 'SEMINGGU.', at: a('seminggu', 1), outline: L.paper}]} {...fl('SEMINGGU.', 104)} />
            <SpanBar barW={lerp(300, W, grow)} spanW={W} text="TUGAS" size={150} bg={L.hot} color={L.ink} tick={L.paper} tickQ={ps(t, K.selesai + 0.2, K.selesai + 0.6)} q={ps(t, a('selesainya') - 0.05, a('selesainya') + 0.25)} />
          </Stack>
        </Card>

        {/* 4 — deadline tomorrow: the same TUGAS squeezes into BESOK */}
        <Card {...card(K.padahal)} bg={L.paper} wipe="right">
          <Stack gap={18}>
            <Tag t={t} at={K.padahal - LEAD} text="PADAHAL" bg={L.ink} color={L.paper} size={110} />
            <Line t={t} words={[{text: 'KALAU', at: a('kalau')}, {text: 'DEADLINE-NYA', at: a('deadline-nya'), color: L.blue}]} {...fl(['KALAU', 'DEADLINE-NYA'], 140)} color={L.ink} />
            <Gap h={30} />
            <Line t={t} words={[{text: 'BESOK,', at: a('besok'), color: L.hot}]} size={210} wdth={52} weight={760} ls={0.01} mode="slam" />
            <SpanBar barW={lerp(W, BESOK_W, squeeze)} spanW={lerp(W, BESOK_W, squeeze)} text="TUGAS" size={150} bg={L.hot} color={L.ink} tick={L.ink} tickQ={1} />
            <Gap h={30} />
            <Line t={t} words={[{text: 'YA,', at: a('ya')}, {text: 'BERES', at: a('beres'), color: L.blue}, {text: 'BESOK', at: a('besok', 1)}, {text: 'JUGA.', at: w('beres besok juga', 2)}]} {...fl(['YA,', 'BERES', 'BESOK', 'JUGA.'], 140)} color={L.ink} />
          </Stack>
        </Card>

        {/* 5 — it has a name */}
        <Card {...card(K.itu)} bg={L.ink} wipe="up">
          <Stack gap={24}>
            <Line t={t} words={[{text: 'ITU', at: K.itu - LEAD}, {text: 'ADA', at: w('itu ada', 1)}]} {...fl(['ITU', 'ADA'], 380)} />
            <div style={{position: 'relative', flexShrink: 0}}>
              <Echo t={t} at={a('namanya')} text="NAMANYA." {...fl('NAMANYA.', 280)} color={L.hot} kind="offset" align="left" n={2} />
              <Line t={t} words={[{text: 'NAMANYA.', at: a('namanya'), color: L.hot}]} {...fl('NAMANYA.', 280)} />
            </div>
          </Stack>
        </Card>

        {/* 6 — HUKUM PARKINSON */}
        <Card {...card(K.hukum)} bg={L.hot} wipe="circle" dur={0.42}>
          <Stack gap={30}>
            <Line t={t} words={[{text: 'HUKUM', at: a('hukum'), color: L.ink}]} {...fl('HUKUM', 400)} mode="slam" align="center" />
            <div style={{position: 'relative', flexShrink: 0}}>
              <Echo t={t} at={a('parkinson')} n={2} text="PARKINSON" {...fl('PARKINSON', 270)} color={L.ink} />
              <Line t={t} words={[{text: 'PARKINSON', at: a('parkinson')}]} {...fl('PARKINSON', 270)} mode="slam" align="center" />
            </div>
          </Stack>
        </Card>

        {/* 7 — 1955 rolls in like a counter */}
        <Card {...card(K.tahun)} bg={L.ink} wipe="down">
          {folio(L.paper)}
          <Stack gap={30}>
            <Line t={t} words={[{text: 'TAHUN', at: K.tahun - LEAD}]} size={240} wdth={lerp(50, fillWdth('TAHUN', 240), p(t, a('tahun'), a('1955') - 0.05))} />
            <Rule t={t} at={a('tahun') + 0.2} dur={0.9} h={10} color={L.paper} />
            <Roll t={t} value="1955" start={K.tahun} lock={a('1955')} step={0.1} size={530} wdth={60} color={L.hot} />
            <Rule t={t} at={a('1955') + 0.3} dur={0.5} h={10} color={L.hot} from="right" />
          </Stack>
        </Card>

        {/* 8 — the credit block */}
        <Card {...card(K.sejarawan)} bg={L.paper} wipe="left" slow={4.5} drift={0.02}>
          {folio(L.ink)}
          <Stack gap={14}>
            <Tag t={t} at={K.sejarawan - LEAD} parts={[{text: 'SEJARAWAN', at: K.sejarawan - LEAD}, {text: 'INGGRIS', at: a('inggris')}]} bg={L.ink} color={L.paper} size={84} />
            <Gap h={10} />
            <Line t={t} words={[{text: 'CYRIL', at: a('cyril')}]} {...fl('CYRIL', 250)} color={L.ink} />
            <Line t={t} words={[{text: 'NORTHCOTE', at: a('northcote')}]} {...fl('NORTHCOTE', 250)} color={L.ink} />
            <Line t={t} words={[{text: 'PARKINSON', at: a('parkinson', 1), color: L.hot}]} {...fl('PARKINSON', 250)} />
            <Gap h={14} />
            <Rule t={t} at={a('menulis') - 0.1} dur={0.5} h={10} color={L.ink} />
            <Line t={t} words={[{text: 'MENULIS', at: a('menulis')}, {text: 'DI', at: w('di majalah')}, {text: 'MAJALAH', at: a('majalah')}]} {...fl(['MENULIS', 'DI', 'MAJALAH'], 96)} color={L.ink} />
            <div style={{display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexShrink: 0}}>
              <Tag t={t} at={a('the economist')} parts={[{text: 'THE', at: a('the economist')}, {text: 'ECONOMIST', at: a('economist')}]} bg={L.blue} color={L.paper} size={104} rot={-2} />
              <Txt size={64} wdth={70} color={L.ink} style={{opacity: ps(t, a('economist') + 0.2, a('economist') + 0.5)}}>1955</Txt>
            </div>
          </Stack>
        </Card>

        {/* 9 — work expands... MEMUAI swells past the frame */}
        <Card {...card(K.pekerjaan)} bg={L.ink} wipe="up">
          {folio(L.paper)}
          <Stack gap={22}>
            <Line t={t} words={[{text: 'PEKERJAAN', at: K.pekerjaan - LEAD}]} {...fl('PEKERJAAN', 240)} />
            <Line t={t} words={[{text: 'AKAN', at: a('akan'), outline: L.paper}]} size={150} wdth={100} />
            <div style={{position: 'relative', flexShrink: 0, height: 340 * 0.9, display: 'flex', alignItems: 'center', justifyContent: 'center', transform: `scale(${1 + 0.8 * over})`}}>
              <div style={{position: 'relative', width: '100%'}}>
                <Echo t={t} at={a('memuai') + 0.3} text="MEMUAI" size={memS} wdth={memW} color={L.hot} n={2} />
                <Line t={t} words={[{text: 'MEMUAI', at: a('memuai'), color: L.hot}]} size={memS} wdth={memW} align="center" style={{overflow: over > 0 ? 'visible' : 'hidden'}} />
              </div>
            </div>
          </Stack>
        </Card>

        {/* 10 — ...to fill all the time available: six justified lines, edge to edge */}
        <Card {...card(K.sampai)} bg={L.hot} wipe="circle" dur={0.36} at={[50, 62]}>
          {folio(L.ink)}
          <Stack gap={12} top={150} bottom={250}>
            {([
              ['SAMPAI', a('sampai'), L.ink, false],
              ['MEMENUHI', a('memenuhi'), L.paper, false],
              ['SELURUH', a('seluruh'), L.ink, false],
              ['WAKTU', a('waktu', 1), L.ink, true],
              ['YANG', w('waktu yang tersedia', 1), L.ink, false],
              ['TERSEDIA.', a('tersedia'), L.paper, false],
            ] as Array<[string, number, string, boolean]>).map(([txt, at, col, ol]) => (
              <Line key={txt} t={t} words={[{text: txt, at, color: col, outline: ol ? L.ink : undefined}]} {...fl(txt, 230)} mode="stretch" fromWdth={58} />
            ))}
          </Stack>
        </Card>

        {/* 11 — for example */}
        <Card {...card(K.contoh)} bg={L.ink} wipe="down">
          {folio(L.paper)}
          <Marquee t={t} text="CONTOH" size={420} top={1180} color="#F3EFE61F" from={K.contoh} speed={90} />
          <Stack gap={34}>
            <Line t={t} words={[{text: 'CONTOHNYA:', at: K.contoh - LEAD}]} size={fitC} wdth={70} ls={lerp(-0.02, 0.03, p(t, a('contohnya'), K.nenek))} />
            <Rule t={t} at={a('contohnya') + 0.15} dur={1.5} h={16} color={L.hot} />
          </Stack>
        </Card>

        {/* 12 — a grandmother with time to spare (SENGGANG floats loose) */}
        <Card {...card(K.nenek)} bg={L.paper} wipe="up">
          {folio(L.ink)}
          <Stack gap={20}>
            <Line t={t} words={[{text: 'SEORANG', at: K.nenek - LEAD}]} {...sm(['SEORANG'], 140)} color={L.ink} />
            <Line t={t} words={[{text: 'NENEK', at: a('nenek'), color: L.hot}]} {...fl('NENEK', 420)} mode="slam" />
            <Line t={t} words={[{text: 'YANG', at: w('nenek yang', 1)}, {text: 'LAGI', at: a('lagi')}]} {...sm(['YANG', 'LAGI'], 140)} color={L.ink} />
            <Line t={t} words={[{text: 'SENGGANG', at: a('senggang'), color: L.blue}]} size={160} wdth={80} ls={lerp(0.02, 0.08, p(t, a('senggang'), K.bisa))} mode="pop" stagger={0.05} bob={0.035} />
          </Stack>
        </Card>

        {/* 13 — a whole day for one postcard */}
        <Card {...card(K.bisa)} bg={L.blue} wipe="up">
          {folio(L.paper)}
          <Stack gap={16}>
            <Line t={t} words={[{text: 'BISA', at: K.bisa - LEAD}, {text: 'MENGHABISKAN', at: a('menghabiskan')}]} {...fl(['BISA', 'MENGHABISKAN'], 92)} />
            <Line t={t} words={[{text: 'SEHARIAN', at: a('seharian')}]} {...fl('SEHARIAN', 250)} mode="stretch" fromWdth={58} />
            <Line t={t} words={[{text: 'PENUH', at: a('penuh'), outline: L.paper}]} {...fl('PENUH', 250)} />
            <Line t={t} words={[{text: 'CUMA', at: a('cuma')}, {text: 'BUAT', at: w('cuma buat', 1)}, {text: 'MENGIRIM', at: a('mengirim')}]} {...fl(['CUMA', 'BUAT', 'MENGIRIM'], 92)} />
            <Gap h={10} />
            <Postcard t={t} at={a('satu kartu') - 0.1} />
          </Stack>
        </Card>

        {/* 14 — the timesheet */}
        <Card {...card(K.sejam)} bg={L.ink} wipe="left" slow={10} drift={0.04}>
          {folio(L.paper)}
          <Stack gap={54} top={190} style={{transform: `translateY(${sheetFollow(t)}px)`}}>
            <TimeRow t={t} dur={[{text: 'SEJAM', at: K.sejam - LEAD}]} label={[[{text: 'CARI', at: a('cari')}, {text: 'KARTUNYA,', at: a('kartunya')}]]} minutes={60} barAt={a('cari')} />
            <TimeRow t={t} dur={[{text: 'SEJAM', at: a('sejam', 1)}]} label={[[{text: 'CARI', at: a('cari', 1)}, {text: 'KACAMATA,', at: a('kacamata')}]]} minutes={60} barAt={a('cari', 1)} />
            <TimeRow t={t} dur={[{text: '½', at: a('setengah')}, {text: 'JAM', at: w('setengah jam', 1)}]} label={[[{text: 'CARI', at: a('cari', 2)}, {text: 'ALAMAT,', at: a('alamat')}]]} minutes={30} barAt={a('cari', 2)} />
            <TimeRow t={t} pre={{text: 'LEBIH DARI', at: a('lebih')}} dur={[{text: 'SEJAM', at: a('sejam', 2)}]} label={[[{text: 'BUAT', at: w('sejam buat', 1)}, {text: 'MENULIS.', at: a('menulis', 1)}]]} minutes={75} more barAt={w('sejam buat', 1)} />
            <TimeRow t={t} pre={{text: 'LALU', at: a('lalu')}} dur={[{text: '20', at: a('20')}, {text: 'MENIT,', at: a('20') + 0.32}]}
              label={[[{text: 'MIKIR', at: a('mikir')}, {text: 'PERLU', at: a('perlu')}, {text: 'BAWA', at: a('bawa')}],
                [{text: 'PAYUNG', at: a('payung'), color: L.hot}, {text: 'ATAU', at: a('atau')}, {text: 'NGGAK?', at: w('atau nggak', 1)}]]}
              minutes={20} barAt={a('mikir')} barColor={L.blue} wobble={[a('mikir') + 0.6, C.endOf('atau nggak') + 0.1]} />
          </Stack>
        </Card>

        {/* 15 — a whole day vs three minutes (split card) */}
        <Card {...card(K.sibuk)} bg={L.ink} wipe="cut">
          {folio(L.paper)}
          <Stack top={170} bottom={1020} gap={18}>
            <Tag t={t} at={K.sibuk} text="NENEK" bg={L.paper} color={L.ink} size={60} />
            <Line t={t} words={[{text: 'SEHARIAN', at: K.sibuk + 0.05, color: L.hot}]} {...fl('SEHARIAN', 230)} mode="slam" />
          </Stack>
          <div style={{position: 'absolute', left: 0, right: 0, top: 960, bottom: 0, background: L.paper, clipPath: `inset(${(1 - ps(t, a('orang') - 0.14, a('orang') + 0.2)) * 100}% 0 0 0)`}}>
            <div style={{position: 'absolute', left: 72, right: 72, top: 70, display: 'flex', flexDirection: 'column', gap: 40}}>
              <Line t={t} words={[{text: 'ORANG', at: a('orang')}, {text: 'YANG', at: w('orang yang', 1)}, {text: 'SIBUK?', at: a('sibuk'), color: L.blue}]} {...fl(['ORANG', 'YANG', 'SIBUK?'], 110)} color={L.ink} />
              <div style={{display: 'flex', alignItems: 'center', gap: 26, flexShrink: 0}}>
                <div style={{border: `5px solid ${L.ink}`, padding: '14px 22px 6px', transform: `scale(${pb(t, a('tiga') - 0.05, a('tiga') + 0.25)})`, transformOrigin: '0 50%'}}>
                  <Line t={t} words={[{text: '3', at: a('tiga')}, {text: 'MENIT,', at: a('tiga') + 0.2}]} size={72} color={L.ink} wdth={100} mode="pop" />
                </div>
                <Tag t={t} at={a('selesai')} text="SELESAI." bg={L.hot} color={L.ink} size={72} rot={-3} />
              </div>
            </div>
          </div>
        </Card>

        {/* 16 — we are the same */}
        <Card {...card(K.kita)} bg={L.hot} wipe="circle" dur={0.36}>
          {folio(L.ink)}
          <Stack gap={24}>
            <Line t={t} words={[{text: 'KITA', at: a('kita juga'), color: L.ink}]} {...fl('KITA', 420)} mode="slam" align="center" />
            <Line t={t} words={[{text: 'JUGA', at: w('kita juga', 1)}, {text: 'BEGITU.', at: a('begitu')}]} {...fl(['JUGA', 'BEGITU.'], 150)} />
          </Stack>
        </Card>

        {/* 17 — loose time: LONGGAR loosens, KELAMAAN drags */}
        <Card {...card(K.longgar)} bg={L.paper} wipe="up">
          {folio(L.ink)}
          <Stack gap={24}>
            <Line t={t} words={[{text: 'WAKTU', at: K.longgar - LEAD}, {text: 'YANG', at: w('waktu yang longgar', 1)}]} {...sm(['WAKTU', 'YANG'], 140)} color={L.ink} />
            <Line t={t} words={[{text: 'LONGGAR', at: a('longgar'), color: L.blue}]} size={190} wdth={70} ls={lerp(-0.02, 0.16, p(t, a('longgar'), K.pile))} mode="pop" stagger={0.04} bob={0.03} />
            <Line t={t} words={[{text: 'BIKIN', at: a('bikin')}, {text: 'KITA', at: w('bikin kita', 1)}, {text: 'MIKIR', at: a('mikir', 1)}]} {...fl(['BIKIN', 'KITA', 'MIKIR'], 130)} color={L.ink} />
            <Line t={t} words={[{text: 'KELAMAAN,', at: a('kelamaan'), outline: L.ink}]} size={190} wdth={lerp(50, fillWdth('KELAMAAN,', 190), p(t, a('kelamaan'), K.pile + 0.3, Easing.inOut(Easing.quad)))} />
          </Stack>
        </Card>

        {/* 18 — the messy pile; the hard part hangs, untouched */}
        <Card {...card(K.pile)} bg={L.ink} wipe="up">
          {folio(L.paper)}
          <Pile t={t} />
        </Card>

        {/* 19 — flip it */}
        <Card {...card(K.balik)} bg={L.hot} wipe="left">
          {folio(L.ink)}
          <Stack gap={26}>
            <Line t={t} words={[{text: 'JADI,', at: K.balik, color: L.ink}]} size={150} wdth={90} />
            <div style={{transform: `scaleY(${lerp(-1, 1, pb(t, a('balik') - 0.1, a('balik') + 0.55))})`, flexShrink: 0}}>
              <Line t={t} words={[{text: 'BALIK', at: a('balik') - 0.16}]} {...fl('BALIK', 380)} mode="pop" stagger={0.012} />
            </div>
            <Line t={t} words={[{text: 'CARANYA.', at: a('caranya'), color: L.ink}]} {...fl('CARANYA.', 200)} />
          </Stack>
        </Card>

        {/* 20 — don't ask how long it takes (struck out) */}
        <Card {...card(K.jangan)} bg={L.paper} wipe="down">
          {folio(L.ink)}
          <Ghost t={t} at={a('tanya')} ch="?" color="#0E0E0E12" top={260} rot={[30, -6]} />
          <Stack gap={20}>
            <Tag t={t} at={K.jangan - LEAD} parts={[{text: 'JANGAN', at: K.jangan - LEAD}, {text: 'TANYA,', at: a('tanya')}]} bg={L.ink} color={L.paper} size={110} />
            <Gap h={24} />
            {([
              [[{text: '“INI', at: a('ini butuh')}, {text: 'BUTUH', at: a('butuh')}], L.ink],
              [[{text: 'BERAPA', at: a('berapa')}], L.ink],
              [[{text: 'LAMA?”', at: a('lama')}], L.hot],
            ] as Array<[Array<{text: string; at: number}>, string]>).map(([ws, col], i) => (
              <div key={i} style={{position: 'relative', flexShrink: 0}}>
                <Line t={t} words={ws} {...fl(ws.map((x) => x.text), 220)} color={col} />
                <Rule t={t} at={C.endOf('lama') + 0.02 + i * 0.07} dur={0.22} h={26} color={i === 2 ? L.ink : L.hot}
                  style={{position: 'absolute', left: -20, right: -20, width: 'auto', top: 220 * 0.42, transform: `rotate(-2deg) scaleX(${ps(t, C.endOf('lama') + 0.02 + i * 0.07, C.endOf('lama') + 0.24 + i * 0.07)})`}} />
              </div>
            ))}
          </Stack>
        </Card>

        {/* 21 — set the time first. Short. Then do it. */}
        <Card {...card(K.tentukan)} bg={L.ink} wipe="up">
          {folio(L.paper)}
          <Stack gap={22}>
            <Line t={t} words={[{text: 'TENTUKAN', at: K.tentukan - LEAD}]} {...fl('TENTUKAN', 200)} />
            <Line t={t} words={[{text: 'DULU', at: a('dulu'), outline: L.paper}]} size={110} wdth={100} />
            <div style={{position: 'relative', flexShrink: 0, padding: '22px 28px 4px'}}>
              <div style={{position: 'absolute', inset: 0, border: `8px solid ${L.hot}`, clipPath: `inset(0 ${(1 - ps(t, a('waktunya') - 0.05, a('waktunya') + 0.35)) * 100}% 0 0)`}} />
              <Line t={t} words={[{text: 'WAKTUNYA.', at: a('waktunya')}]} size={150} wdth={fillWdth('WAKTUNYA.', 150, W - 56)} />
            </div>
            <div style={{position: 'relative', flexShrink: 0}}>
              <Walls q={pendQ} inner={lineW(['PENDEK.'], pendW, PEND_SIZE, 0.01, 780)} h={PEND_SIZE * 0.9} color={L.paper} thick={18} pad={20} />
              <Line t={t} words={[{text: 'PENDEK.', at: a('pendek'), color: L.hot}]} size={PEND_SIZE} wdth={pendW} weight={780} ls={0.01} mode="pop" stagger={0.015} align="center" />
            </div>
            <Line t={t} words={[{text: 'LALU', at: a('lalu kerjakan')}, {text: 'KERJAKAN.', at: a('kerjakan'), color: L.blue}]} {...fl(['LALU', 'KERJAKAN.'], 130)} mode="slam" />
          </Stack>
        </Card>

        {/* 22 — timeboxes with live countdowns */}
        <Card {...card(K.timebox)} bg={L.paper} wipe="left" slow={4.5} drift={0.02}>
          {folio(L.ink)}
          <Stack gap={40} style={{transform: `translateY(${(1 - pio(t, a('satu jam') - 0.35, a('satu jam') + 0.3)) * 270}px)`}}>
            <TimeBox t={t} at={a('25')} big="25" unit="MENIT" unitAt={a('25 menit') + 0.67} minutes={25}
              words={[{text: 'UNTUK', at: a('untuk')}, {text: 'SATU', at: w('untuk satu tugas', 1)}, {text: 'TUGAS.', at: a('tugas', 1), color: L.hot}]} />
            <TimeBox t={t} at={a('satu jam')} big="1" unit="JAM" unitAt={a('satu jam') + 0.42} minutes={60}
              words={[{text: 'UNTUK', at: a('untuk', 1)}, {text: 'SATU', at: w('untuk satu draf', 1)}, {text: 'DRAF.', at: a('draf'), color: L.hot}]} />
          </Stack>
        </Card>

        {/* 23 — if you don't limit your time... */}
        <Card {...card(K.karena)} bg={L.ink} wipe="up">
          {folio(L.paper)}
          <Stack gap={22}>
            <Line t={t} words={[{text: 'KARENA', at: K.karena - LEAD}, {text: 'KALAU', at: w('karena kalau', 1)}]} {...sm(['KARENA', 'KALAU'], 130)} />
            <Line t={t} words={[{text: 'KAMU', at: a('kamu')}, {text: 'NGGAK', at: w('kamu nggak', 1), color: L.hot}]} {...fl(['KAMU', 'NGGAK'], 190)} />
            <div style={{position: 'relative', flexShrink: 0}}>
              <Walls q={ps(t, a('membatasi') - 0.05, a('membatasi') + 0.35)} inner={W - 140} h={170} color={L.hot} pad={18} />
              <Line t={t} words={[{text: 'MEMBATASI', at: a('membatasi')}]} size={170} wdth={fillWdth('MEMBATASI', 170, W - 140)} align="center" />
            </div>
            <Line t={t} words={[{text: 'WAKTUMU,', at: a('waktumu'), outline: L.paper}]} size={160} wdth={lerp(50, fillWdth('WAKTUMU,', 160), p(t, a('waktumu'), K.payoff + 0.2))} align="center" />
          </Stack>
        </Card>

        {/* 24 — payoff + end card: HARIMU gets walled in */}
        <Card {...card(K.payoff)} bg={L.hot} wipe="circle" dur={0.42} slow={4}>
          {folio(L.ink)}
          <Stack gap={24}>
            <Line t={t} words={[{text: 'PEKERJAANMU', at: a('pekerjaanmu'), color: L.ink}]} {...fl('PEKERJAANMU', 200)} mode="slam" />
            <Line t={t} words={[{text: 'YANG', at: w('pekerjaanmu yang', 1)}, {text: 'AKAN', at: a('akan', 1)}]} {...sm(['YANG', 'AKAN'], 130)} />
            <Line t={t} words={[{text: 'MEMBATASI', at: a('membatasi', 1), color: L.ink}]} {...fl('MEMBATASI', 200)} />
            <Gap h={20} />
            <div style={{position: 'relative', flexShrink: 0}}>
              <Walls q={wallQ} inner={lineW(['HARIMU.'], harW, HAR_SIZE, 0.01, 780)} h={HAR_SIZE * 0.9} color={L.ink} />
              <Line t={t} words={[{text: 'HARIMU.', at: a('harimu')}]} size={HAR_SIZE} wdth={harW} weight={780} ls={0.01} align="center" />
            </div>
            <Gap h={40} />
            <div style={{display: 'flex', justifyContent: 'center', opacity: ps(t, C.duration + 0.05, C.duration + 0.45), flexShrink: 0}}>
              <Txt size={34} wdth={110} weight={800} color={L.ink} ls={0.14}>HUKUM PARKINSON · 1955</Txt>
            </div>
          </Stack>
        </Card>
      </AbsoluteFill>
      <Grain />
    </AbsoluteFill>
  );
};

/** Timesheet camera: rows are revealed one by one, the sheet slides so the revealed rows stay centred. */
const sheetFollow = (t: number) => {
  const rows: Array<[number, number]> = [[K.sejam, 135], [a('sejam', 1), 135], [a('setengah'), 135], [a('lebih'), 193], [a('lalu'), 193]];
  return rows.reduce((off, [at, h]) => off + (1 - pio(t, at - 0.3, at + 0.35)) * (h + 54) / 2, 0);
};

const fitC = Math.floor(W / lineW(['CONTOHNYA:'], 70, 1, 0.03));

/** "SATU KARTU POS." as a postcard built from type: stamp with a big 1, address rules. */
const Postcard: React.FC<{t: number; at: number}> = ({t, at}) => {
  const q = pb(t, at, at + 0.4);
  return (
    <div style={{alignSelf: 'center', width: 760, height: 380, background: L.paper, flexShrink: 0, position: 'relative', opacity: q > 0.01 ? 1 : 0,
      transform: `translateY(${(1 - q) * 160}px) rotate(${lerp(-12, -3, q) + Math.sin(t * 1.1) * 0.6}deg) scale(${0.7 + 0.3 * q})`, boxShadow: '0 18px 0 #0E0E0E40'}}>
      <div style={{position: 'absolute', left: 44, top: 60, display: 'flex', flexDirection: 'column', gap: 12}}>
        <Line t={t} words={[{text: 'KARTU', at: a('kartu')}]} size={120} wdth={78} color={L.ink} />
        <Line t={t} words={[{text: 'POS.', at: a('pos'), color: L.hot}]} size={120} wdth={78} />
      </div>
      <div style={{position: 'absolute', left: 400, top: 40, bottom: 40, width: 4, background: '#0E0E0E30'}} />
      <div style={{position: 'absolute', right: 40, top: 36, width: 150, height: 170, border: `6px dashed ${L.hot}`, display: 'flex', alignItems: 'center', justifyContent: 'center',
        transform: `scale(${pb(t, a('satu kartu') - 0.05, a('satu kartu') + 0.25)})`}}>
        <Txt size={130} wdth={60} color={L.hot} style={{marginTop: 14}}>1</Txt>
      </div>
      {[0, 1, 2].map((i) => (
        <div key={i} style={{position: 'absolute', left: 440, right: 40, top: 250 + i * 40, height: 5, background: L.ink, transform: `scaleX(${ps(t, at + 0.3 + i * 0.12, at + 0.7 + i * 0.12)})`, transformOrigin: '0 50%'}} />
      ))}
    </div>
  );
};

/** Card 18: words drop into a messy pile; the camera then lifts to reveal SUSAH hanging above, put off. */
const Pile: React.FC<{t: number}> = ({t}) => {
  const block = (text: string, at: number, bg: string, color: string, size: number, x: number, y: number, rot: number) => {
    const k = Math.max(0, Math.min(1, (t - at + 0.2) / 0.5));
    if (k <= 0) return null;
    const q = 1 - (1 - k * k); // falls with gravity (ease-in), lands at at+0.3
    const land = Math.max(0, 1 - Math.abs(t - at - 0.32) / 0.14); // squash on impact
    return (
      <div style={{position: 'absolute', left: x, top: y, transform: `translateY(${(1 - q) * -620}px) rotate(${rot * q + (1 - q) * rot * -2}deg) scaleY(${1 - 0.08 * land})`, transformOrigin: '50% 100%',
        background: bg, padding: `${size * 0.14}px ${size * 0.22}px ${size * 0.02}px`}}>
        <Txt size={size} wdth={82} color={color}>{text}</Txt>
      </div>
    );
  };
  const hang = pb(t, a('susah') - 0.04, a('susah') + 0.5);
  const swing = Math.sin((t - a('susah')) * 3.2) * 5 * Math.exp(-Math.max(0, t - a('susah')) * 0.9);
  const settle = Math.max(0, 1 - Math.abs(t - a('menunda') - 0.3) / 0.15) * 12;
  // camera: the pile starts centred, then sinks to the bottom so the top can hold the part we put off
  const cam = lerp(-520, 0, pio(t, a('dan menunda') - 0.25, a('bagian') + 0.1));
  return (
    <>
      <div style={{position: 'absolute', left: 0, right: 0, top: 0, bottom: 0, transform: `translateY(${cam + settle}px)`}}>
        {block('KELAMAAN', K.pile - 1, L.paper, L.ink, 140, 110, 1400, -3)}
        {block('MERAPIKAN', a('merapikan'), L.blue, L.paper, 150, 150, 1190, 4)}
        <div style={{position: 'absolute', left: 250, top: 1095, transform: 'rotate(4deg)'}}>
          <Line t={t} words={[{text: 'YANG', at: w('merapikan yang', 1)}, {text: 'NGGAK', at: w('merapikan yang nggak', 2)}, {text: 'PENTING,', at: a('penting')}]} size={64} wdth={90} color={L.paper} />
        </div>
        {block('MENUNDA', a('menunda'), L.hot, L.ink, 170, 100, 840, -6)}
      </div>
      {/* hanging, untouched */}
      <div style={{position: 'absolute', left: 72, right: 72, top: 200}}>
        <Line t={t} words={[{text: 'DAN', at: a('dan menunda')}]} size={70} wdth={100} />
      </div>
      <div style={{position: 'absolute', left: 72, right: 72, top: 300}}>
        <Line t={t} words={[{text: 'BAGIAN', at: a('bagian')}, {text: 'YANG', at: w('bagian yang', 1)}, {text: 'PALING', at: a('paling')}]} {...fl(['BAGIAN', 'YANG', 'PALING'], 110)} />
      </div>
      <div style={{position: 'absolute', left: 0, right: 0, top: 440, display: 'flex', justifyContent: 'center', transform: `translateY(${(1 - hang) * -800}px) rotate(${swing}deg)`, transformOrigin: '50% -400px', opacity: hang > 0.01 ? 1 : 0}}>
        <div style={{border: `6px dashed ${L.hot}`, padding: '28px 40px 6px'}}>
          <Txt size={270} wdth={fillWdth('SUSAH.', 270, 780)} color={L.hot}>SUSAH.</Txt>
        </div>
      </div>
    </>
  );
};

/** Timebox: big number (counts up), unit, the task line, a live countdown and a draining bar. */
const TimeBox: React.FC<{t: number; at: number; big: string; unit: string; unitAt: number; minutes: number; words: Array<{text: string; at: number; color?: string}>}> = ({t, at, big, unit, unitAt, minutes, words}) => {
  const q = ps(t, at - 0.1, at + 0.3);
  const drain = p(t, at + 0.5, at + 8, Easing.linear);
  return (
    <div style={{position: 'relative', border: `8px solid ${L.ink}`, padding: '36px 36px 30px', flexShrink: 0, opacity: q > 0.01 ? 1 : 0, transform: `scale(${0.94 + 0.06 * q})`, clipPath: `inset(0 ${(1 - q) * 100}% 0 0)`}}>
      <div style={{display: 'flex', alignItems: 'flex-end', gap: 28}}>
        <div style={{transform: `scale(${pb(t, at - 0.04, at + 0.26)})`, transformOrigin: '0 80%'}}>
          <Roll t={t} value={big} start={at - 0.08} lock={at + 0.85} step={0.15} size={300} wdth={70} color={L.ink} align="flex-start" />
        </div>
        <div style={{display: 'flex', flexDirection: 'column', gap: 18, paddingBottom: 18}}>
          <Countdown t={t} from={unitAt} minutes={minutes} size={56} color={L.hot} q={ps(t, unitAt - 0.1, unitAt + 0.2)} />
          <Line t={t} words={[{text: unit, at: unitAt}]} size={130} wdth={92} color={L.ink} />
        </div>
      </div>
      <div style={{height: 22}} />
      <Line t={t} words={words} size={96} wdth={fillWdth(words.map((x) => x.text), 96, W - 88)} color={L.ink} />
      <div style={{height: 26}} />
      <div style={{height: 22, background: '#0E0E0E1A'}}>
        <div style={{height: '100%', width: `${100 * (1 - drain) * ps(t, unitAt, unitAt + 0.4)}%`, background: L.hot}} />
      </div>
    </div>
  );
};

const s = (t: number, name: string, vol = 0.55): Sfx => ({t: Math.max(0, t), src: `audio/sfx/lantang/${name}.wav`, vol});
export const LANTANG_SFX: Sfx[] = [
  s(0.02, 'whoosh', 0.35), s(a('sadar') - 0.03, 'slam', 0.75), s(a('nggak') + 0.38, 'pop', 0.5),
  s(K.tugas, 'swipe', 0.45), s(a('seminggu') - 0.03, 'stretch', 0.55),
  s(a('seminggu', 1) + 0.3, 'ding', 0.5),
  s(K.padahal, 'whoosh', 0.45), s(a('besok') - 0.04, 'squeeze', 0.65), s(a('beres'), 'snap', 0.45),
  s(a('hukum') - 0.03, 'slam', 0.85), s(a('parkinson') - 0.03, 'thud', 0.7),
  s(K.tahun, 'swipe', 0.4), s(a('tahun') + 0.15, 'clock', 0.4), s(a('1955') - 0.02, 'slam', 0.75),
  s(K.sejarawan, 'swipe', 0.4), s(a('the economist'), 'snap', 0.5),
  s(K.pekerjaan, 'swipe', 0.4), s(a('memuai') - 0.03, 'stretch', 0.6), s(K.sampai - 1.3, 'riser', 0.5), s(K.sampai, 'slam', 0.8),
  s(a('tersedia'), 'thud', 0.5),
  s(K.contoh, 'swipe', 0.4), s(a('nenek') - 0.03, 'slam', 0.6),
  s(K.bisa, 'whoosh', 0.4), s(a('seharian') - 0.03, 'stretch', 0.55), s(a('satu kartu') - 0.05, 'pop', 0.5),
  s(a('sejam'), 'clock', 0.45), s(a('setengah'), 'tick', 0.45), s(a('20'), 'tick', 0.45), s(a('payung'), 'pop', 0.45),
  s(K.sibuk + 0.03, 'slam', 0.75), s(a('orang') - 0.14, 'swipe', 0.45), s(a('tiga'), 'pop', 0.4), s(a('selesai'), 'ding', 0.55),
  s(a('kita juga') - 0.03, 'slam', 0.75), s(K.longgar, 'swipe', 0.4), s(a('longgar'), 'stretch', 0.45),
  s(a('merapikan') + 0.28, 'thud', 0.6), s(a('menunda') + 0.28, 'thud', 0.65), s(a('susah') - 0.03, 'slam', 0.7),
  s(a('balik') - 0.03, 'whoosh', 0.5), s(C.endOf('lama') + 0.02, 'snap', 0.55),
  s(K.tentukan, 'whoosh', 0.45), s(a('pendek') + 0.05, 'squeeze', 0.75), s(a('kerjakan') - 0.03, 'slam', 0.7),
  s(a('25 menit') + 0.67, 'clock', 0.45),
  s(K.karena, 'swipe', 0.4), s(a('membatasi') - 0.04, 'snap', 0.55), s(a('waktumu'), 'stretch', 0.5), s(K.payoff - 1.3, 'riser', 0.45),
  s(a('pekerjaanmu') - 0.03, 'slam', 0.75), s(a('harimu') + 0.3, 'squeeze', 0.7), s(C.duration + 0.1, 'ding', 0.5),
];
