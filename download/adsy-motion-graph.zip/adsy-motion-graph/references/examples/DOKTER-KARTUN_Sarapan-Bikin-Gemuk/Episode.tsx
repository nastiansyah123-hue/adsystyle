// REFERENCE DEMO (ADSY MOTION GRAPH v2.1). Read for structure only; never copy its story or text. Imports point at the starter kit. Place in src/dokter/; the character lives in the starter at src/styles/medis/Dokter.tsx.
import React from 'react';
import {AbsoluteFill} from 'remotion';
import {at, words} from '../lib/words';
import {buildPages} from '../components/WordCaptions';
import {p, pb, lerp} from '../styles/shared';
import {Dokter, Pose} from '../styles/medis/Dokter';
import project from '../project.json';

// DOKTER KARTUN: a cartoon doctor presents at the bottom right; a title card with one highlighted
// keyword sits on top; one infographic per sentence in the middle; pastel gradient changes per scene.
const INK = '#23233A', HL = '#FFD43B', RED = '#EF4444', GREEN = '#22C55E', CARD = '#FFFFFF', MUTED = '#6B6B85';
const F = 'Mograph Sans', T = 'Mograph Text';
const BG = [['#FCE4EC', '#F8D7E8'], ['#E8E4FB', '#DCD6F7'], ['#FFE9D6', '#FDDCC4'], ['#E0F5EE', '#CBEFE3'], ['#E3EEFC', '#D3E3FA']];

// ---------- building blocks ----------
const Title: React.FC<{t: number; a: number; text: string}> = ({t, a, text}) => {
  const q = pb(t, a, a + 0.35);
  const parts = text.split(/(\[[^\]]+\])/);
  return (
    <div style={{position: 'absolute', top: 175, left: 70, right: 70, display: 'flex', justifyContent: 'center', transform: `translateY(${(1 - q) * -60}px)`, opacity: Math.min(1, q * 2)}}>
      <div style={{position: 'relative', background: CARD, border: `5px solid ${INK}`, borderRadius: 26, padding: '26px 40px', boxShadow: `0 10px 0 ${INK}22`, textAlign: 'center',
        fontFamily: F, fontWeight: 800, fontSize: 66, lineHeight: 1.15, color: INK, maxWidth: 940}}>
        <div style={{position: 'absolute', top: -14, left: '50%', width: 120, height: 22, marginLeft: -60, borderRadius: 11, background: HL, border: `4px solid ${INK}`}} />
        {parts.map((s, i) => s.startsWith('[')
          ? <span key={i} style={{background: HL, border: `4px solid ${INK}`, borderRadius: 10, padding: '0 10px', margin: '0 4px', display: 'inline-block', transform: `scale(${pb(t, a + 0.25, a + 0.55)})`}}>{s.slice(1, -1)}</span>
          : <span key={i}>{s}</span>)}
      </div>
    </div>
  );
};
const pop = (t: number, a: number, d = 0.35) => {
  const q = pb(t, a, a + d);
  return {opacity: Math.min(1, q * 2), transform: `scale(${0.6 + 0.4 * q})`};
};
const Circle: React.FC<{t: number; a: number; size?: number; color?: string; children: React.ReactNode}> = ({t, a, size = 300, color = '#ffffff99', children}) => (
  <div style={{width: size, height: size, borderRadius: size, background: color, display: 'flex', alignItems: 'center', justifyContent: 'center', ...pop(t, a)}}>{children}</div>
);
const Card: React.FC<{t: number; a: number; w?: number; accent?: string; children: React.ReactNode; style?: React.CSSProperties}> = ({t, a, w = 420, accent, children, style}) => (
  <div style={{width: w, background: CARD, border: `5px solid ${INK}`, borderRadius: 24, borderTop: accent ? `16px solid ${accent}` : `5px solid ${INK}`, padding: '26px 24px', boxShadow: `0 10px 0 ${INK}22`,
    display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 14, fontFamily: F, fontWeight: 800, fontSize: 38, color: INK, textAlign: 'center', ...pop(t, a), ...style}}>{children}</div>
);
const Row: React.FC<{t: number; a: number; icon: React.ReactNode; text: string; accent?: string}> = ({t, a, icon, text, accent = HL}) => {
  const q = pb(t, a, a + 0.35);
  return (
    <div style={{display: 'flex', alignItems: 'center', gap: 22, width: 760, background: CARD, border: `5px solid ${INK}`, borderLeft: `18px solid ${accent}`, borderRadius: 18, padding: '18px 26px',
      fontFamily: F, fontWeight: 800, fontSize: 44, color: INK, boxShadow: `0 8px 0 ${INK}22`, opacity: Math.min(1, q * 2), transform: `translateX(${(1 - q) * -120}px)`}}>
      {icon}<span>{text}</span>
    </div>
  );
};
const Ico: React.FC<{kind: string; size?: number}> = ({kind, size = 64}) => {
  const s = size;
  const st = {stroke: INK, strokeWidth: 6, strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const};
  return (
    <svg width={s} height={s} viewBox="0 0 100 100">
      {kind === 'x' && <><circle cx="50" cy="50" r="44" fill={RED} /><path d="M32 32 L68 68 M68 32 L32 68" stroke="#fff" strokeWidth="12" strokeLinecap="round" /></>}
      {kind === 'ok' && <><circle cx="50" cy="50" r="44" fill={GREEN} /><path d="M28 52 L44 68 L72 34" fill="none" stroke="#fff" strokeWidth="12" strokeLinecap="round" strokeLinejoin="round" /></>}
      {kind === 'plate' && <><ellipse cx="50" cy="56" rx="44" ry="24" fill="#fff" {...st} /><circle cx="40" cy="50" r="13" fill={HL} {...st} strokeWidth={4} /><rect x="56" y="38" width="22" height="18" rx="5" fill="#E9A55A" {...st} strokeWidth={4} /></>}
      {kind === 'scale' && <><rect x="10" y="22" width="80" height="66" rx="16" fill="#5EC4B6" {...st} /><path d="M28 50 A22 22 0 0 1 72 50" fill="#fff" {...st} strokeWidth={4} /><line x1="50" y1="50" x2="64" y2="36" {...st} stroke={RED} /></>}
      {kind === 'clock' && <><circle cx="50" cy="50" r="40" fill="#fff" {...st} /><path d="M50 28 V50 L66 58" fill="none" {...st} /></>}
      {kind === 'bolt' && <path d="M56 6 L22 56 H46 L40 94 L78 40 H54 Z" fill={HL} {...st} />}
      {kind === 'brain' && <><path d="M50 18 C28 14 16 32 22 46 C10 56 18 78 36 78 C40 88 60 88 64 78 C82 78 90 56 78 46 C84 32 72 14 50 18 Z" fill="#F9A8D4" {...st} /><path d="M50 20 V82" {...st} fill="none" /></>}
      {kind === 'smile' && <><circle cx="50" cy="50" r="42" fill={HL} {...st} /><circle cx="36" cy="42" r="5" fill={INK} /><circle cx="64" cy="42" r="5" fill={INK} /><path d="M32 60 Q50 76 68 60" fill="none" {...st} /></>}
      {kind === 'batt' && <><rect x="12" y="28" width="70" height="44" rx="8" fill="#fff" {...st} /><rect x="84" y="40" width="8" height="20" rx="3" fill={INK} /><rect x="20" y="36" width="16" height="28" rx="3" fill={RED} /></>}
      {kind === 'person' && <><circle cx="50" cy="30" r="16" fill="#F2C7A5" {...st} /><path d="M20 90 C20 58 32 50 50 50 C68 50 80 58 80 90 Z" fill="#93C5FD" {...st} /></>}
      {kind === 'chat' && <><path d="M14 22 H86 V68 H44 L26 84 V68 H14 Z" fill="#fff" {...st} /><circle cx="36" cy="45" r="5" fill={INK} /><circle cx="50" cy="45" r="5" fill={INK} /><circle cx="64" cy="45" r="5" fill={INK} /></>}
      {kind === 'bulb' && <><path d="M50 10 C28 10 18 28 22 44 C25 56 36 60 36 72 H64 C64 60 75 56 78 44 C82 28 72 10 50 10 Z" fill={HL} {...st} /><rect x="38" y="74" width="24" height="14" rx="4" fill="#9CA3AF" {...st} strokeWidth={4} /></>}
      {kind === 'leaf' && <><path d="M20 80 C20 40 50 16 84 16 C84 52 60 80 20 80 Z" fill="#86EFAC" {...st} /><path d="M24 76 C40 58 56 44 72 30" fill="none" {...st} /></>}
    </svg>
  );
};

// ---------- scenes ----------
type Sc = {title: string; pose: Pose; body: (t: number, a: number) => React.ReactNode};
const W = (s: string, n = 0) => at(s, n);
const CENTER: React.CSSProperties = {position: 'absolute', top: 420, left: 0, right: 0, height: 560, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 34};

const SCENES: Sc[] = [
  {title: 'Sarapan Bikin [Gemuk]?', pose: 'wave', body: (t, a) => (
    <div style={CENTER}>
      <Circle t={t} a={a + 0.1} size={260}><Ico kind="plate" size={170} /></Circle>
      <div style={{fontFamily: F, fontWeight: 800, fontSize: 90, color: INK, ...pop(t, a + 0.3)}}>→</div>
      <Circle t={t} a={W('gemuk') - 0.1} size={260}><Ico kind="scale" size={170} /></Circle>
      <div style={{position: 'absolute', top: 40, right: 150, fontFamily: F, fontWeight: 800, fontSize: 150, color: RED, ...pop(t, W('kok'))}}>?</div>
    </div>)},
  {title: 'Sarapan = [Energi] Pagi', pose: 'point', body: (t, a) => {
    const fill = p(t, W('energi') - 0.2, W('energi') + 0.8);
    return (
      <div style={{...CENTER, flexDirection: 'column', gap: 30}}>
        <div style={{display: 'flex', alignItems: 'center', gap: 20, ...pop(t, a + 0.1)}}>
          <div style={{width: 520, height: 150, border: `7px solid ${INK}`, borderRadius: 26, background: '#fff', padding: 12}}>
            <div style={{width: `${lerp(12, 100, fill)}%`, height: '100%', borderRadius: 14, background: fill < 0.4 ? RED : GREEN}} />
          </div>
          <div style={{width: 26, height: 60, background: INK, borderRadius: 6}} />
          <Ico kind="bolt" size={120} />
        </div>
        <div style={{display: 'flex', gap: 18}}>
          {['Sekolah', 'Kerja', 'Aktivitas'].map((s, i) => <div key={s} style={{fontFamily: F, fontWeight: 800, fontSize: 40, color: INK, background: '#fff', border: `5px solid ${INK}`, borderRadius: 40, padding: '10px 28px', ...pop(t, W('aktivitas') + i * 0.15)}}>{s}</div>)}
        </div>
      </div>);
  }},
  {title: 'Skip Sarapan? Malah [Kalap]', pose: 'open', body: (t) => (
    <div style={{...CENTER, flexDirection: 'column', gap: 22}}>
      <Row t={t} a={W('enggak') - 0.1} icon={<Ico kind="x" size={56} />} text="Lewatkan sarapan" accent={RED} />
      <Row t={t} a={W('kelaparan') - 0.1} icon={<Ico kind="batt" size={56} />} text="Lapar berlebihan" accent="#F59E0B" />
      <Row t={t} a={W('makan', 0) - 0.1} icon={<Ico kind="plate" size={56} />} text="Makan siang kebanyakan" accent={RED} />
    </div>)},
  {title: 'Asal Mula [Mitos]-nya', pose: 'think', body: (t) => (
    <div style={CENTER}>
      <Card t={t} a={W('asumsi') - 0.3} w={760} accent="#A78BFA">
        <Ico kind="bulb" size={130} />
        <div style={{fontSize: 30, color: MUTED, letterSpacing: 3}}>ASUMSINYA</div>
        <div style={{fontSize: 56}}>Kalori pagi = kalori <span style={{background: HL, padding: '0 8px'}}>ekstra</span>?</div>
      </Card>
    </div>)},
  {title: '[Bayangin] Kalau Benar…', pose: 'open', body: (t) => {
    const fat = pb(t, W('otomatis') + 0.2, W('otomatis') + 0.7);
    const stamp = pb(t, W('kelebihan') + 0.3, W('kelebihan') + 0.6);
    return (
      <div style={CENTER}>
        <div style={{display: 'grid', gridTemplateColumns: 'repeat(4, 150px)', gap: 18, background: '#ffffffaa', border: `5px solid ${INK}`, borderRadius: 26, padding: 26, position: 'relative', ...pop(t, W('bayangin'))}}>
          {Array.from({length: 8}, (_, i) => <div key={i} style={{display: 'flex', justifyContent: 'center', transform: `scaleX(${lerp(1, 1.45, i < 2 ? fat : fat * p(t, W('semua'), W('semua') + 0.5))})`}}><Ico kind="person" size={140} /></div>)}
          <div style={{position: 'absolute', top: '50%', left: '50%', fontFamily: F, fontWeight: 800, fontSize: 70, color: '#fff', background: RED, border: `5px solid ${INK}`, borderRadius: 18, padding: '6px 26px', whiteSpace: 'nowrap',
            transform: `translate(-50%, -50%) rotate(-8deg) scale(${lerp(1.8, 1, stamp)})`, opacity: stamp}}>Nyatanya enggak!</div>
        </div>
      </div>);
  }},
  {title: 'Kuncinya: [Total] Kalori', pose: 'point', body: (t) => {
    const outQ = p(t, W('pengeluaran') - 0.2, W('pengeluaran') + 0.3);
    const tilt = lerp(-10, 0, outQ);
    return (
      <div style={{...CENTER, flexDirection: 'column', gap: 10}}>
        <svg width={760} height={380} viewBox="0 0 760 380" style={pop(t, W('total') - 0.2)}>
          <path d="M380 70 L330 360 H430 Z" fill={INK} />
          <g transform={`rotate(${tilt} 380 70)`}>
            <rect x="70" y="62" width="620" height="16" rx="8" fill={INK} />
            <path d="M120 78 L70 200 H250 L200 78" fill="none" stroke={INK} strokeWidth="5" /><path d="M60 200 H260 Q160 260 60 200 Z" fill="#FDBA74" stroke={INK} strokeWidth="5" />
            <path d="M560 78 L510 200 H690 L640 78" fill="none" stroke={INK} strokeWidth="5" /><path d="M500 200 H700 Q600 260 500 200 Z" fill="#86EFAC" stroke={INK} strokeWidth="5" opacity={0.3 + 0.7 * outQ} />
            <text x="160" y="300" textAnchor="middle" fontFamily={F} fontWeight="800" fontSize="42" fill={INK}>MASUK</text>
            <text x="600" y="300" textAnchor="middle" fontFamily={F} fontWeight="800" fontSize="42" fill={INK} opacity={0.3 + 0.7 * outQ}>KELUAR</text>
          </g>
        </svg>
        <div style={{display: 'flex', alignItems: 'center', gap: 14, fontFamily: F, fontWeight: 800, fontSize: 40, color: INK, background: '#fff', border: `5px solid ${INK}`, borderRadius: 40, padding: '8px 26px', ...pop(t, W('waktu') - 0.2)}}>
          <Ico kind="clock" size={50} /> bukan cuma jam makan
        </div>
      </div>);
  }},
  {title: 'Boleh Sarapan, [Asal]…', pose: 'thumb', body: (t) => (
    <div style={{...CENTER, flexDirection: 'column', gap: 26}}>
      <Row t={t} a={W('bergizi') - 0.3} icon={<Ico kind="ok" size={60} />} text="Pilih makanan bergizi" accent={GREEN} />
      <Row t={t} a={W('porsinya') - 0.1} icon={<Ico kind="ok" size={60} />} text="Porsi sesuai kebutuhan" accent={GREEN} />
    </div>)},
  {title: 'Sering [Skip] Sarapan?', pose: 'think', body: (t) => (
    <div style={CENTER}>
      <Circle t={t} a={W('melewatkan') - 0.2} size={300}><Ico kind="batt" size={200} /></Circle>
      <Card t={t} a={W('gimana') - 0.1} w={360} accent="#F59E0B"><div style={{fontSize: 46}}>Gimana rasanya?</div><div style={{fontSize: 30, color: MUTED}}>lemas, susah fokus</div></Card>
    </div>)},
  {title: 'Bonus: [Fokus] & Mood', pose: 'point', body: (t) => {
    const m = (a0: number) => p(t, a0, a0 + 0.8);
    return (
      <div style={CENTER}>
        {[['brain', 'Konsentrasi', W('konsentrasi') - 0.2], ['smile', 'Suasana hati', W('suasana') - 0.1]].map(([k, l, a0]) => (
          <Card key={k as string} t={t} a={a0 as number} w={360} accent="#60A5FA">
            <Ico kind={k as string} size={150} /><div>{l as string}</div>
            <div style={{width: 280, height: 22, borderRadius: 11, background: '#E5E7EB', border: `4px solid ${INK}`}}><div style={{width: `${m(a0 as number) * 100}%`, height: '100%', borderRadius: 8, background: GREEN}} /></div>
          </Card>
        ))}
      </div>);
  }},
  {title: 'Jangan [Takut] Sarapan', pose: 'wave', body: (t) => (
    <div style={{...CENTER, flexDirection: 'column', gap: 26}}>
      {[['1', 'Pilih menu sehat', W('pilih', 1) - 0.2, GREEN], ['2', 'Jangan berlebihan', W('berlebihan', 1) - 0.2, '#F59E0B']].map(([n, s, a0, c]) => (
        <Row key={n as string} t={t} a={a0 as number} accent={c as string} text={s as string}
          icon={<div style={{width: 62, height: 62, borderRadius: 31, background: c as string, border: `5px solid ${INK}`, color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 38}}>{n as string}</div>} />
      ))}
    </div>)},
  {title: 'Yang Penting: [Seimbang]', pose: 'open', body: (t) => (
    <div style={CENTER}>
      <Card t={t} a={W('kapan') - 0.2} w={360} accent={RED}><Ico kind="x" size={110} /><div style={{fontSize: 42}}>Kapan makan</div></Card>
      <div style={{width: 100, height: 100, borderRadius: 50, background: HL, border: `5px solid ${INK}`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: F, fontWeight: 800, fontSize: 38, color: INK, ...pop(t, W('tapi'))}}>VS</div>
      <Card t={t} a={W('seberapa') - 0.1} w={360} accent={GREEN}><Ico kind="ok" size={110} /><div style={{fontSize: 42}}>Sehat &amp; seimbang</div></Card>
    </div>)},
  {title: 'Sarapan Favoritmu [Apa]?', pose: 'wave', body: (t, a) => (
    <div style={{...CENTER, flexDirection: 'column', gap: 26}}>
      <Circle t={t} a={a + 0.1} size={260}><Ico kind="chat" size={170} /></Circle>
      <div style={{fontFamily: F, fontWeight: 800, fontSize: 52, color: INK, background: '#fff', border: `5px solid ${INK}`, borderRadius: 22, padding: '12px 34px', ...pop(t, W('favorit'))}}>Tulis di komentar!</div>
    </div>)},
];
export const STARTS = [0, 4.55, 10.01, 16.01, 21.87, 28.01, 34.45, 40.21, 44.65, 49.82, 55.13, 61.16];

// ---------- captions: dark pill, active word on a yellow box ----------
const pages = buildPages(words, 4);
const Captions: React.FC<{t: number}> = ({t}) => {
  const pg = pages.find((x) => t >= x.start - 0.08 && t < x.end);
  if (!pg) return null;
  const q = p(t, pg.start - 0.08, pg.start + 0.1);
  return (
    <div style={{position: 'absolute', top: 1010, left: 60, right: 60, display: 'flex', justifyContent: 'center', opacity: q, transform: `translateY(${(1 - q) * 14}px)`}}>
      <div style={{background: '#1F1F33', borderRadius: 18, padding: '14px 24px', fontFamily: F, fontWeight: 800, fontSize: 50, color: '#fff', lineHeight: 1.3, textAlign: 'center', maxWidth: 940}}>
        {pg.words.map((w, k) => {
          const next = pg.words[k + 1];
          const on = t >= w.start && t < (next ? next.start : w.end + 0.25);
          return <span key={w.i}><span style={{background: on ? HL : 'transparent', color: on ? INK : '#fff', borderRadius: 8, padding: '0 6px'}}>{w.word.replace(/[.,;:]+$/, '')}</span>{k < pg.words.length - 1 ? ' ' : ''}</span>;
        })}
      </div>
    </div>
  );
};

export const DokterEpisode: React.FC<{t: number}> = ({t}) => {
  let i = SCENES.length - 1;
  while (i > 0 && t < STARTS[i]) i--;
  const sc = SCENES[i], a = STARTS[i];
  const [c0, c1] = BG[i % BG.length];
  const prev = SCENES[Math.max(0, i - 1)];
  return (
    <AbsoluteFill style={{background: `linear-gradient(180deg, ${c0}, ${c1})`}}>
      {/* soft decorative dots */}
      <svg width={1080} height={1920} style={{position: 'absolute', opacity: 0.35}}>
        {[[140, 1250, 60], [930, 470, 40], [90, 520, 26], [980, 1000, 70], [400, 1350, 30]].map(([x, y, r], k) => <circle key={k} cx={x} cy={y + Math.sin(t + k) * 10} r={r} fill="#ffffff" />)}
      </svg>
      {/* progress bar */}
      <div style={{position: 'absolute', top: 0, left: 0, height: 10, width: `${(t / project.durationSeconds) * 100}%`, background: RED}} />
      <Title t={t} a={a} text={sc.title} />
      {sc.body(t, a)}
      <Captions t={t} />
      <Dokter t={t} pose={sc.pose} poseAt={a} prevPose={i === 0 ? 'open' : prev.pose} x={500} y={1120} s={1} />
    </AbsoluteFill>
  );
};
