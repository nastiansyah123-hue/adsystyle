// REFERENCE DEMO (ADSY MOTION GRAPH v2.1). Read for structure only; never copy its story or text. Imports point at the starter kit.
import React from 'react';
import {AbsoluteFill, Audio, staticFile, useCurrentFrame} from 'remotion';
import project from './project.json';
import {SfxTrack} from './components/SfxTrack';
import {FontFaces} from './Fonts';
import {DokterEpisode} from './dokter/Episode';

const sound = project as {musicFile?: string | null; musicVolume?: number; musicAutomation?: Array<{frame: number; volume: number}>};
const musicGain = (frame: number): number => {
  const base = sound.musicVolume ?? 0.24;
  const pts = sound.musicAutomation ?? [];
  if (!pts.length) return base;
  if (frame <= pts[0].frame) return pts[0].volume;
  if (frame >= pts[pts.length - 1].frame) return pts[pts.length - 1].volume;
  let i = 1;
  while (pts[i].frame < frame) i++;
  const l = pts[i - 1], r = pts[i];
  return l.volume + (r.volume - l.volume) * ((frame - l.frame) / Math.max(1, r.frame - l.frame));
};

export const Main: React.FC = () => {
  const t = useCurrentFrame() / 60;
  return (
    <AbsoluteFill style={{overflow: 'hidden', background: '#000'}}>
      <FontFaces />
      <DokterEpisode t={t} />
      <SfxTrack />
      {sound.musicFile && <Audio src={staticFile(sound.musicFile)} volume={musicGain} />}
      {project.voiceoverFile && <Audio src={staticFile(project.voiceoverFile)} />}
    </AbsoluteFill>
  );
};
