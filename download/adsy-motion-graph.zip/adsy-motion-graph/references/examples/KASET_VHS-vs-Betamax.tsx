// REFERENCE DEMO (ADSY MOTION GRAPH v1.9) — read for structure only: scenes, camera moves, word-pinned beats, SFX cues.
// Do NOT copy this story, its text or its layout into a buyer video. Written in the author's demo workspace, so a few
// imports differ from the starter: `makeCues(words)` ≈ the starter's `at()/endOf()` from src/lib/words.ts, and
// `EpisodeAudio` ≈ Main.tsx audio (musicFile + auto-duck) + <SfxTrack /> fed by src/audio-plan.json sfxCues.
// A `getInputProps()` draft switch, if present, was a workspace-only shortcut: do not copy it (the starter has --silent-draft).
import React from 'react';
import {AbsoluteFill, getInputProps} from 'remotion';
import {makeCues} from '../../lib/cues';
import {lerp, p, pagesFor, pb, pio, rnd, StyleFonts, useTime} from '../../styles/shared';
import {EpisodeAudio, Sfx} from '../../styles/audio';
import {
  BarsPattern, Belt, BetaTape, Big, burst, CC, Chrome, cl, CrtTv, Crt, Dive, Factory, FilmStrip, Flip, glitchBands, GOLD, HEAD, hitBands, K, Lamp, LicenseDoc,
  Mark, Mode, OSD, Osd, pauseBand, Person, PictureStack, PriceTag, Push, Rosette, RUBY, scrubBands, SILVER, slam, slide, Sofa, Spine, Squash, StatRow, Tab, Tank,
  TapeLayer, TestCard, trackBand, Vcr, VhsFilter, VhsTape, VRoll, lq,
} from '../../styles/kaset/kit';
import wordsFile from './words.json';

// KASET episode — "VHS vs Betamax": a 90s TV special about the living-room war, played back from a worn VHS tape.
// Told like a boxing broadcast: tale-of-the-tape cards for both formats, an instant replay, three rounds with a score
// bug, a fast-forward from 1976 to 2002, a CRT power squash, then the lesson. Deck OSD + Line-21 captions stay crisp.

const C = makeCues(wordsFile);
const a = C.at;
const PAGES = pagesFor(C.words, 4, 22);
export const KASET_DURATION = C.duration + 1.4;
const END = KASET_DURATION;
const fa = (x: number) => Math.ceil(x * 60) / 60; // frame-aligned cut

// ───────── tape timeline ─────────
const CUT1 = fa(a('bukan') - 0.08); // dive into the TV → fight card (glitch)
const ROLL1: [number, number] = [a('di satu sisi') - 0.36, a('di satu sisi') - 0.04]; // → Betamax corner
const PUSH1: [number, number] = [a('kasetnya') - 0.34, a('kasetnya') - 0.03]; // → Betamax features
const FLIP1: [number, number] = [a('di sisi lain') - 0.34, a('di sisi lain') - 0.01]; // → VHS corner
const REW: [number, number] = [a('banyak') - 0.46, a('banyak') - 0.04]; // ◀◀ instant replay
const CUT2 = fa(a('tapi justru') - 0.08); // → champion
const PAUSE: [number, number] = [a('kenapa') + 0.2, a('pertama') - 0.08]; // ‖ freeze on KENAPA?
const R1 = PAUSE[1];
const ROLL2: [number, number] = [a('kedua') - 0.36, a('kedua') - 0.04];
const PUSH2: [number, number] = [a('ketiga') - 0.34, a('ketiga') - 0.02];
const CUT4 = fa(a('betamax', 3) - 0.1); // → pushed out
const CUT5 = fa(a('sony berhenti') - 0.1); // → factory line
const FF: [number, number] = [a('tahun 2002') - 0.24, a('2002') - 0.01]; // ▶▶ 1976 → 2002
const STOP: [number, number] = [a('2002') + 0.16, a('pelajarannya') - 0.2];
const OFF: [number, number] = [STOP[1] - 0.36, STOP[1]]; // CRT squash off
const ON: [number, number] = [STOP[1], STOP[1] + 0.34]; // … and on again
const LESSON = STOP[1];
const PUSH3: [number, number] = [a('yang menang', 1) - 0.3, a('yang menang', 1) - 0.02];
const TRACK: Array<[number, number]> = [[1.05, 1.85], [10.0, 10.75], [46.1, 46.85], [62.15, 62.85]];
const CAP_END = PAGES[PAGES.length - 1].end + 0.02; // last caption gone → end card text
const SC = [a('utuh') + 0.15, a('bersaing') + 0.2, a('paling banyak') + 0.55]; // VHS takes a round
const OUT0 = CUT4;

const ov = (t: number, [s, e]: [number, number]) => Math.max(0, Math.min(t, e) - s);
const live = (t: number, s: number, e: number) => t >= s && t < e;

// ───────── shared scene furniture ─────────
const BG = {
  blue: `radial-gradient(ellipse 90% 60% at 50% 34%, #3A5CF7 0%, ${K.blue} 46%, ${K.navy} 100%)`,
  red: 'radial-gradient(ellipse 90% 60% at 50% 34%, #F0584D 0%, #B8241E 46%, #3E0907 100%)',
  navy: 'radial-gradient(ellipse 90% 60% at 50% 34%, #26337E 0%, #0F1850 50%, #05071A 100%)',
  slate: 'radial-gradient(ellipse 90% 60% at 50% 40%, #4A5578 0%, #252C48 55%, #0E1224 100%)',
};
const Studio: React.FC<{bg: string; stripes?: boolean; children?: React.ReactNode}> = ({bg, stripes = true, children}) => (
  <AbsoluteFill style={{background: bg, overflow: 'hidden'}}>
    {stripes && <AbsoluteFill style={{backgroundImage: 'repeating-linear-gradient(135deg, rgba(255,255,255,0.05) 0 28px, transparent 28px 70px)'}} />}
    {children}
  </AbsoluteFill>
);
const Rays: React.FC<{t: number; cx: number; cy: number; color?: string; opacity?: number; r?: number}> = ({t, cx, cy, color = '#FFFFFF', opacity = 0.08, r = 1500}) => (
  <svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0}}>
    <g transform={`translate(${cx} ${cy}) rotate(${lq(t * 6, 8)})`} fill={color} opacity={opacity}>
      {Array.from({length: 14}, (_, i) => {
        const a0 = (i / 14) * Math.PI * 2, a1 = a0 + Math.PI / 14;
        return <path key={i} d={`M 0 0 L ${Math.cos(a0) * r} ${Math.sin(a0) * r} L ${Math.cos(a1) * r} ${Math.sin(a1) * r} Z`} />;
      })}
    </g>
  </svg>
);
const Spot: React.FC<{x: number; y: number; w: number; k?: number}> = ({x, y, w, k = 1}) => (
  <>
    <div style={{position: 'absolute', left: x - w * 0.18, top: 0, width: w * 0.36, height: y, clipPath: 'polygon(35% 0, 65% 0, 100% 100%, 0 100%)', background: 'linear-gradient(rgba(255,250,230,0.0), rgba(255,250,230,0.16))', opacity: k}} />
    <div style={{position: 'absolute', left: x - w / 2, top: y - w * 0.09, width: w, height: w * 0.18, borderRadius: '50%', background: 'radial-gradient(ellipse, rgba(255,250,230,0.32), rgba(255,250,230,0) 70%)', opacity: k}} />
  </>
);
const Confetti: React.FC<{t: number; at: number; n?: number}> = ({t, at, n = 46}) => {
  if (t < at) return null;
  const cols = [K.yellow, K.red, K.white, '#3A5CF7', K.tung];
  return (
    <>
      {Array.from({length: n}, (_, i) => {
        const k = t - at - rnd(i * 3.1) * 0.5;
        if (k < 0) return null;
        const x = rnd(i * 1.7) * 1080 + Math.sin(k * 3 + i) * 30, y = -40 + k * (320 + rnd(i * 2.3) * 260);
        if (y > 1960) return null;
        return <div key={i} style={{position: 'absolute', left: x, top: y, width: 16, height: 26, background: cols[i % cols.length], transform: `rotate(${i * 37 + k * 140}deg)`}} />;
      })}
    </>
  );
};
/** title words that each land on their spoken word */
const Words: React.FC<{t: number; items: Array<[string, number]>; size: number; color?: string; deep?: string; gap?: number; style?: React.CSSProperties}> = ({t, items, size, color = K.white, deep = K.navy, gap = 26, style}) => (
  <div style={{display: 'flex', gap, ...style}}>
    {items.map(([w, at]) => <Big key={w + at} size={size} color={color} deep={deep} style={slam(t, at)}>{w}</Big>)}
  </div>
);
/** a tab whose words light up as they are spoken */
const WordTab: React.FC<{t: number; items: Array<[string, number]>; bg: string; fg: string; size: number; style?: React.CSSProperties}> = ({t, items, bg, fg, size, style}) => (
  <div style={{...slide(t, items[0][1], -260, 0), ...style}}>
    <Tab bg={bg} fg={fg} size={size}>
      {items.map(([w, at], i) => <span key={w + at} style={{opacity: t >= at - 0.03 ? 1 : 0.2}}>{w}{i < items.length - 1 ? ' ' : ''}</span>)}
    </Tab>
  </div>
);

// ───────── 1 · living room, late 70s ─────────
const Room: React.FC<{t: number}> = ({t}) => {
  const dive = pio(t, CUT1 - 0.42, CUT1);
  const drift = lq(1 + 0.035 * p(t, 0, CUT1 - 0.42), 1);
  return (
    <AbsoluteFill style={{background: '#C77A35', overflow: 'hidden'}}>
      <Dive q={dive} fx={473} fy={1005} s1={3.4}>
        <div style={{position: 'absolute', inset: 0, transform: `scale(${drift})`, transformOrigin: '540px 1000px'}}>
          <AbsoluteFill style={{backgroundImage: 'repeating-linear-gradient(90deg, #B8662B 0 46px, #C77A35 46px 92px)'}} />
          <AbsoluteFill style={{backgroundImage: 'radial-gradient(circle at 46px 46px, rgba(255,214,150,0.22) 0 14px, transparent 15px)', backgroundSize: '92px 92px'}} />
          <div style={{position: 'absolute', left: 0, right: 0, top: 1290, bottom: 0, background: 'linear-gradient(#5A3420, #3A2214)'}} />
          <div style={{position: 'absolute', left: 0, right: 0, top: 1280, height: 18, background: '#3A2214'}} />
          {/* wall frame */}
          <div style={{position: 'absolute', left: 790, top: 700, width: 200, height: 150, background: 'linear-gradient(#F2A65A, #D8322B)', border: '12px solid #4A2914', boxShadow: '6px 8px 0 rgba(0,0,0,0.3)'}} />
          <div style={{position: 'absolute', left: 900, top: 820}}><Lamp w={150} /></div>
          {/* TV on a cabinet */}
          <div style={{position: 'absolute', left: 170, top: 1262, width: 740, height: 150, background: 'linear-gradient(#7A4A26, #4A2914)', borderRadius: 8, boxShadow: lq('0 20px 30px rgba(0,0,0,0.4)', '0 14px 0 rgba(0,0,0,0.35)')}}>
            {[0, 1].map((i) => <div key={i} style={{position: 'absolute', left: 40 + i * 340, top: 24, width: 320, height: 100, border: '4px solid #2E1A0C', borderRadius: 6}} />)}
          </div>
          <div style={{position: 'absolute', left: 220, top: 760}}>
            <CrtTv w={640} screen={(sw, sh) => (
              <>
                <BarsPattern w={sw} h={sh} />
                <div style={{position: 'absolute', left: sw * 0.14, right: sw * 0.14, top: sh * 0.3, height: sh * 0.36, background: '#06060A', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center'}}>
                  <div style={{fontFamily: OSD, fontSize: 20, letterSpacing: 4, color: K.yellow}}>KANAL 9</div>
                  <div style={{fontFamily: HEAD, fontSize: 58, lineHeight: 1, color: K.white}}>SIARAN KHUSUS</div>
                </div>
              </>
            )} />
          </div>
          <div style={{position: 'absolute', left: -120, top: 1330}}><Sofa w={560} color="#9C4F22" /></div>
          {/* titles */}
          <WordTab t={t} items={[['AKHIR', a('akhir')], ['TAHUN', a('tahun')], ['70-AN', a('70-an')]]} bg={K.yellow} fg={K.navy} size={78} style={{position: 'absolute', left: 64, top: 236}} />
          <div style={{position: 'absolute', left: 64, top: 352, display: 'flex', gap: 30}}>
            <Chrome text="PERANG" size={196} grad={SILVER} deep={K.navy} style={slam(t, a('perang'))} />
            <Chrome text="BESAR" size={196} grad={GOLD} deep="#6A2A0A" style={slam(t, a('besar'))} />
          </div>
          <WordTab t={t} items={[['DI', a('di ruang')], ['RUANG', a('ruang')], ['TAMU', a('tamu')]]} bg={K.white} fg={K.red} size={82} style={{position: 'absolute', left: 64, top: 586}} />
        </div>
      </Dive>
    </AbsoluteFill>
  );
};

// ───────── 2 · not weapons — tapes ─────────
const Fight: React.FC<{t: number}> = ({t}) => {
  const drop = p(t, a('tapi') - 0.04, a('tapi') + 0.36, (x) => x * x);
  const inQ = p(t, a('perang', 2) - 0.12, a('perang', 2) + 0.24);
  const vs = pb(t, a('kaset') - 0.05, a('kaset') + 0.3);
  return (
    <AbsoluteFill style={{background: K.blue, overflow: 'hidden'}}>
      <AbsoluteFill style={{background: `linear-gradient(160deg, #F0584D 0%, ${K.red} 30%, #8E1B17 47%, #F4F4F4 47.4%, #F4F4F4 48.6%, #2E4CF0 49%, ${K.blue} 70%, ${K.navy} 100%)`}} />
      <Rays t={t} cx={540} cy={900} opacity={0.07} />
      {/* weapons, crossed out, then dropped */}
      {drop < 1 && (
        <div style={{position: 'absolute', inset: 0, transform: `translateY(${drop * 1100}px) rotate(${drop * 8}deg)`}}>
          <div style={{position: 'absolute', left: 240, top: 640, ...slide(t, CUT1, 0, 140, 0.3)}}><Tank w={600} color="#0A0F2E" /></div>
          <svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0, ...slam(t, a('senjata'), 1.8)}}>
            <g stroke="#F4F4F4" strokeWidth={70} strokeLinecap="round"><line x1={300} y1={560} x2={780} y2={1040} /><line x1={780} y1={560} x2={300} y2={1040} /></g>
            <g stroke={K.red} strokeWidth={44} strokeLinecap="round"><line x1={300} y1={560} x2={780} y2={1040} /><line x1={780} y1={560} x2={300} y2={1040} /></g>
          </svg>
          <WordTab t={t} items={[['BUKAN', a('bukan')], ['SENJATA', a('senjata')]]} bg={K.white} fg={K.red} size={96} style={{position: 'absolute', left: 230, top: 1130}} />
        </div>
      )}
      {/* the two tapes face off */}
      <div style={{position: 'absolute', left: lerp(-760, 64, inQ) + Math.sin(t * 2) * 6, top: 560, transform: `rotate(-8deg)`}}><BetaTape w={520} t={t} /></div>
      <div style={{position: 'absolute', left: lerp(1100, 450, inQ) - Math.sin(t * 2) * 6, top: 930, transform: `rotate(7deg)`}}><VhsTape w={566} t={t} /></div>
      {vs > 0.001 && (
        <div style={{position: 'absolute', left: 540, top: 900, transform: `translate(-50%, -50%) scale(${vs})`}}>
          <svg width={520} height={520} viewBox="-260 -260 520 520" style={{position: 'absolute', left: -260 + 130, top: -260 + 130, overflow: 'visible'}}>
            <path d={burst(14, 250, 150)} fill={K.yellow} transform={`rotate(${t * 10})`} />
          </svg>
          <Chrome text="VS" size={260} grad={RUBY} deep="#4A0806" n={12} style={{position: 'relative', width: 260, textAlign: 'center'}} />
        </div>
      )}
      <div style={{position: 'absolute', left: 64, top: 232}}>
        <Big size={150} color={K.white} deep={K.navy} style={slam(t, a('perang', 2))}>PERANG</Big>
        <div style={{display: 'flex', gap: 26, marginTop: -6}}>
          <Chrome text="KASET" size={180} grad={GOLD} deep="#6A2A0A" style={slam(t, a('kaset'))} />
          <Chrome text="VIDEO" size={180} grad={GOLD} deep="#6A2A0A" style={slam(t, a('video'))} />
        </div>
      </div>
    </AbsoluteFill>
  );
};

// ───────── 3 · corner one: Betamax ─────────
const Corner: React.FC<{t: number; red: boolean; at: number; tape: React.ReactNode; sil: React.ReactNode; tw: number; tx: number}> = ({t, red, at, tape, sil, tw, tx}) => {
  const lit = t >= at - 0.03;
  const flash = lit ? 1 - p(t, at - 0.03, at + 0.4) : 0;
  const bob = Math.sin(t * 1.8) * 8;
  return (
    <>
      <Spot x={540} y={830} w={820} k={lit ? 1 : 0.55} />
      <div style={{position: 'absolute', left: tx, top: 430 + bob, transform: `perspective(1600px) rotateY(${Math.sin(t * 1.1) * 9}deg) scale(${lit ? lerp(1.1, 1, p(t, at - 0.03, at + 0.25)) : 1})`}}>
        {lit ? tape : sil}
        {!lit && <div style={{position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: HEAD, fontSize: 220, color: red ? '#F0584D' : '#5E7DFF', opacity: 0.8}}>?</div>}
      </div>
      {flash > 0 && <div style={{position: 'absolute', left: tx - 60, top: 370, width: tw + 120, height: 500, borderRadius: '50%', background: 'radial-gradient(ellipse, rgba(255,255,255,0.9), rgba(255,255,255,0) 70%)', opacity: flash}} />}
    </>
  );
};
const Beta: React.FC<{t: number}> = ({t}) => {
  const typing = t < a('1975') - 0.03;
  return (
    <Studio bg={BG.red}>
      <Rays t={t} cx={540} cy={640} opacity={0.06} />
      <WordTab t={t} items={[['DI', a('di satu sisi')], ['SATU', a('satu sisi')], ['SISI', a('sisi')]]} bg={K.white} fg={K.red} size={80} style={{position: 'absolute', left: 64, top: 236}} />
      <Corner t={t} red at={a('betamax')} tw={600} tx={240} tape={<BetaTape w={600} t={t} />} sil={<BetaTape w={600} sil="#2A0605" />} />
      <div style={{position: 'absolute', left: 0, right: 0, top: 858, display: 'flex', justifyContent: 'center'}}>
        <Chrome text="BETAMAX" size={212} grad={SILVER} deep="#4E0806" style={slam(t, a('betamax'), 1.7)} />
      </div>
      <div style={{position: 'absolute', left: 90, top: 1112, ...slide(t, a('buatan'), -900, 0)}}>
        <StatRow label="BUATAN" accent="#8E1B17" w={900} size={84} value={<span style={{opacity: t >= a('sony') - 0.03 ? 1 : 0}}>SONY</span>} />
      </div>
      <div style={{position: 'absolute', left: 90, top: 1232, ...slide(t, a('rilis'), -900, 0)}}>
        <StatRow label="RILIS" accent="#8E1B17" w={900} size={84} value={typing
          ? <span style={{color: '#8C92B0'}}>{'19'}<span style={{opacity: Math.floor(t * 2.5) % 2 ? 1 : 0.15}}>_</span></span>
          : <span style={{display: 'inline-block', ...slam(t, a('1975'), 1.6)}}>1975</span>} />
      </div>
    </Studio>
  );
};

const Beta2: React.FC<{t: number}> = ({t}) => {
  const shrink = pio(t, a('kasetnya') - 0.05, a('ringkas') + 0.12);
  const w = lerp(660, 470, shrink);
  const tvIn = p(t, a('gambarnya') - 0.1, a('gambarnya') + 0.3);
  const split = p(t, a('lebih') - 0.05, a('lebih') + 0.3);
  return (
    <Studio bg={BG.red}>
      <div style={{position: 'absolute', left: 64, top: 236, display: 'flex', gap: 16}}>
        <Tab bg="#8E1B17" fg={K.white} size={74}>BETAMAX</Tab>
        <div style={slam(t, a('ringkas'), 1.5)}><Tab bg={K.yellow} fg={K.navy} size={74}>RINGKAS</Tab></div>
      </div>
      {/* compact: shrinks inside the dashed outline of its old size */}
      <div style={{position: 'absolute', left: 540 - 330, top: 400, width: 660, height: 412, border: '5px dashed rgba(255,230,220,0.55)', borderRadius: 30, opacity: shrink}} />
      <div style={{position: 'absolute', left: 540 - w / 2, top: 606 - (w * 200) / 640}}><BetaTape w={w} t={t} /></div>
      {shrink > 0.3 && (
        <svg width={1080} height={900} style={{position: 'absolute', left: 0, top: 0, opacity: cl((shrink - 0.3) * 2)}}>
          <g stroke={K.white} strokeWidth={8} fill={K.white}>
            <line x1={190} y1={606} x2={290} y2={606} /><path d="M 300 606 L 270 588 L 270 624 Z" />
            <line x1={890} y1={606} x2={790} y2={606} /><path d="M 780 606 L 810 588 L 810 624 Z" />
          </g>
        </svg>
      )}
      {/* sharper picture: one test card, Betamax half sharp, the other half soft */}
      <div style={{position: 'absolute', left: 230, top: 880, opacity: cl(tvIn * 4), transform: `translateY(${(1 - tvIn) * 1100}px)`}}>
        <CrtTv w={620} antenna={false} screen={(sw, sh) => (
          <>
            <TestCard w={sw} h={sh} />
            <div style={{position: 'absolute', left: sw / 2, top: 0, width: sw / 2, height: sh, overflow: 'hidden', clipPath: `inset(0 0 0 ${(1 - split) * 100}%)`}}>
              <div style={{position: 'absolute', left: -sw / 2, top: 0, filter: lq('blur(4px)', undefined), opacity: lq(1, 0.55)}}><TestCard w={sw} h={sh} /></div>
            </div>
            <div style={{position: 'absolute', left: sw / 2 - 2, top: 0, width: 4, height: sh, background: K.white, opacity: split}} />
            <div style={{position: 'absolute', left: 10, bottom: 10, fontFamily: HEAD, fontSize: 34, color: K.white, background: '#8E1B17', padding: '4px 10px 0', opacity: split}}>BETAMAX</div>
            <div style={{position: 'absolute', right: 10, bottom: 10, fontFamily: HEAD, fontSize: 34, color: K.white, background: K.blue, padding: '4px 10px 0', opacity: split}}>VHS</div>
          </>
        )} />
      </div>
      <div style={{position: 'absolute', left: 120, top: 1330, transform: 'rotate(-3deg)'}}>
        <div style={slam(t, a('tajam'), 1.5)}><Tab bg={K.yellow} fg={K.navy} size={92}>LEBIH TAJAM</Tab></div>
      </div>
      <div style={{position: 'absolute', left: 620, top: 1318, transform: 'rotate(5deg)'}}>
        <div style={slam(t, a('dianggap'), 1.4)}><Tab bg={K.white} fg={K.red} size={58}>*DIANGGAP</Tab></div>
      </div>
    </Studio>
  );
};

// ───────── 4 · corner two: VHS ─────────
const Vhs: React.FC<{t: number}> = ({t}) => (
  <Studio bg={BG.blue}>
    <Rays t={t} cx={540} cy={640} opacity={0.07} />
    <WordTab t={t} items={[['DI', a('di sisi lain')], ['SISI', a('sisi lain')], ['LAIN', a('lain')]]} bg={K.white} fg={K.blue} size={80} style={{position: 'absolute', left: 64, top: 236}} />
    <Corner t={t} red={false} at={a('vhs')} tw={680} tx={200} tape={<VhsTape w={680} t={t} />} sil={<VhsTape w={680} sil="#050A2A" />} />
    <div style={{position: 'absolute', left: 0, right: 0, top: 836, display: 'flex', justifyContent: 'center'}}>
      <Chrome text="VHS" size={250} grad={GOLD} deep="#6A2A0A" style={slam(t, a('vhs'), 1.7)} />
    </div>
    <div style={{position: 'absolute', left: 90, top: 1112, ...slide(t, a('dari'), 900, 0)}}>
      <StatRow label="DARI" accent={K.navy} w={900} size={84} value={<span style={{opacity: t >= a('jvc') - 0.03 ? 1 : 0}}>JVC</span>} />
    </div>
    <div style={{position: 'absolute', left: 90, top: 1232, ...slide(t, a('menyusul'), 900, 0)}}>
      <StatRow label="RILIS" accent={K.navy} w={900} size={84} value={t < a('setahun') - 0.03 ? <span style={{color: '#8C92B0'}}>MENYUSUL…</span> : <span style={{display: 'inline-block', ...slam(t, a('setahun'), 1.4)}}>SETAHUN KEMUDIAN</span>} />
    </div>
    <div style={{position: 'absolute', left: 700, top: 1040, transform: 'rotate(8deg)'}}>
      <div style={slam(t, a('kemudian'), 1.6)}><Tab bg={K.red} fg={K.white} size={64}>+1 TAHUN</Tab></div>
    </div>
  </Studio>
);

// ───────── 5 · instant replay: "Betamax is better" → but VHS won → why? ─────────
const FANS = [
  {x: 40, y: 1120, shirt: '#2FA39A', kind: 0, at: a('banyak'), say: 'BETAMAX!', bx: 30, by: 930},
  {x: 800, y: 1150, shirt: '#E07A2E', kind: 1, at: a('bilang'), say: 'LEBIH TAJAM!', bx: 600, by: 960},
  {x: 430, y: 1210, shirt: '#7A3FB0', kind: 2, at: a('unggul'), say: 'LEBIH UNGGUL!', bx: 300, by: 1040},
];
const Replay: React.FC<{t: number}> = ({t}) => (
  <Studio bg={BG.red}>
    <Rays t={t} cx={540} cy={700} opacity={0.06} />
    <div style={{position: 'absolute', left: 64, top: 236, display: 'flex', gap: 16}}>
      <Tab bg={K.yellow} fg={K.navy} size={70}>ULANGAN</Tab>
      <WordTab t={t} items={[['BANYAK', a('banyak')], ['YANG', a('yang bilang')], ['BILANG', a('bilang')]]} bg={K.white} fg={K.red} size={70} />
    </div>
    <Spot x={540} y={880} w={760} />
    {/* podium */}
    <div style={{position: 'absolute', left: 300, top: 820, width: 480, height: 200, background: 'linear-gradient(#F4F4F4, #B9BEC9)', boxShadow: '12px 12px 0 rgba(0,0,0,0.35)', display: 'flex', justifyContent: 'center'}}>
      <div style={{fontFamily: HEAD, fontSize: 170, lineHeight: 1.15, color: K.red}}>1</div>
    </div>
    <div style={{position: 'absolute', left: 290, top: 500 + Math.sin(t * 2) * 6}}><BetaTape w={500} t={t} /></div>
    <div style={{position: 'absolute', left: 700, top: 380, transform: 'rotate(12deg)', ...slam(t, a('unggul'), 1.8)}}><Rosette w={190} text="UNGGUL" /></div>
    {FANS.map((f, i) => (
      <React.Fragment key={i}>
        <div style={{position: 'absolute', left: f.x, top: f.y, ...slide(t, f.at - 0.2, 0, 300, 0.35)}}><Person w={240} shirt={f.shirt} kind={f.kind} /></div>
        <div style={{position: 'absolute', left: f.bx, top: f.by, ...slam(t, f.at, 1.4)}}>
          <div style={{background: K.white, color: K.navy, fontFamily: HEAD, fontSize: 64, lineHeight: 1, padding: '14px 24px 4px', borderRadius: 18, boxShadow: '8px 8px 0 rgba(0,0,0,0.35)', whiteSpace: 'nowrap'}}>{f.say}</div>
        </div>
      </React.Fragment>
    ))}
  </Studio>
);

const Champ: React.FC<{t: number}> = ({t}) => {
  const rise = pb(t, CUT2 - 0.02, a('vhs', 1) + 0.12);
  const why = p(t, a('kenapa') - 0.06, a('kenapa') + 0.2);
  return (
    <Studio bg={BG.blue}>
      <Rays t={t} cx={540} cy={760} opacity={0.09} color={K.yellow} />
      <div style={{position: 'absolute', left: 64, top: 236, display: 'flex', gap: 16}}>
        <div style={slam(t, a('tapi justru'), 1.4)}><Tab bg={K.red} fg={K.white} size={86}>TAPI</Tab></div>
        <div style={slam(t, a('justru'), 1.4)}><Tab bg={K.white} fg={K.navy} size={86}>JUSTRU</Tab></div>
      </div>
      {/* loser, small and dim */}
      <div style={{position: 'absolute', left: 70, top: 1150, width: 300, height: 120, background: 'linear-gradient(#9AA0B4, #6C7290)'}} />
      <div style={{position: 'absolute', left: 90, top: 990, filter: lq('saturate(0.4) brightness(0.75)', undefined), opacity: lq(1, 0.6)}}><BetaTape w={260} t={t * 0.2} /></div>
      {/* winner podium */}
      <div style={{position: 'absolute', left: 390, top: 1040, width: 560, height: 300, background: 'linear-gradient(#FFF3B0, #F6D64A 40%, #B9811C)', boxShadow: '14px 14px 0 rgba(0,0,0,0.35)', display: 'flex', justifyContent: 'center'}}>
        <div style={{fontFamily: HEAD, fontSize: 210, lineHeight: 1.2, color: '#6A4206'}}>1</div>
      </div>
      <div style={{position: 'absolute', left: 380, top: lerp(1500, 640, rise), opacity: cl(rise * 4)}}><VhsTape w={580} t={t} /></div>
      <div style={{position: 'absolute', left: 390, top: 900, ...slam(t, a('menang'), 1.9)}}><Belt w={560} /></div>
      <Confetti t={t} at={a('menang')} />
      <div style={{position: 'absolute', left: 0, right: 0, top: 430, display: 'flex', justifyContent: 'center', ...slam(t, a('vhs', 1), 1.6)}}>
        <Big size={150} color={K.yellow} deep="#6A4206">VHS MENANG</Big>
      </div>
      {why > 0 && <AbsoluteFill style={{background: 'rgba(5,7,26,0.62)', opacity: why}} />}
      {why > 0 && (
        <div style={{position: 'absolute', left: 0, right: 0, top: 640, display: 'flex', justifyContent: 'center', ...slam(t, a('kenapa'), 1.8)}}>
          <Big size={330} color={K.yellow} deep="#7A5A06" n={14}>KENAPA?</Big>
        </div>
      )}
    </Studio>
  );
};

// ───────── rounds ─────────
const RoundTitle: React.FC<{t: number; at: number; n: number; sub: string; subAt: number}> = ({t, at, n, sub, subAt}) => {
  const q = pio(t, at + 0.62, at + 0.98);
  const x = lerp(160, 64, q), y = lerp(560, 226, q), s = lerp(1, 0.34, q);
  return (
    <div style={{position: 'absolute', left: 0, top: 0, width: 760, transformOrigin: '0 0', transform: `translate(${x}px, ${y}px) scale(${s})`, zIndex: 30}}>
      {q < 1 && (
        <svg width={760} height={760} viewBox="-380 -380 760 760" style={{position: 'absolute', left: 0, top: -170, opacity: 1 - q, overflow: 'visible'}}>
          <path d={burst(16, 380, 240)} fill={K.yellow} transform={`rotate(${t * 8}) scale(${pb(t, at - 0.05, at + 0.3)})`} />
        </svg>
      )}
      <div style={{position: 'relative', display: 'flex', flexDirection: 'column', alignItems: 'center'}}>
        <Chrome text={`RONDE ${n}`} size={230} grad={GOLD} deep="#6A2A0A" style={slam(t, at, 1.6)} />
        <Big size={150} color={K.white} deep={K.navy} style={{marginTop: -6, ...slam(t, subAt, 1.5)}}>{sub}</Big>
      </div>
    </div>
  );
};
const roundBody = (t: number, at: number) => p(t, at + 0.7, at + 1.05);
const Score: React.FC<{t: number}> = ({t}) => {
  const vis = p(t, R1 + 0.8, R1 + 1.1) * (1 - p(t, OUT0 - 0.25, OUT0));
  if (vis <= 0) return null;
  const n = SC.filter((s) => t >= s).length;
  const last = SC.filter((s) => t >= s).pop();
  const bump = last !== undefined ? 1 + 0.3 * (1 - p(t, last, last + 0.35)) : 1;
  const cell = (bg: string, name: string, v: number, k = 1) => (
    <div style={{display: 'flex', alignItems: 'center', background: bg, padding: '10px 18px 2px', gap: 14, fontFamily: HEAD, fontSize: 56, lineHeight: 1, color: K.white}}>
      <span>{name}</span>
      <span style={{display: 'inline-block', minWidth: 46, textAlign: 'center', background: K.white, color: K.navy, padding: '4px 6px 0', transform: `scale(${k})`}}>{v}</span>
    </div>
  );
  return (
    <div style={{position: 'absolute', right: 64, top: 236, display: 'flex', boxShadow: '8px 8px 0 rgba(0,0,0,0.45)', borderTop: '3px solid rgba(255,255,255,0.5)', opacity: vis, transform: `translateX(${(1 - vis) * 300}px)`, zIndex: 31}}>
      {cell('#B8241E', 'BETA', 0)}
      {cell(K.blue, 'VHS', n, bump)}
    </div>
  );
};

/** round 1 — recording time: 1 hour vs 2 hours = one whole film */
const Track: React.FC<{y: number; fill: number; color: string; label: string; labelAt: number; t: number}> = ({y, fill, color, label, labelAt, t}) => {
  const x0 = 330, len = 600;
  return (
    <>
      <div style={{position: 'absolute', left: x0, top: y, width: len, height: 96, background: '#0A0F2E', boxShadow: 'inset 0 6px 0 rgba(0,0,0,0.5), 8px 8px 0 rgba(0,0,0,0.35)', border: '4px solid #F4F4F4'}} />
      <div style={{position: 'absolute', left: x0 + 4, top: y + 4, width: Math.max(0, (len - 8) * fill), height: 88, background: `linear-gradient(rgba(255,255,255,0.35), rgba(255,255,255,0) 45%, rgba(0,0,0,0.2)), ${color}`}} />
      {[0, 0.5, 1].map((k, i) => (
        <React.Fragment key={i}>
          <div style={{position: 'absolute', left: x0 + len * k - 2, top: y - 18, width: 4, height: 132, background: '#F4F4F4', opacity: 0.8}} />
          <div style={{position: 'absolute', left: x0 + len * k - 60, width: 120, top: y - 64, textAlign: 'center', fontFamily: HEAD, fontSize: 40, color: '#C9D4FF'}}>{['0', '1 JAM', '2 JAM'][i]}</div>
        </React.Fragment>
      ))}
      <div style={{position: 'absolute', left: x0 + 4 + (len - 8) * fill - 190, width: 180, top: y + 12, textAlign: 'right', fontFamily: HEAD, fontSize: 76, lineHeight: 1, color: K.navy, ...slam(t, labelAt, 1.6)}}>{label}</div>
    </>
  );
};
const Round1: React.FC<{t: number}> = ({t}) => {
  const body = roundBody(t, R1);
  const fb = p(t, a('betamax', 2), a('satu jam'), (x) => x) * 0.5;
  const fv = p(t, a('vhs', 2), a('dua'), (x) => x);
  const film = p(t, a('cukup') - 0.05, a('cukup') + 0.4);
  return (
    <Studio bg={BG.blue}>
      <RoundTitle t={t} at={R1} n={1} sub="DURASI" subAt={a('durasi')} />
      <div style={{position: 'absolute', inset: 0, opacity: body, transform: `translateY(${(1 - body) * 60}px)`}}>
        <div style={{position: 'absolute', left: 54, top: 530}}><BetaTape w={250} t={t} /></div>
        <div style={{position: 'absolute', left: 74, top: 704, ...slam(t, a('awalnya'), 1.4)}}><Tab bg={K.white} fg={K.red} size={48}>AWALNYA</Tab></div>
        <Track t={t} y={560} fill={fb} color="#E2413A" label="1 JAM" labelAt={a('satu jam')} />
        <div style={{position: 'absolute', left: 54, top: 880}}><VhsTape w={260} t={t} /></div>
        <Track t={t} y={910} fill={fv} color={K.yellow} label="2 JAM" labelAt={a('dua')} />
        {/* one whole film fits the two-hour tape (dashed slot waits for it) */}
        <div style={{position: 'absolute', left: 330, top: 1100, width: 600, height: 120, border: '5px dashed rgba(201,212,255,0.6)', boxSizing: 'border-box', opacity: 1 - film,
          display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: HEAD, fontSize: 70, color: 'rgba(201,212,255,0.7)'}}>? FILM</div>
        <div style={{position: 'absolute', left: 330, top: 1100, opacity: cl(film * 3), transform: `translateX(${(1 - film) * 700}px)`}}><FilmStrip w={600} h={120} frames={9} seed={4} /></div>
        <svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0, opacity: film}}>
          <path d="M 330 1238 L 330 1260 L 930 1260 L 930 1238" stroke="#F4F4F4" strokeWidth={6} fill="none" />
          {/* the same film over the one-hour tape: runs past the end of the recording */}
          <rect x={334} y={690} width={592} height={40} fill="none" stroke="#F4F4F4" strokeWidth={4} strokeDasharray="14 10" opacity={0.7} />
        </svg>
        <div style={{position: 'absolute', left: 360, top: 1290, display: 'flex', alignItems: 'center', gap: 16, ...slam(t, a('utuh'), 1.5)}}>
          <Mark w={84} />
          <Tab bg={K.yellow} fg={K.navy} size={80}>1 FILM UTUH</Tab>
        </div>
      </div>
      <Score t={t} />
    </Studio>
  );
};

/** round 2 — JVC licenses VHS to many factories → many players, competitive prices */
const FACT = [{x: 50, y: 860}, {x: 400, y: 900}, {x: 750, y: 860}, {x: 120, y: 1130}, {x: 470, y: 1160}, {x: 790, y: 1120}];
const PLAYERS = ['#26262E', '#B9BEC9', '#CDB88E', '#3A3F52', '#1C1C22', '#D9DCE4', '#5A2A24', '#26262E'];
const Round2: React.FC<{t: number}> = ({t}) => {
  const R = ROLL2[1];
  const body = roundBody(t, R);
  const pan = pio(t, a('pilihan') - 0.3, a('pilihan') + 0.15);
  return (
    <Studio bg={BG.blue}>
      <RoundTitle t={t} at={R} n={2} sub="LISENSI" subAt={a('lisensi')} />
      <div style={{position: 'absolute', inset: 0, opacity: body}}>
        <div style={{position: 'absolute', inset: 0, transform: `translateY(${-pan * 1050}px)`}}>
          <div style={{position: 'absolute', inset: 0, opacity: cl(1 - pan * 1.6)}}>
          {/* JVC head office */}
          <div style={{position: 'absolute', left: 380, top: 420, ...slide(t, a('jvc', 1), 0, 200)}}>
            <div style={{width: 320, height: 330, background: 'linear-gradient(#2E4CF0, #142A9C)', boxShadow: '12px 12px 0 rgba(0,0,0,0.35)', position: 'relative'}}>
              {Array.from({length: 12}, (_, i) => <div key={i} style={{position: 'absolute', left: 30 + (i % 4) * 70, top: 110 + Math.floor(i / 4) * 66, width: 46, height: 40, background: '#F6D64A', opacity: 0.85}} />)}
              <div style={{position: 'absolute', left: 30, right: 30, top: 22, height: 70, background: K.white, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: HEAD, fontSize: 70, color: K.navy, paddingTop: 6}}>JVC</div>
            </div>
          </div>
          {/* licences flying out to the factories */}
          {FACT.map((f, i) => (
            <div key={i} style={{position: 'absolute', left: f.x, top: f.y, ...slam(t, a('ke banyak') + i * 0.09, 1.4)}}><Factory w={240} t={t} color={['#2A3A8C', '#3A2A7C', '#1F4E8C'][i % 3]} /></div>
          ))}
          {FACT.map((f, i) => {
            const s = a('membagikan') + i * 0.16;
            const q = pio(t, s + 0.2, s + 1.2);
            if (t < s) return null;
            const x = lerp(510, f.x + 70, q), y = lerp(560, f.y - 40, q) - Math.sin(q * Math.PI) * 180;
            return <div key={`d${i}`} style={{position: 'absolute', left: x, top: y, transform: `rotate(${lerp(-10, 8, q) + i * 3}deg) scale(${lerp(0.7, 1, p(t, s, s + 0.2))})`}}><LicenseDoc w={100} /></div>;
          })}
          <div style={{position: 'absolute', left: 64, top: 770, ...slam(t, a('lisensi'), 1.4)}}><Tab bg={K.yellow} fg={K.navy} size={60}>LISENSI VHS</Tab></div>
          <div style={{position: 'absolute', left: 560, top: 770, ...slam(t, a('banyak pabrik'), 1.4)}}><Tab bg={K.white} fg={K.navy} size={60}>BANYAK PABRIK</Tab></div>
          </div>
          {/* the showroom below */}
          {PLAYERS.map((c, i) => {
            const col = i % 2, row = Math.floor(i / 2);
            const at = a('pemutarnya') + i * 0.08;
            const tag = a('harganya') + i * 0.06;
            return (
              <div key={i} style={{position: 'absolute', left: 64 + col * 490, top: 1450 + row * 182, ...slam(t, at, 1.3)}}>
                <Vcr w={420} body={c} accent={[K.red, K.yellow, '#2FA39A', '#3A5CF7'][i % 4]} label="VHS" readout={['12:00', '0:00', 'PLAY', '12:00'][i % 4]} led={i % 3 ? '#FF3B2F' : '#3BFF7A'} />
                {t >= tag - 0.04 && (
                  <div style={{position: 'absolute', left: 330, top: -40, transform: `rotate(${Math.sin((t - tag) * 7) * 14 * Math.max(0, 1 - (t - tag) / 1.2)}deg)`, transformOrigin: '50% 0', ...slide(t, tag, 0, -120, 0.25)}}>
                    <PriceTag w={74} color={[K.yellow, K.white, '#FF9D4A'][i % 3]} />
                  </div>
                )}
              </div>
            );
          })}
        </div>
        <div style={{position: 'absolute', left: 64, top: 1150, display: 'flex', gap: 16, opacity: pan}}>
          <div style={slam(t, a('banyak dan'), 1.4)}><Tab bg={K.yellow} fg={K.navy} size={80}>PILIHAN BANYAK</Tab></div>
        </div>
        <div style={{position: 'absolute', left: 300, top: 1268, transform: 'rotate(-3deg)', opacity: pan}}>
          <div style={slam(t, a('bersaing'), 1.5)}><Tab bg={K.red} fg={K.white} size={96}>HARGA BERSAING</Tab></div>
        </div>
      </div>
      <Score t={t} />
    </Studio>
  );
};

/** round 3 — video rental: shelves full of VHS films; people buy the player with the most films */
const STORE_IN = a('toko-toko') - 0.06;
const COUNTER = a('dan orang') - 0.12;
const Round3: React.FC<{t: number}> = ({t}) => {
  const R = PUSH2[1];
  const body = roundBody(t, R);
  const dive = pio(t, STORE_IN - 0.4, STORE_IN);
  const inside = t >= STORE_IN;
  const settle = 1 - pio(t, STORE_IN, STORE_IN + 0.45);
  const pan = pio(t, COUNTER - 0.25, COUNTER + 0.2);
  const neon = p(t, a('rental') - 0.05, a('rental') + 0.3);
  const stacks = p(t, COUNTER + 0.15, a('filmnya') + 0.35);
  return (
    <Studio bg={inside ? BG.navy : 'linear-gradient(#1A1030 0%, #3A1A3A 45%, #6A2A2A 100%)'} stripes={false}>
      <RoundTitle t={t} at={R} n={3} sub="RENTAL VIDEO" subAt={a('rental')} />
      <div style={{position: 'absolute', inset: 0, opacity: body}}>
        {!inside ? (
          <Dive q={dive} fx={540} fy={1060} s1={3.2}>
            {/* storefront */}
            <div style={{position: 'absolute', left: 80, top: 520, width: 920, height: 780, background: 'linear-gradient(#5A3A6A, #3A2448)', boxShadow: lq('0 30px 60px rgba(0,0,0,0.5)', '0 24px 0 rgba(0,0,0,0.4)')}} />
            <div style={{position: 'absolute', left: 120, top: 560, width: 840, height: 150, background: '#140A1E', border: '6px solid #2A1A3A', display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
              <div style={{fontFamily: HEAD, fontSize: 128, lineHeight: 1, paddingTop: 10, color: lerp(0, 1, neon) > 0.5 ? '#FFE3F4' : '#5A3A5A',
                textShadow: lq(`0 0 ${12 * neon}px #FF4FB0, 0 0 ${30 * neon}px #FF4FB0, 0 0 ${60 * neon}px rgba(255,79,176,0.7)`, neon > 0.5 ? '0 0 0 #FF4FB0, 3px 0 0 #FF4FB0, -3px 0 0 #FF4FB0, 0 3px 0 #FF4FB0, 0 -3px 0 #FF4FB0, 6px 6px 0 rgba(255,79,176,0.45)' : 'none')}}>RENTAL VIDEO</div>
            </div>
            <svg width={1080} height={120} style={{position: 'absolute', left: 0, top: 716}}>
              {Array.from({length: 12}, (_, i) => <path key={i} d={`M ${100 + i * 73.3} 0 L ${173 + i * 73.3} 0 L ${173 + i * 73.3} 70 Q ${136 + i * 73.3} 100 ${100 + i * 73.3} 70 Z`} fill={i % 2 ? K.white : K.red} />)}
            </svg>
            {[0, 1].map((side) => (
              <div key={side} style={{position: 'absolute', left: side ? 660 : 130, top: 850, width: 290, height: 330, background: '#0E1430', border: '8px solid #2A1A3A', overflow: 'hidden'}}>
                {[0, 1].map((r) => (
                  <div key={r} style={{position: 'absolute', left: 8, top: 18 + r * 156, display: 'flex', gap: 3, alignItems: 'flex-end'}}>
                    {Array.from({length: 8}, (_, i) => <Spine key={i} h={130} seed={side * 50 + r * 20 + i} />)}
                  </div>
                ))}
              </div>
            ))}
            <div style={{position: 'absolute', left: 460, top: 900, width: 160, height: 400, background: '#0A0610', border: '8px solid #2A1A3A'}}>
              <div style={{position: 'absolute', left: 16, right: 16, top: 30, height: 150, background: 'rgba(255,214,120,0.25)'}} />
            </div>
          </Dive>
        ) : (
          <div style={{position: 'absolute', inset: 0, transformOrigin: '540px 900px', transform: `scale(${1 + settle * 0.3}) translateY(${-pan * 920}px)`}}>
            {/* shelves filling with VHS films */}
            <div style={{position: 'absolute', inset: 0, opacity: cl(1 - pan * 1.5)}}>
            {[0, 1, 2].map((r) => (
              <React.Fragment key={r}>
                <div style={{position: 'absolute', left: 40, top: 640 + r * 270, width: 1000, height: 24, background: 'linear-gradient(#93603A, #4A2914)', boxShadow: '0 10px 0 rgba(0,0,0,0.35)'}} />
                <div style={{position: 'absolute', left: 60, top: 640 + r * 270 - 222, display: 'flex', gap: 4, alignItems: 'flex-end'}}>
                  {Array.from({length: 18}, (_, i) => {
                    const at = STORE_IN + 0.12 + (r * 18 + i) * 0.034;
                    const q = pb(t, at, at + 0.18);
                    return <div key={i} style={{opacity: cl(q * 3), transform: `translateY(${(1 - q) * -60}px)`}}><Spine h={216} seed={r * 31 + i * 1.7} /></div>;
                  })}
                </div>
              </React.Fragment>
            ))}
            <div style={{position: 'absolute', left: 0, right: 0, top: 1210, display: 'flex', justifyContent: 'center', ...slam(t, a('film vhs'), 1.5)}}>
              <Tab bg={K.yellow} fg={K.navy} size={110}>RAK PENUH FILM VHS</Tab>
            </div>
            </div>
            {/* the counter */}
            <div style={{position: 'absolute', left: 0, right: 0, top: 1880, height: 900, background: 'linear-gradient(#2A3552, #151B2E)'}} />
            <div style={{position: 'absolute', left: 40, top: 2120, width: 1000, height: 60, background: 'linear-gradient(#93603A, #4A2914)', boxShadow: '0 14px 0 rgba(0,0,0,0.35)'}} />
            {/* film stacks on the counter, behind each player */}
            {[0, 1].map((i) => <div key={`b${i}`} style={{position: 'absolute', left: 170, top: 2120 - 125 - i * 105, opacity: cl(stacks * 3 - i), transform: `rotate(${(rnd(i + 7) - 0.5) * 5}deg)`}}><BetaTape w={200} /></div>)}
            {Array.from({length: 7}, (_, i) => <div key={`v${i}`} style={{position: 'absolute', left: 690, top: 2120 - 127 - i * 100, opacity: cl(stacks * 8 - i), transform: `rotate(${(rnd(i) - 0.5) * 6}deg)`}}><VhsTape w={230} accent={[K.red, K.yellow, '#2FA39A', '#3A5CF7'][i % 4]} label="FILM" /></div>)}
            <div style={{position: 'absolute', left: 70, top: 2010}}><Vcr w={400} label="BETAMAX" body="#3A3F52" accent="#E07A2E" readout="0:00" /></div>
            <div style={{position: 'absolute', left: 600, top: 2010}}><Vcr w={410} label="VHS" accent={K.red} readout="PLAY" led="#3BFF7A" /></div>
            <div style={{position: 'absolute', left: 380, top: 2190, ...slide(t, COUNTER, 0, 300, 0.4)}}><Person w={300} shirt="#2FA39A" kind={1} /></div>
            <div style={{position: 'absolute', left: 780, top: 2200, ...slam(t, a('paling banyak'), 1.8)}}><Mark w={130} /></div>
          </div>
        )}
        {inside && pan > 0.5 && (
          <div style={{position: 'absolute', left: 64, top: 1300, opacity: cl((pan - 0.5) * 2)}}>
            <div style={slam(t, a('paling banyak'), 1.5)}><Tab bg={K.yellow} fg={K.navy} size={84}>FILM PALING BANYAK</Tab></div>
          </div>
        )}
      </div>
      <Score t={t} />
    </Studio>
  );
};

// ───────── 6 · Betamax pushed out ─────────
const Out: React.FC<{t: number}> = ({t}) => {
  const push = pio(t, CUT4 + 0.05, a('tersingkir') + 0.5);
  const tip = p(t, a('tersingkir') + 0.25, a('tersingkir') + 1.05, (x) => x * x);
  const bx = lerp(380, 70, push);
  return (
    <Studio bg={BG.slate}>
      <Spot x={lerp(540, 300, push)} y={1010} w={700} k={1 - tip * 0.6} />
      <div style={{position: 'absolute', left: 0, right: 0, top: 236, display: 'flex', justifyContent: 'center', gap: 22}}>
        <Big size={150} color={K.white} deep={K.navy} style={slam(t, a('pelan-pelan'), 1.4)}>PELAN-PELAN</Big>
      </div>
      <div style={{position: 'absolute', left: 0, right: 0, top: 400, display: 'flex', justifyContent: 'center'}}>
        <Chrome text="TERSINGKIR" size={190} grad={RUBY} deep="#4A0806" style={slam(t, a('tersingkir'), 1.5)} />
      </div>
      {/* the shelf */}
      <div style={{position: 'absolute', left: 150, top: 1012, width: 960, height: 30, background: 'linear-gradient(#93603A, #4A2914)', boxShadow: '0 12px 0 rgba(0,0,0,0.35)'}} />
      <div style={{position: 'absolute', left: bx, top: 1012 - 186 + tip * 700, transformOrigin: '0% 100%', transform: `rotate(${-tip * 70}deg)`, filter: lq(`saturate(${1 - push * 0.5})`, undefined)}}>
        <BetaTape w={300} t={t * (1 - push)} />
      </div>
      {[0, 1, 2, 3].map((i) => (
        <div key={i} style={{position: 'absolute', left: bx + 310 + i * 250, top: 1012 - 170, transform: `rotate(${(rnd(i + 3) - 0.5) * 3}deg)`}}>
          <VhsTape w={240} t={t} accent={[K.red, K.yellow, '#2FA39A', '#3A5CF7'][i]} />
        </div>
      ))}
      <div style={{position: 'absolute', left: 0, right: 0, top: 1120, display: 'flex', justifyContent: 'center', gap: 20, opacity: push}}>
        {Array.from({length: 5}, (_, i) => <div key={i} style={{opacity: cl(push * 5 - i)}}><Person w={130} shirt={['#2FA39A', '#E07A2E', '#7A3FB0', '#D8322B', '#3A5CF7'][i]} kind={i} /></div>)}
      </div>
    </Studio>
  );
};

// ───────── 7 · the factory line stops; fast-forward to 2002 ─────────
const Line: React.FC<{t: number}> = ({t}) => {
  const stopAt = a('berhenti');
  // conveyor position: constant speed, then eased stop over 0.6 s
  const v = 260;
  const run = t < stopAt ? (t - CUT5) * v : (stopAt - CUT5) * v + v * 0.3 * p(t, stopAt, stopAt + 0.6) * 1.0;
  const ffQ = cl((t - FF[0]) / (FF[1] - FF[0]));
  const steps = Math.ceil((FF[1] - FF[0]) * 20);
  const yr = t < FF[0] ? 1976 : t >= FF[1] ? 2002 : Math.round(lerp(1976, 2002, Math.min(1, Math.floor(ffQ * steps + 1) / steps)));
  const lampRed = t >= stopAt;
  return (
    <Studio bg={BG.navy}>
      <AbsoluteFill style={{backgroundImage: 'linear-gradient(rgba(120,150,255,0.08) 2px, transparent 2px), linear-gradient(90deg, rgba(120,150,255,0.08) 2px, transparent 2px)', backgroundSize: '90px 90px'}} />
      {/* maker sign + lamp */}
      <div style={{position: 'absolute', left: 64, top: 236, display: 'flex', gap: 16, alignItems: 'center', ...slide(t, a('sony', 1), -400, 0)}}>
        <div style={{background: '#06060A', border: '5px solid #F4F4F4', padding: '12px 30px 2px', fontFamily: HEAD, fontSize: 84, lineHeight: 1, color: K.white, boxShadow: '8px 8px 0 rgba(0,0,0,0.45)'}}>SONY</div>
        <Tab bg={K.white} fg={K.navy} size={58}>PEMUTAR BETAMAX</Tab>
      </div>
      <div style={{position: 'absolute', left: 860, top: 370, width: 110, height: 110, borderRadius: '50%', background: lampRed ? 'radial-gradient(circle, #FF8A7A, #D8322B 60%, #6A0A08)' : 'radial-gradient(circle, #9AFFB8, #2FA36A 60%, #0A3A20)',
        boxShadow: lq(lampRed ? '0 0 50px rgba(255,60,40,0.8)' : '0 0 30px rgba(60,255,120,0.5)', lampRed ? '0 0 0 14px rgba(255,60,40,0.35)' : '0 0 0 10px rgba(60,255,120,0.25)'), border: '6px solid #1A1A22'}} />
      {/* year board */}
      <div style={{position: 'absolute', left: 140, top: 480, width: 800, height: 290, background: '#06080C', border: '8px solid #2A2F45', boxShadow: '12px 12px 0 rgba(0,0,0,0.4)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center'}}>
        <div style={{fontFamily: OSD, fontSize: 40, letterSpacing: 8, color: '#7CFFB0', opacity: 0.85}}>TAHUN</div>
        <div style={{position: 'relative', ...(t >= FF[1] ? slam(t, a('2002'), 1.5) : {})}}>
          {t >= FF[1] ? <Chrome text="2002" size={200} grad={GOLD} deep="#6A2A0A" n={10} /> : <div style={{fontFamily: OSD, fontSize: 190, lineHeight: 1, color: '#7CFFB0', textShadow: lq('0 0 18px rgba(124,255,176,0.7)', '3px 3px 0 rgba(20,90,50,0.8)')}}>{yr}</div>}
        </div>
      </div>
      {/* conveyor with Betamax players */}
      <div style={{position: 'absolute', left: 0, right: 0, top: 1190, height: 60, background: 'repeating-linear-gradient(90deg, #2A2F45 0 40px, #3A4060 40px 80px)', backgroundPosition: `${run}px 0`, borderTop: '6px solid #6C7290', borderBottom: '6px solid #14182A'}} />
      {Array.from({length: 7}, (_, i) => <div key={i} style={{position: 'absolute', left: 30 + i * 150, top: 1262, width: 40, height: 40, borderRadius: '50%', background: '#14182A', border: '5px solid #6C7290'}} />)}
      {Array.from({length: 5}, (_, i) => {
        const x = (((i * 300 + run) % 1500) + 1500) % 1500 - 380;
        return <div key={i} style={{position: 'absolute', left: x, top: 1086}}><Vcr w={360} label="BETAMAX" body="#3A3F52" accent="#E07A2E" readout={lampRed ? '-:--' : '0:00'} led={lampRed ? '#FF3B2F' : '#3BFF7A'} /></div>;
      })}
      <div style={{position: 'absolute', left: 120, top: 860, transform: 'rotate(-6deg)'}}>
        <div style={slam(t, stopAt, 1.7)}><Tab bg={K.red} fg={K.white} size={120}>■ BERHENTI</Tab></div>
      </div>
    </Studio>
  );
};

// ───────── 8 · the lesson ─────────
const Lesson: React.FC<{t: number}> = ({t}) => (
  <Studio bg={BG.navy}>
    <Rays t={t} cx={540} cy={820} opacity={0.05} />
    <div style={{position: 'absolute', left: 0, right: 0, top: 240, display: 'flex', justifyContent: 'center'}}>
      <Chrome text="PELAJARANNYA?" size={168} grad={SILVER} deep={K.navy} style={slam(t, a('pelajarannya'), 1.5)} />
    </div>
    <WordTab t={t} items={[['YANG', a('yang paling bagus')], ['PALING', a('paling bagus')], ['BAGUS', a('bagus')]]} bg={K.yellow} fg={K.navy} size={84} style={{position: 'absolute', left: 64, top: 470}} />
    <Spot x={540} y={1060} w={760} />
    <div style={{position: 'absolute', left: 240, top: 700 + Math.sin(t * 1.6) * 6}}><BetaTape w={600} t={t} /></div>
    <div style={{position: 'absolute', left: 740, top: 560, transform: 'rotate(10deg)', ...slam(t, a('bagus'), 1.8)}}><Rosette w={220} text="BAGUS" /></div>
    <div style={{position: 'absolute', left: 120, top: 1090, transform: 'rotate(-6deg)', ...slam(t, a('belum'), 1.6)}}>
      <div style={{border: `10px solid ${K.red}`, padding: '18px 34px 6px', background: 'rgba(244,244,244,0.92)', boxShadow: '10px 10px 0 rgba(0,0,0,0.4)'}}>
        <div style={{fontFamily: HEAD, fontSize: 110, lineHeight: 0.95, color: K.red, whiteSpace: 'nowrap'}}>BELUM TENTU</div>
        <div style={{fontFamily: HEAD, fontSize: 150, lineHeight: 0.95, color: K.red, ...slam(t, a('menang', 1), 1.5)}}>MENANG</div>
      </div>
    </div>
  </Studio>
);

// ───────── 9 · who wins: easiest to use, most friends ─────────
const FRIENDS = [{x: 40, y: 430, k: 0, s: '#2FA39A'}, {x: 860, y: 420, k: 1, s: '#E07A2E'}, {x: 30, y: 700, k: 2, s: '#7A3FB0'}, {x: 880, y: 690, k: 0, s: K.red}, {x: 210, y: 300, k: 1, s: K.yellow}, {x: 700, y: 290, k: 2, s: '#3A5CF7'}];
const Win: React.FC<{t: number}> = ({t}) => {
  const fr = a('banyak temannya');
  const endQ = p(t, CAP_END, CAP_END + 0.3);
  const strapQ = p(t, C.duration + 0.02, C.duration + 0.4);
  return (
    <Studio bg={BG.blue}>
      <Rays t={t} cx={540} cy={560} opacity={0.09} color={K.yellow} />
      <Confetti t={t} at={a('menang', 2)} n={36} />
      <WordTab t={t} items={[['YANG', a('yang menang', 1)], ['MENANG', a('menang', 2)]]} bg={K.yellow} fg={K.navy} size={84} style={{position: 'absolute', left: 64, top: 236}} />
      {FRIENDS.map((f, i) => (
        <div key={i} style={{position: 'absolute', left: f.x, top: f.y, ...slam(t, fr - 0.1 + i * 0.07, 1.5)}}><Person w={170} shirt={f.s} kind={f.k} /></div>
      ))}
      <div style={{position: 'absolute', left: 240, top: 400 + Math.sin(t * 1.7) * 6, ...slam(t, a('yang menang', 1), 1.4)}}><VhsTape w={600} t={t} /></div>
      <div style={{position: 'absolute', left: 240, top: 660, ...slam(t, a('menang', 2), 1.8)}}><Belt w={600} /></div>
      <div style={{position: 'absolute', left: 64, top: 890, ...slam(t, a('sering'), 1.3)}}><Tab bg={K.white} fg={K.navy} size={60}>SERING KALI…</Tab></div>
      {[990, 1130].map((y, i) => (
        <div key={y} style={{position: 'absolute', left: 184, top: y + 4, width: 780, height: 104, border: '5px dashed rgba(201,212,255,0.55)', boxSizing: 'border-box', opacity: 1 - p(t, [a('paling gampang'), a('dan paling')][i] - 0.05, [a('paling gampang'), a('dan paling')][i] + 0.2),
          display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: HEAD, fontSize: 70, color: 'rgba(201,212,255,0.7)'}}>?</div>
      ))}
      <div style={{position: 'absolute', left: 64, top: 990, display: 'flex', alignItems: 'center', gap: 20, ...slide(t, a('paling gampang'), -900, 0)}}>
        <div style={slam(t, a('gampang'), 1.8)}><Mark w={100} /></div>
        <StatRow label="PALING" accent={K.navy} w={780} size={74} value={<span>GAMPANG <span style={{opacity: t >= a('dipakai') - 0.03 ? 1 : 0.15}}>DIPAKAI</span></span>} />
      </div>
      <div style={{position: 'absolute', left: 64, top: 1130, display: 'flex', alignItems: 'center', gap: 20, ...slide(t, a('dan paling'), -900, 0)}}>
        <div style={slam(t, fr, 1.8)}><Mark w={100} /></div>
        <StatRow label="PALING" accent={K.navy} w={780} size={74} value={<span>BANYAK <span style={{opacity: t >= a('temannya') - 0.03 ? 1 : 0.15}}>TEMANNYA</span></span>} />
      </div>
      {/* end card strap after the last word */}
      {strapQ > 0 && (
        <div style={{position: 'absolute', left: 64, top: 1290, display: 'flex', alignItems: 'stretch', boxShadow: '10px 10px 0 rgba(0,0,0,0.45)', transform: `translateX(${(1 - strapQ) * -1000}px)`}}>
          <div style={{background: K.red, color: K.white, fontFamily: HEAD, fontSize: 64, lineHeight: 1, padding: '14px 22px 4px'}}>KANAL 9</div>
          <div style={{background: 'linear-gradient(#FFFFFF, #DADFF0)', color: K.navy, fontFamily: HEAD, fontSize: 64, lineHeight: 1, padding: '14px 26px 4px'}}>SIARAN KHUSUS · TAMAT</div>
        </div>
      )}
      {endQ > 0 && (
        <div style={{position: 'absolute', left: 0, right: 0, top: 1450, display: 'flex', justifyContent: 'center', opacity: endQ}}>
          <div style={{background: '#000', color: K.white, fontFamily: OSD, fontSize: 52, padding: '10px 22px 6px'}}>PERANG KASET VIDEO · 1975–2002</div>
        </div>
      )}
    </Studio>
  );
};

// ───────── picture timeline ─────────
const sceneAt = (t: number): React.ReactNode => {
  if (t < CUT1) return <Room t={t} />;
  if (t < ROLL1[0]) return <Fight t={t} />;
  if (t < ROLL1[1]) return <VRoll q={pio(t, ROLL1[0], ROLL1[1])} a={<Fight t={t} />} b={<Beta t={t} />} />;
  if (t < PUSH1[0]) return <Beta t={t} />;
  if (t < PUSH1[1]) return <Push q={pio(t, PUSH1[0], PUSH1[1])} a={<Beta t={t} />} b={<Beta2 t={t} />} />;
  if (t < FLIP1[0]) return <Beta2 t={t} />;
  if (t < FLIP1[1]) return <Flip q={pio(t, FLIP1[0], FLIP1[1])} a={<Beta2 t={t} />} b={<Vhs t={t} />} under={<Vhs t={t} />} />;
  if (t < REW[0]) return <Vhs t={t} />;
  if (t < REW[1]) return <Vhs t={REW[0] - (t - REW[0]) * 3} />;
  if (t < CUT2) return <Replay t={t} />;
  if (t < PAUSE[0]) return <Champ t={t} />;
  if (t < PAUSE[1]) return <Champ t={PAUSE[0]} />;
  if (t < ROLL2[0]) return <Round1 t={t} />;
  if (t < ROLL2[1]) return <VRoll q={pio(t, ROLL2[0], ROLL2[1])} a={<Round1 t={t} />} b={<Round2 t={t} />} />;
  if (t < PUSH2[0]) return <Round2 t={t} />;
  if (t < PUSH2[1]) return <Push q={pio(t, PUSH2[0], PUSH2[1])} a={<Round2 t={t} />} b={<Round3 t={t} />} />;
  if (t < CUT4) return <Round3 t={t} />;
  if (t < CUT5) return <Out t={t} />;
  if (t < LESSON) return <Line t={t} />;
  if (t < PUSH3[0]) return <Lesson t={t} />;
  if (t < PUSH3[1]) return <Push q={pio(t, PUSH3[0], PUSH3[1])} a={<Lesson t={t} />} b={<Win t={t} />} />;
  return <Win t={t} />;
};
const bandsAt = (t: number) => [
  ...TRACK.flatMap(([s, e]) => trackBand(t, s, e)),
  ...glitchBands(t, CUT1, 9), ...glitchBands(t, CUT2, 21), ...glitchBands(t, R1, 33), ...glitchBands(t, CUT4, 45), ...glitchBands(t, CUT5, 57),
  ...hitBands(t, a('senjata'), 560, 600, 40), ...hitBands(t, a('menang'), 700, 700, 50), ...hitBands(t, STORE_IN, 600, 700, 60), ...hitBands(t, a('berhenti'), 800, 600, 70),
  ...scrubBands(t, REW[0], REW[1], -1), ...scrubBands(t, FF[0], FF[1], 1), ...pauseBand(t, PAUSE[0], PAUSE[1]),
];

// ───────── deck state ─────────
const MODES: Array<{m: Mode; s: number; e: number}> = [
  {m: 'REW', s: REW[0], e: REW[1]}, {m: 'PAUSE', s: PAUSE[0], e: PAUSE[1]}, {m: 'FF', s: FF[0], e: FF[1]}, {m: 'STOP', s: STOP[0], e: STOP[1]},
];
const modeAt = (t: number): {m: Mode; since: number} => {
  const hit = MODES.find((x) => t >= x.s && t < x.e);
  if (hit) return {m: hit.m, since: hit.s};
  return {m: 'PLAY', since: Math.max(0, ...MODES.filter((x) => x.e <= t).map((x) => x.e))};
};
const counterAt = (t: number) => (t >= LESSON ? t - LESSON : 3730 + t + 11 * ov(t, FF) - ov(t, PAUSE) - 11 * ov(t, REW) - ov(t, STOP));
const STAMPS = [a('1975'), a('setahun'), a('2002'), LESSON];
const stampAt = (t: number): {l1: string; l2: string; on: boolean} => {
  if (t >= LESSON) return {l1: '-- -- ----', l2: '12:00', on: (t - LESSON) % 1 < 0.6};
  const clock = (s: number) => {
    const x = 21 * 3600 + 4 * 60 + 17 + s;
    return `${String(Math.floor(x / 3600) % 24).padStart(2, '0')}:${String(Math.floor(x / 60) % 60).padStart(2, '0')}:${String(Math.floor(x % 60)).padStart(2, '0')}`;
  };
  if (t < a('1975') - 0.02) return {l1: 'AKHIR 70-AN', l2: clock(t), on: true};
  if (t < a('setahun') - 0.02) return {l1: 'TAHUN 1975', l2: clock(t), on: true};
  if (t < FF[0]) return {l1: 'TAHUN 1976', l2: clock(t), on: true};
  if (t < FF[1]) {
    const steps = Math.ceil((FF[1] - FF[0]) * 20);
    const k = Math.min(steps, Math.floor((t - FF[0]) * 20) + 1);
    return {l1: `TAHUN ${Math.round(lerp(1976, 2002, k / steps))}`, l2: clock(t + k * 7919), on: true};
  }
  return {l1: 'TAHUN 2002', l2: clock(t + 99999), on: true};
};

export const VhsBetamaxEpisode: React.FC = () => {
  const {t} = useTime();
  const md = modeAt(t);
  const st = stampAt(t);
  const lastStamp = STAMPS.filter((s) => t >= s - 0.02).pop();
  const paused = md.m === 'PAUSE';
  const search = md.m === 'FF' || md.m === 'REW';
  const jitter = (paused ? (Math.floor(t * 15) % 2 ? 3 : -3) : 0) + (search ? (Math.floor(t * 20) % 2 ? 4 : -2) : 0);
  const sq = t < LESSON ? pio(t, OFF[0], OFF[1]) : 1 - pio(t, ON[0], ON[1]);
  return (
    <AbsoluteFill style={{background: '#030304', overflow: 'hidden'}}>
      <StyleFonts />
      {/* music + SFX are generated later from plans/kaset.json and KASET_SFX; a picture-only draft skips audio with --props='{"draftNoAudio":true}' */}
      {!(getInputProps() as {draftNoAudio?: boolean}).draftNoAudio && (
        <EpisodeAudio vo="audio/vo/kaset.mp3" words={C.words} music="audio/music/kaset.wav" bed={0.5} duck={0.18} sfx={KASET_SFX} />
      )}
      <VhsFilter />
      <Squash k={sq}>
        <PictureStack t={t} scene={sceneAt} bands={bandsAt(t)} jitter={jitter} />
        <TapeLayer t={t} />
        {sq > 0.02 && <div style={{position: 'absolute', left: 0, right: 0, top: 930, height: 60, background: 'rgba(255,255,255,0.9)', opacity: sq * sq, boxShadow: lq('0 0 60px 20px rgba(200,220,255,0.6)', '0 0 0 24px rgba(200,220,255,0.35)')}} />}
      </Squash>
      <Osd mode={md.m} pop={p(t, md.since, md.since + 0.12)} counter={counterAt(t)} line1={st.l1} line2={st.l2} line2On={st.on}
        stampPop={lastStamp !== undefined ? p(t, lastStamp - 0.02, lastStamp + 0.14) : 1} />
      <CC t={t} pages={PAGES} />
      <Crt />
    </AbsoluteFill>
  );
};

// ───────── sound: only the KASET SFX names (click whir rew ff pause static beep glitch thunk tvon chime whoosh) ─────────
const s = (t: number, name: string, vol = 0.55): Sfx => ({t: Math.max(0, t), src: `audio/sfx/kaset/${name}.wav`, vol});
export const KASET_SFX: Sfx[] = [
  s(0, 'click', 0.5), s(a('perang') - 0.02, 'thunk', 0.6), s(a('tamu') - 0.02, 'whoosh', 0.4), s(CUT1 - 0.4, 'whoosh', 0.5), s(CUT1 - 0.03, 'glitch', 0.55),
  s(a('senjata') - 0.02, 'thunk', 0.75), s(a('perang', 2) - 0.1, 'whoosh', 0.55), s(a('kaset') - 0.02, 'thunk', 0.7),
  s(ROLL1[0], 'static', 0.4), s(a('betamax') - 0.03, 'tvon', 0.6), s(a('1975') - 0.02, 'thunk', 0.65), s(PUSH1[0], 'whoosh', 0.45), s(a('ringkas') - 0.02, 'click', 0.5),
  s(a('tajam') - 0.02, 'beep', 0.45), s(FLIP1[0], 'whoosh', 0.5), s(a('vhs') - 0.03, 'tvon', 0.6), s(a('kemudian') - 0.02, 'beep', 0.45),
  s(REW[0], 'rew', 0.65), s(a('unggul') - 0.02, 'chime', 0.4), s(CUT2 - 0.03, 'glitch', 0.55), s(a('menang') - 0.02, 'thunk', 0.8), s(a('kenapa') - 0.02, 'thunk', 0.7), s(PAUSE[0], 'pause', 0.65),
  s(R1 + 0.02, 'chime', 0.6), s(a('satu jam') - 0.02, 'beep', 0.5), s(a('dua') - 0.02, 'beep', 0.55), s(a('utuh') - 0.02, 'chime', 0.5),
  s(ROLL2[0], 'static', 0.4), s(ROLL2[1] + 0.02, 'chime', 0.6), s(a('membagikan') + 0.2, 'whoosh', 0.45), s(a('pilihan') - 0.3, 'whoosh', 0.4), s(a('bersaing') - 0.02, 'thunk', 0.6),
  s(PUSH2[0], 'whoosh', 0.5), s(PUSH2[1] + 0.02, 'chime', 0.6), s(STORE_IN - 0.4, 'whoosh', 0.45), s(a('film vhs') - 0.02, 'thunk', 0.55), s(a('paling banyak') - 0.02, 'chime', 0.55),
  s(CUT4 - 0.03, 'glitch', 0.5), s(a('tersingkir') + 0.9, 'thunk', 0.4), s(CUT5 - 0.03, 'glitch', 0.5), s(a('berhenti') - 0.02, 'thunk', 0.75), s(FF[0], 'ff', 0.6), s(a('2002') - 0.02, 'thunk', 0.8),
  s(OFF[0], 'static', 0.35), s(ON[0], 'tvon', 0.65), s(a('belum') - 0.02, 'thunk', 0.7), s(PUSH3[0], 'whoosh', 0.5), s(a('banyak temannya') - 0.02, 'beep', 0.55),
  s(CAP_END, 'chime', 0.5),
];
