// REFERENCE DEMO (ADSY MOTION GRAPH v1.9) — read for structure only: scenes, camera moves, word-pinned beats, SFX cues.
// Do NOT copy this story, its text or its layout into a buyer video. Written in the author's demo workspace, so a few
// imports differ from the starter: `makeCues(words)` ≈ the starter's `at()/endOf()` from src/lib/words.ts, and
// `EpisodeAudio` ≈ Main.tsx audio (musicFile + auto-duck) + <SfxTrack /> fed by src/audio-plan.json sfxCues.
// A `getInputProps()` draft switch, if present, was a workspace-only shortcut: do not copy it (the starter has --silent-draft).
import React from 'react';
import {AbsoluteFill, getInputProps} from 'remotion';
import {makeCues} from '../../lib/cues';
import {lerp, pagesFor, rnd, StyleFonts, useTime} from '../../styles/shared';
import {EpisodeAudio, Sfx} from '../../styles/audio';
import {
  Backdrop, blobEllipse, Cam, Caption, cf, Clay, ClayDefs, ClayG, ClayGrads, ClayLine, ClayWord, Contact, Crumbs, drop, flatten, HZ, ID, jig, kAt, L, Label, mul, Pill, Place, pop,
  LITE, press, SETS, SP, SQ, Star, Thumb, Timeline, TR, useBoil, useLemFonts, wobPath,
} from '../../styles/lempung/kit';
import {
  Arms, balloonNodes, BowlBack, BowlFront, BUBBLE, Bubble, CrowdItem, CRUST, Dough, DOUGH, DOUGH_DK, FlourSack, Gauge, GLUTEN, Hand, Loaf, Magnifier,
  mixColor, Molecule, Mood, OVEN, OvenBody, Slice, strand, SugarCube, WaterDrop, Wisp, Yeast, YeastRow,
} from '../../styles/lempung/props';
import wordsFile from './words.json';

// LEMPUNG episode — "Roti mengembang": why bread dough doubles. A claymation tabletop film: a bowl of dough, a
// magnifier into the micro world where a clay yeast cell eats sugar and puffs out CO2, kneading hands that link
// protein strands into an elastic gluten net, a cross-section of millions of linked balloons catching gas, a clay
// oven where the yeast works until it is too hot and stops (gently), a loaf browning, and a crumb full of yeast.
// Stop-motion on a 12 fps held clock, clay transitions (rolling pin / dough-sheet slap) at 24 fps, frame-exact captions.

const C = makeCues(wordsFile);
const a = C.at;
const PAGES = pagesFor(C.words, 4, 22);
export const LEMPUNG_DURATION = C.duration + 1.4;
const END = a('mereka') + 0.45;


const hop = (tq: number, at: number): SQ => {
  const k = kAt(tq, at);
  const rows: number[][] = [[0, 1.1, 0.86], [-46, 0.92, 1.1], [-20, 0.96, 1.05], [0, 1.08, 0.93], [0, 1, 1]];
  if (k < 0) return ID;
  const r = rows[Math.min(k, rows.length - 1)];
  return {...ID, y: r[0], sx: r[1], sy: r[2]};
};
/** squash-press keyed on a hold count (k = holds since the press). */
const squish = (k: number): SQ => (k === 0 ? {...ID, sx: 1.12, sy: 0.85} : k === 1 ? {...ID, sx: 0.95, sy: 1.06} : k === 2 ? {...ID, sx: 1.02, sy: 0.99} : ID);
const clamp01 = (v: number) => Math.max(0, Math.min(1, v));

// ================================ S1 — kitchen: why does dough double? ================================
const RISE = [1, 1.07, 1.16, 1.27, 1.4, 1.54, 1.68, 1.8, 1.92, 2.02, 2.08, 1.97, 2.0];
const Kitchen: React.FC<SP> = ({tq, hold}) => {
  const BX = 430, BB = 1440, BW = 720, BH = BW * 0.52;
  const DW = 600, DBASE = 1190;
  const kR = kAt(tq, a('mengembang'));
  const rise = kR < 0 ? 1 : RISE[Math.min(kR, RISE.length - 1)];
  const top1 = DBASE - 120 * (DW / 400), top2 = DBASE - 240 * (DW / 400);
  const MAG = a('rahasianya');
  const km = kAt(tq, MAG - 3 / 12);
  const MP = [[1360, 640], [1080, 720], [760, 800], [520, 860], [436, 878]];
  const mp = km < 0 ? null : km < MP.length ? MP[km] : [436 + Math.sin(hold * 0.6) * 3, 878 + Math.cos(hold * 0.5) * 3];
  const RG = a('ragi');
  const mini = [[170, 200], [330, 150], [250, 320], [390, 320], [120, 360]];
  const dj = jig(hold, 3, 0.5);
  return (
    <>
      <Cam tq={tq} from={0} to={8.9} impacts={[a('dua'), RG]}>
        <Backdrop set={SETS.cream} />
        <Crumbs seed={5} colors={[L.teal, L.mustard, DOUGH_DK, L.tomato]} top={1462} />
        {/* measuring stick */}
        <Contact x={880} y={1442} w={90} k={0.7} />
        <Clay f="slabB" style={{left: 870, top: 700, width: 34, height: 742, borderRadius: 17, background: L.cream}}>
          {Array.from({length: 18}).map((_, i) => <div key={i} style={{position: 'absolute', left: 0, top: 30 + i * 40, width: i % 2 ? 12 : 22, height: 4, background: 'rgba(107,69,50,0.45)'}} />)}
        </Clay>
        <Pill tq={tq} at={a('adonan')} x={748} y={top1 - 44} w={112} h={88} color={L.cream} ink={L.cocoa} size={46}>1×</Pill>
        <Pill tq={tq} at={a('dua')} x={748} y={top2 - 44} w={112} h={88} color={L.tomato} ink={L.cream} size={46}>2×</Pill>
        {kR >= 9 && <div style={{position: 'absolute', left: 706, top: top2 - 3, width: 40, height: 6, borderRadius: 3, background: L.tomato}} />}
        {/* bowl + rising dough */}
        <Contact x={BX} y={BB} w={BW * 0.9} />
        <Place x={BX - BW / 2} y={BB - BH} w={BW} h={BH}><BowlBack w={BW} /></Place>
        <Place x={BX - DW / 2 + dj.x} y={DBASE - DW * 0.75} w={DW} h={DW * 0.8} rot={dj.r * 0.5}><Dough w={DW} rise={rise} holes={kR >= 4} /></Place>
        <Place x={BX - BW / 2} y={BB - BH} w={BW} h={BH}><BowlFront w={BW} /></Place>
      </Cam>
      {/* magnifier into the dough: tiny living things */}
      {mp && (
        <div style={{position: 'absolute', left: mp[0], top: mp[1], zIndex: 20}}>
          <Magnifier r={250}>
            <div style={{position: 'absolute', inset: 0, background: `radial-gradient(circle at 40% 35%, #FBEBCB, ${DOUGH} 70%)`}}>
              {Array.from({length: 14}).map((_, i) => <div key={i} style={{position: 'absolute', left: rnd(i * 3.3) * 460, top: rnd(i * 7.1) * 460, width: 20 + rnd(i) * 26, height: 16 + rnd(i) * 20, borderRadius: '50%', background: 'rgba(196,150,90,0.35)'}} />)}
              <YeastRow f="fine" items={mini.map(([x, y], i) => {
                const s = pop(tq, a('makhluk') + i / 24);
                const waving = tq >= RG;
                return {x, base: y + 40, w: 64, on: s.on, sx: s.sx, sy: s.sy, mood: waving ? 'grin' : 'smile', look: tq >= a('hidup') ? ((hold + i * 2) % 6 < 3 ? -5 : 5) : 0,
                  arms: waving ? ((hold + i) % 4 < 2 ? 'waveL' : 'waveR') : 'down'} as CrowdItem;
              })} />
            </div>
          </Magnifier>
        </div>
      )}
      <Pill tq={tq} at={a('super')} x={236} y={1150} w={400} h={100} color={L.ink} ink={L.cream} size={52} rot={-4} z={21}>SUPER KECIL</Pill>
      <ClayLine text="PERNAH KEPIKIRAN?" starts={[-1 / 12, a('kepikiran')]} tq={tq} hold={hold} size={92} y={150} color={L.cocoa} seed={1} out={a('kenapa') - 2 / 12} />
      <ClayLine text="KENAPA?" starts={[a('kenapa')]} tq={tq} hold={hold} size={210} y={104} color={L.tomato} seed={2} f="txtB" out={RG - 2 / 12} />
      <ClayLine text="MENGEMBANG" starts={[a('mengembang')]} tq={tq} hold={hold} size={124} y={336} color={L.teal} seed={3} out={RG - 2 / 12} />
      <ClayLine text="RAGI" starts={[RG]} tq={tq} hold={hold} size={290} y={84} color={L.mustard} seed={4} f="txtB" shade="#C98A1E" />
    </>
  );
};

// ================================ S2–S4 — micro world: the yeast eats, puffs gas, gas escapes ================================
const BUBS = [
  {x: 800, y: 940, d: 150}, {x: 290, y: 1000, d: 112}, {x: 930, y: 1170, d: 92}, {x: 190, y: 820, d: 120}, {x: 870, y: 730, d: 100}, {x: 230, y: 640, d: 84},
];
const FLOATIES = Array.from({length: 16}).map((_, i) => ({x: rnd(i * 2.7) * 1080, y: 120 + rnd(i * 5.3) * 1250, d: 18 + rnd(i * 8.1) * 46}));
const Micro: React.FC<SP> = ({tq, hold}) => {
  const YX = 540, YB = 1440, YW = 470;
  const CUT1 = a('dan seperti'), CUT2 = a('tapi');
  const R1 = a('ragi', 1), AIR = a('air'), HAN = a('hangat'), GUL = a('gula'), DIA = a('dia mulai'), MAK = a('makan');
  const KIT = a('kita'), BUA = a('buang'), GAS = a('gas'), KAR = a('karbon'), DIO = a('dioksida'), PLU = a('plus'), ALK = a('alkohol');
  const GAS2 = a('gas', 1), KAB = a('kabur'), KOK = a('kok'), TER = a('terperangkap');
  // ---- yeast acting ----
  let mood: Mood = 'smile', look = 0, arms: Arms = 'down', blush = 0.45, sq: SQ = ID, dx = 0, rot = 0;
  if (tq >= R1 && tq < R1 + 0.6) { sq = hop(tq, R1); arms = (hold % 4 < 2) ? 'waveR' : 'up'; mood = 'grin'; }
  if (tq >= AIR && tq < GUL) look = -7;
  if (tq >= GUL && tq < DIA) { look = 7; arms = 'side'; mood = 'grin'; }
  if (tq >= DIA && tq < CUT1) {
    dx = 50; rot = 7; look = 7;
    mood = tq < MAK ? 'open' : Math.floor(kAt(tq, MAK) / 2) % 2 ? 'chomp' : 'open';
    if (tq >= MAK) sq = Math.floor(kAt(tq, MAK) / 2) % 2 ? {...ID, sx: 1.05, sy: 0.96} : ID;
  }
  if (tq >= CUT1 && tq < KIT) { mood = 'smile'; look = 0; }
  if (tq >= KIT && tq < BUA) { mood = 'grin'; blush = 1; look = 8; }
  if (tq >= BUA && tq < GAS) { mood = 'effort'; blush = 1; sq = {...ID, sx: 1.08, sy: 0.92}; }
  if (tq >= GAS && tq < KAR) { mood = kAt(tq, GAS) < 6 ? 'relief' : 'grin'; blush = 0.9; sq = kAt(tq, GAS) === 0 ? {...ID, sx: 0.92, sy: 1.1} : kAt(tq, GAS) === 1 ? {...ID, sx: 1.04, sy: 0.97} : ID; }
  if (tq >= KAR && tq < PLU) { mood = 'smile'; look = -6; }
  if (tq >= PLU && tq < CUT2) { mood = 'o'; look = 6; }
  if (tq >= CUT2 && tq < KAB) { mood = 'smile'; look = (hold % 8 < 4) ? -5 : 5; }
  if (tq >= KAB && tq < KOK) { mood = 'open'; arms = 'up'; sq = squish(kAt(tq, KAB)); }
  if (tq >= KOK) { mood = 'worry'; arms = 'side'; look = 0; }
  if (mood === 'smile' && hold % 31 === 0) mood = 'relief';
  const j = jig(hold, 21, 0.7);
  // ---- gas bubbles ----
  const bubbles = BUBS.map((b, i) => {
    const k = kAt(tq, GAS + i / 24);
    if (k < 0) return null;
    const q = clamp01((k + 1) / 4);
    const e = 1 - (1 - q) * (1 - q);
    let x = lerp(650, b.x, e), y = lerp(1300, b.y, e);
    const d = b.d * lerp(0.3, 1, e);
    y -= Math.max(0, tq - GAS - 0.4) * 16;
    x += Math.sin(hold * 0.45 + i * 1.7) * 5;
    const kk = kAt(tq, KAB + i / 24);
    if (kk >= 0) y -= kk * (kk + 1) * 16 + kk * 26;
    if (y < -200) return null;
    const face = tq >= GAS2;
    return {i, x, y, d, face, look: face ? ((hold + i) % 6 < 3 ? -6 : 6) : 0, tag: i < 2 && tq >= KAR && tq < KAB};
  }).filter(Boolean) as {i: number; x: number; y: number; d: number; face: boolean; look: number; tag: boolean}[];
  const kg = kAt(tq, GAS);
  return (
    <>
      <Cam tq={tq} from={8.6} to={24.9} push={0.02} impacts={[R1, GAS, KOK]} moves={[{from: CUT1, to: CUT1, s: 1.15, fx: 540, fy: 1130}, {from: CUT2, to: CUT2, s: 1, fx: 540, fy: 960}]}>
        <Backdrop set={SETS.micro} />
        {FLOATIES.map((f, i) => <div key={i} style={{position: 'absolute', left: f.x, top: f.y + ((hold + i * 5) % 24) * -1.5, width: f.d, height: f.d, borderRadius: '50%', background: 'rgba(255,255,255,0.32)'}} />)}
        <Crumbs seed={14} colors={['#9ED3CF', '#FFFFFF', L.sky]} top={1466} />
        {/* water drop (warm) + sugar cubes, before the close-up */}
        {tq < CUT1 && (
          <>
            {(() => { const s = drop(tq, AIR, 1.4); return <><Contact x={200} y={YB} w={130} s={s} /><Place x={130} y={YB - 182} w={140} h={182} s={s}><WaterDrop w={140} /></Place></>; })()}
            {tq >= HAN && [0, 1, 2].map((i) => (
              <div key={i} style={{position: 'absolute', left: 150 + i * 36, top: YB - 182 - 170 - (i % 2) * 20 - (kAt(tq, HAN) % 6) * 3, opacity: 0.9}}><Wisp h={150} color={L.cream} phase={hold * 0.9 + i * 2} width={13} /></div>
            ))}
            {[[860, YB, 104], [968, YB, 100], [912, YB - 98, 96]].map(([x, b, w], i) => {
              let s = drop(tq, GUL + i / 12, 1.2);
              const eat = MAK + [2, 1, 0][i] * (2 / 12);
              s = mul(s, flatten(tq, eat));
              return <React.Fragment key={i}>{i < 2 && <Contact x={x} y={YB} w={w} s={s} />}<Place x={x - w / 2} y={b - w} w={w} h={w} s={s} rot={[-6, 5, 10][i]}><SugarCube w={w} /></Place></React.Fragment>;
            })}
            {tq >= MAK && [0, 1, 2, 3].map((i) => {
              const k = kAt(tq, MAK + (i % 2) * (4 / 12));
              if (k < 0 || k > 3) return null;
              return <Clay key={i} f="fine" style={{left: 720 + i * 26 + k * 18, top: 1180 - k * 22 + (i % 2) * 30, width: 18 - k * 3, height: 16 - k * 3, borderRadius: '40%', background: '#FFFDF6', zIndex: 6}} />;
            })}
          </>
        )}
        {/* the yeast */}
        <Contact x={YX + dx} y={YB} w={390} s={sq} k={0.9} />
        <Place x={YX - YW / 2 + dx + j.x} y={YB - YW * 1.2} w={YW} h={YW * 1.2} s={sq} rot={rot + j.r} z={5}>
          <Yeast w={YW} mood={mood} look={look} arms={arms} blush={blush} />
        </Place>
        {/* fart puffs */}
        {kg >= 0 && kg < 5 && [0, 1, 2].map((i) => {
          const d = [70, 54, 40][i] * (kg < 2 ? 0.7 + kg * 0.3 : 1.3 - (kg - 2) * 0.3);
          return <Clay key={i} f="fine" style={{left: 700 + i * 46 - d / 2 + kg * 10, top: 1330 - i * 34 - d / 2 - kg * 8, width: d, height: d, borderRadius: '50%', background: '#F3FBFB', zIndex: 4}} />;
        })}
        {bubbles.map((b) => (
          <React.Fragment key={b.i}>
            {tq >= KAB && kAt(tq, KAB + b.i / 24) >= 1 && [0, 1].map((m) => <div key={m} style={{position: 'absolute', left: b.x - 14 + m * 22, top: b.y + b.d * 0.55 + 10, width: 6, height: 34, borderRadius: 3, background: 'rgba(255,255,255,0.7)', zIndex: 6}} />)}
            <div style={{position: 'absolute', left: b.x - b.d / 2, top: b.y - b.d / 2, zIndex: 7}}><Bubble d={b.d} face={b.face} look={b.look} tag={b.tag} /></div>
          </React.Fragment>
        ))}
        {/* a little alcohol */}
        {tq >= PLU && tq < CUT2 && (() => { const s = pop(tq, PLU); return <Place x={820} y={1260} w={84} h={109} s={s} rot={14} z={6}><WaterDrop w={84} face={false} color={L.lilac} /></Place>; })()}
      </Cam>
      {/* wall / screen-space words */}
      <ClayLine text="JAMUR" starts={[a('jamur')]} tq={tq} hold={hold} size={210} y={96} color={L.lilac} seed={5} f="txtB" out={CUT1 - 2 / 12} />
      <ClayLine text="BERSEL SATU" starts={[a('bersel'), a('satu')]} tq={tq} hold={hold} size={110} y={330} color={L.teal} seed={6} out={CUT1 - 2 / 12} />
      <ClayLine text="BUANG GAS!" starts={[BUA, GAS]} tq={tq} hold={hold} size={160} y={110} color={L.tomato} seed={7} f="txtB" out={KAR - 2 / 12} />
      {tq >= KAR - 1 / 12 && tq < CUT2 + 2 / 12 && (
        <Place x={330} y={226} w={420} h={176} s={mul(pop(tq, KAR), flatten(tq, CUT2 - 2 / 12))} origin="50% 50%" z={30}><Molecule w={420} /></Place>
      )}
      <Pill tq={tq} at={DIO} x={250} y={430} w={580} h={92} color={L.cream} ink={L.ink} size={48} out={CUT2 - 2 / 12} z={30}>KARBON DIOKSIDA</Pill>
      <Pill tq={tq} at={ALK} x={420} y={1430} w={480} h={88} color={L.lilac} ink={L.cream} size={44} out={CUT2 - 2 / 12} z={30}>+ SEDIKIT ALKOHOL</Pill>
      <ClayLine text="KABUR!" starts={[KAB]} tq={tq} hold={hold} size={210} y={104} color={L.tomato} seed={8} f="txtB" out={KOK - 2 / 12} />
      {(() => {
        const s = mul(pop(tq, KOK), kAt(tq, KOK) >= 4 ? {...ID, sx: 1 + Math.sin(hold * 0.9) * 0.025, sy: 1 - Math.sin(hold * 0.9) * 0.035} : ID);
        const sL = press(tq, TER), sR = press(tq, TER + 1 / 12);
        return (
          <>
            <Place x={290} y={850 - 0.8 * 560} w={500} h={560} s={s} rot={Math.sin(hold * 1.1) * 4} origin={`50% ${0.8 * 560}px`} z={30}>
              <ClayWord text="?" tq={tq} hold={hold} at={-10} size={560} y={0} w={500} color={L.mustard} f="big" seed={13} />
            </Place>
            <Place x={50} y={540} w={220} h={260} s={sL} rot={-12} origin="50% 70%" z={30}><ClayWord text="?" tq={tq} hold={hold} at={-10} size={260} y={0} w={220} color={L.tomato} f="slabA" seed={14} /></Place>
            <Place x={810} y={600} w={220} h={260} s={sR} rot={12} origin="50% 70%" z={30}><ClayWord text="?" tq={tq} hold={hold} at={-10} size={260} y={0} w={220} color={L.lilac} f="slabB" seed={15} /></Place>
          </>
        );
      })()}
    </>
  );
};

// ================================ S5 — flour + kneading → gluten net ================================
const NET_STEP = 128;
const NET_NODES = (() => {
  const out: [number, number][] = [];
  for (let r = -3; r <= 3; r++) for (let c = -3; c <= 3; c++) {
    const x = 360 + c * NET_STEP + (r % 2 ? NET_STEP / 2 : 0), y = 360 + r * NET_STEP * 0.87;
    if (Math.hypot(x - 360, y - 360) < 330) out.push([x, y]);
  }
  return out;
})();
const NET_LINKS = (() => {
  const out: [number, number, number][] = [];
  NET_NODES.forEach((p, i) => NET_NODES.forEach((q, k) => {
    if (k > i && Math.hypot(p[0] - q[0], p[1] - q[1]) < NET_STEP * 1.08) out.push([i, k, Math.hypot((p[0] + q[0]) / 2 - 360, (p[1] + q[1]) / 2 - 360)]);
  }));
  return out.sort((x, y) => x[2] - y[2]);
})();
const STRANDS = Array.from({length: 11}).map((_, i) => ({x: 120 + rnd(i * 4.1) * 480, y: 130 + rnd(i * 6.7) * 460, len: 110 + rnd(i * 2.2) * 80, ang: rnd(i * 9.9) * Math.PI}));
const ELASTIC: [number, number][] = [[1.22, 0.86], [1.22, 0.86], [0.88, 1.12], [0.88, 1.12], [1.08, 0.95], [0.97, 1.02], [1, 1]];

const Knead: React.FC<SP> = ({tq, hold}) => {
  const DX = 600, DB = 1398, DW = 560;
  const TEP = a('tepung'), DIU = a('diuleni'), AIR = a('air', 1), PRO = a('protein'), MEM = a('membentuk'), ELA = a('elastis'), NAM = a('namanya'), GLU = a('gluten');
  const sackS = drop(tq, TEP, 1.2);
  const kn = kAt(tq, DIU - 2 / 12);
  const kneading = kn >= 2 && tq < PRO;
  const ph = kneading ? Math.floor((kn - 2) / 2) % 2 : -1;
  const hard = kneading && (kn - 2) % 2 === 0;
  const dSq: SQ = kneading ? (hard ? {...ID, sx: 1.14, sy: 0.84, x: ph ? 10 : -10} : {...ID, sx: 0.98, sy: 1.03}) : squish(kAt(tq, AIR));
  const doughTop = DB - 120 * 1.15 * (DW / 400);
  const handTop = doughTop - 276 + 60;
  const handY = (side: 0 | 1) => {
    if (kn < 0) return null;
    if (kn === 0) return -620;
    if (kn === 1) return handTop - 240;
    if (tq >= PRO) { const k = kAt(tq, PRO); return k > 3 ? null : handTop - 260 * (k + 1); }
    return handTop + (ph === side ? (hard ? 44 : 20) : -36);
  };
  const lens = pop(tq, PRO);
  const km = kAt(tq, MEM);
  const linksOn = km < 0 ? 0 : Math.min(NET_LINKS.length, (km + 1) * 5);
  const strandW = km < 0 ? 16 : Math.max(0, 16 - (km + 1) * 4);
  const ke = kAt(tq, ELA);
  const el = ke < 0 ? [1, 1] : ELASTIC[Math.min(ke, ELASTIC.length - 1)];
  const glow = tq >= GLU;
  return (
    <>
      <Cam tq={tq} from={24.6} to={33.2} impacts={[TEP, ELA]}>
        <Backdrop set={SETS.peach} />
        <Crumbs seed={23} colors={['#FFFFFF', DOUGH_DK, L.cream]} top={1468} />
        {/* floured board */}
        <Contact x={560} y={1458} w={860} k={0.8} />
        <Clay f="slabB" style={{left: 140, top: 1390, width: 840, height: 66, borderRadius: 26, background: L.wood}} />
        <div style={{position: 'absolute', left: 140, top: 1374, width: 840, height: 40, filter: 'url(#fine)'}}>
          {[[90, 18, 120], [300, 10, 70], [640, 14, 140], [760, 6, 60]].map(([x, y, w], i) => <div key={i} style={{position: 'absolute', left: x, top: y, width: w, height: 18, borderRadius: 9, background: '#FFFDF7'}} />)}
        </div>
        {/* flour sack + puff */}
        <Contact x={196} y={1420} w={230} s={sackS} />
        <Place x={70} y={1420 - 312} w={250} h={312} s={sackS} rot={-4}><FlourSack w={250} /></Place>
        {kAt(tq, TEP) >= 0 && kAt(tq, TEP) < 6 && [0, 1, 2, 3].map((i) => {
          const k = kAt(tq, TEP);
          const d = [90, 70, 80, 56][i] * (k < 3 ? 0.6 + k * 0.25 : 1.35 - (k - 3) * 0.4);
          return <Clay key={i} f="fine" style={{left: [40, 250, 110, 300][i] - d / 2 + (i % 2 ? 1 : -1) * k * 12, top: 1390 - [20, 40, 90, 110][i] - d / 2 - k * 10, width: d, height: d, borderRadius: '50%', background: '#FFFFFF', zIndex: 4}} />;
        })}
        {/* dough + water drop */}
        <Contact x={DX} y={DB} w={DW * 0.9} s={dSq} />
        <Place x={DX - DW / 2} y={DB - DW * 0.75} w={DW} h={DW * 0.8} s={dSq} z={3}><Dough w={DW} rise={1.15} /></Place>
        {(() => { const s = drop(tq, AIR, 3); if (!s.on || kAt(tq, AIR) > 0) return null; return <Place x={DX - 40} y={doughTop - 110} w={80} h={104} s={s} z={4}><WaterDrop w={80} face={false} /></Place>; })()}
        {kAt(tq, AIR) >= 1 && kAt(tq, AIR) < 4 && [-1, 1, -0.5, 0.5].map((dir, i) => {
          const k = kAt(tq, AIR);
          return <Clay key={i} f="fine" style={{left: DX + dir * (30 + k * 46) - 10, top: doughTop - 10 - k * (24 - k * 6) - (i > 1 ? 18 : 0), width: 22, height: 22, borderRadius: '50%', background: L.sky, zIndex: 4}} />;
        })}
        {/* kneading hands */}
        {[0, 1].map((side) => {
          const y = handY(side as 0 | 1);
          if (y === null) return null;
          return <Place key={side} x={(side ? 730 : 490) - 115} y={y} w={230} h={299} rot={side ? 9 : -9} z={5}><Hand w={230} flip={side === 1} /></Place>;
        })}
      </Cam>
      {/* magnifier into the dough: loose protein → linked elastic net */}
      {lens.on && (
        <Place x={540 - 360} y={830 - 360} w={720} h={720} s={lens} origin="50% 50%" z={20}>
          <div style={{position: 'absolute', left: 360, top: 360}}>
            <Magnifier r={360} handle>
              <div style={{position: 'absolute', inset: 0, background: `radial-gradient(circle at 40% 35%, #FBEBCB, ${DOUGH} 72%)`}}>
                <svg width={720} height={720} style={{position: 'absolute', left: 0, top: 0, overflow: 'visible'}}>
                  {strandW > 0 && (
                    <ClayG f="txtA">
                      {STRANDS.map((s0, i) => <path key={i} d={strand(s0.x, s0.y, s0.len, s0.ang + Math.sin(hold * 0.7 + i) * 0.15, hold * 0.8 + i)} stroke={GLUTEN} strokeWidth={strandW} strokeLinecap="round" strokeLinejoin="round" fill="none" />)}
                    </ClayG>
                  )}
                  {linksOn > 0 && (
                    <ClayG f="txtA" transform={`translate(360 360) scale(${el[0]} ${el[1]}) translate(-360 -360)`}>
                      {NET_LINKS.slice(0, linksOn).map(([i, k], n) => {
                        const p = NET_NODES[i], q = NET_NODES[k];
                        const mx = (p[0] + q[0]) / 2 + Math.sin(n * 1.3 + hold * 0.3) * 6, my = (p[1] + q[1]) / 2 + Math.cos(n * 1.7) * 8;
                        return <path key={n} d={`M ${p[0]} ${p[1]} Q ${mx} ${my} ${q[0]} ${q[1]}`} stroke={glow ? '#EE7F45' : GLUTEN} strokeWidth={15} strokeLinecap="round" fill="none" />;
                      })}
                      {NET_NODES.map((p, i) => (NET_LINKS.slice(0, linksOn).some(([x, y]) => x === i || y === i) ? <circle key={i} cx={p[0]} cy={p[1]} r={15} fill={cf(glow ? '#EE7F45' : GLUTEN)} /> : null))}
                    </ClayG>
                  )}
                </svg>
              </div>
            </Magnifier>
          </div>
        </Place>
      )}
      <Pill tq={tq} at={ELA} x={360} y={1200} w={360} h={100} color={L.mustard} ink={L.ink} size={56} rot={-5} z={22}>ELASTIS!</Pill>
      <ClayLine text="TEPUNG" starts={[TEP]} tq={tq} hold={hold} size={210} y={104} color={L.teal} seed={9} f="txtB" out={PRO - 2 / 12} />
      <ClayLine text="PROTEIN" starts={[PRO]} tq={tq} hold={hold} size={170} y={120} color={L.lilac} seed={10} out={NAM} />
      <ClayLine text="GLUTEN" starts={[GLU]} tq={tq} hold={hold} size={240} y={92} color={L.tomato} seed={11} f="txtB" />
    </>
  );
};

// ================================ S6 — millions of linked balloons catch the gas; dough puffs ================================
const DOME = 'M 150 1420 C 140 1080 290 900 540 900 C 790 900 940 1080 930 1420 Z';
const NODES = balloonNodes(540, 1170, 340, 240, 60);
const LINKS = (() => {
  const out: [number, number][] = [];
  NODES.forEach((p, i) => NODES.forEach((q, k) => { if (k > i && Math.hypot(p.x - q.x, p.y - q.y) < 66) out.push([i, k]); }));
  return out;
})();
const ROWY = Array.from(new Set(NODES.map((n) => Math.round(n.y)))).sort((x, y) => y - x);
const CATCH = [3, 9, 15, 22, 30, 38, 45, 52, 60, 66].filter((i) => i < NODES.length);
const PUFF = [1.02, 1.06, 1.12, 1.19, 1.25, 1.21, 1.23];

const Balloons: React.FC<SP> = ({tq, hold}) => {
  const J = a('jutaan'), SAL = a('saling'), GEL = a('gelembung'), DIT = a('ditangkap'), ADN = a('adonan', 1), PEL = a('pelan-pelan'), MGB = a('menggembung');
  const radius = (n: typeof NODES[number], i: number) => {
    let r = 9;
    const kj = kAt(tq, J + n.ring / 24);
    if (kj >= 0) r = kj === 0 ? 24 : kj === 1 ? 19 : 21;
    const row = ROWY.indexOf(Math.round(n.y));
    const kf = kAt(tq, GEL + 0.25 + row / 24);
    if (kf >= 0) r = kf === 0 ? 30 : kf === 1 ? 25.5 : 27;
    return r + (i % 3) * 0.6;
  };
  const filled = (n: typeof NODES[number]) => kAt(tq, GEL + 0.25 + ROWY.indexOf(Math.round(n.y)) / 24) >= 0;
  const kp = kAt(tq, PEL);
  const km = kAt(tq, MGB);
  const puffS = km >= 0 ? PUFF[Math.min(km, PUFF.length - 1)] * 1.04 : kp >= 0 ? 1 + Math.min(kp, 7) * 0.006 : 1;
  const linkW = tq >= SAL ? (kAt(tq, SAL) < 2 ? 12 : 9) : 6;
  const linksShown = LINKS.length;
  const boil = useBoil();
  const dome = wobPath(DOME, 9, boil, 5);
  return (
    <>
      <Cam tq={tq} from={33.0} to={41.2} push={0.015} impacts={[MGB]} s0={2.2} fx0={540} fy0={1170} moves={[{from: ADN, to: ADN + 0.7, s: 1.25, fx: 540, fy: 1120}]}>
        <Backdrop set={SETS.butter} />
        <Crumbs seed={31} colors={[L.tomato, L.teal, L.cream]} top={1470} />
        <Contact x={540} y={1452} w={900} k={0.8} />
        <svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0, overflow: 'visible'}}>
          <defs><clipPath id="lem-dome"><path d={dome} /></clipPath></defs>
          <ClayG f="slabA"><rect x={110} y={1418} width={860} height={36} rx={18} fill={cf(L.cocoa)} /></ClayG>
          <g transform={`translate(540 1420) scale(${puffS}) translate(-540 -1420)`}>
            {/* zoomed 2.2×: in lite the rim-less chain keeps this huge region cheap; grain stays on */}
            <ClayG f="big" tex flat><path d={dome} fill={cf(DOUGH)} stroke={LITE ? DOUGH_DK : undefined} strokeWidth={LITE ? 7 : undefined} /></ClayG>
            <g clipPath="url(#lem-dome)">
              <ClayG f="fine" flat>
                {LINKS.slice(0, linksShown).map(([i, k], n) => <line key={n} x1={NODES[i].x} y1={NODES[i].y} x2={NODES[k].x} y2={NODES[k].y} stroke={GLUTEN} strokeWidth={linkW} strokeLinecap="round" />)}
              </ClayG>
              <ClayG f="fine" flat>
                {NODES.map((n, i) => {
                  const r = radius(n, i);
                  const c = filled(n) ? n.c : mixColor(n.c, DOUGH, 0.45);
                  return (
                    <React.Fragment key={i}>
                      <path d={blobEllipse(n.x, n.y, r, r, i + 1, boil, 0.07, 7)} fill={cf(c)} />
                      <circle cx={n.x - r * 0.35} cy={n.y - r * 0.38} r={r * 0.22} fill="#FFFFFF" opacity={0.75} />
                    </React.Fragment>
                  );
                })}
              </ClayG>
              {/* gas bubbles rising into the balloons */}
              <ClayG f="fine" flat>
                {CATCH.map((ni, m) => {
                  const k = kAt(tq, GEL + m / 24 - 2 / 12);
                  if (k < 0 || k > 6) return null;
                  const n = NODES[ni];
                  const q = k / 6;
                  return <circle key={m} cx={n.x + Math.sin(m) * 30 * (1 - q)} cy={lerp(1440, n.y, q)} r={lerp(9, 17, q)} fill={cf(BUBBLE)} stroke="#FFFFFF" strokeWidth={3} />;
                })}
              </ClayG>
            </g>
          </g>
        </svg>
      </Cam>
      <ClayLine text="JUTAAN BALON" starts={[J, a('balon')]} tq={tq} hold={hold} size={136} y={110} color={L.teal} seed={12} out={GEL - 2 / 12} />
      <ClayLine text="SALING TERSAMBUNG" starts={[SAL, a('tersambung')]} tq={tq} hold={hold} size={92} y={286} color={L.cocoa} seed={13} out={GEL - 2 / 12} />
      <ClayLine text="DITANGKAP!" starts={[DIT]} tq={tq} hold={hold} size={170} y={104} color={L.tomato} seed={14} f="txtB" out={ADN} />
      <ClayLine text="MENGGEMBUNG" starts={[MGB]} tq={tq} hold={hold} size={128} y={130} color={L.teal} seed={15} f="txtB" />
    </>
  );
};

// ================================ S7 — oven: gas expands, yeast works hard, too hot, yeast stops ================================
const OBUB: [number, number, number][] = [[210, 330, 26], [300, 268, 22], [400, 300, 30], [500, 330, 24], [565, 392, 18], [180, 405, 16], [350, 392, 14], [452, 232, 16]];
const MINIS = [235, 330, 430, 525];
const OvenScene: React.FC<SP> = ({tq, hold}) => {
  const OX = 70, OT = 560, W = OVEN.win;
  const IN = a('masuk'), ON = a('oven'), GEL = a('gelembungnya'), MEM = a('memuai'), BES = a('besar'), RG = a('ragi', 2), HAB = a('habis-habisan');
  const SAM = a('sampai', 1), SUH = a('suhunya'), PAN = a('panas'), R3 = a('ragi', 3), BRH = a('berhenti');
  const kin = kAt(tq, IN);
  const trayX = kin < 0 ? 900 : [620, 330, 110, -12, 4, 0][Math.min(kin, 5)];
  const kon = kAt(tq, ON);
  const lit = kon >= 0;
  const hot = clamp01(kAt(tq, SUH) / 10);
  const glowC = mixColor('#FF9A3D', '#E8492E', hot);
  const ovenSq: SQ = kon === 0 ? {...ID, sx: 1.02, sy: 0.97} : kon === 1 ? {...ID, sx: 0.99, sy: 1.01} : ID;
  const grow = 1 + clamp01((kAt(tq, MEM) + 1) / 12) * 0.75;
  const riseO = 1 + clamp01((kAt(tq, BES) + 1) / 6) * 0.22;
  const stop = tq >= BRH;
  const boil = useBoil();
  const odome = wobPath(`M 120 440 C 112 ${440 - 150 * riseO} 220 ${440 - 220 * riseO} 370 ${440 - 220 * riseO} C 520 ${440 - 220 * riseO} 628 ${440 - 150 * riseO} 620 440 Z`, 77, boil, 3);
  const needle = tq < ON ? -105 : tq < MEM ? -105 + clamp01((kon + 1) / 3) * 45 : tq < BES ? -40 : tq < SUH ? 0 : tq < PAN ? 0 + clamp01((kAt(tq, SUH) + 1) / 9) * 70 : 104 + (hold % 2 ? 3 : -3);
  return (
    <>
      <Cam tq={tq} from={41.0} to={51.2} push={0.01} impacts={[ON, PAN]} moves={[
        {from: GEL, to: GEL + 0.5, s: 1.3, fx: 540, fy: 1050}, {from: SAM, to: SAM + 0.4, s: 1, fx: 540, fy: 960}, {from: R3, to: R3 + 0.45, s: 1.32, fx: 540, fy: 1050},
      ]}>
        <Backdrop set={SETS.oven} />
        {lit && <AbsoluteFill style={{background: `radial-gradient(ellipse 70% 30% at 50% 82%, ${glowC}${hot > 0.5 ? '55' : '38'}, transparent 70%)`}} />}
        <Contact x={540} y={1462} w={900} k={1.1} />
        <Place x={OX} y={OT} w={OVEN.w} h={OVEN.h} s={ovenSq}>
          <OvenBody lamp={lit ? 1 : 0} />
          {/* window interior */}
          <div style={{position: 'absolute', left: W.x, top: W.y, width: W.w, height: W.h, borderRadius: 40, overflow: 'hidden',
            background: lit ? `radial-gradient(ellipse 80% 70% at 50% 75%, ${glowC}, #3A1D12 85%)` : '#2B1B15'}}>
            {lit && [70, 300, 530].map((x) => <div key={x} style={{position: 'absolute', left: x, top: 34, width: 150, height: 12, borderRadius: 6, background: hot > 0.4 ? '#FFB067' : '#F07A3A', boxShadow: LITE ? undefined : `0 0 18px ${glowC}`}} />)}
            <div style={{position: 'absolute', left: 30, right: 30, top: 462, height: 8, borderRadius: 4, background: 'rgba(30,14,8,0.6)'}} />
            <svg width={W.w} height={W.h} style={{position: 'absolute', left: trayX, top: 0, overflow: 'visible'}}>
              <defs><clipPath id="lem-odome"><path d={odome} /></clipPath></defs>
              <ClayG f="slabA"><rect x={90} y={440} width={560} height={24} rx={12} fill={cf(L.cocoa)} /></ClayG>
              <ClayG f="slabA"><path d={odome} fill={cf(mixColor(DOUGH, '#E9B676', hot * 0.5))} /></ClayG>
              <ClayG f="fine" clipPath="url(#lem-odome)">
                {OBUB.map(([x, y, r], i) => <circle key={i} cx={x} cy={440 - (440 - y) * riseO} r={r * (tq >= MEM ? grow : 1)} fill={cf(BUBBLE)} />)}
              </ClayG>
            </svg>
            {/* mini yeast at work */}
            {tq >= RG - 1 / 12 && (
              <YeastRow f="fine" items={MINIS.map((x, i) => {
                const s = pop(tq, RG + i / 24);
                const fast = tq >= HAB;
                const bounce = stop ? 0 : (fast ? (hold + i) % 2 : Math.floor((hold + i) / 2) % 2) * -9;
                return {x: x + trayX, base: 436 + bounce + (stop ? 4 : 0), w: 76, on: s.on, sx: s.sx * (stop ? 1.04 : 1), sy: s.sy * (stop ? 0.95 : 1),
                  mood: stop ? 'sleep' : 'effort', arms: stop ? 'down' : (hold + i) % 2 ? 'pump1' : 'pump2', dim: stop ? 0.35 : 0,
                  sweat: fast && !stop ? 1 + ((hold + i) % 3) * 12 : 0, blush: stop ? 0.25 : 0.8} as CrowdItem;
              })} />
            )}
            {stop && MINIS.map((x, i) => {
              const k = kAt(tq, BRH + i / 12);
              if (k < 0 || k > 16) return null;
              const sc = k < 12 ? 1 : 1 - (k - 11) * 0.2;
              return <div key={i} style={{position: 'absolute', left: x + trayX - 12, top: 340 - k * 9 - (i % 2) * 20, transform: `scale(${Math.max(0, sc)})`}}><Star size={26} color="#FFF4E2" /></div>;
            })}
            <div style={{position: 'absolute', inset: 0, background: 'linear-gradient(115deg, transparent 30%, rgba(255,255,255,0.10) 38%, transparent 46%)'}} />
          </div>
        </Place>
        {/* heat shimmer above the oven */}
        {hot > 0.3 && [250, 430, 650, 830].map((x, i) => (
          <div key={x} style={{position: 'absolute', left: x, top: 340 - (hold % 4) * 6 - (i % 2) * 24}}><Wisp h={200} color={glowC} phase={hold * 1.1 + i * 2} width={12} /></div>
        ))}
        <Place x={860 - 125} y={330 - 125} w={250} h={250} s={pop(tq, 41.0)} origin="50% 50%" z={20}><Gauge d={250} a={needle} /></Place>
        <ClayLine text="OVEN" starts={[ON]} tq={tq} hold={hold} size={210} y={190} x={20} w={700} color={L.cream} seed={16} f="txtB" out={GEL - 2 / 12} />
        <ClayLine text="PANAS!" starts={[PAN]} tq={tq} hold={hold} size={190} y={200} x={20} w={700} color={L.tomato} seed={17} f="txtB" out={R3 - 2 / 12} />
      </Cam>
    </>
  );
};

// ================================ S8 — alcohol evaporates, crust browns, smells good ================================
const Crust: React.FC<SP> = ({tq, hold}) => {
  const MEN = a('menguap'), KUL = a('kulitnya'), BER = a('berubah'), COK = a('cokelat'), WAN = a('wangi');
  const bake = clamp01((kAt(tq, BER) + 1) / 5);
  const km = kAt(tq, MEN);
  const lj = jig(hold, 51, 0.5);
  return (
    <>
      <Cam tq={tq} from={50.8} to={54.9} impacts={[COK]} s0={1.22} fx0={540} fy0={1100}>
        <Backdrop set={SETS.cream} />
        <Crumbs seed={41} colors={[CRUST, DOUGH_DK, L.tomato]} top={1470} />
        <Contact x={540} y={1456} w={860} k={0.8} />
        <Clay f="slabB" style={{left: 120, top: 1392, width: 840, height: 64, borderRadius: 24, background: L.wood}}><Thumb x={700} y={30} r={24} rot={30} /></Clay>
        <Contact x={540} y={1398} w={620} k={0.9} />
        <Place x={540 - 350 + lj.x} y={1398 - 392} w={700} h={392} s={squish(kAt(tq, COK))}><Loaf w={700} bake={bake} /></Place>
        {/* alcohol wisps leave */}
        {(km < 8) && [400, 540, 680].map((x, i) => {
          const k = Math.max(-1, km);
          const sc = k < 0 ? 1 : 1 - k / 8;
          return <div key={x} style={{position: 'absolute', left: x - 36, top: 760 - Math.max(0, k) * 48 - (i % 2) * 30, transform: `scale(${sc})`, transformOrigin: '50% 100%'}}><Wisp h={240} color={L.lilac} phase={hold * 0.9 + i * 2.2} /></div>;
        })}
        {/* aroma */}
        {tq >= WAN - 1 / 12 && [420, 560, 700].map((x, i) => {
          const k = kAt(tq, WAN + i / 24);
          if (k < 0) return null;
          return <div key={x} style={{position: 'absolute', left: x - 38, top: 820 - Math.min(k, 8) * 14 - (i % 2) * 40, transform: `scale(${Math.min(1, 0.5 + k * 0.17)})`, transformOrigin: '50% 100%'}}><Wisp h={250} color={L.mustard} phase={hold * 0.8 + i * 1.9} width={18} /></div>;
        })}
        {tq >= WAN && [[300, 900, 56], [790, 860, 48], [860, 1040, 36], [230, 1060, 40]].map(([x, y, s], i) => {
          if (kAt(tq, WAN + i / 12) < 0) return null;
          const tw = (hold + i) % 4 < 2 ? 1 : 0.78;
          return <div key={i} style={{position: 'absolute', left: x - s / 2, top: y - s / 2, transform: `scale(${kAt(tq, WAN + i / 12) === 0 ? 1.3 : tw})`}}><Star size={s} color={i % 2 ? L.mustard : '#FFFFFF'} /></div>;
        })}
      </Cam>
      <ClayLine text="MENGUAP" starts={[MEN]} tq={tq} hold={hold} size={180} y={116} color={L.lilac} seed={18} f="txtB" out={KUL} />
      <ClayLine text="COKELAT" starts={[COK]} tq={tq} hold={hold} size={200} y={100} color={CRUST} seed={19} f="txtB" />
      <ClayLine text="& WANGI" starts={[WAN]} tq={tq} hold={hold} size={140} y={318} color={L.tomato} seed={20} />
    </>
  );
};

// ================================ S9 — the soft slice → countless yeast + gluten holding their breath; end card ================================
const ROWS = [
  {base: 990, w: 64, n: 12, f: 'fine'}, {base: 1100, w: 90, n: 10, f: 'fine'}, {base: 1222, w: 118, n: 8, f: 'txtA'}, {base: 1352, w: 150, n: 6, f: 'txtA'}, {base: 1500, w: 186, n: 5, f: 'slabC'},
];
const GNODES: [number, number][] = [];
for (let r = 0; r < 3; r++) for (let c = 0; c < 7; c++) GNODES.push([90 + c * 150 + (r % 2 ? 75 : 0), 540 + r * 150]);
const GLINKS: [number, number][] = [];
GNODES.forEach((p, i) => GNODES.forEach((q, k) => { if (k > i && Math.hypot(p[0] - q[0], p[1] - q[1]) < 175 && p[0] < 1000 && q[0] < 1000) GLINKS.push([i, k]); }));
GLINKS.sort((x, y) => Math.abs((GNODES[x[0]][0] + GNODES[x[1]][0]) / 2 - 540) - Math.abs((GNODES[y[0]][0] + GNODES[y[1]][0]) / 2 - 540));
const GBUBS: [number, number, number][] = [[165, 615, 100], [315, 615, 108], [465, 615, 102], [615, 615, 110], [765, 615, 100], [240, 765, 96], [390, 765, 106], [540, 765, 98], [690, 765, 108], [840, 765, 94]];

const Payoff: React.FC<SP> = ({tq, hold}) => {
  const MAK = a('makan', 1), EMP = a('empuk'), ING = a('ingat'), RG = a('ragi', 4), TAK = a('tak'), TER = a('terhitung'), JUM = a('jumlahnya');
  const JAR = a('jaringan', 1), GL = a('gluten', 2), MEN = a('menahan');
  const ki = kAt(tq, ING + 0.5);
  const IR = [0, 70, 200, 420, 760, 1200, 1700];
  const r = ki < 0 ? 0 : IR[Math.min(ki, IR.length - 1)];
  const sliceOn = r < 1700;
  const crowdOn = r > 0;
  const bk = kAt(tq, MAK);
  const bite = bk < 0 ? 0 : bk === 0 ? 0.6 : 1;
  const rowStart = [JUM, TER + 2 / 12, TER, a('kerja'), a('hasil') - 1 / 12];
  const puffing = tq >= MEN && tq < END;
  const kend = kAt(tq, END);
  const kl = kAt(tq, JAR);
  const linksOn = kl < 0 ? 0 : Math.min(GLINKS.length, (kl + 1) * 4);
  return (
    <>
      {sliceOn && (
        <Cam tq={tq} from={54.6} to={58.6} push={0.04} impacts={[MAK]}>
          <Backdrop set={SETS.rose} />
          <Crumbs seed={51} colors={[CRUST, '#F8E7C4', L.tomato]} top={1470} />
          <Contact x={540} y={1452} w={660} k={1} />
          <Place x={540 - 350} y={1452 - 784} w={700} h={784} s={squish(kAt(tq, EMP))}><Slice w={700} bite={bite} id="pay" /></Place>
          {bk >= 0 && bk < 5 && [0, 1, 2, 3].map((i) => (
            <Clay key={i} f="fine" style={{left: 790 + i * 28 + bk * (20 + i * 8), top: 760 - bk * (30 - bk * 7) + i * 14, width: 20 - i * 2, height: 18 - i * 2, borderRadius: '45%', background: i % 2 ? CRUST : '#F8E7C4', zIndex: 6}} />
          ))}
        </Cam>
      )}
      {crowdOn && (
        <AbsoluteFill style={{clipPath: r < 1700 ? `circle(${r}px at 540px 1130px)` : undefined}}>
          <Cam tq={tq} from={58.3} to={65.4} push={0.025} impacts={[TER, END]}>
            <AbsoluteFill style={{background: 'linear-gradient(180deg, #F9E8C6 0%, #F3DCB0 60%, #EBCB98 100%)'}} />
            {Array.from({length: 26}).map((_, i) => <div key={i} style={{position: 'absolute', left: rnd(i * 3.7) * 1080 - 40, top: rnd(i * 5.9) * 1800, width: 50 + rnd(i * 1.3) * 120, height: 36 + rnd(i * 2.9) * 80, borderRadius: '50%', background: 'rgba(214,170,105,0.28)'}} />)}
            <AbsoluteFill style={{background: 'radial-gradient(ellipse 85% 70% at 50% 50%, transparent 55%, rgba(120,70,30,0.28) 100%)'}} />
            {/* gluten net holding the gas above the crowd */}
            {linksOn > 0 && (
              <svg width={1080} height={560} viewBox="0 400 1080 560" style={{position: 'absolute', left: 0, top: 400, overflow: 'visible', willChange: LITE ? 'transform' : undefined}}>
                <ClayG f="txtA">
                  {GLINKS.slice(0, linksOn).map(([i, k], n) => {
                    const p = GNODES[i], q = GNODES[k];
                    return <path key={n} d={`M ${p[0]} ${p[1]} Q ${(p[0] + q[0]) / 2 + Math.sin(n + hold * 0.4) * 8} ${(p[1] + q[1]) / 2 + 14} ${q[0]} ${q[1]}`} stroke={GLUTEN} strokeWidth={14} strokeLinecap="round" fill="none" />;
                  })}
                </ClayG>
                <ClayG f="fine">
                  {GBUBS.map(([x, y, d], i) => {
                    const s = pop(tq, GL + (i % 5) / 24);
                    if (!s.on) return null;
                    const inf = puffing ? 1.14 : kend >= 0 && kend < 2 ? 0.92 : 1;
                    return <React.Fragment key={i}><circle cx={x} cy={y} r={(d / 2) * s.sx * inf} fill={cf(BUBBLE)} /><circle cx={x - d * 0.16} cy={y - d * 0.18} r={d * 0.09} fill="#FFFFFF" /></React.Fragment>;
                  })}
                </ClayG>
              </svg>
            )}
            {/* countless yeast */}
            {ROWS.map((row, ri) => {
              const items: CrowdItem[] = Array.from({length: row.n}).map((_, j) => {
                const span = 1080 - 120;
                const x = 60 + (span / (row.n - 1)) * j + (ri % 2 ? 18 : -18) + (rnd(ri * 13 + j) - 0.5) * 20;
                const order = Math.abs(j - (row.n - 1) / 2);
                const s = pop(tq, rowStart[ri] + order / 24);
                const mood: Mood = puffing ? 'puff' : kend >= 0 && kend < 3 ? 'relief' : kend >= 3 ? 'grin' : 'smile';
                const wave = LITE ? (hold + ri) % 4 < 2 : (hold + j * 3 + ri) % 4 < 2; // lite: a row changes pose together, every 2 holds
                return {x, base: row.base, w: row.w * (0.94 + rnd(ri * 7 + j) * 0.12), on: s.on, sx: s.sx, sy: s.sy, mood, arms: puffing ? 'down' : wave ? 'waveL' : 'waveR',
                  look: (hold + j) % 10 < 5 ? -4 : 4, blush: 0.5, color: [L.mustard, '#F6D06F', '#F8DA8A'][(j + ri) % 3] === L.mustard ? '#F3C65A' : [L.mustard, '#F6D06F', '#F8DA8A'][(j + ri) % 3]};
              });
              return <YeastRow key={ri} items={items} f={row.f} />;
            })}
            {/* end card hero */}
            {kend >= -1 && (() => {
              const s = pop(tq, END + 0.1);
              return <Place x={540 - 120} y={1540 - 288} w={240} h={288} s={s} z={10}><Yeast w={240} mood="grin" arms={(hold % 4) < 2 ? 'waveR' : 'up'} blush={0.9} /></Place>;
            })()}
            {kend >= 1 && [[300, 1180, 50], [780, 1160, 44], [880, 1290, 34], [200, 1300, 36]].map(([x, y, sz], i) => (
              <div key={i} style={{position: 'absolute', left: x - sz / 2, top: y - sz / 2, transform: `scale(${(hold + i) % 4 < 2 ? 1 : 0.78})`, zIndex: 11}}><Star size={sz} color={i % 2 ? L.mustard : '#FFFFFF'} /></div>
            ))}
          </Cam>
        </AbsoluteFill>
      )}
      {crowdOn && r < 1700 && (
        <svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0, overflow: 'visible', zIndex: 30}}>
          <ClayG f="slabA"><circle cx={540} cy={1130} r={r} fill="none" stroke={DOUGH_DK} strokeWidth={34} /></ClayG>
        </svg>
      )}
      <ClayLine text="ROTI EMPUK" starts={[a('roti', 1), EMP]} tq={tq} hold={hold} size={170} y={104} color={L.tomato} seed={21} f="txtB" out={ING + 0.15} />
      <ClayLine text="HASIL KERJA" starts={[a('hasil'), a('kerja')]} tq={tq} hold={hold} size={124} y={330} color={L.cocoa} seed={27} out={TAK - 2 / 12} />
      <ClayLine text="RAGI" starts={[RG]} tq={tq} hold={hold} size={230} y={84} color={L.mustard} seed={22} f="txtB" shade="#C98A1E" out={JAR - 2 / 12} />
      <ClayLine text="TAK TERHITUNG" starts={[TAK, TER]} tq={tq} hold={hold} size={108} y={330} color={L.teal} seed={23} out={JAR - 2 / 12} />
      <ClayLine text="GLUTEN" starts={[GL]} tq={tq} hold={hold} size={220} y={92} color={L.tomato} seed={24} f="txtB" out={END - 2 / 12} />
      <ClayLine text="RAGI + GLUTEN" starts={[END, END + 0.1, END + 0.2]} tq={tq} hold={hold} size={122} y={118} color={L.cocoa} seed={25} />
      <ClayLine text="= ROTI EMPUK" starts={[END + 0.3, END + 0.38, END + 0.46]} tq={tq} hold={hold} size={150} y={282} color={L.tomato} seed={26} f="txtB" />
    </>
  );
};

// ================================ timeline ================================
const TRS: TR[] = [
  {a: 8.55, b: 8.95, kind: 'roll'},
  {a: 24.55, b: 24.92, kind: 'slap', lip: SETS.peach.floor},
  {a: 32.82, b: 33.2, kind: 'roll'},
  {a: 40.9, b: 41.22, kind: 'slap', lip: SETS.oven.floor},
  {a: 50.82, b: 51.2, kind: 'roll'},
  {a: 54.55, b: 54.9, kind: 'slap', lip: '#E2ADA3'},
];
const SCENES: React.FC<SP>[] = [Kitchen, Micro, Knead, Balloons, OvenScene, Crust, Payoff];

// Draft renders before the music/SFX files exist: --props='{"draftNoAudio":true}' skips EpisodeAudio.
const DRAFT = (getInputProps() as {draftNoAudio?: boolean}).draftNoAudio === true;

export const RotiMengembangEpisode: React.FC = () => {
  const {t} = useTime();
  useLemFonts();
  const hold = Math.floor(t * HZ);
  return (
    <AbsoluteFill style={{background: SETS.cream.wall, overflow: 'hidden'}}>
      <StyleFonts />
      <ClayDefs hold={hold} />
      {!DRAFT && <EpisodeAudio vo="audio/vo/lempung.mp3" words={C.words} music="audio/music/lempung.wav" bed={0.5} duck={0.18} sfx={LEMPUNG_SFX} />}
      <Timeline t={t} scenes={SCENES} trs={TRS} />
      <Caption t={t} pages={PAGES} />
      <ClayGrads />
    </AbsoluteFill>
  );
};

// ================================ sound effects (lead renders the wavs from these names) ================================
const S = (name: string, t: number, vol = 0.6): Sfx => ({t: Math.max(0, t), src: `audio/sfx/lempung/${name}.wav`, vol});
export const LEMPUNG_SFX: Sfx[] = [
  // S1 kitchen
  S('plop', a('kenapa'), 0.55), S('stretch', a('mengembang'), 0.6), S('boing', a('dua'), 0.7),
  S('pop', a('makhluk'), 0.45), S('plop', a('super'), 0.5), S('ding', a('ragi'), 0.65),
  S('roll', 8.55, 0.6),
  // S2–S4 micro world
  S('boing', a('ragi', 1), 0.6), S('bubble', a('air'), 0.55), S('thud', a('gula'), 0.5), S('squish', a('makan'), 0.6),
  S('squish', a('buang'), 0.5), S('puff', a('gas'), 0.8), S('pop', a('karbon'), 0.6), S('plop', a('alkohol'), 0.5),
  S('stretch', a('kabur'), 0.55), S('boing', a('kok'), 0.6),
  S('slap', 24.86, 0.75),
  // S5 flour + kneading
  S('thud', a('tepung'), 0.7), S('squish', a('diuleni') + 0.17, 0.55), S('plop', a('air', 1), 0.55),
  S('stretch', a('membentuk'), 0.55), S('boing', a('elastis'), 0.75), S('ding', a('gluten'), 0.6),
  S('roll', 32.82, 0.6),
  // S6 balloons
  S('pop', a('jutaan'), 0.6), S('bubble', a('gelembung'), 0.55), S('pop', a('ditangkap'), 0.6), S('puff', a('menggembung'), 0.65),
  S('slap', 41.16, 0.75),
  // S7 oven
  S('roll', a('masuk'), 0.5), S('thud', a('oven'), 0.75), S('bubble', a('memuai'), 0.5),
  S('sizzle', a('suhunya'), 0.6), S('ding', a('panas'), 0.6),
  S('roll', 50.82, 0.55),
  // S8 crust
  S('bubble', a('menguap'), 0.45), S('sizzle', a('cokelat'), 0.45), S('ding', a('wangi'), 0.55),
  S('slap', 54.84, 0.7),
  // S9 payoff + end card
  S('squish', a('makan', 1), 0.6), S('boing', a('empuk'), 0.65), S('pop', a('ragi', 4), 0.55), S('pop', a('terhitung'), 0.6),
  S('stretch', a('jaringan', 1), 0.5), S('puff', a('menahan'), 0.5), S('ding', END, 0.7),
];
