// REFERENCE DEMO (ADSY MOTION GRAPH v1.9) — read for structure only: scenes, camera moves, word-pinned beats, SFX cues.
// Do NOT copy this story, its text or its layout into a buyer video. Written in the author's demo workspace, so a few
// imports differ from the starter: `makeCues(words)` ≈ the starter's `at()/endOf()` from src/lib/words.ts, and
// `EpisodeAudio` ≈ Main.tsx audio (musicFile + auto-duck) + <SfxTrack /> fed by src/audio-plan.json sfxCues.
// A `getInputProps()` draft switch, if present, was a workspace-only shortcut: do not copy it (the starter has --silent-draft).
import React from 'react';
import {AbsoluteFill, getInputProps} from 'remotion';
import {makeCues} from '../../lib/cues';
import {lerp, p, pio, rnd, StyleFonts, useTime} from '../../styles/shared';
import {EpisodeAudio, Sfx} from '../../styles/audio';
import {
  Banner, BOOK_CLOSED, CLOUD, BOOK_FLIP, BOOK_OPEN, buildPages, Buddy, BUDDY, Cells, CHECK, clamp01, COIN, CROSS, CRYSTAL, d25, d50, DayTile, DialogFrame,
  DialogText, DOCTOR, DUMBBELL, alignHop, alignWalk, FieldBg, FLAG_A, FLAG_B, FOOTPRINT, FRUIT, GEAR_A, GEAR_B, HEART, Hero, HOURGLASS_A, HOURGLASS_B, hop, Hud, LibraryBg,
  MenuBg, MINI, MINI_B, MIRROR, MOON, opening, P, PATIENT_FACE, PATIENT_WRAP, Pointer, PxDefs, pxShake, RaysBg, SkyBands, sn, Sparkle, SpiralWipe, Spr, step,
  Tag, tick, Trans, Tx, typed, useFontsReady, WATER, Win,
} from '../../styles/piksel/kit';
import wordsFile from './words.json';

// PIKSEL episode — "66 hari, bukan 21": the habit myth told as a 16-bit RPG. A hero and a calendar-buddy (the habit)
// walk a quest; the 21-day claim levels up then busts as MITOS; lore library → the 1960 book and its "minimal";
// a party of 96 players (UCL study, 2010); result screen 66 HARI → OTOMATIS; a tower from 18 to ~254 days;
// skipping a day is no GAME OVER (CONTINUE, progress kept); chase consistency; AUTO mode: the habit walks on its own.

const C = makeCues(wordsFile);
const a = C.at;
export const PIKSEL_DURATION = C.duration + 1.4;
const END = C.duration;

const T = {
  kebiasaan: a('kebiasaan'), n21: a('21'), sayangnya: a('sayangnya'), mitos: a('mitos'),
  angka: a('angka'), berasal: a('berasal'), buku: a('buku'), n1960: a('1960'), karya: a('karya'), dokter: a('dokter'), plastik: a('plastik'),
  ia: a('ia'), pasiennya: a('pasiennya'), minimal: a('minimal'), sekitar: a('sekitar'), n21c: a('21', 2), untuk: a('untuk'), wajah: a('wajah'), barunya: a('barunya'),
  lama: a('lama-lama'), kata: a('kata'), minimal2: a('minimal', 1), hilang: a('hilang'), jadilah: a('jadilah'), mitos2: a('mitos', 1),
  dalam: a('dalam studi'), studi: a('studi'), n2010: a('2010'), peneliti: a('peneliti'), university: a('university'), melacak: a('melacak'), n96: a('96'),
  membangun: a('membangun'), minum: a('minum'), makan: a('makan'), olahraga: a('olahraga'),
  hasilnya: a('hasilnya'), rata: a('rata-rata'), n66: a('66'), hari66: a('66 hari') + 0.5, sampai: a('sampai kebiasaan'), otomatis: a('otomatis'),
  dan: a('dan rentangnya'), lebar: a('lebar'), n18: a('18'), diperkirakan: a('diperkirakan'), n254: a('254'),
  kabar: a('kabar'), bolos: a('bolos'), nggak: a('nggak'), ulang: a('ulang'), nol: a('nol'), progresmu: a('progresmu'),
  jadi: a('jadi jangan'), kejar: a('kejar'), angkaAjaib: a('angka ajaib'), ajaib: a('ajaib'), kejar2: a('kejar', 1), konsistensi: a('konsistensi'),
  satu: a('satu hari', 1), langkah: a('langkah'), sampai3: a('sampai kebiasaan', 1), jalan2: a('jalan sendiri'), sendiri: a('sendiri'),
};
// scene transitions (each lands its new scene on the cue word)
const X1: [number, number] = [T.angka - 0.25, T.angka - 0.01];            // dissolve  MITOS → LORE
const X2: [number, number] = [T.ia - 0.3, T.ia - 0.01];                   // blinds    LORE → QUOTE
const X3: [number, number] = [T.dalam - 0.25, T.dalam - 0.01];            // squares   QUOTE → STUDY
const XS: [number, number] = [T.hasilnya - 0.52, T.hasilnya - 0.16];      // spiral cover  STUDY → RESULT
const XR: [number, number] = [T.hasilnya - 0.4, T.hasilnya - 0.02];       // spiral reveal
const X5: [number, number] = [T.dan - 0.3, T.dan - 0.01];                 // iris      RESULT → RANGE
const X6: [number, number] = [T.kabar - 0.25, T.kabar - 0.01];            // dissolve  RANGE → NO RESET
const X7: [number, number] = [T.jadi - 0.25, T.jadi - 0.01];              // squares   NO RESET → CONSISTENCY
const X8: [number, number] = [T.satu - 0.3, T.satu - 0.01];               // blinds    CONSISTENCY → FINALE

const BREAKS = [0, 7, 10, 18, 23, 27, 31, 36, 41, 43, 49, 54, 61, 67, 72, 77, 81, 86, 92, 97, 103, 106, 111, 113, 117, 122];
const PAGES = buildPages(C.words, BREAKS);

const fall = (k: number) => (k <= 0 ? 0 : sn(k * k * 700));
/** falling bits vanish after `lim` px, before they get fast enough to jump a whole flicker-scan cell per frame */
const gone = (k: number, lim = 110) => fall(k) > lim;

// ═════════════════════════ 1 · MITOS — the 21-day quest levels up… and busts ═════════════════════════
const Myth: React.FC<{t: number}> = ({t}) => {
  const scroll = Math.min(t, T.mitos) * 24;
  const day = Math.max(1, Math.min(21, Math.floor(((tick(t) - 0.1) / (T.n21 - 0.1)) * 20) + 1));
  const full = t >= T.n21, doubt = t >= T.sayangnya, busted = t >= T.mitos;
  const sh = pxShake(t, [T.mitos], 3);
  const hold = step(t, 8);
  return (
    <g>
      <FieldBg t={t} scroll={scroll} />
      <g transform={`translate(${sh.x} ${sh.y})`}>
        <Win x={12} y={54} w={246} h={74} tone="blue">
          <Tx x={24} y={62} c={P.yellow}>QUEST:</Tx>
          <Tx x={80} y={62}>{typed('KEBIASAAN BARU', t, T.kebiasaan)}</Tx>
          <Tx x={24} y={78} c={P.g1}>HARI</Tx>
          <Tx x={24} y={92} s={24} c={busted ? P.g2 : full ? P.yellow : P.white} sh={P.ink}>{String(day).padStart(2, '0')}</Tx>
          <Tx x={76} y={100} s={16} c={P.g1} sh={P.ink}>/21</Tx>
          <Tx x={132} y={78} c={P.g1}>PROGRES</Tx>
          {!busted ? (
            <Cells x={132} y={94} n={21} cw={4} h={14} color={(i) => (i < day ? (doubt ? P.g2 : i % 2 ? P.green : P.lime) : P.g3)} />
          ) : (
            <g>
              <rect x={131} y={93} width={106} height={16} fill={P.ink} />
              {Array.from({length: 21}).map((_, i) => {
                const k = t - T.mitos - ((i * 7) % 5) * 0.03;
                return gone(k, 90) ? null : <rect key={i} x={132 + i * 5 + sn(((i % 5) - 2) * Math.max(0, k) * 40)} y={94 + fall(k)} width={4} height={14} fill={i % 2 ? P.green : P.lime} />;
              })}
            </g>
          )}
        </Win>
        {full && !busted && (
          <g>
            <Banner y={136} open={opening(t, T.n21)} tone={doubt ? 'dark' : 'gold'} l1="KEBIASAAN" l2={doubt ? 'TERBENTUK?' : 'TERBENTUK!'} c1={doubt ? P.g1 : P.white} c2={doubt ? P.g1 : P.yellow} sh={doubt ? P.ink : P.red} />
            {doubt && Array.from({length: 6}).map((_, g) => (
              <rect key={g} x={sn(20 + rnd(hold * 3.1 + g) * 220)} y={sn(140 + rnd(hold * 5.7 + g * 2) * 38)} width={sn(6 + rnd(hold + g * 9) * 22)} height={2 + (g % 3)} fill={[P.red, P.ink, P.cyan][g % 3]} />
            ))}
            {!doubt && <><Sparkle x={18} y={132} t={t} at={T.n21 + 0.08} dur={0.8} /><Sparkle x={246} y={176} t={t} at={T.n21 + 0.2} dur={0.8} /><Sparkle x={236} y={132} t={t} at={T.n21 + 0.45} dur={0.6} /></>}
          </g>
        )}
        {busted && (
          <Win x={30} y={132} w={210} h={54} tone="red" open={opening(t, T.mitos, 0.08)}>
            <Tx x={135} y={145} s={32} a="middle" c={P.yellow} ol={P.ink} sh={P.plum}>MITOS!</Tx>
          </Win>
        )}
      </g>
      {/* the habit (buddy) and the player */}
      {t >= T.kebiasaan && t < T.n21 && <g transform={`translate(0 ${hop(t, T.kebiasaan, 3)})`}><Tag x={20} y={212} w={86} text="KEBIASAAN" tone="teal" c={P.lime} /></g>}
      <Buddy x={36} y={236} s={3} t={t} mood={busted ? 'sad' : 'happy'} hopping={t < alignHop(T.mitos)} />
      <Hero x={100} y={194 + hop(t, T.mitos, 8)} s={4} t={t} walk={t < alignWalk(T.mitos)} cheer={full && t < alignWalk(T.sayangnya)} />
      {doubt && !busted && <Tx x={170} y={186 + hop(t, T.sayangnya + 0.15, 4)} s={16} c={P.yellow} ol={P.ink}>?</Tx>}
      {busted && <Tx x={170} y={186 + hop(t, T.mitos, 6)} s={16} c={P.red} ol={P.ink}>!</Tx>}
    </g>
  );
};

// ═════════════════════════ 2 · ASAL-USUL — the 1960 book by a plastic surgeon ═════════════════════════
const Lore: React.FC<{t: number}> = ({t}) => {
  const dropQ = p(t, T.buku, T.buku + 0.2, (v) => v * v);
  const landed = t >= T.buku + 0.2;
  const bookY = sn(lerp(112, 146, dropQ)) + (landed && t < T.buku + 0.27 ? 2 : 0);
  const bookM = t < T.buku + 0.48 ? BOOK_CLOSED : t < T.buku + 0.6 ? BOOK_FLIP : BOOK_OPEN;
  const bookX = bookM === BOOK_CLOSED ? 74 : 56;
  const dashes = Math.floor(10 * p(t, T.berasal, T.buku - 0.05));
  const docX = sn(lerp(284, 176, pio(t, T.karya, T.karya + 0.5)));
  const docMoving = t > T.karya && t < T.karya + 0.5;
  return (
    <g>
      <LibraryBg t={t} />
      <g transform={`translate(0 ${hop(t, T.angka, 6) + (step(t, 2) % 2)})`}>
        <Tx x={135} y={60} s={48} a="middle" c={P.yellow} ol={P.ink} sh={P.red}>21</Tx>
      </g>
      <Sparkle x={70} y={62} t={t} at={T.angka + 0.05} dur={0.6} />
      <Sparkle x={196} y={92} t={t} at={T.angka + 0.2} dur={0.6} />
      {t < T.n1960 && <Tx x={135} y={118} a="middle" c={P.g1}>{t >= T.berasal ? 'BERASAL DARI...' : 'ASALNYA?'}</Tx>}
      {Array.from({length: dashes}).map((_, i) => <rect key={i} x={109} y={112 + i * 4} width={2} height={2} fill={P.yellow} />)}
      {t >= T.n1960 && (
        <g transform={`translate(0 ${hop(t, T.n1960 + 0.12, 3)})`}>
          <Win x={49} y={110} w={172} h={28} tone="gold" open={opening(t, T.n1960)}>
            <Tx x={135} y={116} s={16} a="middle" c={P.ink} sh={P.white}>TAHUN 1960</Tx>
          </Win>
        </g>
      )}
      <Sparkle x={42} y={106} t={t} at={T.n1960 + 0.12} dur={0.5} />
      <Sparkle x={222} y={132} t={t} at={T.n1960 + 0.2} dur={0.5} />
      {/* lectern + book */}
      {bookM === BOOK_OPEN && <rect x={50} y={140} width={120} height={60} fill={d25('yellow')} />}
      <rect x={66} y={200} width={88} height={6} fill={P.plum} />
      <rect x={66} y={200} width={88} height={1} fill={P.red} />
      <rect x={100} y={206} width={20} height={58} fill={P.plum} />
      <rect x={100} y={206} width={3} height={58} fill={P.red} />
      <rect x={82} y={262} width={56} height={6} fill={P.plum} />
      <rect x={66} y={206} width={88} height={2} fill={d50('ink')} />
      {t >= T.buku && <Spr m={bookM} x={bookX} y={bookY} s={3} />}
      {/* the author walks in */}
      {t >= T.karya && <Spr m={DOCTOR} x={docX} y={186 - (docMoving && step(t, 6) % 2 ? 1 : 0)} s={4} />}
      {t >= T.karya + 0.5 && <Tx x={240} y={172 + hop(t, T.karya + 0.5, 4)} s={16} c={P.yellow} ol={P.ink}>!</Tx>}
      <Win x={12} y={272} w={246} h={70} tone="blue">
        <Tx x={24} y={280} c={P.g1}>PENULIS:</Tx>
        {t < T.dokter ? (
          <Tx x={24} y={296} s={16} c={P.g2}>???</Tx>
        ) : (
          <>
            <Tx x={24} y={296} s={16} c={P.white} sh={P.ink}>{typed('DOKTER BEDAH', t, T.dokter)}</Tx>
            <Tx x={24} y={316} s={16} c={P.yellow} sh={P.ink}>{typed('PLASTIK', t, T.plastik)}</Tx>
          </>
        )}
      </Win>
    </g>
  );
};

// ═════════════════════════ 3 · KUTIPAN — "minimal sekitar 21 hari" … and the word that got lost ═════════════════════════
const Quote: React.FC<{t: number}> = ({t}) => {
  const shiftUp = -sn(22 * pio(t, T.hilang + 0.4, T.hilang + 0.62));
  const minShown = t >= T.minimal;
  const blinkMin = t >= T.minimal2 && t < T.hilang && step(t, 4) % 2;
  const sh = pxShake(t, [T.mitos2], 2);
  const phaseB = t >= T.lama;
  const chainT0 = T.hilang - 3 * 0.55;
  const k = Math.max(0, Math.min(4, Math.floor((t - chainT0) / 0.55)));
  const bubble = k <= 1 ? 'MINIMAL 21 HARI' : k === 2 ? 'MIN... 21 HARI' : '21 HARI!';
  return (
    <g>
      <LibraryBg t={t} />
      <g transform={`translate(${sh.x} ${sh.y})`}>
        <Win x={12} y={54} w={246} h={162} tone="page">
          <Tx x={24} y={62} c={P.plum}>BUKU (1960)</Tx>
          <Tx x={24} y={76} s={16} c={P.ink}>{typed('"PASIEN BUTUH', t, T.pasiennya)}</Tx>
          {t < T.pasiennya && step(t, 3) % 2 === 0 && <rect x={24} y={90} width={14} height={2} fill={P.ink} />}
          {t >= T.ia && t < T.pasiennya && <Tx x={238} y={62} a="end" c={P.red}>{typed('MENULIS...', t, T.ia + 0.15)}</Tx>}
          {minShown && (
            <g>
              {t < T.hilang + 0.25 && <rect x={22} y={96} width={116} height={20} fill={t >= T.hilang ? d50('red') : blinkMin ? P.orange : P.red} />}
              {[...'MINIMAL'].map((ch, j) => {
                const kk = t - T.hilang - j * 0.05;
                if (j >= typed('MINIMAL', t, T.minimal).length || gone(kk, 100)) return null;
                return <Tx key={j} x={24 + j * 16 + sn(Math.max(0, kk) * (j - 3) * 30)} y={99 + fall(kk)} s={16} c={P.white}>{ch}</Tx>;
              })}
            </g>
          )}
          <g transform={`translate(0 ${shiftUp})`}>
            <Tx x={24} y={120} s={16} c={P.ink}>{typed('SEKITAR', t, T.sekitar)}</Tx>
            <Tx x={24} y={142} s={24} c={P.red} sh={P.white}>{typed('21 HARI"', t, T.n21c)}</Tx>
            {t < T.jadilah && <Tx x={24} y={176} c={P.plum}>{typed('UNTUK TERBIASA DENGAN', t, T.untuk, 24)}</Tx>}
            {t < T.jadilah && <Tx x={24} y={188} c={P.plum}>{typed('WAJAH BARUNYA."', t, T.wajah, 24)}</Tx>}
          </g>
          {phaseB && t < T.jadilah && <rect x={15} y={57} width={240} height={156} fill={d25('yellow')} />}
        </Win>
        {t >= T.jadilah && (
          <Win x={12} y={166} w={246} h={30} tone="red" open={opening(t, T.jadilah)}>
            <Tx x={23} y={173} s={16} c={P.yellow} ol={P.ink} sh={P.plum}>{t < T.mitos2 ? 'JADILAH' : 'JADILAH MITOS!'}</Tx>
          </Win>
        )}
        <Sparkle x={236} y={160} t={t} at={T.mitos2 + 0.05} dur={0.5} />
      </g>
      <Win x={12} y={222} w={246} h={122} tone="dark">
        {!phaseB ? (
          <g>
            <Tx x={24} y={230} c={P.g1}>PASIEN</Tx>
            {t < T.wajah ? <Spr m={PATIENT_WRAP} x={28} y={262} s={3} /> : <Spr m={PATIENT_FACE} x={28} y={262} s={3} />}
            {t >= T.wajah && t < T.barunya + 0.4 && [0, 1, 2, 3, 4, 5].map((i) => {
              const kk = t - T.wajah - i * 0.04;
              return <rect key={i} x={34 + i * 7 + sn(Math.max(0, kk) * (i - 2.5) * 40)} y={266 + (i % 3) * 6 + fall(kk) / 4} width={6} height={3} fill={i % 2 ? P.white : P.g1} />;
            })}
            <Spr m={MIRROR} x={84} y={286} s={2} />
            {t >= T.barunya && <><Spr m={HEART} x={70} y={252 + hop(t, T.barunya, 4)} s={2} /><Sparkle x={22} y={262} t={t} at={T.barunya} dur={0.6} /><Sparkle x={104} y={282} t={t} at={T.barunya + 0.1} dur={0.6} /></>}
            <Tx x={128} y={230} c={t >= T.n21c ? P.yellow : P.g2}>MIN. 21 HARI</Tx>
            {Array.from({length: 21}).map((_, i) => {
              const c = i % 7, r = Math.floor(i / 7);
              const on = t >= T.n21c + 0.08 + r * 0.1;
              return <DayTile key={i} x={128 + c * 16} y={246 + r * 18 + (on && t < T.n21c + 0.15 + r * 0.1 ? -2 : 0)} w={13} h={13} dim={!on} />;
            })}
            {t >= T.untuk && <Tx x={128} y={308 + hop(t, T.untuk, 2)} c={P.lime}>UNTUK TERBIASA</Tx>}
          </g>
        ) : (
          <g>
            <Spr m={step(t, 2) % 2 ? HOURGLASS_B : HOURGLASS_A} x={22} y={230} s={3} />
            {[22, 68, 114, 160, 206].map((x, i) => {
              const at = T.lama + i * 0.08;
              if (t < at) return null;
              return <Spr key={i} m={step(t + i * 0.2, 4) % 2 ? MINI_B : MINI} x={x} y={300 + hop(t, at, 3) + (k === i && t >= chainT0 ? -3 : 0)} s={3} sub={{h: [P.ink, P.orange, P.plum, P.yellow, P.g2][i], S: [P.blue, P.red, P.teal, P.orange, P.green][i]}} />;
            })}
            {t >= chainT0 && (() => {
              const cx = [22, 68, 114, 160, 206][k] + 13;
              const w = bubble.length * 8 + 12;
              const bx = Math.max(16, Math.min(254 - w, cx - w / 2));
              return (
                <g transform={`translate(0 ${hop(t, chainT0 + k * 0.55, 2)})`}>
                  <Win x={bx} y={262} w={w} h={20} tone="page" shadow={false}>
                    <Tx x={bx + w / 2} y={268} a="middle" c={k >= 3 ? P.red : P.ink}>{bubble}</Tx>
                  </Win>
                  <rect x={cx - 2} y={282} width={4} height={4} fill={P.white} />
                  <rect x={cx - 1} y={286} width={2} height={4} fill={P.white} />
                </g>
              );
            })()}
          </g>
        )}
      </Win>
    </g>
  );
};

// ═════════════════════════ 4 · STUDI — UCL 2010, a party of 96 players ═════════════════════════
const HAIR = [P.ink, P.plum, P.orange, P.yellow, P.g2, P.red, P.white];
const GROUP = [{at: () => T.minum, c: P.sky}, {at: () => T.makan, c: P.red}, {at: () => T.olahraga, c: P.orange}];
const Study: React.FC<{t: number}> = ({t}) => {
  const appear = (c: number, r: number) => T.melacak + (c + r) * 0.045;
  let count = 0;
  const tq = tick(t);
  for (let r = 0; r < 8; r++) for (let c = 0; c < 12; c++) if (tq >= appear(c, r)) count++;
  const scanY = sn(lerp(132, 254, clamp01((t - T.melacak) / (T.n96 - T.melacak))));
  const items = [{m: WATER, s: 2, x: 48, y: 274, label: 'MINUM AIR'}, {m: FRUIT, s: 2, x: 124, y: 278, label: 'MAKAN BUAH'}, {m: DUMBBELL, s: 2, x: 198, y: 282, label: 'OLAHRAGA'}];
  const cur = t >= T.olahraga ? 2 : t >= T.makan ? 1 : t >= T.minum ? 0 : -1;
  return (
    <g>
      <MenuBg t={t} id="dotsStudy" />
      <Win x={12} y={54} w={246} h={52} tone="blue">
        <Tx x={24} y={62} c={P.yellow}>{t < T.studi ? 'LAPORAN' : typed('LAPORAN STUDI', t, T.studi - 0.35)}</Tx>
        {t >= T.n2010 && <g transform={`translate(0 ${hop(t, T.n2010 + 0.12, 3)})`}><Tag x={150} y={57} w={96} text="TERBIT 2010" tone="gold" c={P.ink} open={opening(t, T.n2010)} /></g>}
        <Tx x={24} y={78} c={P.g1}>{t >= T.peneliti ? 'PENELITI DARI:' : '...'}</Tx>
        <Tx x={24} y={91} c={P.white}>{typed('UNIVERSITY COLLEGE LONDON', t, T.university)}</Tx>
      </Win>
      <Sparkle x={240} y={52} t={t} at={T.n2010 + 0.1} dur={0.5} />
      <Win x={12} y={112} w={246} h={150} tone="dark">
        <Tx x={24} y={120} c={P.yellow}>PARTY</Tx>
        <Tx x={150} y={120} c={P.g1}>PEMAIN</Tx>
        <Tx x={206} y={116 + hop(t, T.n96, 3)} s={16} c={t >= T.n96 ? P.yellow : P.white} sh={P.ink}>{String(Math.min(96, count)).padStart(2, '0')}</Tx>
        {Array.from({length: 96}).map((_, i) => {
          const c = i % 12, r = Math.floor(i / 12);
          const at = appear(c, r);
          if (t < at) return <Spr key={i} m={MINI} x={31 + c * 18} y={134 + r * 15} tint={P.g3} tintK={P.ink} />;
          const g = GROUP[Math.floor(c / 4)];
          const shirt = t >= g.at() ? g.c : P.g1;
          const walk = t >= T.membangun && step(t + i * 0.07, 4) % 2;
          const dy = hop(t, at, 2) + hop(t, T.n96 + ((c * 3 + r) % 6) * 0.03, 2) + (t >= g.at() ? hop(t, g.at() + (r % 4) * 0.03, 3) : 0);
          return <Spr key={i} m={walk ? MINI_B : MINI} x={31 + c * 18} y={134 + r * 15 + dy} sub={{h: HAIR[(c * 7 + r * 3) % HAIR.length], S: shirt}} />;
        })}
        {t >= T.melacak && t < T.n96 + 0.1 && (
          <g>
            <rect x={16} y={scanY - 6} width={238} height={6} fill={d25('cyan')} />
            <rect x={16} y={scanY} width={238} height={2} fill={P.cyan} />
          </g>
        )}
      </Win>
      <Win x={12} y={268} w={246} h={76} tone="blue">
        {items.map((it, i) => {
          const at = [T.minum, T.makan, T.olahraga][i];
          const on = t >= at;
          const bx = [40, 119, 194][i];
          return (
            <g key={i}>
              <rect x={bx} y={274} width={36} height={32} fill={P.ink} />
              <rect x={bx + 1} y={275} width={34} height={30} fill={on ? P.deep : P.g3} />
              {on && <g transform={`translate(0 ${hop(t, at, 4)})`}><Spr m={it.m} x={it.x} y={it.y} s={it.s} /></g>}
              {on && <Spr m={CHECK} x={bx + 26} y={296} />}
              {!on && <Tx x={bx + 18} y={286} s={8} a="middle" c={P.g2}>?</Tx>}
              <rect x={bx} y={307} width={36} height={3} fill={on ? GROUP[i].c : P.g3} />
            </g>
          );
        })}
        {cur >= 0 ? (
          <Tx x={135} y={318 + hop(t, [T.minum, T.makan, T.olahraga][cur], 2)} s={16} a="middle" c={GROUP[cur].c} sh={P.ink}>{items[cur].label}</Tx>
        ) : (
          <Tx x={135} y={322} a="middle" c={P.g1}>{t >= T.membangun ? typed('MEMBANGUN KEBIASAAN BARU', t, T.membangun, 24) : 'KEBIASAAN: ???'}</Tx>
        )}
      </Win>
    </g>
  );
};

// ═════════════════════════ 5 · HASIL — average 66 days to OTOMATIS ═════════════════════════
const Result: React.FC<{t: number}> = ({t}) => {
  const slam = t >= T.n66;
  const kk = t - T.n66;
  const slamY = !slam ? 0 : kk < 0.05 ? -14 : kk < 0.1 ? -6 : kk < 0.15 ? 2 : 0;
  const roll = Math.floor(66 * p(tick(t), T.rata + 0.05, T.n66 - 0.03, (v) => v));
  const sh = pxShake(t, [T.n66], 3);
  const filled = Math.floor(66 * clamp01((t - T.sampai) / (T.otomatis - T.sampai)));
  const auto = t >= T.otomatis;
  return (
    <g>
      <RaysBg cx={135} cy={150} t={t} />
      <Banner y={54} open={opening(t, T.hasilnya)} tone="red" l1="HASIL STUDI" />
      <Sparkle x={20} y={52} t={t} at={T.hasilnya + 0.1} dur={0.5} />
      <g transform={`translate(${sh.x} ${sh.y})`}>
        <Tx x={135} y={94} s={16} a="middle" c={P.g1} sh={P.ink}>{typed('RATA-RATA', t, T.rata)}</Tx>
        {slam ? (
          <Tx x={135} y={116 + slamY} s={64} a="middle" c={P.yellow} ol={P.ink} sh={P.red}>66</Tx>
        ) : (
          <Tx x={135} y={116} s={64} a="middle" c={P.g2} sh={P.ink}>{t >= T.rata ? String(roll).padStart(2, '0') : '??'}</Tx>
        )}
        {t >= T.hari66 - 0.5 && <Tx x={135} y={180 + hop(t, T.hari66 - 0.5, 3)} s={16} a="middle" c={P.white} ol={P.ink}>HARI</Tx>}
      </g>
      {slam && <><Sparkle x={58} y={118} t={t} at={T.n66 + 0.05} dur={0.6} /><Sparkle x={206} y={160} t={t} at={T.n66 + 0.15} dur={0.6} /><Sparkle x={214} y={112} t={t} at={T.n66 + 0.3} dur={0.5} /></>}
      <Win x={12} y={204} w={246} h={58} tone="blue">
        <Tx x={24} y={212} c={P.g1}>KEBIASAAN</Tx>
        <Tx x={238} y={212} a="end" c={auto ? P.lime : P.g1}>OTOMATIS</Tx>
        <Cells x={25} y={228} n={66} cw={2} h={14} color={(i) => (i < filled ? (i % 2 ? P.green : P.lime) : P.g3)} />
        <Spr m={step(t, 8) % 2 && auto ? GEAR_B : GEAR_A} x={226} y={226} />
      </Win>
      {auto && <Banner y={268} open={opening(t, T.otomatis)} tone="gold" l1="OTOMATIS!" c1={P.white} sh={P.red} />}
      {auto && <><Sparkle x={20} y={266} t={t} at={T.otomatis + 0.08} dur={0.7} /><Sparkle x={244} y={290} t={t} at={T.otomatis + 0.18} dur={0.7} /></>}
      <Hero x={60} y={auto ? 300 : 302} s={2} t={t} walk={!auto} cheer={auto} />
      <Buddy x={178} y={310} s={2} t={t} />
      <Spr m={step(t, 8) % 2 ? GEAR_B : GEAR_A} x={118} y={308} s={2} />
    </g>
  );
};

// ═════════════════════════ 6 · RENTANG — from 18 to an estimated 254 days ═════════════════════════
const K = 1.6; // world px per day
const yw = (d: number) => 326 - d * K;
const OTHERS: Array<[number, number]> = [[25, 206], [31, 122], [38, 188], [44, 100], [52, 214], [59, 126], [74, 196], [85, 108], [97, 176], [112, 134], [130, 206], [155, 116], [185, 184], [220, 140]];
/** irregular brick courses (no fixed period, so the camera pan cannot alias) */
const BRICKS = (() => {
  const out: Array<{y: number; h: number; j1: number; j2: number}> = [];
  let y = 325, i = 0;
  while (y > -140) { const h = 6 + Math.floor(rnd(i * 3.3) * 5); out.push({y, h, j1: 6 + Math.floor(rnd(i * 5.1) * 14), j2: 24 + Math.floor(rnd(i * 7.7) * 16)}); y -= h; i++; }
  return out;
})();
const Range: React.FC<{t: number}> = ({t}) => {
  const cam = sn(300 * pio(t, T.diperkirakan, T.n254 - 0.05));
  const grow = Math.floor(30 * p(t, T.lebar, T.lebar + 0.7)) * 10;
  const htop = 140 + grow;
  const topY = 326 - htop;
  const sh = pxShake(t, [T.lebar + 0.7], 1);
  const climb = sn(lerp(372, 406, p(t, T.diperkirakan + 0.4, T.n254)));
  const cl = step(t, 5);
  return (
    <g transform={`translate(${sh.x} ${cam + sh.y})`}>
      <SkyBands bands={[[-300, 'deep'], [-70, 'blue'], [110, 'sky'], [220, 'cyan']]} to={330} />
      {[[30, -260], [90, -230], [160, -280], [220, -200], [60, -150], [200, -120], [120, -250]].map(([x, y], i) => <rect key={i} x={x} y={y} width={1} height={1} fill={(step(t + i * 0.37, 2) + i) % 3 ? P.white : P.g1} />)}
      {[[150, 20], [40, 160], [-60, 70], [-160, 190]].map(([y, x0], j) => (
        <Spr key={j} m={CLOUD} x={((x0 + cl * (1 + (j % 2))) % 340) - 40} y={y} />
      ))}
      {/* ground */}
      <rect x={0} y={326} width={270} height={300} fill={P.green} />
      <rect x={0} y={326} width={270} height={2} fill={P.lime} />
      <rect x={0} y={328} width={270} height={3} fill={d50('lime')} />
      {/* tower */}
      <rect x={27} y={topY} width={46} height={htop} fill={P.ink} />
      <rect x={28} y={topY} width={44} height={htop} fill={P.g2} />
      {BRICKS.filter((b) => b.y > topY).map((b, r) => (
        <g key={r}>
          <rect x={28} y={b.y} width={44} height={1} fill={P.g3} />
          <rect x={28 + b.j1} y={b.y - b.h + 1} width={1} height={b.h - 1} fill={P.g3} />
          <rect x={28 + b.j2} y={b.y - b.h + 1} width={1} height={b.h - 1} fill={P.g3} />
        </g>
      ))}
      <rect x={28} y={topY} width={3} height={htop} fill={P.g1} />
      {[0, 1, 2, 3, 4].map((i) => <rect key={i} x={27 + i * 10} y={topY - 6} width={6} height={6} fill={P.g2} stroke={P.ink} strokeWidth={0} />)}
      {Array.from({length: 27}).map((_, i) => {
        const d = i * 10, y = yw(d);
        return y > topY ? <rect key={i} x={74} y={y} width={i % 5 === 0 ? 7 : 3} height={1} fill={P.white} /> : null;
      })}

      {/* scattered players on ledges */}
      {OTHERS.map(([d, x], i) => (
        <g key={i}>
          <rect x={x - 2} y={yw(d)} width={13} height={2} fill={P.g1} />
          <rect x={x - 2} y={yw(d) + 2} width={13} height={1} fill={P.g3} />
          <Spr m={step(t + i * 0.21, 4) % 2 ? MINI_B : MINI} x={x} y={yw(d) - 11} sub={{h: HAIR[i % HAIR.length], S: [P.sky, P.red, P.orange][i % 3]}} />
        </g>
      ))}
      {t >= T.lebar + 0.25 && <g transform={`translate(0 ${hop(t, T.lebar + 0.25, 4)})`}><Tag x={96} y={64} w={128} text="LEBAR BANGET!" tone="red" c={P.yellow} open={opening(t, T.lebar + 0.25)} /></g>}
      <Sparkle x={226} y={58} t={t} at={T.lebar + 0.35} dur={0.5} />
      <Spr m={MOON} x={214} y={-196} />
      {/* 18: the fastest */}
      <rect x={92} y={yw(18)} width={26} height={3} fill={P.g1} />
      <Spr m={MINI} x={96} y={yw(18) - 22 + hop(t, T.n18, 5)} s={2} sub={{h: P.ink, S: P.lime}} />
      {t >= T.n18 && <Spr m={step(t, 4) % 2 ? FLAG_B : FLAG_A} x={120} y={yw(18) - 28} s={2} />}
      {t >= T.n18 && <g transform={`translate(0 ${hop(t, T.n18 + 0.1, 3)})`}><Tag x={146} y={yw(18) - 30} w={76} text="18 HARI" tone="gold" c={P.ink} open={opening(t, T.n18)} /></g>}
      <Sparkle x={140} y={yw(18) - 40} t={t} at={T.n18 + 0.1} dur={0.5} />
      {/* 66: the average */}
      <rect x={146} y={yw(66)} width={26} height={3} fill={P.g1} />
      <Spr m={MINI} x={150} y={yw(66) - 22} s={2} sub={{h: P.plum, S: P.yellow}} />
      <Tag x={100} y={yw(66) - 42} w={106} text="RATA-RATA 66" tone="dark" c={P.yellow} />
      {/* ~254: the slowest, estimated */}
      <rect x={96} y={yw(254)} width={30} height={3} fill={P.g1} />
      <Spr m={MINI} x={100} y={sn(326 - climb * 1) - 22 + (t >= T.n254 ? hop(t, T.n254, 5) : 0)} s={2} sub={{h: P.orange, S: P.red}} />
      {t >= T.n254 && <Spr m={step(t, 4) % 2 ? FLAG_B : FLAG_A} x={128} y={yw(254) - 28} s={2} />}
      {t >= T.diperkirakan + 0.5 && <Tag x={98} y={yw(254) - 82} w={82} text="PERKIRAAN" tone="dark" c={P.g1} open={opening(t, T.diperkirakan + 0.5)} />}
      {t >= T.n254 && <g transform={`translate(0 ${hop(t, T.n254 + 0.1, 3)})`}><Win x={66} y={yw(254) - 62} w={140} h={28} tone="gold" open={opening(t, T.n254)}><Tx x={136} y={yw(254) - 56} s={16} a="middle" c={P.ink} sh={P.white}>254 HARI</Tx></Win></g>}
      <Sparkle x={60} y={yw(254) - 60} t={t} at={T.n254 + 0.12} dur={0.6} />
      <Sparkle x={210} y={yw(254) - 40} t={t} at={T.n254 + 0.2} dur={0.6} />
    </g>
  );
};

// ═════════════════════════ 7 · BOLOS? — no GAME OVER, progress keeps going ═════════════════════════
const BOLOS_XW = 172 + (T.bolos + 0.15 - X6[0]) * 30;
const scrollNoReset = (t: number) => {
  const s0 = X6[0], stop = alignWalk(T.bolos + 0.15);
  if (t < stop) return (t - s0) * 30;
  const go = alignWalk(T.progresmu);
  if (t < go) return (stop - s0) * 30;
  return (stop - s0) * 30 + (t - go) * 40;
};
const NoReset: React.FC<{t: number}> = ({t}) => {
  const scroll = scrollNoReset(t);
  const walking = t < alignWalk(T.bolos + 0.15) || t >= alignWalk(T.progresmu);
  const hopping = t < alignHop(T.bolos + 0.15) || t >= alignHop(T.progresmu);
  const over = t >= T.nggak && t < T.progresmu;
  const cont = t >= T.progresmu;
  const sh = pxShake(t, [T.nol], 3);
  const base = 14;
  const prog = base + (t >= T.progresmu ? 1 : 0) + (t >= T.progresmu + 1.0 ? 1 : 0);
  const tiles = [-3, -2, -1, 0, 1, 2, 3].map((i) => BOLOS_XW + i * 52);
  return (
    <g>
      <FieldBg t={t} scroll={scroll} />
      <Win x={12} y={54} w={246} h={62} tone="blue">
        <Tx x={24} y={62} c={P.yellow}>PROGRES KEBIASAAN</Tx>
        <Cells x={24} y={78} n={33} cw={5} h={12} color={(i) => (i < base ? (i % 2 ? P.green : P.lime) : i === base && t >= T.bolos ? P.g2 : i < prog + (t >= T.bolos ? 1 : 0) && cont ? (i % 2 ? P.green : P.lime) : P.g3)} />
        <Spr m={CRYSTAL} x={228} y={70 + (step(t, 2) % 2)} tint={cont && t < T.progresmu + 0.2 ? P.white : undefined} />
        <Tx x={24} y={98} c={cont ? P.lime : t >= T.bolos ? P.orange : P.g1}>{cont ? typed('PROGRES TETAP JALAN', t, T.progresmu + 0.1) : t >= T.bolos ? 'HARI INI: BOLOS' : 'HARI INI: OK'}</Tx>
      </Win>
      {cont && <Sparkle x={24 + base * 6} y={72} t={t} at={T.progresmu} dur={0.6} />}
      {/* day tiles along the path */}
      {tiles.map((xw, i) => {
        const x = sn(xw - scroll);
        if (x < -24 || x > 280) return null;
        const isBolos = i === 3;
        const passed = x + 9 < 128 + (isBolos ? 0 : 0);
        return (
          <g key={i}>
            <DayTile x={x} y={262} w={18} h={16} dim={isBolos && t >= T.bolos} />
            {passed && !isBolos && <Spr m={CHECK} x={x + 4} y={248} />}
            {isBolos && t >= T.bolos && <g transform={`translate(0 ${hop(t, T.bolos, 3)})`}><Spr m={CROSS} x={x + 5} y={265} /><Tag x={x - 6} y={238} w={48} text="BOLOS" tone="red" /></g>}
          </g>
        );
      })}
      <Buddy x={40} y={236} s={3} t={t} hopping={hopping} mood={over ? 'sad' : 'happy'} />
      <Hero x={96} y={194} s={4} t={t} walk={walking} cheer={cont && t < T.progresmu + 0.5} />
      {t >= T.kabar && t < T.bolos && <g transform={`translate(0 ${hop(t, T.kabar, 4)})`}><Spr m={HEART} x={162} y={180} s={2} /></g>}
      <Sparkle x={150} y={176} t={t} at={T.kabar + 0.05} dur={0.6} />
      {t >= T.bolos + 0.15 && !cont && <Tx x={166} y={182 + hop(t, T.bolos + 0.15, 4)} s={16} c={P.yellow} ol={P.ink}>?</Tx>}
      <g transform={`translate(${sh.x} ${sh.y})`}>
        {over && (
          <Win x={30} y={124} w={210} h={60} tone="plum" open={opening(t, T.nggak)}>
            <Tx x={135} y={132} s={16} a="middle" c={P.red} ol={P.ink}>GAME OVER?</Tx>
            <Tx x={135} y={156} a="middle" c={P.g1}>{t >= T.ulang ? typed('ULANG DARI NOL?', t, T.ulang) : ''}</Tx>
            {t >= T.nol && <Spr m={CROSS} x={114} y={130 + hop(t, T.nol, 4)} s={6} />}
          </Win>
        )}
        {cont && (
          <Win x={30} y={124} w={210} h={60} tone="gold" open={opening(t, T.progresmu)}>
            <Tx x={135} y={132} s={16} a="middle" c={P.white} ol={P.ink} sh={P.red}>CONTINUE?</Tx>
            <Pointer x={60} y={153} t={t} />
            <Tx x={74} y={156} c={P.ink}>YA</Tx>
            <Tx x={150} y={156} c={P.plum}>TIDAK</Tx>
          </Win>
        )}
      </g>
    </g>
  );
};

// ═════════════════════════ 8 · KUNCINYA — don't chase magic numbers, chase consistency ═════════════════════════
const NUMS: Array<[string, number, number]> = [['21', 34, 92], ['66', 112, 76], ['254', 190, 96]];
const Consist: React.FC<{t: number}> = ({t}) => {
  const run = t >= alignWalk(T.kejar) && t < alignWalk(T.ajaib);
  const heroX = sn(lerp(20, 70, p(t, T.kejar, T.ajaib)));
  const unlocked = t >= T.konsistensi;
  return (
    <g>
      <MenuBg t={t} id="dotsKey" />
      {t >= T.angkaAjaib && <g transform={`translate(0 ${hop(t, T.angkaAjaib, 3)})`}><Tag x={83} y={56} w={104} text="ANGKA AJAIB" tone="dark" c={P.yellow} open={opening(t, T.angkaAjaib)} /></g>}
      {t >= T.ajaib && <rect x={80} y={63} width={110} height={2} fill={P.red} />}
      {NUMS.map(([n, x, y], i) => {
        const gone = t - T.ajaib - i * 0.06;
        const bob = step(t + i * 0.3, 3) % 2;
        if (gone > 0.5 || fall(gone - 0.2) > 90) return <Sparkle key={i} x={x + 18} y={y + 18} t={t} at={T.ajaib + i * 0.06 + 0.3} dur={0.4} />;
        return (
          <g key={i} transform={`translate(0 ${bob + (gone > 0.2 ? fall(gone - 0.2) : 0)})`}>
            <Spr m={COIN} x={x} y={y} s={2} />
            <Tx x={x + 22} y={y + 14} s={n.length > 2 ? 8 : 16} a="middle" c={P.plum}>{n}</Tx>
            {gone > 0 && <Spr m={CROSS} x={x + 8} y={y + 8} s={4} />}
          </g>
        );
      })}
      <Hero x={heroX} y={150} s={3} t={t} walk={run} />
      {run && <Tx x={heroX + 44} y={146 + hop(t, T.kejar, 3)} s={16} c={P.yellow} ol={P.ink}>!</Tx>}
      {t >= T.ajaib + 0.1 && <Tx x={heroX + 44} y={146 + hop(t, T.ajaib + 0.1, 3)} s={16} c={P.red} ol={P.ink}>?</Tx>}
      <Win x={12} y={218} w={246} h={126} tone="dark">
        {!unlocked ? (
          <Tx x={24} y={228} c={P.g1}>{t >= T.kejar2 ? 'KEJAR...' : 'SKILL BARU'}</Tx>
        ) : (
          <Banner y={224} open={opening(t, T.konsistensi)} tone="gold" l1="KONSISTENSI" c1={P.white} sh={P.red} />
        )}
        {Array.from({length: 7}).map((_, i) => {
          const at = T.kejar2 + i * 0.11;
          const on = t >= at;
          return (
            <g key={i} transform={`translate(0 ${hop(t, at, 3)})`}>
              <DayTile x={30 + i * 30} y={270} w={24} h={22} dim={!on} />
              {on && <Spr m={CHECK} x={33 + i * 30} y={276} />}
            </g>
          );
        })}
        {unlocked && <Tx x={135} y={312 + hop(t, T.konsistensi + 0.2, 2)} a="middle" c={P.lime}>SKILL TERBUKA!</Tx>}
        {unlocked && <><Sparkle x={20} y={220} t={t} at={T.konsistensi + 0.05} dur={0.6} /><Sparkle x={244} y={248} t={t} at={T.konsistensi + 0.15} dur={0.6} /></>}
      </Win>
    </g>
  );
};

// ═════════════════════════ 9 · AUTO — one day, one step, the habit walks on its own + end card ═════════════════════════
const Finale: React.FC<{t: number}> = ({t}) => {
  const k0 = X8[0];
  const heroStop = t >= alignWalk(T.sampai3);
  const scroll = (Math.min(t, alignWalk(T.sampai3)) - k0) * 22;
  const buddyX = sn(t < T.sampai3 ? 40 : lerp(40, 222, clamp01((t - T.sampai3) / 3.3)));
  const on = t >= T.jalan2;
  const knob = sn(lerp(0, 18, clamp01((t - T.jalan2) / 0.12)));
  const end = t >= END + 0.02;
  return (
    <g>
      <FieldBg t={t} scroll={scroll + (heroStop ? (t - T.sampai3) * 6 : 0)} dawn sunY={sn(lerp(196, 150, clamp01((t - k0) / 5)))} />
      {!end && <Win x={12} y={54} w={246} h={40} tone="blue">
        <Tx x={24} y={62} c={on ? P.lime : P.g1}>MODE OTOMATIS</Tx>
        <Tx x={24} y={76} c={P.g2}>KEBIASAAN JALAN SENDIRI</Tx>
        <rect x={200} y={64} width={40} height={18} fill={P.ink} />
        <rect x={201} y={65} width={38} height={16} fill={on ? P.green : P.g3} />
        <rect x={203 + knob} y={67} width={16} height={12} fill={P.white} />
      </Win>}
      {on && <Sparkle x={244} y={60} t={t} at={T.jalan2 + 0.05} dur={0.6} />}
      {!end && t >= T.satu && (
        <g transform={`translate(0 ${hop(t, T.satu, 4)})`}>
          <Tag x={40} y={112} w={88} text="1 HARI" tone="gold" c={P.ink} s={16} open={opening(t, T.satu)} />
        </g>
      )}
      {!end && t >= T.langkah && (
        <g transform={`translate(0 ${hop(t, T.langkah, 4)})`}>
          <Tag x={138} y={112} w={104} text="1 LANGKAH" tone="teal" c={P.lime} open={opening(t, T.langkah)} />
        </g>
      )}
      {t >= T.langkah && [0, 1, 2].map((i) => t >= T.langkah + i * 0.12 && <Spr key={i} m={FOOTPRINT} x={sn(86 - i * 14 - (scroll - (T.langkah - k0) * 22))} y={272 + (i % 2) * 4} />)}
      <Hero x={100} y={194 + (t >= T.langkah && t < T.langkah + 0.14 ? -4 : 0)} s={4} t={t} walk={!heroStop} cheer={t >= T.sendiri} />
      <Buddy x={buddyX} y={t < T.sampai3 ? 236 : 244} s={3} t={t} sub={BUDDY} />
      {buddyX > 160 && <g transform={`translate(0 ${hop(t, T.jalan2, 3)})`}><Tag x={Math.min(186, buddyX - 11)} y={222} w={70} text="AUTO" tone="teal" c={P.lime} /></g>}
      {t >= T.sendiri && <><Sparkle x={170} y={190} t={t} at={T.sendiri} dur={0.6} /><Sparkle x={84} y={200} t={t} at={T.sendiri + 0.12} dur={0.6} /></>}
      {end && (
        <g>
          <Win x={20} y={56} w={230} h={124} tone="blue" open={opening(t, END + 0.02, 0.14)}>
            <Tx x={135} y={68} s={24} a="middle" c={P.yellow} ol={P.ink} sh={P.red}>66 HARI,</Tx>
            <Tx x={135} y={98} s={24} a="middle" c={P.white} ol={P.ink} sh={P.plum}>BUKAN 21</Tx>
            <Tx x={135} y={134} a="middle" c={P.lime}>SATU HARI, SATU LANGKAH</Tx>
            {step(t - END, 2) % 2 === 0 && <g><Pointer x={70} y={153} t={t} still /><Tx x={84} y={156} c={P.white} sh={P.ink}>MULAI HARI INI</Tx></g>}
          </Win>
          <Sparkle x={24} y={50} t={t} at={END + 0.15} dur={1.2} />
          <Sparkle x={240} y={170} t={t} at={END + 0.3} dur={1.2} />
        </g>
      )}
    </g>
  );
};

// ═════════════════════════ episode ═════════════════════════
const CHAPTERS = ['MITOS', 'ASAL-USUL', 'STUDI', 'HASIL', 'RENTANG', 'BOLOS?', 'KUNCINYA'];
const mid = (w: [number, number]) => (w[0] + w[1]) / 2;
const chapterAt = (t: number) => (t < mid(X1) ? 0 : t < mid(X3) ? 1 : t < XS[1] ? 2 : t < mid(X5) ? 3 : t < mid(X6) ? 4 : t < mid(X7) ? 5 : 6);

const Scenes: React.FC<{t: number}> = ({t}) => {
  if (t < X1[0]) return <Myth t={t} />;
  if (t < X1[1]) return <Trans kind="dissolve" t={t} a={X1[0]} b={X1[1]} id="x1" from={<Myth t={t} />} to={<Lore t={t} />} />;
  if (t < X2[0]) return <Lore t={t} />;
  if (t < X2[1]) return <Trans kind="blinds" t={t} a={X2[0]} b={X2[1]} id="x2" from={<Lore t={t} />} to={<Quote t={t} />} />;
  if (t < X3[0]) return <Quote t={t} />;
  if (t < X3[1]) return <Trans kind="squares" t={t} a={X3[0]} b={X3[1]} id="x3" from={<Quote t={t} />} to={<Study t={t} />} />;
  if (t < XS[0]) return <Study t={t} />;
  if (t < XR[1]) return <><Study t={t} /><SpiralWipe t={t} cover={XS} reveal={XR} id="xs"><Result t={t} /></SpiralWipe></>;
  if (t < X5[0]) return <Result t={t} />;
  if (t < X5[1]) return <Trans kind="iris" t={t} a={X5[0]} b={X5[1]} id="x5" from={<Result t={t} />} to={<Range t={t} />} />;
  if (t < X6[0]) return <Range t={t} />;
  if (t < X6[1]) return <Trans kind="dissolve" t={t} a={X6[0]} b={X6[1]} id="x6" from={<Range t={t} />} to={<NoReset t={t} />} />;
  if (t < X7[0]) return <NoReset t={t} />;
  if (t < X7[1]) return <Trans kind="squares" t={t} a={X7[0]} b={X7[1]} id="x7" from={<NoReset t={t} />} to={<Consist t={t} />} />;
  if (t < X8[0]) return <Consist t={t} />;
  if (t < X8[1]) return <Trans kind="blinds" t={t} a={X8[0]} b={X8[1]} id="x8" from={<Consist t={t} />} to={<Finale t={t} />} />;
  return <Finale t={t} />;
};

export const EnamPuluhEnamEpisode: React.FC = () => {
  useFontsReady();
  const {t} = useTime();
  const draft = (getInputProps() as {draftNoAudio?: boolean}).draftNoAudio === true;
  const ended = t >= END + 0.02;
  return (
    <AbsoluteFill style={{background: P.ink}}>
      <StyleFonts />
      {/* music + SFX are generated later from plans/piksel.json and PIKSEL_SFX; picture-only drafts pass --props='{"draftNoAudio":true}' */}
      {!draft && <EpisodeAudio vo="audio/vo/piksel.mp3" words={C.words} music="audio/music/piksel.wav" bed={0.5} duck={0.18} sfx={PIKSEL_SFX} />}
      <svg width={1080} height={1920} viewBox="0 0 270 480" shapeRendering="crispEdges" style={{position: 'absolute', left: 0, top: 0}}>
        <PxDefs />
        <Scenes t={t} />
        <Hud chapter={ended ? 'TAMAT' : CHAPTERS[chapterAt(t)]} idx={ended ? 7 : chapterAt(t)} n={7} t={t} />
        <DialogFrame t={t} pages={PAGES} />
      </svg>
      <DialogText t={t} pages={PAGES} />
    </AbsoluteFill>
  );
};

// ═════════════════════════ SFX (names from the PIKSEL set only) ═════════════════════════
const s = (t: number, name: string, vol = 0.55): Sfx => ({t: Math.max(0, t), src: `audio/sfx/piksel/${name}.wav`, vol});
export const PIKSEL_SFX: Sfx[] = [
  // 1 mitos
  s(0.02, 'select', 0.35), s(T.kebiasaan, 'blip', 0.4), s(T.n21, 'levelup', 0.7), s(T.sayangnya, 'error', 0.55), s(T.mitos, 'hit', 0.8),
  // 2 lore
  s(X1[0], 'warp', 0.45), s(T.angka, 'blip', 0.5), s(T.buku + 0.18, 'jump', 0.5), s(T.n1960, 'confirm', 0.6), s(T.dokter, 'blip', 0.45),
  // 3 quote
  s(T.minimal, 'confirm', 0.55), s(T.n21c, 'coin', 0.55), s(T.wajah, 'heal', 0.55), s(T.lama, 'warp', 0.35), s(T.hilang, 'error', 0.55), s(T.mitos2, 'hit', 0.7),
  // 4 study
  s(X3[0], 'warp', 0.45), s(T.n2010, 'confirm', 0.55), s(T.melacak, 'powerup', 0.45), s(T.n96, 'coin', 0.65), s(T.minum, 'select', 0.5), s(T.makan, 'select', 0.5), s(T.olahraga, 'select', 0.55),
  // 5 result
  s(XS[0], 'warp', 0.55), s(T.rata, 'blip', 0.45), s(T.n66, 'hit', 0.85), s(T.otomatis, 'levelup', 0.75),
  // 6 range
  s(T.lebar, 'powerup', 0.55), s(T.n18, 'coin', 0.6), s(T.diperkirakan, 'jump', 0.4), s(T.n254, 'confirm', 0.65),
  // 7 no reset
  s(T.kabar, 'heal', 0.55), s(T.bolos, 'error', 0.5), s(T.nggak, 'blip', 0.5), s(T.nol, 'hit', 0.65), s(T.progresmu, 'confirm', 0.6),
  // 8 consistency
  s(X7[0], 'warp', 0.4), s(T.kejar, 'jump', 0.45), s(T.ajaib, 'error', 0.5), s(T.konsistensi, 'powerup', 0.65),
  // 9 finale
  s(T.satu, 'coin', 0.55), s(T.langkah, 'step', 0.5), s(T.jalan2, 'confirm', 0.55), s(T.sendiri, 'levelup', 0.7), s(END + 0.05, 'select', 0.45),
];
