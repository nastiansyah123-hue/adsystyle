// REFERENCE DEMO (ADSY MOTION GRAPH v1.9) — read for structure only: scenes, camera moves, word-pinned beats, SFX cues.
// Do NOT copy this story, its text or its layout into a buyer video. Written in the author's demo workspace, so a few
// imports differ from the starter: `makeCues(words)` ≈ the starter's `at()/endOf()` from src/lib/words.ts, and
// `EpisodeAudio` ≈ Main.tsx audio (musicFile + auto-duck) + <SfxTrack /> fed by src/audio-plan.json sfxCues.
// A `getInputProps()` draft switch, if present, was a workspace-only shortcut: do not copy it (the starter has --silent-draft).
import React from 'react';
import {AbsoluteFill, Easing, getInputProps} from 'remotion';
import {makeCues} from '../../lib/cues';
import {camera, lerp, p, pagesFor, pb, rnd, StyleFonts, useTime, World} from '../../styles/shared';
import {EpisodeAudio, Sfx} from '../../styles/audio';
import {
  Abs, Blob, Caption, Chip, Crystal, Dot, Drift, galonPath, Glass, gooFilter, GlassRect, Gloss, Goo, Headline, Hex, hexPts, inKidney, K,
  KidneyIcon, kidneyPath, mix, ps, Ring, Shot, Shots, SWATCH, tick, TONE, tumblerPath, txt, wave,
} from '../../styles/cair/kit';
import wordsFile from './words.json';

// CAIR episode — "Ginjal 180 liter": volume is liquid. 180 L a day fills a tank and nine galons, 3 L of plasma loops
// through a filter 60×, a million nephrons glow inside a glass kidney, one nephron presses fluid through a membrane,
// >99 % flows back to the blood, 1–2 L drips into a beaker, the colour scale is a daily report, and a glass of water ends it.

const C = makeCues(wordsFile);
const PAGES = pagesFor(C.words, 4, 24);
export const CAIR_DURATION = C.duration + 1.4;
const a = C.at;

const T = {
  saring: a('menyaring'), n180: a('180'), kira: a('kira-kira'), sembilan: a('9'),
  padahal: a('padahal'), plasma: a('plasma'), tiga: a('3'), artinya: a('artinya'), sama: a('cairan yang sama'), disaring: a('disaring'), bolak: a('bolak-balik'), enam: a('60'), kali: a('kali sehari'),
  didalam: a('di dalam'), setiap: a('setiap ginjal'), ada: a('ada sekitar'), sejuta: a('sejuta'), namanya: a('namanya'), nefron: a('nefron'),
  masuk: a('darah masuk'), tekan: a('ditekan'), halus: a('sangat halus'), sel: a('sel darah'), protein: a('protein'), tinggal: a('tetap tinggal'),
  air: a('air garam'), garam: a('garam'), gula: a('gula'), sisa: a('sisa metabolisme'), lolos: a('ikut lolos'),
  tunggu: a('tapi tunggu'), kalau: a('kalau 180'), l180: a('180', 1), kenapa: a('kenapa'), nggak: a('nggak pipis'), q180: a('180', 2),
  karena: a('karena'), hampir: a('hampir'), ambil: a('diambil lagi'), lebih: a('lebih dari'), n99: a('99'), kembali: a('kembali ke darah'),
  gulanya: a('gulanya'), semua: a('diambil semua'), garamnya: a('garamnya'), takar: a('ditakar'), pas: a('pas'),
  tersisa: a('yang tersisa'), satu: a('1 sampai'), dua: a('2 liter'), itulah: a('itulah'), seni: a('air seni'),
  makanya: a('makanya'), warna: a('warnanya'), laporan: a('laporan harian'), pucat: a('kuning pucat'), biasa: a('biasanya'), pekat: a('makin pekat'), hemat: a('ginjalmu lagi'),
  jadi: a('jadi sebelum'), scroll: a('lanjut scroll'), minum: a('minum dulu'), segelas: a('segelas'), sudah: a('ginjalmu sudah'),
};
const DIVE = {from: T.nefron + 0.35, to: T.nefron + 1.15}; // camera dives into one nephron
const DROP_AT = T.dua + 0.4; // the last 1–2 L falls into the beaker
const TAP_Y = 574; // mouth of the glass tap that fills the tumbler
const POUR_LAND = T.scroll + 0.72;

type Pt = [number, number];
const quad = (p0: Pt, c: Pt, p1: Pt, n = 24): Pt[] => Array.from({length: n + 1}, (_, i) => {
  const u = i / n;
  return [(1 - u) ** 2 * p0[0] + 2 * (1 - u) * u * c[0] + u * u * p1[0], (1 - u) ** 2 * p0[1] + 2 * (1 - u) * u * c[1] + u * u * p1[1]];
});
const along = (pts: Pt[], d: number): Pt | null => {
  if (d < 0) return null;
  for (let i = 1; i < pts.length; i++) {
    const [x0, y0] = pts[i - 1], [x1, y1] = pts[i];
    const L = Math.hypot(x1 - x0, y1 - y0);
    if (d <= L) return [lerp(x0, x1, L ? d / L : 0), lerp(y0, y1, L ? d / L : 0)];
    d -= L;
  }
  return null;
};
const svgAbs: React.CSSProperties = {position: 'absolute', left: 0, top: 0};

// ---------------------------------------------------------------- S1 — 180 litres a day, ≈ 9 galons
const S1 = (t: number) => {
  const tank = {x: 170, y: 500, w: 740, h: 880};
  const lvl = lerp(0.3, 0.8, ps(t, 0, T.n180 + 0.3));
  const level = tank.y + tank.h - tank.h * lvl;
  const hit = t >= T.n180 ? Math.max(0, 1 - (t - T.n180) / 1.3) : 0;
  const n = Math.round(lerp(0, 180, p(tick(t), 0.05, T.n180 + 0.02, Easing.out(Easing.cubic))));
  const out = ps(t, T.kira - 0.1, T.kira + 0.45);
  const bump = t > T.n180 ? Math.sin(Math.min(1, (t - T.n180) / 0.4) * Math.PI) : 0;
  const gal = [0, 1, 2, 3, 4, 5, 6, 7, 8].map((i) => ({cx: [240, 540, 840][i % 3], y0: [470, 790, 1110][Math.floor(i / 3)], i}));
  return (
    <Drift t={t} seed={1}>
      {out < 1 && (
        <div style={{position: 'absolute', inset: 0, opacity: 1 - out, transform: `scale(${1 - 0.14 * out})`, transformOrigin: '540px 940px'}}>
          <svg width={1080} height={1920} style={svgAbs}>
            <defs>
              <Goo id="g1" blur={14} />
              <clipPath id="tank1"><rect x={tank.x} y={tank.y} width={tank.w} height={tank.h} rx={90} /><rect x={430} y={300} width={220} height={260} /></clipPath>
            </defs>
            <g clipPath="url(#tank1)">
              <g {...gooFilter('g1')}>
                <path d={wave(tank.x - 40, tank.x + tank.w + 40, level, tank.y + tank.h + 40, t, 9 + 26 * hit)} fill={K.violet} />
                {Array.from({length: 40}).map((_, i) => {
                  const t0 = -0.9 + i * 0.13;
                  const dt = t - t0;
                  if (dt < 0 || t0 > T.kira - 0.4) return null;
                  const y = 320 + 0.5 * 2600 * dt * dt;
                  if (y > level + 20) return null;
                  return <circle key={i} cx={540 + (rnd(i) - 0.5) * 80} cy={y} r={17 + rnd(i + 3) * 9} fill={K.violet} />;
                })}
                {Array.from({length: 8}).map((_, i) => {
                  const dt = t - T.n180 - i * 0.02;
                  if (dt < 0 || dt > 1.4) return null;
                  const x = 540 + (rnd(i * 5) - 0.5) * 760 * dt;
                  const y = level - (760 + rnd(i * 9) * 420) * dt + 0.5 * 2600 * dt * dt;
                  return y < level + 10 ? <circle key={i} cx={x} cy={y} r={14 + rnd(i * 2) * 12} fill={K.violet} /> : null;
                })}
              </g>
              <path d={wave(tank.x, tank.x + tank.w, level + 22, tank.y + tank.h + 10, t + 0.4, 6 + 12 * hit, 3)} fill="#ffffff1c" />
              {Array.from({length: 16}).map((_, k) => {
                const life = 1.8 + rnd(k) * 1.4;
                const age = (t + rnd(k * 3) * 3) % life;
                const y = tank.y + tank.h - 30 - age * 300;
                return y > level + 26 ? <circle key={k} cx={tank.x + 80 + rnd(k * 7) * (tank.w - 160) + Math.sin(age * 5 + k) * 8} cy={y} r={6 + rnd(k * 5) * 12} fill="none" stroke="#ffffff" strokeOpacity={0.4} strokeWidth={3} /> : null;
              })}
            </g>
            <GlassRect x={tank.x} y={tank.y} w={tank.w} h={tank.h} r={90} />
            {[0.25, 0.5, 0.75].map((f) => {
              const y = tank.y + tank.h - tank.h * f;
              return <g key={f}><line x1={tank.x + tank.w - 90} x2={tank.x + tank.w - 36} y1={y} y2={y} stroke="#ffffff" strokeOpacity={0.55} strokeWidth={4} strokeLinecap="round" />
                <line x1={tank.x + tank.w - 64} x2={tank.x + tank.w - 36} y1={y + tank.h / 8} y2={y + tank.h / 8} stroke="#ffffff" strokeOpacity={0.35} strokeWidth={3} strokeLinecap="round" /></g>;
            })}
          </svg>
          <Abs center y={700} style={{transform: `scale(${1 + 0.07 * bump})`}}>
            <Glass style={{width: 600, padding: '30px 0 38px', textAlign: 'center'}}>
              <div style={{...txt(250, 800), fontVariantNumeric: 'tabular-nums', lineHeight: 1}}>{n}</div>
              <div style={{...txt(50, 600), letterSpacing: 10, marginTop: 6}}>LITER / HARI</div>
            </Glass>
          </Abs>
        </div>
      )}
      {out > 0 && (
        <svg width={1080} height={1920} style={svgAbs}>
          <defs>{gal.map((g) => <clipPath key={g.i} id={`gal${g.i}`}><path d={galonPath(g.cx, g.y0)} /></clipPath>)}</defs>
          {gal.map((g) => {
            const q = pb(t, T.kira + 0.05 + g.i * 0.05, T.kira + 0.45 + g.i * 0.05);
            const f = ps(t, T.kira + 0.3 + g.i * 0.1, T.kira + 0.85 + g.i * 0.1);
            if (q <= 0.001) return null;
            const lv = lerp(g.y0 + 272, g.y0 + 80, f);
            const cy = g.y0 + 140;
            return (
              <g key={g.i} transform={`translate(${g.cx} ${cy}) scale(${q}) translate(${-g.cx} ${-cy})`} opacity={Math.min(1, q * 2)}>
                <path d={galonPath(g.cx, g.y0)} fill="rgba(255,255,255,0.07)" />
                <g clipPath={`url(#gal${g.i})`}>
                  <path d={wave(g.cx - 100, g.cx + 100, lv, g.y0 + 290, t, 4 + 9 * (1 - f) * (f > 0 ? 1 : 0), g.i)} fill={K.cyan} />
                  <path d={wave(g.cx - 100, g.cx + 100, lv + 14, g.y0 + 290, t + 0.4, 4, g.i + 3)} fill="#ffffff22" />
                  <line x1={g.cx - 100} x2={g.cx + 100} y1={g.y0 + 165} y2={g.y0 + 165} stroke="#ffffff" strokeOpacity={0.2} strokeWidth={3} />
                  <line x1={g.cx - 100} x2={g.cx + 100} y1={g.y0 + 218} y2={g.y0 + 218} stroke="#ffffff" strokeOpacity={0.2} strokeWidth={3} />
                </g>
                <path d={galonPath(g.cx, g.y0)} fill="none" stroke="rgba(255,255,255,0.5)" strokeWidth={3} />
                <rect x={g.cx - 30} y={g.y0} width={60} height={28} rx={8} fill="rgba(255,255,255,0.45)" />
                <rect x={g.cx - 72} y={g.y0 + 120} width={12} height={110} rx={6} fill="#ffffff40" />
                <text x={g.cx + 4} y={g.y0 + 200} textAnchor="middle" fill={K.white} opacity={ps(t, T.kira + 0.5 + g.i * 0.1, T.kira + 0.8 + g.i * 0.1)} style={{...txt(64, 800)}}>{g.i + 1}</text>
              </g>
            );
          })}
        </svg>
      )}
      <Headline t={t} items={[
        {at: -1, text: 'Tiap hari'},
        {at: T.kira, text: '180 liter ≈'},
        {at: T.sembilan, text: <span>≈ <span style={{color: K.cyan}}>9 galon</span> air minum</span>},
      ]} />
    </Drift>
  );
};

// ---------------------------------------------------------------- S2 — only 3 L of plasma, filtered 60× a day
const RING = {x: 540, y: 900, r: 330};
// two slow laps, then the blob accelerates smoothly to 2 laps/s (capped so it never strobes); the counter races ahead
const LAP_W = Math.PI * 2 * 2, LAP_RAMP = 0.8;
const loopPhi = (t: number) => {
  const u = Math.max(0, t - (T.bolak + 0.9));
  return Math.PI * 2 * 1.55 * ps(t, T.sama - 0.1, T.bolak + 0.9) + (u < LAP_RAMP ? (LAP_W * u * u) / (2 * LAP_RAMP) : LAP_W * (LAP_RAMP / 2 + u - LAP_RAMP));
};

const S2 = (t: number) => {
  const shrink = pio2(t, T.artinya - 0.1, T.artinya + 0.8);
  const Mr = 290 * (1 - shrink);
  const My = lerp(700, RING.y, shrink);
  const Pq = pb(t, T.plasma - 0.1, T.plasma + 0.4);
  const ring = ps(t, T.artinya, T.sama + 0.2);
  const phi = loopPhi(t);
  const pos = (ph: number): Pt => [RING.x + RING.r * Math.cos(Math.PI / 2 - ph), RING.y + RING.r * Math.sin(Math.PI / 2 - ph)];
  const passes = phi >= Math.PI / 2 ? Math.floor((phi - Math.PI / 2) / (Math.PI * 2)) + 1 : 0;
  const n = t >= T.enam ? 60 : t < T.bolak + 0.9 ? passes : Math.min(60, Math.max(passes, Math.round(lerp(2, 60, p(tick(t), T.bolak + 0.9, T.enam, Easing.in(Easing.quad))))));
  const near = Math.cos(phi - Math.PI / 2); // 1 when the blob sits in the filter
  const glow = Math.max(0, near) ** 10;
  const pop60 = pb(t, T.enam - 0.05, T.enam + 0.35);
  const [px, py] = shrink > 0 ? pos(phi) : [540, 1235];
  return (
    <Drift t={t} seed={2}>
      <svg width={1080} height={1920} style={svgAbs}>
        <defs><Goo id="g2" blur={15} /></defs>
        {ring > 0 && (
          <g opacity={Math.min(1, ring * 1.5)}>
            <circle cx={RING.x} cy={RING.y} r={RING.r} fill="none" stroke="#ffffff" strokeOpacity={0.08} strokeWidth={96} pathLength={1} strokeDasharray={`${ring} 1`} transform={`rotate(90 ${RING.x} ${RING.y})`} />
            <circle cx={RING.x} cy={RING.y} r={RING.r + 48} fill="none" stroke="#ffffff" strokeOpacity={0.4} strokeWidth={3} pathLength={1} strokeDasharray={`${ring} 1`} transform={`rotate(90 ${RING.x} ${RING.y})`} />
            <circle cx={RING.x} cy={RING.y} r={RING.r - 48} fill="none" stroke="#ffffff" strokeOpacity={0.4} strokeWidth={3} pathLength={1} strokeDasharray={`${ring} 1`} transform={`rotate(90 ${RING.x} ${RING.y})`} />
            <circle cx={RING.x} cy={RING.y} r={RING.r - 28} fill="none" stroke="#ffffff" strokeOpacity={0.22} strokeWidth={8} strokeLinecap="round" pathLength={1} strokeDasharray={`${0.18 * ring} 1`} transform={`rotate(200 ${RING.x} ${RING.y})`} />
          </g>
        )}
        <g {...gooFilter('g2')}>
          <Blob x={540} y={My} r={Mr} fill={K.violet} t={t} seed={4} />
          {Pq > 0 && [0, 1, 2, 3, 4, 5, 6, 7].map((k) => {
            if (k > 0 && t < T.bolak) return null;
            const [x, y] = k === 0 ? [px, py] : pos(phi - k * Math.min(0.13, Math.max(0, (loopPhi(t) - loopPhi(t - 0.03)) * 0.7)));
            return <Blob key={k} x={x} y={y} r={(52 - k * 4) * Pq} fill={K.pink} t={t} seed={7 + k} />;
          })}
        </g>
        <Gloss x={540} y={My} r={Mr} />
        <Gloss x={px} y={py} r={52 * Pq} opacity={0.5} />
        {ring > 0.3 && (
          <g opacity={ps(t, T.sama, T.sama + 0.4)}>
            <rect x={RING.x + RING.r - 70} y={RING.y - 14} width={140} height={28} rx={10} fill="#ffffff" fillOpacity={0.18 + 0.4 * glow} stroke="#ffffff" strokeOpacity={0.7} strokeWidth={3} />
            {[0, 1, 2, 3, 4, 5].map((k) => <line key={k} x1={RING.x + RING.r - 56 + k * 22} x2={RING.x + RING.r - 56 + k * 22} y1={RING.y - 14} y2={RING.y + 14} stroke="#ffffff" strokeOpacity={0.6} strokeWidth={3} />)}
            <circle cx={RING.x + RING.r} cy={RING.y} r={70} fill={K.cyan} opacity={0.25 * glow} />
          </g>
        )}
      </svg>
      {Mr > 60 && (
        <Abs center y={590} o={(1 - ps(t, T.artinya - 0.1, T.artinya + 0.3)) * ps(t, T.padahal - 0.4, T.padahal)}>
          <div style={{textAlign: 'center'}}>
            <div style={txt(150, 800)}>180 L</div>
            <div style={{...txt(42, 500), opacity: 0.9, marginTop: 8}}>disaring / hari</div>
          </div>
        </Abs>
      )}
      <Abs x={612} y={1202}><Chip t={t} at={T.plasma} text="plasma darah" color={K.pink} size={36} out={T.artinya - 0.2} /></Abs>
      <Abs x={64} w={390} y={1170} o={ps(t, T.tiga - 0.1, T.tiga + 0.25) * (1 - ps(t, T.artinya - 0.2, T.artinya + 0.1))} style={{textAlign: 'right'}}>
        <div style={{...txt(40, 400), opacity: 0.85}}>cuma</div>
        <div style={txt(118, 800, K.pink)}>≈ 3 L</div>
      </Abs>
      {n > 0 && (
        <Abs center y={760} o={ps(t, T.disaring - 0.4, T.disaring - 0.1)}>
          <div style={{textAlign: 'center', transform: `scale(${0.85 + 0.15 * pop60})`}}>
            <div style={{...txt(230, 800), fontVariantNumeric: 'tabular-nums', lineHeight: 1}}>×{n}</div>
            <div style={{...txt(52, 600, K.white), marginTop: 6, opacity: ps(t, T.kali - 0.1, T.kali + 0.2), letterSpacing: 2}}>kali sehari</div>
          </div>
        </Abs>
      )}
      <Headline t={t} items={[{at: T.padahal, text: 'Padahal…'}, {at: T.sama, text: 'Cairan yang sama'}, {at: T.disaring, text: <span>Disaring <span style={{color: K.pink}}>bolak-balik</span></span>}]} />
    </Drift>
  );
};
function pio2(t: number, a0: number, b0: number) {
  return p(t, a0, b0, Easing.inOut(Easing.cubic));
}

// ---------------------------------------------------------------- S3 — a million mini filters: nephrons
const NEPH: Pt[] = (() => {
  const out: Pt[] = [];
  for (let k = 0; out.length < 150 && k < 2000; k++) {
    const x = (rnd(k * 1.7 + 0.3) - 0.5) * 300, y = (rnd(k * 2.3 + 5.1) - 0.5) * 440;
    if (inKidney(x, y)) out.push([x, y]);
  }
  return out;
})();
const KID = {y: 930, l: 310, r: 770, tilt: 9};
/** Kidney-local point (notch at +x) → world, for the kidney centred at cx (flip −1 = mirrored, tilted the other way). */
const kidWorld = (cx: number, flip: number, x: number, y: number): Pt => {
  const th = (KID.tilt * flip * Math.PI) / 180, xf = x * flip;
  return [cx + xf * Math.cos(th) - y * Math.sin(th), KID.y + xf * Math.sin(th) + y * Math.cos(th)];
};
const TARGET: Pt = kidWorld(KID.r, -1, -40, 40); // the nephron we dive into
const S3 = (t: number) => {
  const pose = camera(t, {x: 540, y: 930, s: 1, r: 0}, [
    {from: T.ada - 0.1, to: T.sejuta + 0.6, x: KID.r, y: KID.y + 20, s: 1.5},
    {from: DIVE.from, to: DIVE.to, x: TARGET[0], y: TARGET[1], s: 7},
  ]);
  const scr = (x: number, y: number): Pt => [540 + (x - pose.x) * pose.s, 960 + (y - pose.y) * pose.s];
  const kidney = (cx: number, flip: number, i: number) => {
    const q = pb(t, T.didalam - 0.25 + i * 0.14, T.didalam + 0.3 + i * 0.14);
    if (q <= 0.001) return null;
    const id = `kid${i}`;
    return (
      <g key={i} transform={`translate(${cx} ${KID.y}) scale(${q}) rotate(${KID.tilt * flip}) translate(${-cx} ${-KID.y})`}>
        <defs><clipPath id={id}><path d={kidneyPath(cx, KID.y, 1, flip)} /></clipPath></defs>
        <path d={kidneyPath(cx, KID.y, 1, flip)} fill="rgba(255,255,255,0.08)" />
        <g clipPath={`url(#${id})`}>
          <path d={wave(cx - 180, cx + 180, KID.y - 60, KID.y + 240, t, 8, i * 3)} fill={K.violet} opacity={0.85} />
          <path d={wave(cx - 180, cx + 180, KID.y - 40, KID.y + 240, t + 0.5, 6, i * 3 + 1)} fill="#ffffff18" />
        </g>
        <path d={kidneyPath(cx, KID.y, 1, flip)} fill="none" stroke="#ffffff" strokeOpacity={0.55} strokeWidth={4} />
        <ellipse cx={cx - 78 * flip} cy={KID.y - 118} rx={44} ry={19} fill="#fff" opacity={0.3} transform={`rotate(${-40 * flip} ${cx - 78 * flip} ${KID.y - 118})`} />
        {NEPH.map(([x, y], k) => {
          const d = Math.hypot(x, y) / 250;
          const qd = ps(t, T.sejuta - 0.25 + d * 0.6 + i * 0.1, T.sejuta + 0.1 + d * 0.6 + i * 0.1);
          if (qd <= 0.001) return null;
          return <circle key={k} cx={cx + x * flip} cy={KID.y + y} r={5.5 * qd} fill={k % 7 === 0 ? K.pink : '#ffffff'} opacity={0.55 + 0.45 * Math.sin(t * 3 + k)} />;
        })}
      </g>
    );
  };
  const [tx, ty] = scr(TARGET[0], TARGET[1]);
  const mark = ps(t, T.namanya - 0.1, T.namanya + 0.3) * (1 - ps(t, DIVE.from, DIVE.from + 0.3));
  const card = ps(t, T.namanya - 0.05, T.namanya + 0.35) * (1 - ps(t, DIVE.from - 0.15, DIVE.from + 0.15));
  return (
    <>
      <World pose={pose}>
        <svg width={1080} height={1920} style={svgAbs}>
          <g opacity={pb(t, T.didalam - 0.3, T.didalam + 0.2)}>
            <line x1={540} x2={540} y1={560} y2={1320} stroke={K.pink} strokeWidth={26} strokeLinecap="round" />
            <path d={`M 540 900 C 480 900 ${kidWorld(KID.l, 1, 62, 0)[0] + 40} ${kidWorld(KID.l, 1, 62, 0)[1]} ${kidWorld(KID.l, 1, 62, 0).join(" ")}`} fill="none" stroke={K.pink} strokeWidth={18} strokeLinecap="round" />
            <path d={`M 540 900 C 600 900 ${kidWorld(KID.r, -1, 62, 0)[0] - 40} ${kidWorld(KID.r, -1, 62, 0)[1]} ${kidWorld(KID.r, -1, 62, 0).join(" ")}`} fill="none" stroke={K.pink} strokeWidth={18} strokeLinecap="round" />
            <line x1={540} x2={540} y1={560} y2={1320} stroke="#ffffff" strokeOpacity={0.5} strokeWidth={6} strokeDasharray="10 30" strokeDashoffset={-t * 90} strokeLinecap="round" />
          </g>
          {kidney(KID.l, 1, 0)}
          {kidney(KID.r, -1, 1)}
          {/* the chosen nephron, in world space so the dive lands on it */}
          <circle cx={TARGET[0]} cy={TARGET[1]} r={6 + 2 * ps(t, T.namanya, T.namanya + 0.3)} fill={K.pink} opacity={ps(t, T.sejuta, T.sejuta + 0.4)} />
        </svg>
      </World>
      <svg width={1080} height={1920} style={svgAbs}>
        {mark > 0 && <circle cx={tx} cy={ty} r={30 + 8 * Math.sin(t * 6)} fill="none" stroke={K.pink} strokeWidth={4} opacity={mark} />}
        {card > 0 && <line x1={tx} x2={tx} y1={ty + 34} y2={1300} stroke="#ffffff" strokeOpacity={0.6 * card} strokeWidth={3} strokeDasharray="6 8" />}
      </svg>
      <Abs center y={1300} o={card} style={{transform: `translateY(${(1 - card) * 40}px)`}}>
        <Glass style={{padding: '22px 60px 30px', textAlign: 'center'}}>
          <div style={{...txt(36, 300)}}>namanya</div>
          <div style={{...txt(112, 800), height: 118 * ps(t, T.nefron - 0.15, T.nefron + 0.25), opacity: ps(t, T.nefron - 0.1, T.nefron + 0.2), background: `linear-gradient(90deg, ${K.pink}, ${K.amber})`, WebkitBackgroundClip: 'text', color: 'transparent'}}>nefron</div>
        </Glass>
      </Abs>
      <Abs center y={190} o={ps(t, T.sejuta - 0.1, T.sejuta + 0.3) * (1 - ps(t, DIVE.from - 0.2, DIVE.from + 0.1))} style={{transform: `translateY(${(1 - ps(t, T.sejuta - 0.1, T.sejuta + 0.4)) * 30}px)`}}>
        <Glass style={{padding: '24px 56px 30px', textAlign: 'center'}}>
          <div style={txt(124, 800)}>± 1 juta</div>
          <div style={{...txt(40, 500), opacity: 0.9, marginTop: 8}}>saringan mini di tiap ginjal</div>
        </Glass>
      </Abs>
      <Headline t={t} items={[{at: T.didalam - 0.2, text: <><KidneyIcon size={48} />Di dalam ginjal</>}]} until={T.sejuta - 0.15} />
    </>
  );
};

// ---------------------------------------------------------------- S4 — one nephron: pressed through a fine membrane
const BALL = {x: 400, y: 650, r: 165};
const MEM = {y: 862, h: 26, x0: 80, x1: 1000};
const BASIN = {x: 80, y: 860, w: 920, h: 620};
type Kind = 'air' | 'garam' | 'gula' | 'sisa';
const DROPS: Array<{kind: Kind; from: number; every: number}> = [
  {kind: 'air', from: T.tekan + 0.3, every: 0.09},
  {kind: 'garam', from: T.garam - 0.05, every: 0.2},
  {kind: 'gula', from: T.gula - 0.05, every: 0.2},
  {kind: 'sisa', from: T.sisa - 0.05, every: 0.22},
];
const DROP_END = T.lolos + 1.5;
const DROP_V = 120, DROP_G = 700; // px/s, px/s² — slow enough to read each kind
const basinLevel = (t: number) => lerp(1330, 1175, ps(t, T.tekan + 0.6, T.lolos + 0.6));
const dropShape = (kind: Kind, x: number, y: number, k: number) => {
  if (kind === 'air') return <circle key={k} cx={x} cy={y} r={11} fill={K.cyan} />;
  if (kind === 'garam') return <rect key={k} x={x - 8} y={y - 8} width={16} height={16} rx={3} fill="#ffffff" transform={`rotate(${45 + k * 17} ${x} ${y})`} />;
  if (kind === 'gula') return <polygon key={k} points={hexPts(x, y, 11)} fill={K.amber} />;
  return <circle key={k} cx={x} cy={y} r={8} fill="none" stroke="#ffffff" strokeWidth={4} />;
};
const S4 = (t: number) => {
  const tf = Math.min(t, T.tunggu + 0.03); // "Tapi tunggu" freezes the nephron
  const dive = ps(t, DIVE.from + 0.1, DIVE.to);
  const press = ps(tf, T.tekan - 0.1, T.tekan + 0.3) * (0.5 - 0.5 * Math.cos((Math.PI * 2 * Math.max(0, tf - T.tekan)) / 0.95));
  const by = BALL.y + 14 * press;
  const lv = basinLevel(tf);
  const flow = 260 * Math.max(0, tf - (T.masuk - 0.5));
  const lens = pb(t, T.halus - 0.15, T.halus + 0.3) * (1 - ps(t, T.sel - 0.3, T.sel));
  const bumpOf = (delay: number) => Math.sin(Math.PI * Math.max(0, Math.min(1, (tf - T.tinggal - delay) / 0.75)));
  const freeze = ps(t, T.tunggu - 0.05, T.tunggu + 0.3);
  return (
    <div style={{position: 'absolute', inset: 0, transform: `scale(${1 + 0.05 * ps(t, T.tunggu, T.tunggu + 1.2)})`, transformOrigin: '540px 860px'}}>
      <div style={{position: 'absolute', inset: 0, transformOrigin: `${BALL.x}px ${BALL.y}px`, transform: `translate(${(540 - BALL.x) * (1 - dive)}px, ${(960 - BALL.y) * (1 - dive)}px) scale(${lerp(0.2, 1, dive)})`}}>
        <Drift t={tf} seed={4} amt={0.7}>
          <svg width={1080} height={1920} style={svgAbs}>
            <defs>
              <Goo id="g4" blur={15} />
              <clipPath id="basin4"><rect x={BASIN.x} y={BASIN.y} width={BASIN.w} height={BASIN.h} rx={48} /></clipPath>
              <clipPath id="lens4"><circle cx={790} cy={875} r={120} /></clipPath>
            </defs>
            {/* basin + filtrate */}
            <GlassRect x={BASIN.x} y={BASIN.y} w={BASIN.w} h={BASIN.h} r={48} />
            <g clipPath="url(#basin4)">
              <path d={wave(BASIN.x, BASIN.x + BASIN.w, lv, BASIN.y + BASIN.h + 10, tf, 8)} fill={K.violet} opacity={0.75} />
              <path d={wave(BASIN.x, BASIN.x + BASIN.w, lv + 16, BASIN.y + BASIN.h + 10, tf + 0.4, 5, 2)} fill="#ffffff18" />
            </g>
            {/* falling drops (only the small stuff passes) */}
            {DROPS.map((dr) => Array.from({length: Math.ceil((DROP_END - dr.from) / dr.every) + 1}).map((_, k) => {
              const t0 = dr.from + k * dr.every;
              const dt = tf - t0;
              if (dt < 0 || t0 > DROP_END) return null;
              const x = 262 + rnd(k * 3.7 + dr.every * 10) * 276;
              const y = 820 + DROP_V * dt + 0.5 * DROP_G * dt * dt;
              if (y > basinLevel(t0 + dt) + 4) {
                const land = (Math.sqrt(DROP_V * DROP_V + 2 * DROP_G * (lv - 820)) - DROP_V) / DROP_G;
                const age = dt - land;
                return dr.kind === 'air' && age < 0.45 ? <ellipse key={`${dr.kind}${k}`} cx={x} cy={lv} rx={12 + 60 * age} ry={4 + 10 * age} fill="none" stroke="#ffffff" strokeOpacity={0.5 * (1 - age / 0.45)} strokeWidth={3} /> : null;
              }
              return dropShape(dr.kind, x, y, k);
            }))}
            {/* blood in → glomerulus ball */}
            <g {...gooFilter('g4')}>
              <rect x={-80} y={BALL.y - 40} width={420} height={80} rx={40} fill={K.pink} />
              <g transform={`translate(${BALL.x} ${by}) scale(${1 + 0.07 * press} ${1 - 0.09 * press}) translate(${-BALL.x} ${-BALL.y})`}>
                <Blob x={BALL.x} y={BALL.y} r={BALL.r} fill={K.pink} t={tf} seed={11} />
              </g>
            </g>
            {Array.from({length: 8}).map((_, k) => {
              const x = -40 + ((flow + k * 46) % 340);
              return <circle key={k} cx={x} cy={BALL.y + Math.sin(k * 2.1) * 16} r={9} fill="#ffffff" opacity={0.45 * Math.min(1, (300 - x) / 60)} />;
            })}
            <Gloss x={BALL.x} y={by} r={BALL.r} opacity={0.32} />
            {/* cells that stay: red cells + proteins */}
            {[0, 1, 2, 3].map((i) => {
              const q = pb(tf, T.sel - 0.05 + i * 0.08, T.sel + 0.35 + i * 0.08);
              if (q <= 0.001) return null;
              const ang = i * Math.PI / 2 + tf * 0.6;
              const x0 = BALL.x + Math.cos(ang) * 82, y0 = by + Math.sin(ang) * 70;
              const y = lerp(y0, MEM.y - 32, bumpOf(i * 0.06) * 0.95);
              return (
                <g key={i} transform={`translate(${x0} ${y}) scale(${q})`}>
                  <circle r={30} fill={TONE.raspberry} stroke="#ffffff" strokeOpacity={0.7} strokeWidth={3} />
                  <circle r={13} fill="#FF8CC0" />
                </g>
              );
            })}
            {[0, 1, 2, 3].map((i) => {
              const q = pb(tf, T.protein - 0.05 + i * 0.08, T.protein + 0.35 + i * 0.08);
              if (q <= 0.001) return null;
              const ang = i * Math.PI / 2 + Math.PI / 4 - tf * 0.5;
              const x0 = BALL.x + Math.cos(ang) * 112, y0 = by + Math.sin(ang) * 96;
              const y = lerp(y0, MEM.y - 24, bumpOf(0.25 + i * 0.06) * 0.95);
              return (
                <g key={i} transform={`translate(${x0} ${y}) rotate(${tf * 60 + i * 50}) scale(${q})`}>
                  {[-1, 0, 1].map((j) => <circle key={j} cx={j * 19} cy={j === 0 ? -6 : 4} r={12} fill={K.violet} stroke="#ffffff" strokeOpacity={0.8} strokeWidth={2.5} />)}
                </g>
              );
            })}
            {/* the membrane: segments with fine pores */}
            <rect x={MEM.x0} y={MEM.y} width={MEM.x1 - MEM.x0} height={MEM.h} rx={12} fill="#ffffff" fillOpacity={0.06} />
            {Array.from({length: 28}).map((_, i) => {
              const x = MEM.x0 + 6 + i * 32.6;
              const hitGlow = Math.max(bumpOf(0.2), bumpOf(0.45)) * (x > 230 && x < 580 ? 1 : 0);
              return <rect key={i} x={x} y={MEM.y + 2} width={24} height={MEM.h - 4} rx={6} fill="#ffffff" fillOpacity={0.3 + 0.5 * hitGlow} stroke="#ffffff" strokeOpacity={0.55} strokeWidth={2} />;
            })}
            {/* magnifier on the membrane */}
            {lens > 0.001 && (
              <g opacity={Math.min(1, lens)} transform={`translate(790 875) scale(${lens}) translate(-790 -875)`}>
                <line x1={875} y1={960} x2={950} y2={1035} stroke="#ffffff" strokeOpacity={0.65} strokeWidth={20} strokeLinecap="round" />
                <circle cx={790} cy={875} r={120} fill={TONE.deep} fillOpacity={0.6} />
                <g clipPath="url(#lens4)">
                  <g transform="translate(790 875) scale(2.6) translate(-790 -875)">
                    {Array.from({length: 10}).map((_, i) => <rect key={i} x={MEM.x0 + 6 + (i + 20) * 32.6} y={MEM.y + 2} width={24} height={MEM.h - 4} rx={6} fill="#ffffff" fillOpacity={0.45} stroke="#ffffff" strokeOpacity={0.8} strokeWidth={1.5} />)}
                  </g>
                  {[0, 1, 2].map((k) => <circle key={k} cx={790 - 85 + k * 85} cy={((t * 160 + k * 70) % 260) + 745} r={9} fill={K.cyan} />)}
                </g>
                <circle cx={790} cy={875} r={120} fill="none" stroke="#ffffff" strokeOpacity={0.8} strokeWidth={7} />
                <ellipse cx={745} cy={815} rx={40} ry={16} fill="#fff" opacity={0.3} transform="rotate(-35 745 815)" />
              </g>
            )}
          </svg>
          <Abs x={64} y={448} o={ps(tf, T.masuk - 0.1, T.masuk + 0.25)} style={{transform: `translateX(${(1 - ps(tf, T.masuk - 0.1, T.masuk + 0.4)) * -30}px)`}}>
            <div style={{...txt(36, 700), display: 'flex', alignItems: 'center', gap: 10}}><Dot color={K.pink} size={16} />darah masuk →</div>
          </Abs>
          <Abs x={610} y={418} o={ps(tf, T.tinggal - 0.1, T.tinggal + 0.25)}><div style={{...txt(32, 700), letterSpacing: 6, opacity: 0.85}}>TETAP TINGGAL</div></Abs>
          <Abs x={610} y={478}><Chip t={tf} at={T.sel} text="Sel darah" icon={<div style={{width: 26, height: 26, borderRadius: 13, background: TONE.raspberry, border: '3px solid #FF8CC0'}} />} /></Abs>
          <Abs x={610} y={572}><Chip t={tf} at={T.protein} text="Protein" color={K.violet} /></Abs>
          <Abs x={110} y={918} o={ps(tf, T.lolos - 0.1, T.lolos + 0.25)}><div style={{...txt(32, 700), letterSpacing: 6, opacity: 0.85}}>IKUT LOLOS ↓</div></Abs>
          <div style={{position: 'absolute', left: 104, top: 980, width: 880, display: 'flex', flexWrap: 'wrap', gap: 18}}>
            <Chip t={tf} at={T.air} text="Air" color={K.cyan} />
            <Chip t={tf} at={T.garam} text="Garam" icon={<Crystal />} />
            <Chip t={tf} at={T.gula} text="Gula" icon={<Hex />} />
            <Chip t={tf} at={T.sisa} text="Sisa metabolisme" icon={<Ring />} />
          </div>
        </Drift>
      </div>
      <Headline t={tf} items={[
        {at: T.masuk - 0.3, text: <><KidneyIcon size={46} />Nefron</>},
        {at: T.tekan, text: 'Ditekan lewat saringan'},
        {at: T.halus, text: <span>Saringan <span style={{color: K.cyan}}>sangat halus</span></span>},
        {at: T.sel, text: 'Tinggal atau lolos?'},
      ]} />
      {freeze > 0 && (
        <>
          <div style={{position: 'absolute', inset: -100, background: K.night, opacity: 0.5 * freeze}} />
          <Abs center y={800} o={freeze} style={{transform: `scale(${0.8 + 0.2 * pb(t, T.tunggu - 0.05, T.tunggu + 0.35)})`}}>
            <Glass style={{padding: '30px 56px', display: 'flex', alignItems: 'center', gap: 30}}>
              <div style={{display: 'flex', gap: 12}}><div style={{width: 18, height: 64, borderRadius: 9, background: K.white}} /><div style={{width: 18, height: 64, borderRadius: 9, background: K.white}} /></div>
              <div style={txt(84, 800)}>Tapi tunggu…</div>
            </Glass>
          </Abs>
        </>
      )}
    </div>
  );
};

// ---------------------------------------------------------------- S5 — why don't we pee 180 L?
const S5 = (t: number) => {
  const line = (at: number): React.CSSProperties => ({display: 'inline-block', opacity: ps(t, at - 0.1, at + 0.25), transform: `translateY(${(1 - ps(t, at - 0.1, at + 0.35)) * 30}px)`});
  // big lines open their own space as they arrive, so the card grows instead of showing an empty slab
  const grow = (at: number): React.CSSProperties => ({...txt(108, 800), height: 114 * ps(t, at - 0.15, at + 0.3), opacity: ps(t, at - 0.05, at + 0.3), transform: `translateY(${(1 - ps(t, at - 0.1, at + 0.35)) * 24}px)`});
  const card = pb(t, T.kalau - 0.1, T.kalau + 0.35);
  // the question mark fills with liquid while the question builds
  const rise = ps(t, T.kalau - 0.25, T.kalau + 0.7);
  const qy = 860 + (1 - rise) * 160;
  const lvl = lerp(qy + 30, qy - 690, ps(t, T.kalau, T.q180 + 0.6));
  const Q = (fill: string) => <text x={540} y={qy} textAnchor="middle" fill={fill} style={{fontFamily: txt(10).fontFamily, fontWeight: 800, fontSize: 900}}>?</text>;
  return (
    <Drift t={t} seed={5}>
      <svg width={1080} height={1920} style={svgAbs}>
        <defs><Goo id="g5" blur={18} /><clipPath id="q5">{Q('#fff')}</clipPath></defs>
        <g {...gooFilter('g5')} opacity={0.9}>
          <Blob x={150 + Math.sin(t * 0.8) * 40} y={1380} r={110} fill="#ffffff2e" t={t} seed={3} />
          <Blob x={930 + Math.cos(t * 0.7) * 40} y={1120} r={130} fill="#ffffff24" t={t} seed={5} />
          <Blob x={880} y={300 + Math.sin(t) * 30} r={70} fill={`${K.amber}aa`} t={t} seed={7} />
        </g>
        <g opacity={rise}>
          {Q('#ffffff26')}
          <g clipPath="url(#q5)">
            <path d={wave(200, 880, lvl, qy + 80, t, 14, 2)} fill={K.amber} />
            <path d={wave(200, 880, lvl + 24, qy + 80, t + 0.4, 9, 5)} fill="#ffffff30" />
          </g>
        </g>
      </svg>
      <div style={{position: 'absolute', left: 90, right: 90, top: 900, height: 560, display: 'flex', alignItems: 'center', justifyContent: 'center', opacity: Math.min(1, card * 1.5), transform: `scale(${0.9 + 0.1 * card})`}}>
        <Glass style={{padding: '40px 56px 48px', textAlign: 'center'}}>
          <div style={{...txt(54, 300), marginBottom: 10 + 8 * ps(t, T.kenapa - 0.15, T.kenapa + 0.3)}}><span style={line(T.kalau)}>Kalau</span>{' '}<span style={line(T.l180)}>180 L lolos…</span></div>
          <div style={grow(T.kenapa)}>kenapa kita</div>
          <div style={grow(T.nggak)}>nggak pipis</div>
          <div style={grow(T.q180)}><span style={{background: `linear-gradient(90deg, ${K.amber}, #fff)`, WebkitBackgroundClip: 'text', color: 'transparent'}}>180 liter?</span></div>
        </Glass>
      </div>
    </Drift>
  );
};

// ---------------------------------------------------------------- S6 — almost all of it is taken back
const TUBE = {top: 700, bottom: 1400, w: 210, L: 300, R: 780};
const ARC: Pt[] = quad([TUBE.L, 690], [540, 420], [TUBE.R, 690]);
const levelL = (t: number) => lerp(752, 1384, ps(t, T.ambil + 0.1, T.kembali + 0.5));
const levelR = (t: number) => lerp(1160, 800, ps(t, T.ambil + 0.4, T.kembali + 0.9));
const route = (start: Pt, t: number): Pt[] => [start, [TUBE.L, 690], ...ARC.slice(1), [TUBE.R, levelR(t)]];
const GULA: Pt[] = [[238, 1336], [282, 1352], [330, 1338], [362, 1356], [256, 1366], [312, 1368]];
const GARAM: Pt[] = [[236, 1350], [276, 1334], [320, 1356], [356, 1340], [300, 1372], [250, 1372], [344, 1370]];
const S6 = (t: number) => {
  const lL = levelL(t), lR = levelR(t);
  const stream = route([TUBE.L, lL], t);
  const counter = ps(t, T.lebih - 0.15, T.lebih + 0.25) * (1 - ps(t, T.gulanya - 0.35, T.gulanya - 0.05));
  const n = Math.round(lerp(0, 99, p(tick(t), T.lebih, T.n99 + 0.05, Easing.out(Easing.cubic))));
  const hit = pb(t, T.n99 - 0.05, T.n99 + 0.35);
  const tube = (x: number, lv: number, color: string, label: string, i: number) => (
    <g key={label}>
      <defs><clipPath id={`tube6${i}`}><rect x={x - TUBE.w / 2} y={TUBE.top} width={TUBE.w} height={TUBE.bottom - TUBE.top} rx={TUBE.w / 2} /></clipPath></defs>
      <rect x={x - TUBE.w / 2} y={TUBE.top} width={TUBE.w} height={TUBE.bottom - TUBE.top} rx={TUBE.w / 2} fill="rgba(255,255,255,0.08)" />
      <g clipPath={`url(#tube6${i})`}>
        <path d={wave(x - TUBE.w / 2, x + TUBE.w / 2, lv, TUBE.bottom + 10, t, 7, i)} fill={color} />
        <path d={wave(x - TUBE.w / 2, x + TUBE.w / 2, lv + 16, TUBE.bottom + 10, t + 0.4, 5, i + 3)} fill="#ffffff22" />
      </g>
      <rect x={x - TUBE.w / 2} y={TUBE.top} width={TUBE.w} height={TUBE.bottom - TUBE.top} rx={TUBE.w / 2} fill="none" stroke="rgba(255,255,255,0.4)" strokeWidth={3} />
      <rect x={x - TUBE.w / 2 + 26} y={TUBE.top + 50} width={16} height={TUBE.bottom - TUBE.top - 150} rx={8} fill="#ffffff2a" />
      <text x={x} y={TUBE.bottom + 62} textAnchor="middle" fill="#ffffffcc" style={{...txt(34, 700), letterSpacing: 5}}>{label}</text>
    </g>
  );
  const traveller = (pts: Pt[], at: number, k: number, speed: number, keep: boolean) => {
    const dt = t - at;
    if (keep || dt <= 0) return pts[k];
    const d = dt * speed;
    return along(route(pts[k], t), d);
  };
  return (
    <Drift t={t} seed={6} amt={0.8}>
      <svg width={1080} height={1920} style={svgAbs}>
        <defs><Goo id="g6" blur={12} /></defs>
        <path d={`M ${ARC.map(([x, y]) => `${x} ${y}`).join(' L ')}`} fill="none" stroke="#ffffff" strokeOpacity={0.08} strokeWidth={70} strokeLinecap="round" />
        <path d={`M ${ARC.map(([x, y]) => `${x} ${y - 35}`).join(' L ')}`} fill="none" stroke="#ffffff" strokeOpacity={0.3} strokeWidth={3} />
        <path d={`M ${ARC.map(([x, y]) => `${x} ${y + 35}`).join(' L ')}`} fill="none" stroke="#ffffff" strokeOpacity={0.3} strokeWidth={3} />
        {tube(TUBE.L, lL, K.violet, 'HASIL SARINGAN', 0)}
        {tube(TUBE.R, lR, K.pink, 'DARAH', 1)}
        <g {...gooFilter('g6')}>
          {Array.from({length: 150}).map((_, k) => {
            const t0 = T.ambil - 0.1 + k * 0.03;
            if (t0 > T.kembali + 0.5) return null;
            const pt = along(stream, (t - t0) * 900);
            return pt ? <circle key={k} cx={pt[0]} cy={pt[1]} r={18 + 4 * Math.sin(k * 1.3)} fill={K.cyan} /> : null;
          })}
        </g>
        {/* sugar: all of it goes back */}
        {GULA.map((_, k) => {
          const q = pb(t, T.gulanya + k * 0.06, T.gulanya + 0.35 + k * 0.06);
          const pt = traveller(GULA, T.semua + k * 0.12, k, 1150, false);
          if (!pt || q <= 0.001) return null;
          const fade = 1 - ps(t, T.semua + k * 0.12 + 1.35, T.semua + k * 0.12 + 1.6);
          return <polygon key={k} points={hexPts(pt[0], pt[1], 15 * q)} fill={K.amber} opacity={fade} stroke="#fff" strokeOpacity={0.6} strokeWidth={2} />;
        })}
        {/* salt: measured — five go back, two stay */}
        {GARAM.map((_, k) => {
          const q = pb(t, T.garamnya + k * 0.06, T.garamnya + 0.35 + k * 0.06);
          const pt = traveller(GARAM, T.takar + k * 0.12, k, 1150, k >= 5);
          if (!pt || q <= 0.001) return null;
          const fade = k >= 5 ? 1 : 1 - ps(t, T.takar + k * 0.12 + 1.35, T.takar + k * 0.12 + 1.6);
          return <rect key={k} x={pt[0] - 11 * q} y={pt[1] - 11 * q} width={22 * q} height={22 * q} rx={4} fill="#ffffff" opacity={fade} transform={`rotate(45 ${pt[0]} ${pt[1]})`} />;
        })}
      </svg>
      <Abs x={TUBE.L - 140} w={280} y={lL - 96} o={(1 - ps(t, T.ambil, T.ambil + 0.4)) * 1} style={{textAlign: 'center'}}><div style={txt(68, 800)}>180 L</div></Abs>
      <Headline t={t} items={[{at: T.hampir - 0.1, text: 'Hampir semuanya…'}, {at: T.ambil, text: <span>diambil <span style={{color: K.cyan}}>lagi</span></span>}]} until={T.lebih - 0.15} />
      {counter > 0.001 && (
        <Abs center y={180} o={counter} style={{transform: `translateY(${(1 - counter) * -40}px)`}}>
          <Glass style={{padding: '22px 64px 30px', textAlign: 'center', minWidth: 620}}>
            <div style={{...txt(44, 400), opacity: 0.9}}>lebih dari</div>
            <div style={{...txt(190, 800), lineHeight: 1, fontVariantNumeric: 'tabular-nums', transform: `scale(${1 + 0.08 * Math.sin(Math.PI * Math.min(1, hit))})`}}>{n}<span style={{color: K.cyan}}>%</span></div>
            <div style={{...txt(42, 500), marginTop: 8, opacity: ps(t, T.kembali - 0.1, T.kembali + 0.25)}}>air kembali ke darah</div>
          </Glass>
        </Abs>
      )}
      <Abs x={90} w={900} y={190} o={ps(t, T.gulanya - 0.1, T.gulanya + 0.3)} style={{transform: `translateX(${(1 - ps(t, T.gulanya - 0.1, T.gulanya + 0.4)) * -60}px)`}}>
        <Glass radius={36} style={{display: 'flex', alignItems: 'center', gap: 24, padding: '22px 34px'}}>
          <Hex size={46} />
          <div style={txt(64, 800)}>Gula</div>
          <div style={{flex: 1}} />
          <div style={{display: 'flex', alignItems: 'center', gap: 14, opacity: ps(t, T.semua - 0.1, T.semua + 0.25)}}>
            <div style={{width: 44, height: 44, borderRadius: 22, background: K.amber, color: K.night, ...txt(30, 800, K.night), display: 'flex', alignItems: 'center', justifyContent: 'center'}}>✓</div>
            <div style={txt(46, 600)}>diambil semua</div>
          </div>
        </Glass>
      </Abs>
      <Abs x={90} w={900} y={340} o={ps(t, T.garamnya - 0.1, T.garamnya + 0.3)} style={{transform: `translateX(${(1 - ps(t, T.garamnya - 0.1, T.garamnya + 0.4)) * -60}px)`}}>
        <Glass radius={36} style={{display: 'flex', alignItems: 'center', gap: 24, padding: '22px 34px'}}>
          <Crystal size={34} />
          <div style={txt(64, 800)}>Garam</div>
          <div style={{flex: 1}} />
          <div style={{display: 'flex', alignItems: 'center', gap: 18, opacity: ps(t, T.takar - 0.1, T.takar + 0.25)}}>
            <div style={txt(46, 600)}>ditakar pas</div>
            <Gauge t={t} />
          </div>
        </Glass>
      </Abs>
    </Drift>
  );
};
const Gauge: React.FC<{t: number}> = ({t}) => {
  const dt = Math.max(0, t - T.takar);
  const ang = t < T.takar ? -70 : -70 * Math.exp(-3.4 * dt) * Math.cos(8.5 * dt);
  return (
    <svg width={110} height={66} viewBox="-55 -56 110 66">
      <path d="M -44 0 A 44 44 0 0 1 44 0" fill="none" stroke="#ffffff" strokeOpacity={0.45} strokeWidth={7} strokeLinecap="round" />
      <path d="M -12 -42.3 A 44 44 0 0 1 12 -42.3" fill="none" stroke={K.cyan} strokeWidth={9} strokeLinecap="round" />
      <line x1={0} y1={0} x2={0} y2={-36} stroke="#ffffff" strokeWidth={5} strokeLinecap="round" transform={`rotate(${ang})`} />
      <circle r={7} fill="#ffffff" />
    </svg>
  );
};

// ---------------------------------------------------------------- S8 — only 1–2 L remains: urine
const RING8 = {x: 540, y: 760, r: 300};
const BEAK = {x: 400, w: 280, top: 1150, bottom: 1460};
const S8 = (t: number) => {
  const shrink = pio2(t, T.tersisa + 0.1, T.satu);
  const fallDt = Math.max(0, t - DROP_AT);
  const land = Math.sqrt((1390 - RING8.y) / 1800);
  const landed = fallDt >= land;
  const dy = landed ? 1390 : RING8.y + 1800 * fallDt * fallDt;
  const r = landed ? 0 : lerp(285, 46, shrink);
  const color = mix(K.violet, TONE.pale, ps(t, DROP_AT + 0.05, DROP_AT + 0.5));
  const lv = lerp(BEAK.bottom - 6, 1376, ps(t, DROP_AT + land, DROP_AT + land + 0.5));
  const splashT = t - (DROP_AT + land);
  return (
    <Drift t={t} seed={8}>
      <svg width={1080} height={1920} style={svgAbs}>
        <defs>
          <Goo id="g8" blur={15} />
          <clipPath id="beak8"><rect x={BEAK.x} y={BEAK.top} width={BEAK.w} height={BEAK.bottom - BEAK.top} rx={40} /></clipPath>
        </defs>
        <circle cx={RING8.x} cy={RING8.y} r={RING8.r} fill="none" stroke="#ffffff" strokeOpacity={0.42} strokeWidth={4} strokeDasharray="16 14" strokeDashoffset={-t * 20} />
        <g {...gooFilter('g8')}>
          <Blob x={RING8.x} y={dy} r={r} fill={color} t={t} seed={13} />
          {splashT > 0 && splashT < 0.7 && [0, 1, 2, 3].map((k) => {
            const vx = (k - 1.5) * 150, vy = 520 + (k % 2) * 160;
            return <circle key={k} cx={RING8.x + vx * splashT} cy={lv - vy * splashT + 1500 * splashT * splashT} r={13} fill={TONE.pale} />;
          })}
        </g>
        <Gloss x={RING8.x} y={dy} r={r} />
        {splashT > 0 && (
          <g clipPath="url(#beak8)">
            <path d={wave(BEAK.x - 10, BEAK.x + BEAK.w + 10, lv, BEAK.bottom + 10, t, 4 + 10 * Math.max(0, 1 - splashT / 1.2), 4)} fill={TONE.pale} />
          </g>
        )}
        <GlassRect x={BEAK.x} y={BEAK.top} w={BEAK.w} h={BEAK.bottom - BEAK.top} r={40} />
        <rect x={BEAK.x - 16} y={BEAK.top - 6} width={BEAK.w + 32} height={16} rx={8} fill="rgba(255,255,255,0.3)" />
        {[0, 1, 2].map((k) => <line key={k} x1={BEAK.x + BEAK.w - 70} x2={BEAK.x + BEAK.w - 26} y1={BEAK.top + 80 + k * 80} y2={BEAK.top + 80 + k * 80} stroke="#ffffff" strokeOpacity={0.5} strokeWidth={3} />)}
      </svg>
      <Abs center y={RING8.y - 90} o={1 - ps(t, T.tersisa, T.tersisa + 0.5)}><div style={txt(150, 800)}>180 L</div></Abs>
      <Abs center y={426}><Chip t={t} at={T.tersisa + 0.2} text="dari 180 L" color={K.violet} size={36} /></Abs>
      <Abs center y={530} o={ps(t, T.satu - 0.1, T.satu + 0.2)}>
        <div style={{...txt(170, 800), lineHeight: 1}}>1<span style={{opacity: ps(t, T.dua - 0.1, T.dua + 0.15)}}>–2</span><span style={{opacity: ps(t, T.dua + 0.2, T.dua + 0.45), color: TONE.pale}}> L</span></div>
      </Abs>
      <Abs x={BEAK.x + BEAK.w + 30} y={1290}><Chip t={t} at={T.seni} text="air seni" color={TONE.pale} /></Abs>
      <Headline t={t} items={[{at: T.tersisa, text: 'Yang tersisa…'}, {at: T.itulah, text: <span>Itulah <span style={{color: TONE.pale}}>air seni</span></span>}]} />
    </Drift>
  );
};

// ---------------------------------------------------------------- S9 — colour = a daily report
const VIAL = {xs: [180, 360, 540, 720, 900], w: 116, top: 470, bottom: 1090};
const S9 = (t: number) => {
  const sel = ps(t, T.pekat - 0.1, T.pekat + 0.45);
  const selQ = pb(t, T.pucat - 0.1, T.pucat + 0.3);
  const swap = ps(t, T.pekat - 0.15, T.pekat + 0.25);
  const cardQ = pb(t, T.pucat - 0.1, T.pucat + 0.3);
  const bar = ps(t, T.laporan - 0.1, T.laporan + 0.6);
  return (
    <Drift t={t} seed={9}>
      <svg width={1080} height={1920} style={svgAbs}>
        <defs>
          {VIAL.xs.map((x, i) => <clipPath key={i} id={`vial${i}`}><rect x={x - VIAL.w / 2} y={VIAL.top} width={VIAL.w} height={VIAL.bottom - VIAL.top} rx={VIAL.w / 2} /></clipPath>)}
          <linearGradient id="scale9" x1="0" x2="1" y1="0" y2="0">{SWATCH.map((c, i) => <stop key={i} offset={i / 4} stopColor={c} />)}</linearGradient>
        </defs>
        {selQ > 0.001 && (
          <rect x={lerp(96, 636, sel)} y={VIAL.top - 40} width={348} height={VIAL.bottom - VIAL.top + 80} rx={44} fill="#ffffff" fillOpacity={0.07} stroke="#ffffff" strokeOpacity={0.75 * Math.min(1, selQ)} strokeWidth={4}
            transform={`translate(${lerp(96, 636, sel) + 174} 780) scale(${0.9 + 0.1 * selQ}) translate(${-(lerp(96, 636, sel) + 174)} -780)`} />
        )}
        {VIAL.xs.map((x, i) => {
          const f = ps(t, T.makanya + 0.05 + i * 0.12, T.makanya + 0.75 + i * 0.12);
          const lv = lerp(VIAL.bottom + 4, 610, f);
          return (
            <g key={i}>
              <rect x={x - VIAL.w / 2} y={VIAL.top} width={VIAL.w} height={VIAL.bottom - VIAL.top} rx={VIAL.w / 2} fill="rgba(255,255,255,0.08)" />
              <g clipPath={`url(#vial${i})`}>
                <path d={wave(x - 70, x + 70, lv, VIAL.bottom + 10, t, 4 + 8 * (1 - f) * (f > 0 ? 1 : 0), i)} fill={SWATCH[i]} />
                <path d={wave(x - 70, x + 70, lv + 14, VIAL.bottom + 10, t + 0.4, 3, i + 4)} fill="#ffffff22" />
              </g>
              <rect x={x - VIAL.w / 2} y={VIAL.top} width={VIAL.w} height={VIAL.bottom - VIAL.top} rx={VIAL.w / 2} fill="none" stroke="#ffffff" strokeOpacity={0.45} strokeWidth={3} />
              <rect x={x - VIAL.w / 2 - 10} y={VIAL.top - 14} width={VIAL.w + 20} height={22} rx={11} fill="rgba(255,255,255,0.3)" />
              <rect x={x - VIAL.w / 2 + 18} y={VIAL.top + 40} width={12} height={VIAL.bottom - VIAL.top - 140} rx={6} fill="#ffffff38" />
            </g>
          );
        })}
        <g opacity={bar}>
          <line x1={130} x2={lerp(130, 930, bar)} y1={1150} y2={1150} stroke="url(#scale9)" strokeWidth={10} strokeLinecap="round" />
          <path d={`M ${lerp(130, 930, bar) + 4} 1132 L ${lerp(130, 930, bar) + 30} 1150 L ${lerp(130, 930, bar) + 4} 1168 Z`} fill={SWATCH[4]} />
          <text x={124} y={1205} fill="#ffffffcc" style={txt(34, 600)}>pucat</text>
          <text x={956} y={1205} textAnchor="end" fill="#ffffffcc" style={txt(34, 600)}>pekat</text>
        </g>
      </svg>
      <Abs center y={318} o={ps(t, T.laporan, T.laporan + 0.4) * 0.6}><div style={{...txt(24, 600), letterSpacing: 4}}>ILUSTRASI · BUKAN SARAN MEDIS</div></Abs>
      {cardQ > 0.001 && (
        <div style={{position: 'absolute', left: 64, right: 64, top: 1250, opacity: Math.min(1, cardQ * 1.4), transform: `translateY(${(1 - cardQ) * 40}px)`}}>
          <Glass style={{height: 196, position: 'relative', overflow: 'hidden'}}>
            {[{c: SWATCH[0], title: 'Kuning pucat', sub: 'biasanya cairanmu cukup', at: T.biasa, tc: SWATCH[0], q: 1 - swap, dx: -70 * swap},
              {c: SWATCH[4], title: 'Makin pekat', sub: 'ginjalmu lagi berhemat air', at: T.hemat, tc: SWATCH[3], q: swap, dx: 70 * (1 - swap)}].map((r) => r.q > 0.001 && (
              <div key={r.title} style={{position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', gap: 30, padding: '0 44px', opacity: r.q, transform: `translateX(${r.dx}px)`}}>
                <div style={{width: 84, height: 84, borderRadius: 42, background: r.c, boxShadow: `0 0 30px ${r.c}88, inset 0 -8px 0 #00000022`, border: '3px solid rgba(255,255,255,0.6)', flexShrink: 0}} />
                <div>
                  <div style={txt(66, 800, r.tc)}>{r.title}</div>
                  <div style={{...txt(42, 500), marginTop: 8, opacity: ps(t, r.at - 0.1, r.at + 0.25)}}>{r.sub}</div>
                </div>
              </div>
            ))}
          </Glass>
        </div>
      )}
      <Headline t={t} items={[{at: T.warna - 0.1, text: 'Warnanya…'}, {at: T.laporan, text: <span>Warna = <span style={{color: K.amber}}>laporan harian</span></span>}]} />
    </Drift>
  );
};

// ---------------------------------------------------------------- S10 — drink a glass first (end card)
const CUP = {cx: 540, top: 610, bottom: 1370, wTop: 450, wBot: 372};
const TAP = `M 1130 504 L 610 504 Q 540 504 540 ${TAP_Y - 6}`;
const S10 = (t: number) => {
  const stop = T.segelas + 0.9;
  const head = TAP_Y + 0.5 * 3000 * Math.max(0, t - T.scroll) ** 2;
  const tail = t < stop ? TAP_Y - 20 : TAP_Y + 0.5 * 3000 * (t - stop) ** 2;
  const pipeIn = ps(t, T.jadi, T.scroll), pipeOut = ps(t, stop - 0.3, stop + 0.1); // water front / tail along the tap
  const lv = t < POUR_LAND ? CUP.bottom + 30 : lerp(CUP.bottom - 8, 740, ps(t, POUR_LAND, T.segelas + 1.0));
  const pouring = t > POUR_LAND && t < stop + 0.4 ? 1 : 0;
  const amp = 5 + 14 * pouring;
  const card = pb(t, T.minum - 0.1, T.minum + 0.35);
  const cupPath = tumblerPath(CUP.cx, CUP.top, CUP.bottom, CUP.wTop, CUP.wBot);
  const end = ps(t, C.duration + 0.3, C.duration + 0.7);
  return (
    <Drift t={t} seed={10}>
      <svg width={1080} height={1920} style={svgAbs}>
        <defs>
          <Goo id="g10" blur={13} />
          <clipPath id="cup10"><path d={cupPath} /><rect x={490} y={TAP_Y - 30} width={100} height={CUP.top - TAP_Y + 40} /></clipPath>
          <clipPath id="cupIn10"><path d={cupPath} /></clipPath>
        </defs>
        <path d={cupPath} fill="rgba(255,255,255,0.07)" />
        {/* glass tap: water runs through it from the right, then falls */}
        <path d={TAP} fill="none" stroke="#ffffff" strokeOpacity={0.1} strokeWidth={52} strokeLinecap="round" />
        <path d={TAP} fill="none" stroke={K.cyan} strokeWidth={30} strokeLinecap="round" pathLength={1} strokeDasharray={`${Math.max(0, pipeIn - pipeOut)} 2`} strokeDashoffset={-pipeOut} opacity={pipeIn - pipeOut > 0.002 ? 1 : 0} />
        <path d={`M 1130 484 L 610 484`} fill="none" stroke="#ffffff" strokeOpacity={0.45} strokeWidth={4} strokeLinecap="round" />
        <ellipse cx={540} cy={TAP_Y - 4} rx={28} ry={8} fill="none" stroke="#ffffff" strokeOpacity={0.6} strokeWidth={4} />
        <g clipPath="url(#cup10)">
          <g {...gooFilter('g10')}>
            <path d={wave(CUP.cx - 280, CUP.cx + 280, lv, CUP.bottom + 40, t, amp, 6)} fill={K.cyan} />
            {t > T.scroll && Array.from({length: 42}).map((_, k) => {
              const y = TAP_Y + k * 20;
              if (y < tail || y > Math.min(head, lv + 20)) return null;
              return <circle key={k} cx={CUP.cx + Math.sin(y * 0.02 + t * 8) * 4} cy={y} r={17 - 4 * ps(t, stop - 0.6, stop)} fill={K.cyan} />;
            })}
          </g>
        </g>
        <g clipPath="url(#cupIn10)">
          <path d={wave(CUP.cx - 280, CUP.cx + 280, lv + 18, CUP.bottom + 40, t + 0.4, amp * 0.6, 8)} fill="#ffffff22" />
          {t > POUR_LAND && Array.from({length: 14}).map((_, k) => {
            const life = 1.6 + rnd(k) * 1.2;
            const age = (t - POUR_LAND - rnd(k * 3) * 1.5) % life;
            if (t - POUR_LAND < rnd(k * 3) * 1.5) return null;
            const y = CUP.bottom - 30 - age * 260;
            return y > lv + 14 ? <circle key={k} cx={CUP.cx - 160 + rnd(k * 7) * 320 + Math.sin(age * 6 + k) * 6} cy={y} r={5 + rnd(k * 5) * 8} fill="none" stroke="#ffffff" strokeOpacity={0.55} strokeWidth={3} /> : null;
          })}
        </g>
        <path d={cupPath} fill="none" stroke="#ffffff" strokeOpacity={0.5} strokeWidth={4} />
        <rect x={CUP.cx - CUP.wBot / 2 + 30} y={CUP.bottom - 34} width={CUP.wBot - 60} height={14} rx={7} fill="#ffffff30" />
        <path d={`M ${CUP.cx - CUP.wTop / 2 + 40} ${CUP.top + 50} L ${CUP.cx - CUP.wBot / 2 + 40} ${CUP.bottom - 90}`} stroke="#ffffff" strokeOpacity={0.3} strokeWidth={16} strokeLinecap="round" />
      </svg>
      <Headline t={t} items={[{at: T.jadi - 0.1, text: 'Sebelum lanjut scroll…'}]} until={T.minum - 0.15} />
      {card > 0.001 && (
        <Abs center y={180} o={Math.min(1, card * 1.5)} style={{transform: `scale(${0.9 + 0.1 * card})`}}>
          <Glass style={{padding: '26px 64px 34px', textAlign: 'center'}}>
            <div style={txt(100, 800)}>Minum dulu</div>
            <div style={{...txt(100, 800), height: 106 * ps(t, T.segelas - 0.15, T.segelas + 0.25), opacity: ps(t, T.segelas - 0.1, T.segelas + 0.25)}}><span style={{background: `linear-gradient(90deg, ${K.cyan}, #fff)`, WebkitBackgroundClip: 'text', color: 'transparent'}}>segelas.</span></div>
          </Glass>
        </Abs>
      )}
      <Abs center y={1408}><Chip t={t} at={T.sudah} text="Ginjalmu sudah kerja dari tadi" icon={<KidneyIcon size={40} />} size={38} /></Abs>
      <Abs center y={1590} o={end} style={{transform: `translateY(${(1 - end) * 20}px)`}}>
        <Glass radius={999} style={{padding: '14px 34px', display: 'flex', alignItems: 'center', gap: 14, ...txt(34, 600)}}><Dot color={K.cyan} size={14} />Ginjal · ≈ 180 L disaring / hari</Glass>
      </Abs>
    </Drift>
  );
};

// ---------------------------------------------------------------- timeline
const SHOTS: Shot[] = [
  {from: 0, render: S1, bg: 'night'},
  {from: T.padahal, render: S2, bg: 'night', sweep: {at: T.padahal - 0.3, dir: 'up', colors: [K.cyan, K.violet], seed: 1}},
  {from: T.didalam, render: S3, bg: 'night', sweep: {at: T.didalam - 0.3, dir: 'down', colors: [K.pink, K.violet], seed: 2}, until: DIVE.to},
  {from: DIVE.from + 0.1, render: S4, bg: 'deep', style: (t) => ({opacity: ps(t, DIVE.from + 0.1, DIVE.to - 0.15)})},
  {from: T.kalau, render: S5, bg: 'flood', sweep: {at: T.kalau - 0.25, dir: 'up', colors: [K.pink, K.violet], seed: 3}},
  {from: T.karena, render: S6, bg: 'deep', sweep: {at: T.karena - 0.3, dir: 'down', colors: [TONE.indigo, TONE.deep], seed: 4}},
  {from: T.tersisa, render: S8, bg: 'night', sweep: {at: T.tersisa - 0.3, dir: 'up', colors: [K.cyan, K.violet], seed: 5}},
  {from: T.makanya, render: S9, bg: 'amber', sweep: {at: T.makanya - 0.3, dir: 'up', colors: [K.amber, K.pink], seed: 6}},
  {from: T.jadi, render: S10, bg: 'aqua', sweep: {at: T.jadi - 0.3, dir: 'down', colors: [K.cyan, K.violet], seed: 7}},
];

export const GinjalEpisode: React.FC = () => {
  const {t} = useTime();
  // music bed is generated later from plans/cair.json; a silent draft can skip it with --props='{"draftNoMusic":true}'
  const {draftNoMusic} = getInputProps() as {draftNoMusic?: boolean};
  return (
    <AbsoluteFill style={{background: K.night, overflow: 'hidden'}}>
      <StyleFonts />
      <EpisodeAudio vo="audio/vo/cair.mp3" words={C.words} music={draftNoMusic ? undefined : 'audio/music/cair.wav'} bed={0.5} duck={0.18} sfx={CAIR_SFX} />
      <Shots t={t} shots={SHOTS} />
      <Caption t={t} pages={PAGES} />
    </AbsoluteFill>
  );
};

const s = (t: number, name: string, vol = 0.55): Sfx => ({t: Math.max(0, t), src: `audio/sfx/cair/${name}.wav`, vol});
export const CAIR_SFX: Sfx[] = [
  // S1
  s(0.02, 'pour', 0.4), s(T.saring, 'drip', 0.4), s(T.n180 - 0.03, 'splash', 0.75), s(T.kira - 0.1, 'whoosh', 0.45), s(T.kira + 0.35, 'bloop', 0.4), s(T.sembilan, 'pop', 0.6),
  // S2
  s(T.padahal - 0.3, 'wave', 0.6), s(T.plasma - 0.05, 'bloop', 0.55), s(T.tiga, 'pop', 0.5), s(T.artinya, 'whoosh', 0.45), s(T.disaring, 'glass', 0.45),
  s(T.bolak + 0.9, 'swell', 0.55), s(T.enam - 0.03, 'splash', 0.7),
  // S3
  s(T.didalam - 0.3, 'wave', 0.55), s(T.didalam + 0.05, 'glass', 0.5), s(T.sejuta - 0.1, 'bubble', 0.55), s(T.namanya, 'pop', 0.5), s(DIVE.from, 'whoosh', 0.5),
  // S4
  s(T.masuk, 'pour', 0.45), s(T.tekan, 'gulp', 0.5), s(T.halus - 0.12, 'glass', 0.45), s(T.sel, 'bloop', 0.45), s(T.tinggal, 'pop', 0.5),
  s(T.air, 'drip', 0.5), s(T.gula, 'drip', 0.45), s(T.lolos, 'drain', 0.5),
  // S5
  s(T.tunggu, 'glass', 0.6), s(T.kalau - 0.25, 'wave', 0.6), s(T.kenapa, 'pop', 0.55), s(T.q180 + 0.4, 'drip', 0.6),
  // S6–S7
  s(T.karena - 0.3, 'swell', 0.5), s(T.ambil, 'pour', 0.55), s(T.n99 - 0.03, 'splash', 0.7), s(T.gulanya - 0.1, 'whoosh', 0.4), s(T.semua, 'bubble', 0.45),
  s(T.garamnya - 0.1, 'whoosh', 0.4), s(T.takar, 'glass', 0.5),
  // S8
  s(T.tersisa - 0.3, 'wave', 0.55), s(T.tersisa + 0.1, 'drain', 0.6), s(T.satu, 'pop', 0.5), s(DROP_AT, 'drip', 0.6), s(DROP_AT + 0.6, 'splash', 0.45), s(T.seni, 'bloop', 0.45),
  // S9
  s(T.makanya - 0.3, 'wave', 0.5), s(T.warna - 0.1, 'pour', 0.4), s(T.pucat - 0.05, 'glass', 0.5), s(T.pekat - 0.1, 'whoosh', 0.4),
  // S10
  s(T.jadi - 0.3, 'wave', 0.55), s(T.scroll, 'pour', 0.6), s(T.minum, 'pop', 0.5), s(T.sudah, 'bubble', 0.45), s(C.duration + 0.3, 'glass', 0.55),
];
