// REFERENCE DEMO (ADSY MOTION GRAPH v2.1). Read for structure only; never copy its story or text. Imports point at the starter kit.
import React from 'react';
import {AbsoluteFill} from 'remotion';
import {at} from '../lib/words';
import {p, pb, lerp, drawOn, pio} from '../styles/shared';
import {SceneProps, StyleTag, Caps, enter} from '../styles/medis/kit';

// ============ 09 KMS — growth-card chart ============
const KM = {card: '#FBDDE6', edge: '#E79BB2', ink: '#3A2A33', green: '#7DCB8A', yellow: '#F7E27A', red: '#F29C8F', lineA: '#1F7A47', lineB: '#C2413B'};
export const Kms: React.FC<SceneProps> = ({t, a}) => {
  const tKo = at('konsentrasi'), tSu = at('suasana'), tBa = at('baik');
  const X0 = 150, X1 = 960, Y0 = 520, Y1 = 1160;
  const x = (h: number) => X0 + ((h - 7) / 10) * (X1 - X0);
  const y = (v: number) => Y1 - v * (Y1 - Y0);
  const A = [[7, 0.78], [9, 0.82], [11, 0.76], [13, 0.72], [15, 0.76], [17, 0.74]];
  const B = [[7, 0.6], [9, 0.42], [11, 0.24], [13, 0.5], [15, 0.4], [17, 0.36]];
  const path = (pts: number[][]) => pts.map(([h, v], i) => `${i ? 'L' : 'M'}${x(h)} ${y(v)}`).join(' ');
  const dA = p(t, tKo - 0.5, tKo + 0.9), dB = p(t, tKo, tKo + 1.3);
  const mood = pb(t, tSu, tSu + 0.4);
  const face = (cx: number, cy: number, happy: boolean, q: number) => (
    <g transform={`translate(${cx} ${cy}) scale(${q})`} opacity={q}>
      <circle r="38" fill={happy ? '#FFE08A' : '#FFD0C4'} stroke={KM.ink} strokeWidth="5" />
      <circle cx="-12" cy="-8" r="5" fill={KM.ink} /><circle cx="12" cy="-8" r="5" fill={KM.ink} />
      <path d={happy ? 'M-16 10 Q0 24 16 10' : 'M-16 18 Q0 4 16 18'} fill="none" stroke={KM.ink} strokeWidth="5" strokeLinecap="round" />
    </g>
  );
  return (
    <AbsoluteFill style={{background: '#F6EEE9', ...enter(t, a)}}>
      <div style={{position: 'absolute', top: 210, left: 60, right: 60, bottom: 500, background: KM.card, border: `6px solid ${KM.edge}`, borderRadius: 26}} />
      <div style={{position: 'absolute', top: 240, left: 100, right: 100, textAlign: 'center'}}>
        <div style={{fontFamily: 'Kms Head', fontWeight: 800, fontSize: 64, color: KM.ink, lineHeight: 1}}>KARTU MENUJU FOKUS</div>
        <div style={{fontFamily: 'Kms Text', fontWeight: 700, fontSize: 30, color: KM.ink, opacity: 0.7, marginTop: 8}}>konsentrasi sepanjang hari · ilustrasi</div>
      </div>
      <svg width={1080} height={1920} style={{position: 'absolute'}}>
        <rect x={X0} y={y(1)} width={X1 - X0} height={y(0.65) - y(1)} fill={KM.green} opacity={0.75} />
        <rect x={X0} y={y(0.65)} width={X1 - X0} height={y(0.4) - y(0.65)} fill={KM.yellow} opacity={0.75} />
        <rect x={X0} y={y(0.4)} width={X1 - X0} height={y(0) - y(0.4)} fill={KM.red} opacity={0.6} />
        {Array.from({length: 11}, (_, i) => <line key={i} x1={x(7 + i)} y1={Y0} x2={x(7 + i)} y2={Y1} stroke="#ffffff" strokeWidth="2" opacity={0.6} />)}
        {[7, 9, 11, 13, 15, 17].map((h) => <text key={h} x={x(h)} y={Y1 + 44} textAnchor="middle" fontFamily="Kms Text" fontWeight="800" fontSize="28" fill={KM.ink}>{String(h).padStart(2, '0')}.00</text>)}
        <text x={X0 + 14} y={y(0.9)} fontFamily="Kms Head" fontWeight="700" fontSize="30" fill={KM.ink}>FOKUS BAIK</text>
        <text x={X1 - 14} y={y(0.06)} textAnchor="end" fontFamily="Kms Head" fontWeight="700" fontSize="30" fill={KM.ink}>LEMAS, SULIT FOKUS</text>
        <path d={path(B)} fill="none" stroke={KM.lineB} strokeWidth="9" strokeDasharray="22 14" opacity={dB > 0 ? 1 : 0} style={{clipPath: `inset(0 ${100 - dB * 100}% 0 0)`}} />
        <path d={path(A)} fill="none" stroke={KM.lineA} strokeWidth="11" strokeLinecap="round" {...drawOn(dA)} />
        {A.map(([h, v], i) => <circle key={i} cx={x(h)} cy={y(v)} r="11" fill={KM.lineA} opacity={p(dA, i / 6, i / 6 + 0.1)} />)}
        {face(x(11), y(0.76) - 70, true, mood)}
        {face(x(11), y(0.24) + 70, false, mood)}
      </svg>
      <div style={{position: 'absolute', top: 1260, left: 100, right: 100, display: 'flex', justifyContent: 'center', gap: 34, fontFamily: 'Kms Text', fontWeight: 800, fontSize: 32, color: KM.ink}}>
        <span><span style={{display: 'inline-block', width: 40, height: 10, background: KM.lineA, verticalAlign: 'middle', marginRight: 10}} />sarapan</span>
        <span><span style={{display: 'inline-block', width: 40, height: 0, borderTop: `8px dashed ${KM.lineB}`, verticalAlign: 'middle', marginRight: 10}} />tanpa sarapan</span>
      </div>
      <div style={{position: 'absolute', top: 1320, left: 0, right: 0, textAlign: 'center', fontFamily: 'Kms Head', fontWeight: 700, fontSize: 40, color: KM.lineA, opacity: p(t, tBa, tBa + 0.4)}}>mood juga lebih baik</div>
      <StyleTag t={t} a={a} n={9} name="KMS" font="Kms Head" fg={KM.ink} bg="#F6EEE9" />
      <Caps t={t} y={1440} s={{font: 'Kms Head', weight: 800, size: 64, color: '#fff', hl: '#FFF3A0', bg: KM.lineA, radius: 40}} />
    </AbsoluteFill>
  );
};

// ============ 10 ULAR TANGGA — snakes & ladders board ============
const UT = {bg: '#2D5D7B', cells: ['#F6D37A', '#8FD3B6', '#7FB3E6', '#F2A0A0', '#FFF3DD'], ink: '#23313C', wood: '#9A6332', snake: '#E0443E', snake2: '#F7B32B', pawn: '#7B2FF7'};
const SZ = 172, BX = 110, BY = 330;
const cell = (n: number) => {
  const i = n - 1, row = Math.floor(i / 5), colRaw = i % 5;
  const col = row % 2 === 0 ? colRaw : 4 - colRaw;
  return [BX + col * SZ + SZ / 2, BY + (4 - row) * SZ + SZ / 2];
};
const Ladder: React.FC<{from: number; to: number; label: string; q: number}> = ({from, to, label, q}) => {
  const [x0, y0] = cell(from), [x1, y1] = cell(to);
  const ang = Math.atan2(y1 - y0, x1 - x0), nx = -Math.sin(ang) * 26, ny = Math.cos(ang) * 26;
  const len = Math.hypot(x1 - x0, y1 - y0), rungs = Math.floor(len / 46);
  return (
    <g opacity={0.35 + 0.65 * q}>
      <line x1={x0 + nx} y1={y0 + ny} x2={x1 + nx} y2={y1 + ny} stroke={UT.wood} strokeWidth="12" strokeLinecap="round" />
      <line x1={x0 - nx} y1={y0 - ny} x2={x1 - nx} y2={y1 - ny} stroke={UT.wood} strokeWidth="12" strokeLinecap="round" />
      {Array.from({length: rungs}, (_, k) => { const f = (k + 0.5) / rungs; const cx = lerp(x0, x1, f), cy = lerp(y0, y1, f); return <line key={k} x1={cx + nx} y1={cy + ny} x2={cx - nx} y2={cy - ny} stroke={UT.wood} strokeWidth="9" />; })}
      <g transform={`translate(${(x0 + x1) / 2} ${(y0 + y1) / 2})`} opacity={q}>
        <rect x="-118" y="-30" width="236" height="60" rx="30" fill="#fff" stroke={UT.ink} strokeWidth="5" />
        <text y="12" textAnchor="middle" fontFamily="Ula Text" fontWeight="700" fontSize="32" fill={UT.ink}>{label}</text>
      </g>
    </g>
  );
};
export const UlarTangga: React.FC<SceneProps> = ({t, a, b}) => {
  const tTa = at('takut'), tMe = at('menu'), tBe = at('berlebihan', 1), tIn = at('ingat'), tKa = at('kapan'), tSb = at('seberapa'), tSi = at('seimbang');
  // pawn keyframes [time, cell]
  const keys: Array<[number, number]> = [[a, 1], [tTa, 1], [tTa + 0.4, 2], [tMe, 2], [tMe + 0.7, 13], [tIn, 13], [tIn + 0.4, 14], [tIn + 0.8, 15], [tSb, 15], [tSb + 0.8, 24], [tSi + 0.2, 24], [tSi + 0.6, 25]];
  let pos = cell(1), hop = 0;
  for (let i = 1; i < keys.length; i++) {
    const [ta, ca] = keys[i - 1], [tb, cb] = keys[i];
    if (t >= ta) {
      const q = pio(t, ta, tb);
      const A = cell(ca), B = cell(cb);
      pos = [lerp(A[0], B[0], q), lerp(A[1], B[1], q)];
      hop = ca !== cb && q > 0 && q < 1 ? Math.sin(q * Math.PI) : 0;
    }
  }
  const snakeQ = pb(t, tBe - 0.15, tBe + 0.3);
  const ladder1 = p(t, tMe - 0.3, tMe), ladder2 = p(t, tSb - 0.3, tSb);
  const clockX = pb(t, tKa + 0.1, tKa + 0.4);
  const win = pb(t, tSi + 0.6, tSi + 1.0);
  const [sx0, sy0] = cell(19), [sx1, sy1] = cell(8);
  const snakePath = `M${sx0} ${sy0} C${sx0 + 160} ${sy0 + 120} ${sx1 - 200} ${sy1 - 260} ${sx1} ${sy1}`;
  const [kx, ky] = cell(11);
  return (
    <AbsoluteFill style={{background: UT.bg, ...enter(t, a)}}>
      <svg width={1080} height={1920} style={{position: 'absolute'}}>
        <rect x={BX - 20} y={BY - 20} width={SZ * 5 + 40} height={SZ * 5 + 40} rx="24" fill={UT.ink} />
        {Array.from({length: 25}, (_, i) => {
          const [cx, cy] = cell(i + 1);
          return (
            <g key={i}>
              <rect x={cx - SZ / 2} y={cy - SZ / 2} width={SZ} height={SZ} fill={UT.cells[(i * 3) % 5]} stroke={UT.ink} strokeWidth="3" />
              <text x={cx - SZ / 2 + 14} y={cy - SZ / 2 + 42} fontFamily="Ula Head" fontSize="32" fill={UT.ink} opacity={0.7}>{i + 1}</text>
            </g>
          );
        })}
        {(() => { const [fx, fy] = cell(25); return <text x={fx} y={fy + 40} textAnchor="middle" fontFamily="Ula Head" fontSize="36" fill={UT.ink}>SEHAT</text>; })()}
        {(() => { const [fx, fy] = cell(1); return <text x={fx} y={fy + 50} textAnchor="middle" fontFamily="Ula Head" fontSize="28" fill={UT.ink}>MULAI</text>; })()}
        <Ladder from={2} to={13} label="menu sehat" q={ladder1} />
        <Ladder from={15} to={24} label="seimbang" q={ladder2} />
        {/* snake */}
        <g opacity={0.4 + 0.6 * snakeQ}>
          <path d={snakePath} fill="none" stroke={UT.ink} strokeWidth="48" strokeLinecap="round" />
          <path d={snakePath} fill="none" stroke={UT.snake} strokeWidth="38" strokeLinecap="round" />
          <path d={snakePath} fill="none" stroke={UT.snake2} strokeWidth="38" strokeDasharray="18 30" />
          <g transform={`translate(${sx0} ${sy0}) rotate(${Math.sin(t * 8) * 8 * snakeQ})`}>
            <ellipse rx="44" ry="36" fill={UT.snake} stroke={UT.ink} strokeWidth="5" />
            <circle cx="-14" cy="-10" r="7" fill="#fff" /><circle cx="14" cy="-10" r="7" fill="#fff" />
            <path d="M0 30 l0 22 m0 0 l-10 10 m10 -10 l10 10" stroke={UT.snake} strokeWidth="5" fill="none" />
          </g>
          <g transform={`translate(${(sx0 + sx1) / 2 + 40} ${(sy0 + sy1) / 2})`} opacity={snakeQ}>
            <rect x="-130" y="-30" width="260" height="60" rx="30" fill={UT.snake} stroke={UT.ink} strokeWidth="5" />
            <text y="12" textAnchor="middle" fontFamily="Ula Text" fontWeight="700" fontSize="32" fill="#fff">berlebihan</text>
          </g>
        </g>
        {/* clock token: "kapan" doesn't matter */}
        <g transform={`translate(${kx} ${ky})`} opacity={p(t, tIn, tIn + 0.3)}>
          <circle r="50" fill="#fff" stroke={UT.ink} strokeWidth="6" />
          <path d="M0 0 V-30 M0 0 L22 10" stroke={UT.ink} strokeWidth="6" strokeLinecap="round" />
          <path d="M-60 -60 L60 60" stroke={UT.snake} strokeWidth="12" strokeLinecap="round" {...drawOn(clockX)} />
        </g>
        {/* pawn */}
        <g transform={`translate(${pos[0]} ${pos[1] - hop * 90})`}>
          <ellipse cx="0" cy={44 + hop * 90} rx="40" ry="12" fill="#0004" />
          <path d="M-34 40 C-30 0 -18 -10 -16 -20 A26 26 0 1 1 16 -20 C18 -10 30 0 34 40 Z" fill={UT.pawn} stroke={UT.ink} strokeWidth="6" />
        </g>
      </svg>
      <div style={{position: 'absolute', top: 1270, left: 0, right: 0, textAlign: 'center', opacity: win, transform: `scale(${lerp(0.5, 1, win)})`}}>
        <span style={{fontFamily: 'Ula Head', fontSize: 58, color: UT.ink, background: UT.cells[0], border: `6px solid ${UT.ink}`, borderRadius: 20, padding: '8px 30px'}}>SEHAT &amp; SEIMBANG!</span>
      </div>
      <div style={{position: 'absolute', top: 210, left: 0, right: 0, textAlign: 'center', fontFamily: 'Ula Head', fontSize: 44, color: '#fff', opacity: p(t, a, a + 0.4)}}>ULAR TANGGA SARAPAN</div>
      <StyleTag t={t} a={a} n={10} name="ULAR TANGGA" font="Ula Head" fg="#fff" bg={UT.bg} />
      <Caps t={t} y={1440} s={{font: 'Ula Text', weight: 700, size: 64, color: UT.ink, hl: UT.snake, bg: '#fff', radius: 20, border: `6px solid ${UT.ink}`}} />
      {b < 0 && null}
    </AbsoluteFill>
  );
};
