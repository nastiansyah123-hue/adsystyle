// REFERENCE DEMO (ADSY MOTION GRAPH v2.1). Read for structure only; never copy its story or text. Imports point at the starter kit.
import React from 'react';
import {AbsoluteFill} from 'remotion';
import {at} from '../lib/words';
import {p, pb, lerp, rnd, pio} from '../styles/shared';
import {SceneProps, StyleTag, Caps, enter} from '../styles/medis/kit';

// ============ 05 WEBTOON — vertical comic ============
const WT = {bg: '#EDEDED', ink: '#111', skin: '#F6D2B0', shirt: '#5B8DEF', pop: '#FF3B5C', yellow: '#FFD23F'};
const Guy: React.FC<{x: number; y: number; s?: number; round: number; shirt?: string}> = ({x, y, s = 1, round, shirt = WT.shirt}) => {
  const w = lerp(70, 130, round);
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`} stroke={WT.ink} strokeWidth="6" strokeLinejoin="round">
      <path d={`M${-w} 160 C${-w} 40 ${-w * 0.6} 10 0 10 C${w * 0.6} 10 ${w} 40 ${w} 160 Z`} fill={shirt} />
      <circle cx="0" cy="-50" r={lerp(55, 68, round)} fill={WT.skin} />
      <circle cx="-20" cy="-55" r="6" fill={WT.ink} stroke="none" /><circle cx="20" cy="-55" r="6" fill={WT.ink} stroke="none" />
      <path d="M-18 -22 Q0 -10 18 -22" fill="none" />
    </g>
  );
};
const Panel: React.FC<{y: number; h: number; children: React.ReactNode; tone?: boolean}> = ({y, h, children, tone}) => (
  <g transform={`translate(80 ${y})`}>
    <rect width="920" height={h} fill="#fff" stroke={WT.ink} strokeWidth="8" />
    {tone && <rect width="920" height={h} fill="url(#wt-tone)" opacity={0.25} />}
    <svg x="0" y="0" width="920" height={h} overflow="hidden">{children}</svg>
  </g>
);
const Sfx: React.FC<{x: number; y: number; text: string; q: number; color: string; rot?: number; size?: number}> = ({x, y, text, q, color, rot = -8, size = 110}) => (
  <text x={x} y={y} textAnchor="middle" fontFamily="Web SFX" fontSize={size} fill={color} stroke={WT.ink} strokeWidth="6" paintOrder="stroke"
    transform={`rotate(${rot} ${x} ${y}) translate(${x} ${y}) scale(${lerp(0.3, 1, q)}) translate(${-x} ${-y})`} opacity={q}>{text}</text>
);
export const Webtoon: React.FC<SceneProps> = ({t, a}) => {
  const tB = at('bayangin'), tO = at('otomatis'), tSe = at('semua'), tKe = at('kelebihan');
  const scroll = lerp(0, 0, 0) + pio(t, tSe - 0.4, tSe + 0.2) * 640 + pio(t, tKe - 0.3, tKe + 0.2) * 300;
  const puff = pb(t, tO + 0.35, tO + 0.75);
  const crowd = pb(t, tSe, tSe + 0.4);
  const twist = pb(t, tKe + 0.4, tKe + 0.8);
  return (
    <AbsoluteFill style={{background: WT.bg, ...enter(t, a)}}>
      <svg width={1080} height={1920} style={{position: 'absolute'}}>
        <defs><pattern id="wt-tone" width="14" height="14" patternUnits="userSpaceOnUse"><circle cx="7" cy="7" r="2.6" fill={WT.ink} /></pattern></defs>
        <g transform={`translate(0 ${-scroll})`}>
          {/* caption box */}
          <g transform="translate(110 250)" opacity={p(t, tB - 0.2, tB + 0.2)}>
            <rect width="520" height="90" fill={WT.yellow} stroke={WT.ink} strokeWidth="6" />
            <text x="24" y="62" fontFamily="Web Text" fontSize="52" fill={WT.ink}>Bayangin kalau…</text>
          </g>
          <Panel y={370} h={560} tone>
            <Guy x={460} y={260} round={puff} />
            <ellipse cx="460" cy="480" rx="160" ry="34" fill="#fff" stroke={WT.ink} strokeWidth="6" />
            <circle cx="430" cy="466" r="24" fill={WT.yellow} stroke={WT.ink} strokeWidth="4" />
            {puff > 0.05 && [0, 1, 2, 3, 4, 5].map((k) => {
              const an = (k / 6) * Math.PI * 2; const r = lerp(150, 260, puff);
              return <line key={k} x1={460 + Math.cos(an) * r} y1={240 + Math.sin(an) * r} x2={460 + Math.cos(an) * (r + 50)} y2={240 + Math.sin(an) * (r + 50)} stroke={WT.ink} strokeWidth="8" strokeLinecap="round" opacity={1 - puff * 0.4} />;
            })}
            <Sfx x={760} y={160} text="BLUB!" q={puff} color={WT.pop} />
          </Panel>
          <Panel y={960} h={560}>
            {[150, 320, 490, 660, 830].map((x, i) => <Guy key={i} x={x - 40} y={300} s={0.78} round={crowd} shirt={['#5B8DEF', '#F59E0B', '#22C55E', '#A855F7', '#EF4444'][i]} />)}
            <Sfx x={460} y={130} text="HAH?!" q={crowd} color={WT.yellow} rot={4} size={120} />
          </Panel>
          <Panel y={1550} h={420} tone>
            <text x="460" y="190" textAnchor="middle" fontFamily="Web Text" fontSize="76" fill={WT.ink} opacity={twist}>Kenyataannya…</text>
            <text x="460" y="300" textAnchor="middle" fontFamily="Web SFX" fontSize="78" fill={WT.pop} stroke={WT.ink} strokeWidth="5" paintOrder="stroke" opacity={twist}>ENGGAK GITU!</text>
          </Panel>
        </g>
      </svg>
      <div style={{position: 'absolute', top: 1330, right: 70, fontFamily: 'Web SFX', fontSize: 26, color: '#fff', background: WT.ink, padding: '6px 14px', opacity: 0.85}}>SIMULASI</div>
      <StyleTag t={t} a={a} n={5} name="WEBTOON" font="Web SFX" fg={WT.ink} bg={WT.bg} />
      <Caps t={t} y={1440} s={{font: 'Web Text', weight: 400, size: 68, color: WT.ink, hl: WT.pop, bg: '#fff', radius: 60, border: `6px solid ${WT.ink}`}} />
    </AbsoluteFill>
  );
};

// ============ 06 KALENDER — tear-off calendar ============
const KL = {wall: '#E9E1D3', page: '#FFFDF7', red: '#D62F2F', ink: '#262019', green: '#2E8B57', ring: '#8A8A8A'};
const days = [
  {d: 'SENIN', n: 3, inn: 2300, out: 2000}, {d: 'SELASA', n: 4, inn: 2100, out: 2100}, {d: 'RABU', n: 5, inn: 2500, out: 2000},
  {d: 'KAMIS', n: 6, inn: 2200, out: 2300}, {d: 'JUMAT', n: 7, inn: 2600, out: 2000}, {d: 'SABTU', n: 8, inn: 2400, out: 2200},
];
export const Kalender: React.FC<SceneProps> = ({t, a}) => {
  const tTo = at('total'), tPe = at('pengeluaran'), tBu = at('bukan'), tWa = at('waktu');
  const step = 0.62, t0 = tTo - 0.3;
  const idx = Math.max(0, Math.min(days.length - 1, Math.floor((t - t0) / step)));
  const tear = t > t0 ? ((t - t0) / step) % 1 : 0;
  const shown = t < t0 ? 0 : idx;
  const sum = days.slice(0, shown + (t > t0 ? 1 : 0)).reduce((s, x) => s + (x.inn - x.out), 0);
  const day = days[shown];
  const outQ = p(t, tPe - 0.2, tPe + 0.2);
  const clocks = pb(t, tWa - 0.2, tWa + 0.2);
  const last = idx === days.length - 1 && t > t0 + step * (days.length - 1);
  return (
    <AbsoluteFill style={{background: KL.wall, ...enter(t, a)}}>
      {/* nail + rings */}
      <div style={{position: 'absolute', top: 250, left: 190, width: 700, height: 1000}}>
        <div style={{position: 'absolute', top: 30, left: 0, right: 0, height: 970, background: '#d9d0bf', borderRadius: 18, transform: 'rotate(1.5deg)'}} />
        {/* next page underneath */}
        <div style={{position: 'absolute', top: 40, left: 0, right: 0, height: 960, background: KL.page, borderRadius: 14}} />
        {/* current page */}
        <div style={{position: 'absolute', top: 40, left: 0, right: 0, height: 960, background: KL.page, borderRadius: 14, boxShadow: '0 14px 30px #0002',
          transformOrigin: 'top center', transform: !last && tear > 0.75 ? `rotateX(${(tear - 0.75) * 4 * 80}deg) translateY(${(tear - 0.75) * 4 * -60}px)` : 'none',
          opacity: !last && tear > 0.75 ? 1 - (tear - 0.75) * 4 : 1, display: 'flex', flexDirection: 'column', alignItems: 'center', paddingTop: 60}}>
          <div style={{fontFamily: 'Kal Head', fontSize: 56, color: day.d === 'MINGGU' ? KL.red : KL.ink, letterSpacing: 6}}>{day.d}</div>
          <div style={{fontFamily: 'Kal Head', fontSize: 300, lineHeight: 1, color: KL.red}}>{day.n}</div>
          <div style={{width: 560, marginTop: 30, fontFamily: 'Kal Head', fontSize: 46, color: KL.ink}}>
            <div style={{display: 'flex', justifyContent: 'space-between', borderBottom: '3px dashed #c9bfae', padding: '12px 0'}}><span>Masuk</span><span>{day.inn.toLocaleString('id-ID')} kkal</span></div>
            <div style={{display: 'flex', justifyContent: 'space-between', borderBottom: '3px dashed #c9bfae', padding: '12px 0', opacity: 0.25 + 0.75 * outQ}}><span>Keluar</span><span>{day.out.toLocaleString('id-ID')} kkal</span></div>
            <div style={{display: 'flex', justifyContent: 'space-between', padding: '12px 0', color: day.inn - day.out > 0 ? KL.red : KL.green}}><span>Selisih</span><span>{day.inn - day.out > 0 ? '+' : ''}{(day.inn - day.out).toLocaleString('id-ID')}</span></div>
          </div>
          <div style={{fontFamily: 'Kal Hand', fontSize: 40, color: '#8a7f70', marginTop: 10}}>angka contoh</div>
        </div>
        <svg width={700} height={80} style={{position: 'absolute', top: 0}}>
          {[120, 230, 470, 580].map((x) => <rect key={x} x={x} y="10" width="18" height="60" rx="9" fill={KL.ring} />)}
        </svg>
      </div>
      {/* running total */}
      <div style={{position: 'absolute', top: 1290, left: 70, right: 70, display: 'flex', justifyContent: 'center', gap: 20, alignItems: 'center'}}>
        <div style={{fontFamily: 'Kal Head', fontSize: 46, color: '#fff', background: sum > 0 ? KL.red : KL.green, padding: '8px 28px', borderRadius: 12}}>
          Total minggu ini: {sum > 0 ? '+' : ''}{sum.toLocaleString('id-ID')} kkal
        </div>
      </div>
      {/* meal time doesn't change totals */}
      <div style={{position: 'absolute', top: 160, right: 60, display: 'flex', gap: 10, opacity: clocks, transform: `rotate(-4deg) scale(${lerp(0.6, 1, clocks)})`}}>
        <div style={{fontFamily: 'Kal Hand', fontSize: 50, color: KL.ink, background: '#FFF2A8', padding: '6px 20px', boxShadow: '0 6px 12px #0002'}}>jam makan ≠ total</div>
      </div>
      <StyleTag t={t} a={a} n={6} name="KALENDER" font="Kal Head" fg={KL.ink} bg={KL.wall} />
      <Caps t={t} y={1440} s={{font: 'Kal Head', weight: 400, size: 64, color: KL.page, hl: '#FFC2B4', bg: KL.ink, radius: 10}} />
    </AbsoluteFill>
  );
};

// ============ 07 APOTEK — pharmacy label ============
const AP = {bg: '#DDEBF3', blue: '#1E5FB4', ink: '#14233A', foil: '#C9D2DB', foil2: '#AEB9C5', bag: '#FFFFFF'};
export const Apotek: React.FC<SceneProps> = ({t, a}) => {
  const tPi = at('pilih', 0), tBe = at('bergizi'), tPo = at('porsinya'), tSa = at('sarapan', 5);
  const label = p(t, a, a + 0.5);
  const foods = [
    {n: 'telur', c: '#FFE08A'}, {n: 'pisang', c: '#F6D04D'}, {n: 'nasi', c: '#F3EEDD'}, {n: 'sayur', c: '#8BC97A'},
  ];
  const typed = (s: string, a0: number) => s.slice(0, Math.max(0, Math.floor((t - a0) * 28)));
  return (
    <AbsoluteFill style={{background: AP.bg, ...enter(t, a)}}>
      {/* etiket */}
      <div style={{position: 'absolute', top: 230, left: 100, width: 880, background: '#fff', border: `5px solid ${AP.ink}`, borderRadius: 14, overflow: 'hidden', boxShadow: '0 20px 40px #14233a22',
        transform: `translateY(${(1 - label) * -300}px) rotate(${lerp(-5, -1, label)}deg)`}}>
        <div style={{background: AP.blue, color: '#fff', padding: '16px 30px', display: 'flex', justifyContent: 'space-between', alignItems: 'center'}}>
          <span style={{fontFamily: 'Apo Head', fontSize: 58, letterSpacing: 2}}>APOTEK SEHAT</span>
          <span style={{fontFamily: 'Apo Text', fontSize: 24}}>No. 07 · ETIKET</span>
        </div>
        <div style={{padding: '22px 30px', fontFamily: 'Apo Text', fontSize: 38, color: AP.ink, lineHeight: 1.6}}>
          <div>Nama&nbsp;&nbsp;: Kamu</div>
          <div>Resep&nbsp;: <b>{typed('Sarapan bergizi', tSa - 0.2) || ' '}</b></div>
          <div style={{borderTop: `3px dashed ${AP.foil2}`, marginTop: 10, paddingTop: 10, fontFamily: 'Apo Head', fontSize: 74, lineHeight: 1.1, color: AP.blue}}>1 × sehari · pagi</div>
          <div style={{fontFamily: 'Apo Head', fontSize: 50, color: AP.ink, opacity: p(t, tPo - 0.2, tPo + 0.3)}}>Porsi: sesuai kebutuhan</div>
        </div>
      </div>
      {/* blister strip */}
      <svg width={1080} height={520} style={{position: 'absolute', top: 870}}>
        <rect x="110" y="40" width="860" height="330" rx="34" fill={AP.foil} stroke={AP.foil2} strokeWidth="6" />
        {Array.from({length: 12}, (_, i) => <line key={i} x1={150 + i * 70} y1="50" x2={130 + i * 70} y2="360" stroke="#fff" strokeWidth="3" opacity={0.35} />)}
        {foods.map((f, i) => {
          const x = 220 + i * 214, y = 205;
          const q = pb(t, tPi + i * 0.35, tPi + i * 0.35 + 0.35);
          const lift = q * -70;
          return (
            <g key={f.n}>
              <ellipse cx={x} cy={y} rx="86" ry="96" fill="#ffffff66" stroke={AP.foil2} strokeWidth="5" />
              <g transform={`translate(0 ${lift}) rotate(${q * (i % 2 ? 10 : -10)} ${x} ${y})`}>
                <ellipse cx={x} cy={y} rx="62" ry="70" fill={f.c} stroke={AP.ink} strokeWidth="5" />
                {f.n === 'telur' && <circle cx={x} cy={y} r="24" fill="#F59E0B" />}
              </g>
              <text x={x} y={y + 150} textAnchor="middle" fontFamily="Apo Text" fontSize="32" fill={AP.ink} opacity={q}>{f.n}</text>
            </g>
          );
        })}
      </svg>
      <div style={{position: 'absolute', top: 1340, left: 0, right: 0, textAlign: 'center', fontFamily: 'Apo Text', fontSize: 26, color: AP.ink, opacity: p(t, tBe, tBe + 0.4)}}>ini makanan, bukan obat · pilih yang bergizi</div>
      <StyleTag t={t} a={a} n={7} name="APOTEK" font="Apo Text" fg={AP.ink} bg={AP.bg} />
      <Caps t={t} y={1440} s={{font: 'Apo Head', weight: 800, size: 70, color: '#fff', hl: '#FFE08A', bg: AP.blue, radius: 12, upper: true, spacing: 1}} />
    </AbsoluteFill>
  );
};

// ============ 08 ENDOSKOPI — camera inside the body ============
const EN = {dark: [70, 10, 25], light: [236, 140, 130]};
const mixc = (q: number) => `rgb(${EN.dark.map((c, k) => Math.round(c + (EN.light[k] - c) * q)).join(',')})`;
export const Endoskopi: React.FC<SceneProps> = ({t, a}) => {
  const tMe = at('melewatkan'), tGi = at('gimana');
  const arrive = p(t, tMe, tMe + 0.8);
  const travel = (Math.min(t, tMe + 0.6) - a) * 0.55;
  const N = 14;
  const rings = Array.from({length: N}, (_, k) => ((k / N + travel) % 1)).sort((x, y) => x - y);
  const growl = p(t, tGi - 0.1, tGi + 0.3);
  const depth = Math.round(lerp(18, 42, p(t, a, tMe + 0.6)));
  const cx = 540, cy = 820, R = 450;
  return (
    <AbsoluteFill style={{background: '#050304', ...enter(t, a)}}>
      <svg width={1080} height={1920} style={{position: 'absolute'}}>
        <defs>
          <clipPath id="en-lens"><circle cx={cx} cy={cy} r={R} /></clipPath>
          <radialGradient id="en-vig"><stop offset="60%" stopColor="#000" stopOpacity={0} /><stop offset="100%" stopColor="#000" stopOpacity={0.9} /></radialGradient>
          <radialGradient id="en-cave"><stop offset="0%" stopColor="#2a0710" /><stop offset="70%" stopColor="#7a2232" /><stop offset="100%" stopColor="#c86a6a" /></radialGradient>
        </defs>
        <g clipPath="url(#en-lens)">
          <rect x={cx - R} y={cy - R} width={R * 2} height={R * 2} fill={mixc(0.55)} />
          {rings.map((ph, k) => {
            const r = 30 + Math.pow(ph, 2.2) * 900;
            const wob = Math.sin(t * 1.3 + k) * 14 * ph;
            return <ellipse key={k} cx={cx + wob} cy={cy + wob * 0.6} rx={r} ry={r * 0.92} fill="none" stroke={mixc(0.2 + ph * 0.8)} strokeWidth={10 + ph * 120} opacity={(1 - arrive) * 0.95} />;
          })}
          <circle cx={cx} cy={cy} r={lerp(40, 0, arrive)} fill="#1a0408" opacity={1 - arrive} />
          {/* stomach cavity */}
          <g opacity={arrive}>
            <ellipse cx={cx} cy={cy} rx="430" ry="400" fill="url(#en-cave)" />
            {Array.from({length: 7}, (_, k) => (
              <path key={k} d={`M${cx - 380} ${cy - 220 + k * 70} C${cx - 150} ${cy - 260 + k * 70} ${cx + 150} ${cy - 180 + k * 70} ${cx + 380} ${cy - 230 + k * 70}`} fill="none" stroke="#e48c8c" strokeWidth="12" opacity={0.45} />
            ))}
            <text x={cx} y={cy + 20} textAnchor="middle" fontFamily="End Head" fontWeight="700" fontSize="110" fill="#fff" opacity={0.9}>KOSONG</text>
          </g>
          {/* wet highlights */}
          {Array.from({length: 10}, (_, k) => <ellipse key={k} cx={cx - 300 + rnd(k) * 600} cy={cy - 300 + rnd(k + 9) * 600} rx={10 + rnd(k + 3) * 22} ry={5 + rnd(k + 4) * 9} fill="#fff" opacity={0.25 + 0.2 * Math.sin(t * 3 + k)} />)}
          <rect x={cx - R} y={cy - R} width={R * 2} height={R * 2} fill="url(#en-vig)" />
        </g>
        <circle cx={cx} cy={cy} r={R} fill="none" stroke="#222" strokeWidth="16" />
        {/* growl waves */}
        <g opacity={growl} stroke="#FFB4A8" strokeWidth="8" fill="none" strokeLinecap="round">
          {[0, 1, 2].map((k) => <path key={k} d={`M${cx - 120 - k * 50} ${cy + 180 + k * 26} q30 -24 60 0 t60 0 t60 0 t60 0 t60 0`} opacity={0.4 + 0.6 * Math.abs(Math.sin(t * 7 + k))} />)}
        </g>
        <text x={cx} y={cy + 330} textAnchor="middle" fontFamily="End Head" fontWeight="700" fontSize="70" fill="#FFB4A8" opacity={growl}>kruuuk…</text>
      </svg>
      <div style={{position: 'absolute', top: 200, left: 70, right: 70, display: 'flex', justifyContent: 'space-between', fontFamily: 'End Mono', fontSize: 30, color: '#9FE7FF'}}>
        <span>● REC ENDO-CAM</span><span>{depth} cm</span>
      </div>
      <div style={{position: 'absolute', top: 1310, left: 70, right: 70, display: 'flex', justifyContent: 'space-between', fontFamily: 'End Mono', fontSize: 30, color: '#9FE7FF'}}>
        <span>{arrive > 0.5 ? 'LAMBUNG' : 'KERONGKONGAN'}</span><span>ILUSTRASI</span>
      </div>
      <StyleTag t={t} a={a} n={8} name="ENDOSKOPI" font="End Mono" fg="#9FE7FF" bg="#050304" />
      <Caps t={t} y={1440} s={{font: 'End Head', weight: 700, size: 62, color: '#fff', hl: '#FFB4A8', bg: '#1a0408e6', radius: 12, border: '2px solid #9FE7FF55'}} />
    </AbsoluteFill>
  );
};
