// REFERENCE DEMO (ADSY MOTION GRAPH v2.1). Read for structure only; never copy its story or text. Imports point at the starter kit.
// Only JAM TUBUH, DUA SISI, LABEL GIZI, WEBTOON, APOTEK and ENDOSKOPI are official MEDIS looks; KONSUL, KALENDER, KMS and ULAR TANGGA were test-only.
import React from 'react';
import {AbsoluteFill, Audio, staticFile, useCurrentFrame} from 'remotion';
import project from './project.json';
import {SfxTrack} from './components/SfxTrack';
import {FontFaces} from './Fonts';
import {MedisFonts} from './styles/medis/kit';
import {Medis2Fonts, Konsul, JamTubuh, DuaSisi, LabelGizi} from './medis2/scenes1';
import {Webtoon, Kalender, Apotek, Endoskopi} from './medis2/scenes2';
import {Kms, UlarTangga} from './medis2/scenes3';
import {SceneProps} from './styles/medis/kit';

const sound = project as {musicFile?: string | null; musicVolume?: number; musicAutomation?: Array<{frame: number; volume: number}>};
const musicGain = (frame: number): number => {
  const base = sound.musicVolume ?? 0.24;
  const pts = sound.musicAutomation ?? [];
  if (!pts.length) return base;
  if (frame <= pts[0].frame) return pts[0].volume;
  if (frame >= pts[pts.length - 1].frame) return pts[pts.length - 1].volume;
  let i = 1;
  while (pts[i].frame < frame) i++;
  const l = pts[i - 1], r = pts[i];
  return l.volume + (r.volume - l.volume) * ((frame - l.frame) / Math.max(1, r.frame - l.frame));
};

// Scene cuts sit in pauses between spoken sentences (measured word timing).
export const SCENE_STARTS = [0, 4.55, 10.01, 16.01, 21.87, 28.01, 34.45, 40.21, 44.65, 49.82, 61.16, project.durationSeconds];
const KonsulEnd: React.FC<SceneProps> = (pr) => <Konsul {...pr} end />;
const scenes: React.FC<SceneProps>[] = [Konsul, JamTubuh, DuaSisi, LabelGizi, Webtoon, Kalender, Apotek, Endoskopi, Kms, UlarTangga, KonsulEnd];

export const Main: React.FC = () => {
  const t = useCurrentFrame() / 60;
  const S = SCENE_STARTS;
  let i = scenes.length - 1;
  while (i > 0 && t < S[i]) i--;
  const View = scenes[i];
  return (
    <AbsoluteFill style={{overflow: 'hidden', background: '#000'}}>
      <FontFaces />
      <MedisFonts />
      <Medis2Fonts />
      <View t={t} a={S[i]} b={S[i + 1]} />
      <SfxTrack />
      {sound.musicFile && <Audio src={staticFile(sound.musicFile)} volume={musicGain} />}
      {project.voiceoverFile && <Audio src={staticFile(project.voiceoverFile)} />}
    </AbsoluteFill>
  );
};
