// REFERENCE DEMO (ADSY MOTION GRAPH v2.1). Read for structure only; never copy its story or text. Imports point at the starter kit.
import React from 'react';
import {AbsoluteFill, staticFile} from 'remotion';
import {at} from '../lib/words';
import {p, pb, lerp, rnd, drawOn} from '../styles/shared';
import {SceneProps, StyleTag, Caps, enter} from '../styles/medis/kit';

// Fonts for the 10 extra health looks (bundled SIL OFL fonts).
const faces: Array<[string, string, string]> = [
  ['Kon Text', 'Nunito-Var.ttf', '200 1000'], ['Kon UI', 'Inter-Var.ttf', '100 900'],
  ['Jam Head', 'Sora-Var.ttf', '100 800'], ['Jam Mono', 'MartianMono-Var.ttf', '100 800'],
  ['Dua Head', 'Fredoka-Var.ttf', '300 700'],
  ['Gizi Head', 'Archivo-Var.ttf', '100 900'], ['Gizi Text', 'Inter-Var.ttf', '100 900'],
  ['Web SFX', 'Bungee-Regular.ttf', '400'], ['Web Text', 'PatrickHand-Regular.ttf', '400'],
  ['Kal Head', 'DMSerifDisplay-Regular.ttf', '400'], ['Kal Hand', 'CaveatBrush-Regular.ttf', '400'],
  ['Apo Head', 'BarlowCondensed-ExtraBold.ttf', '800'], ['Apo Text', 'IBMPlexMono-SemiBold.ttf', '600'],
  ['End Mono', 'ShareTechMono-Regular.ttf', '400'], ['End Head', 'SpaceGrotesk-Var.ttf', '300 700'],
  ['Kms Head', 'Baloo2-Var.ttf', '400 800'], ['Kms Text', 'Nunito-Var.ttf', '200 1000'],
  ['Ula Head', 'Bungee-Regular.ttf', '400'], ['Ula Text', 'Fredoka-Var.ttf', '300 700'],
];
export const Medis2Fonts: React.FC = () => (
  <style>{faces.map(([f, file, w]) => `@font-face{font-family:'${f}';src:url('${staticFile('fonts/' + file)}') format('truetype');font-weight:${w};}`).join('\n')}</style>
);

// ============ 01 KONSUL — chat with a doctor ============
const KO = {bg: '#E6EFEA', bar: '#0E6B5C', me: '#D3F2C4', doc: '#FFFFFF', ink: '#1B2B27', muted: '#6E847D', tick: '#3B9BE0', chip: '#0E6B5C'};
const Ticks: React.FC = () => (
  <svg width="34" height="18" viewBox="0 0 34 18"><path d="M2 9 l5 5 L17 3 M14 13 l2 2 L28 3" fill="none" stroke={KO.tick} strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" /></svg>
);
const Bubble: React.FC<{t: number; at: number; me?: boolean; time: string; children: React.ReactNode}> = ({t, at: a0, me, time, children}) => {
  const q = pb(t, a0, a0 + 0.3);
  if (t < a0 - 0.01) return null;
  return (
    <div style={{display: 'flex', justifyContent: me ? 'flex-end' : 'flex-start', opacity: Math.min(1, q * 2), transform: `translateY(${(1 - q) * 30}px) scale(${0.9 + 0.1 * q})`, transformOrigin: me ? 'right bottom' : 'left bottom'}}>
      <div style={{maxWidth: 760, background: me ? KO.me : KO.doc, borderRadius: me ? '34px 34px 8px 34px' : '34px 34px 34px 8px', padding: '24px 30px 14px', boxShadow: '0 4px 0 #0000000f',
        fontFamily: 'Kon Text', fontWeight: 700, fontSize: 52, lineHeight: 1.22, color: KO.ink}}>
        {children}
        <div style={{display: 'flex', justifyContent: 'flex-end', alignItems: 'center', gap: 8, fontFamily: 'Kon UI', fontWeight: 500, fontSize: 24, color: KO.muted, marginTop: 6}}>{time}{me && <Ticks />}</div>
      </div>
    </div>
  );
};
const Typing: React.FC<{t: number}> = ({t}) => (
  <div style={{display: 'flex'}}>
    <div style={{background: KO.doc, borderRadius: '34px 34px 34px 8px', padding: '26px 34px', display: 'flex', gap: 14}}>
      {[0, 1, 2].map((k) => <div key={k} style={{width: 20, height: 20, borderRadius: 10, background: KO.muted, opacity: 0.35 + 0.65 * Math.max(0, Math.sin(t * 8 - k * 0.9))}} />)}
    </div>
  </div>
);
export const Konsul: React.FC<SceneProps & {end?: boolean}> = ({t, a, end}) => {
  const tKok = at('kok'), tYa = at('ya', 0) + 0.25, tNah = at('nah'), tFav = at('favorit');
  const chips = ['Nasi uduk', 'Bubur ayam', 'Roti telur', 'Oat pisang'];
  return (
    <AbsoluteFill style={{background: KO.bg, ...enter(t, a)}}>
      <svg width={1080} height={1920} style={{position: 'absolute', opacity: 0.08}}>
        {Array.from({length: 60}, (_, i) => <circle key={i} cx={rnd(i) * 1080} cy={rnd(i + 50) * 1920} r={10 + rnd(i + 9) * 22} fill="none" stroke={KO.bar} strokeWidth="4" />)}
      </svg>
      <div style={{position: 'absolute', top: 0, left: 0, right: 0, height: 250, background: KO.bar}} />
      <div style={{position: 'absolute', top: 150, left: 70, right: 70, display: 'flex', alignItems: 'center', gap: 22}}>
        <svg width="80" height="80" viewBox="0 0 80 80"><circle cx="40" cy="40" r="40" fill="#E6EFEA" /><circle cx="40" cy="31" r="14" fill={KO.bar} /><path d="M16 68 C20 50 60 50 64 68Z" fill={KO.bar} /><rect x="34" y="52" width="12" height="4" fill="#E6EFEA" /><rect x="38" y="48" width="4" height="12" fill="#E6EFEA" /></svg>
        <div>
          <div style={{fontFamily: 'Kon Text', fontWeight: 800, fontSize: 40, color: '#fff'}}>Dokter Umum</div>
          <div style={{fontFamily: 'Kon UI', fontSize: 26, color: '#BFE3DA'}}>{!end && t > tYa ? 'sedang mengetik…' : 'online'}</div>
        </div>
      </div>
      <div style={{position: 'absolute', top: 310, left: 50, right: 50, display: 'flex', flexDirection: 'column', gap: 26}}>
        {!end && <>
          <Bubble t={t} at={0} me time="07.02">Dok, katanya sarapan bikin gemuk ya?</Bubble>
          <Bubble t={t} at={tKok - 0.1} me time="07.02">Kok bisa?</Bubble>
          {t > tYa && <Typing t={t} />}
        </>}
        {end && <>
          <div style={{opacity: 0.45, display: 'flex', flexDirection: 'column', gap: 26}}>
            <Bubble t={t} at={a - 1} me time="07.02">Dok, katanya sarapan bikin gemuk ya?</Bubble>
            <Bubble t={t} at={a - 1} time="07.05">Bukan soal jamnya. Yang penting isi dan porsinya.</Bubble>
          </div>
          <Bubble t={t} at={tNah} time="07.06">Nah, sarapan favorit kamu apa nih?</Bubble>
          <div style={{display: 'flex', flexWrap: 'wrap', gap: 16, marginTop: 10}}>
            {chips.map((c, i) => {
              const q = pb(t, tFav + i * 0.12, tFav + i * 0.12 + 0.3);
              return <div key={c} style={{fontFamily: 'Kon Text', fontWeight: 800, fontSize: 40, color: KO.chip, border: `4px solid ${KO.chip}`, background: '#fff', borderRadius: 40, padding: '10px 28px', opacity: q, transform: `scale(${0.7 + 0.3 * q})`}}>{c}</div>;
            })}
          </div>
        </>}
      </div>
      {/* input bar */}
      <div style={{position: 'absolute', top: 1310, left: 50, right: 50, height: 100, background: '#fff', borderRadius: 50, display: 'flex', alignItems: 'center', padding: '0 36px', fontFamily: 'Kon UI', fontSize: 34, color: KO.muted}}>Tulis pesan…</div>
      <StyleTag t={t} a={a} n={1} name="KONSUL" font="Kon UI" fg="#fff" bg={KO.bar} />
      <Caps t={t} y={1470} s={{font: 'Kon Text', weight: 800, size: 58, color: '#fff', hl: '#B9F5A0', bg: KO.bar, radius: 26}} />
    </AbsoluteFill>
  );
};

// ============ 02 JAM TUBUH — 24-hour body clock ============
export const JamTubuh: React.FC<SceneProps> = ({t, a}) => {
  const tS = at('sarapan', 1), tE = at('energi'), tA = at('aktivitas');
  const hour = lerp(5, 7, p(t, a, tS + 0.3)) + lerp(0, 2, p(t, tA, tA + 1));
  const dawn = p(t, a, tS + 0.6);
  const bg = `linear-gradient(180deg, ${dawn > 0.5 ? '#1B2A6B' : '#0B1230'} 0%, ${dawn > 0.5 ? '#F08A5D' : '#1B2154'} 100%)`;
  const cx = 540, cy = 860, R = 360;
  const ang = (h: number) => (h / 24) * 360 - 180;
  const pt = (h: number, r: number) => [cx + Math.sin((ang(h) * Math.PI) / 180) * r, cy - Math.cos((ang(h) * Math.PI) / 180) * r];
  const arc = (h0: number, h1: number, r: number) => {
    const [x0, y0] = pt(h0, r), [x1, y1] = pt(h1, r);
    return `M${x0} ${y0} A${r} ${r} 0 ${h1 - h0 > 12 ? 1 : 0} 1 ${x1} ${y1}`;
  };
  const en = p(t, tE - 0.2, tE + 0.8);
  const act = p(t, tA - 0.1, tA + 0.8);
  const [hx, hy] = pt(hour, R - 70);
  return (
    <AbsoluteFill style={{background: bg, ...enter(t, a)}}>
      <AbsoluteFill style={{background: 'linear-gradient(180deg,#0B1230,#1B2154)', opacity: 1 - dawn}} />
      <svg width={1080} height={1920} style={{position: 'absolute'}}>
        <circle cx={cx} cy={cy} r={R + 40} fill="#0B1230" opacity={0.55} />
        <circle cx={cx} cy={cy} r={R} fill="none" stroke="#ffffff22" strokeWidth="60" />
        {/* night / day halves */}
        <path d={arc(18, 30, R)} fill="none" stroke="#2C3A8C" strokeWidth="60" />
        <path d={arc(6, 18, R)} fill="none" stroke="#F6B25A" strokeWidth="60" opacity={0.25 + 0.5 * dawn} />
        {/* activity arc */}
        <path d={arc(8, lerp(8.01, 17, act), R)} fill="none" stroke="#FF7A59" strokeWidth="60" opacity={act > 0 ? 1 : 0} />
        {/* energy ring */}
        <path d={arc(7, lerp(7.01, 16, en), R - 90)} fill="none" stroke="#7CF2B4" strokeWidth="26" strokeLinecap="round" opacity={en > 0 ? 1 : 0} />
        {Array.from({length: 24}, (_, h) => {
          const [x, y] = pt(h, R + 82);
          return <text key={h} x={x} y={y + 12} textAnchor="middle" fontFamily="Jam Mono" fontSize="28" fill={h % 6 === 0 ? '#fff' : '#ffffff77'}>{h % 3 === 0 ? String(h).padStart(2, '0') : '·'}</text>;
        })}
        {/* breakfast marker */}
        {(() => {
          const [x, y] = pt(7, R); const q = pb(t, tS - 0.1, tS + 0.3);
          return <g opacity={q} transform={`translate(${x} ${y}) scale(${q})`}><circle r="44" fill="#FFE08A" stroke="#0B1230" strokeWidth="6" /><circle r="16" fill="#F59E0B" /></g>;
        })()}
        <line x1={cx} y1={cy} x2={hx} y2={hy} stroke="#fff" strokeWidth="12" strokeLinecap="round" />
        <circle cx={cx} cy={cy} r="20" fill="#fff" />
      </svg>
      <div style={{position: 'absolute', top: cy - 70, left: 0, right: 0, textAlign: 'center', fontFamily: 'Jam Head', fontWeight: 800, fontSize: 110, color: '#fff', textShadow: '0 6px 30px #0008'}}>
        {String(Math.floor(hour)).padStart(2, '0')}:{String(Math.floor((hour % 1) * 60)).padStart(2, '0')}
      </div>
      <div style={{position: 'absolute', top: 1375, left: 70, right: 70, display: 'flex', justifyContent: 'center', gap: 20, fontFamily: 'Jam Mono', fontWeight: 600, fontSize: 28}}>
        <span style={{color: '#FFE08A', opacity: pb(t, tS, tS + 0.3)}}>● SARAPAN</span>
        <span style={{color: '#7CF2B4', opacity: en}}>● ENERGI</span>
        <span style={{color: '#FF7A59', opacity: act}}>● AKTIVITAS</span>
      </div>
      <StyleTag t={t} a={a} n={2} name="JAM TUBUH" font="Jam Mono" fg="#fff" bg="#0B1230" />
      <Caps t={t} y={1470} s={{font: 'Jam Head', weight: 700, size: 58, color: '#fff', hl: '#7CF2B4', bg: '#0B1230e6', radius: 60}} />
    </AbsoluteFill>
  );
};

// ============ 03 DUA SISI — split screen ============
const DS = {bg: '#FFF7EC', a: '#2BB3A3', b: '#F2665A', ink: '#2A2235', plate: '#FFFFFF'};
const Kid: React.FC<{x: number; color: string; mood: number}> = ({x, color, mood}) => (
  <g transform={`translate(${x} 0)`}>
    <circle cx="0" cy="560" r="80" fill="#F3C9A1" stroke={DS.ink} strokeWidth="6" />
    <circle cx="-26" cy="550" r="8" fill={DS.ink} /><circle cx="26" cy="550" r="8" fill={DS.ink} />
    <path d={`M-28 ${600 - mood * 4} Q0 ${600 + mood * 18} 28 ${600 - mood * 4}`} fill="none" stroke={DS.ink} strokeWidth="6" strokeLinecap="round" />
    <path d="M-110 820 C-110 690 -70 650 0 650 C70 650 110 690 110 820 Z" fill={color} stroke={DS.ink} strokeWidth="6" />
  </g>
);
export const DuaSisi: React.FC<SceneProps> = ({t, a}) => {
  const tL = at('kelaparan'), tM = at('makan', 0), tSi = at('siang');
  const hungerB = p(t, tL - 0.4, tL + 0.6);
  const noon = p(t, tSi - 0.5, tSi);
  const plates = pb(t, tM - 0.1, tM + 0.4);
  const hh = Math.round(lerp(7, 12, p(t, a + 0.5, tSi)));
  const meter = (x: number, v: number, c: string) => (
    <g transform={`translate(${x} 900)`}>
      <rect x="-130" y="0" width="260" height="34" rx="17" fill="#00000012" />
      <rect x="-130" y="0" width={260 * v} height="34" rx="17" fill={c} />
      <text x="0" y="80" textAnchor="middle" fontFamily="Dua Head" fontWeight="600" fontSize="34" fill={DS.ink}>rasa lapar</text>
    </g>
  );
  return (
    <AbsoluteFill style={{background: DS.bg, ...enter(t, a)}}>
      <div style={{position: 'absolute', top: 0, bottom: 0, left: 0, width: 540, background: '#E3F6F2'}} />
      <div style={{position: 'absolute', top: 0, bottom: 0, left: 540, width: 540, background: '#FDE7E3'}} />
      <svg width={1080} height={1920} style={{position: 'absolute'}}>
        <path d={Array.from({length: 40}, (_, i) => `${i ? 'L' : 'M'}${540 + (i % 2 ? 14 : -14)} ${i * 50}`).join(' ')} fill="none" stroke={DS.ink} strokeWidth="6" />
        <Kid x={270} color={DS.a} mood={1} />
        <Kid x={810} color={DS.b} mood={1 - 2 * hungerB} />
        {meter(270, lerp(0.3, 0.45, noon), DS.a)}
        {meter(810, lerp(0.3, 0.95, hungerB), DS.b)}
        {/* stomach growl */}
        <g opacity={hungerB} stroke={DS.b} strokeWidth="6" fill="none" strokeLinecap="round">
          {[0, 1, 2].map((k) => <path key={k} d={`M${930 + k * 14} ${700 - k * 40} q20 -20 40 0`} opacity={0.4 + 0.6 * Math.abs(Math.sin(t * 6 + k))} />)}
        </g>
        {/* lunch plates */}
        <g opacity={plates}>
          <ellipse cx="270" cy="1150" rx="150" ry="42" fill={DS.plate} stroke={DS.ink} strokeWidth="6" />
          <circle cx="250" cy="1132" r="40" fill="#F6E7B8" stroke={DS.ink} strokeWidth="4" /><circle cx="310" cy="1135" r="26" fill="#8BC97A" stroke={DS.ink} strokeWidth="4" />
          {[0, 1, 2].map((k) => (
            <g key={k} transform={`translate(0 ${-k * 70 * plates})`}>
              <ellipse cx="810" cy="1150" rx="150" ry="42" fill={DS.plate} stroke={DS.ink} strokeWidth="6" />
              <circle cx="780" cy="1130" r="44" fill="#F6E7B8" stroke={DS.ink} strokeWidth="4" /><circle cx="850" cy="1128" r="32" fill="#E58B4E" stroke={DS.ink} strokeWidth="4" />
            </g>
          ))}
          <text x="270" y="1260" textAnchor="middle" fontFamily="Dua Head" fontWeight="700" fontSize="40" fill={DS.a}>porsi biasa</text>
          <text x="810" y="1260" textAnchor="middle" fontFamily="Dua Head" fontWeight="700" fontSize="40" fill={DS.b}>porsi ×3</text>
        </g>
      </svg>
      <div style={{position: 'absolute', top: 210, left: 0, width: 540, textAlign: 'center', fontFamily: 'Dua Head', fontWeight: 700, fontSize: 56, color: DS.a}}>SARAPAN</div>
      <div style={{position: 'absolute', top: 210, left: 540, width: 540, textAlign: 'center', fontFamily: 'Dua Head', fontWeight: 700, fontSize: 56, color: DS.b}}>SKIP SARAPAN</div>
      <div style={{position: 'absolute', top: 300, left: 0, right: 0, display: 'flex', justifyContent: 'center'}}>
        <div style={{fontFamily: 'Dua Head', fontWeight: 700, fontSize: 64, color: '#fff', background: DS.ink, borderRadius: 50, padding: '6px 34px'}}>{String(hh).padStart(2, '0')}:00</div>
      </div>
      <StyleTag t={t} a={a} n={3} name="DUA SISI" font="Dua Head" fg={DS.ink} bg={DS.bg} />
      <Caps t={t} y={1470} s={{font: 'Dua Head', weight: 700, size: 62, color: DS.ink, hl: DS.b, bg: '#fff', radius: 40, border: `5px solid ${DS.ink}`}} />
    </AbsoluteFill>
  );
};

// ============ 04 LABEL GIZI — nutrition facts panel ============
const LG = {bg: '#F2E6D0', ink: '#111111', hl: '#FFE14D', red: '#D7263D'};
export const LabelGizi: React.FC<SceneProps> = ({t, a}) => {
  const tMi = at('mitos'), tAs = at('asumsi'), tKa = at('kalori'), tPa = at('pagi', 0);
  const up = p(t, a, a + 0.6);
  const hlE = p(t, tKa - 0.1, tKa + 0.4);
  const akg = Math.round(lerp(0, 21, p(t, tKa, tKa + 0.9)));
  const kk = Math.round(lerp(0, 450, p(t, tKa, tKa + 0.9)));
  const note = pb(t, tAs - 0.05, tAs + 0.3);
  const fact = pb(t, tPa + 0.15, tPa + 0.45);
  const row = (l: string, v: string, pct: string, bold = false, indent = 0) => (
    <div style={{display: 'flex', justifyContent: 'space-between', borderBottom: `3px solid ${LG.ink}`, padding: '10px 0', paddingLeft: indent, fontFamily: 'Gizi Text', fontWeight: bold ? 800 : 500, fontSize: 36}}>
      <span>{l} <span style={{fontWeight: 500}}>{v}</span></span><span style={{fontWeight: 800}}>{pct}</span>
    </div>
  );
  return (
    <AbsoluteFill style={{background: LG.bg, ...enter(t, a)}}>
      <div style={{position: 'absolute', top: 260, left: 110, width: 860, background: '#fff', border: `8px solid ${LG.ink}`, padding: '24px 34px', color: LG.ink,
        transform: `translateY(${(1 - up) * 400}px) rotate(${lerp(4, -1, up)}deg)`, boxShadow: '0 30px 50px #0002'}}>
        <div style={{fontFamily: 'Gizi Head', fontWeight: 900, fontSize: 64, lineHeight: 1, letterSpacing: -1}}>INFORMASI NILAI GIZI</div>
        <div style={{fontFamily: 'Gizi Text', fontSize: 30, borderBottom: `14px solid ${LG.ink}`, padding: '10px 0 12px'}}>Takaran saji: 1 porsi sarapan (contoh)</div>
        <div style={{fontFamily: 'Gizi Text', fontWeight: 800, fontSize: 30, padding: '8px 0', borderBottom: `3px solid ${LG.ink}`}}>JUMLAH PER SAJIAN</div>
        <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', borderBottom: `8px solid ${LG.ink}`, padding: '8px 10px', margin: '0 -10px',
          background: `linear-gradient(90deg, ${LG.hl} ${hlE * 100}%, transparent ${hlE * 100}%)`}}>
          <span style={{fontFamily: 'Gizi Head', fontWeight: 900, fontSize: 56}}>Energi total</span>
          <span style={{fontFamily: 'Gizi Head', fontWeight: 900, fontSize: 64}}>{kk} kkal</span>
        </div>
        <div style={{textAlign: 'right', fontFamily: 'Gizi Text', fontWeight: 800, fontSize: 28, padding: '6px 0', borderBottom: `3px solid ${LG.ink}`}}>% AKG*</div>
        {row('Lemak total', '14 g', '21%', true)}
        {row('Protein', '18 g', '30%', true)}
        {row('Karbohidrat total', '62 g', '19%', true)}
        {row('Gula', '6 g', '', false, 30)}
        {row('Garam (Natrium)', '520 mg', '35%', true)}
        <div style={{fontFamily: 'Gizi Text', fontSize: 24, paddingTop: 12, lineHeight: 1.3}}>*Persen AKG berdasarkan kebutuhan energi 2150 kkal. Energi per sajian: <b>{akg}% AKG</b>.</div>
      </div>
      {/* myth sticky note */}
      <div style={{position: 'absolute', top: 1110, left: 130, width: 420, background: LG.hl, padding: '22px 26px', fontFamily: 'Kal Hand', fontSize: 52, lineHeight: 1.05, color: LG.ink,
        transform: `rotate(${lerp(20, -4, note)}deg) scale(${lerp(1.6, 1, note)})`, opacity: note, boxShadow: '0 12px 20px #0003'}}>
        Mitos: kalori pagi = ekstra?
      </div>
      <div style={{position: 'absolute', top: 1330, left: 60, right: 60, textAlign: 'center', opacity: fact, transform: `scale(${lerp(0.7, 1, fact)})`}}>
        <span style={{fontFamily: 'Gizi Head', fontWeight: 900, fontSize: 44, color: '#fff', background: LG.red, padding: '8px 24px'}}>450 kkal pagi = 450 kkal malam</span>
      </div>
      <StyleTag t={t} a={a} n={4} name="LABEL GIZI" font="Gizi Head" fg={LG.ink} bg={LG.bg} />
      <Caps t={t} y={1440} s={{font: 'Gizi Head', weight: 800, size: 58, color: LG.ink, hl: LG.red, bg: '#fff', radius: 0, border: `6px solid ${LG.ink}`}} />
    </AbsoluteFill>
  );
};
export {lerp, drawOn};
