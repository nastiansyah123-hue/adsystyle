# Changelog — ADSY MOTION GRAPH

## v2.1
- **7 gaya MEDIS baru**: JAM TUBUH, DUA SISI, LABEL GIZI, WEBTOON, APOTEK, ENDOSKOPI, dan DOKTER KARTUN. Total 19 gaya MEDIS.
- **DOKTER KARTUN**: karakter dokter kartun orisinal (`src/styles/medis/Dokter.tsx`) dengan 5 pose; mulut bergerak mengikuti keras-pelan VO lewat `npm run mouth`.
- Contoh baru: `references/examples/MEDIS2_Sarapan-Uji-Gaya-2/` dan `references/examples/DOKTER-KARTUN_Sarapan-Bikin-Gemuk/`.

## v2.0
- **Nama baru: ADSY MOTION GRAPH** (`/adsy-motion-graph`), fokus edukasi kesehatan dan penyakit.
- **12 gaya MEDIS baru**: POSTER PUSKESMAS, MONITOR, TERMAL, REKAM MEDIS, PAPER CUT, KOTA TUBUH, HERBARIUM, RONTGEN, NEON SEL, MIKROSKOP, ANATOMI, KACA PREPARAT. Spesifikasi di `references/STYLES_MEDIS.md`, kit di `src/styles/medis/kit.tsx`, contoh lengkap di `references/examples/MEDIS_Sarapan-Bikin-Gemuk/`.
- **Cukup VO tanpa naskah**: `npm run align -- --transcribe` mengambil teks dari suara (offline, model yang sama dengan subtitle per kata), lalu dirapikan sebelum disinkronkan.
- **Aturan konten kesehatan**: klaim hanya dari naskah atau sumber yang dicek, label "angka contoh", baris sumber untuk pedoman resmi, catatan "bukan saran medis" bila perlu.
- 17 gaya umum dari versi sebelumnya tetap tersedia.

## v1.9.1
- **Claude bicara ke pembeli dengan bahasa biasa.** Hasil tes di Claude chat asli: videonya jalan, tapi status kerjanya penuh istilah teknis (nama file, "typecheck", "sync gate", LUFS) dan laporannya panjang sebelum videonya ada. Sekarang:
  - Di awal, satu kalimat soal waktu proses dan kemungkinan diminta balas **lanjut**.
  - Status kerja maksimal satu baris per tahap, menjelaskan apa yang sedang dibuat (adegan, musik, render), tanpa nama file, perintah, atau angka teknis.
  - Kalau balasan berhenti sebelum video jadi: dua baris saja ("Video sudah N% jadi, progresnya tersimpan. Balas **lanjut**…"), tanpa kata "limit", "kehabisan", atau "error".
  - Saat video jadi: MP4 dulu, lalu maksimal empat baris (judul · durasi · gaya, isi video, catatan penting bila ada, contoh cara minta revisi).
  - Detail teknis (daftar adegan, ukuran audio, hasil cek) disimpan di file catatan produksi `_PRODUKSI.md` dan diberikan kalau pembeli memintanya.
- Claude diminta menggabungkan langkah kerja supaya video 40–60 detik biasanya cukup sekali **lanjut**. Gerbang QC tetap sama.
- Pesan render yang belum selesai sekarang selalu menyebut sisa waktunya, termasuk saat tinggal tahap suara dan penggabungan.

## v1.9.0
- **4 gaya baru, jadi total 17 gaya.** Dipilih dari tren 2026: kembalinya gaya buatan tangan dan nostalgia analog, serta visual berbasis kode.
  - **LEMPUNG:** claymation. Semua dari plastisin di atas meja, gerak stop-motion 12 fps, transisi rolling pin dan adonan. Bawaannya mode clay ringan supaya cepat dirender tanpa GPU.
  - **KASET:** rekaman VHS siaran TV 90-an. Ada tampilan PLAY/REW/FF/PAUSE, grafis berita, colour bars, dan subtitle gaya closed caption.
  - **PIKSEL:** UI game RPG 16-bit. Kotak dialog, bar HP/XP, quest, level up, dan battle wipe, dengan palet pixel orisinal.
  - **TITIK:** visualisasi titik. Ribuan titik (1 titik = 1 unit) berubah jadi grafik, tulisan, atau potret, dengan angka yang dihitung pasti.
- **Suara per gaya:**
  - LEMPUNG: toy piano + klarinet.
  - KASET: synth TV 90-an.
  - PIKSEL: chiptune.
  - TITIK: ambient generatif.

  Masing-masing punya 12 efek suara sendiri.
- **Render jauh lebih cepat di chat Claude.** Di sandbox chat (tanpa GPU, 2 core), gaya-gaya yang berat sekarang otomatis memakai mode ringan, dengan tampilan yang tetap sama di layar HP. Gaya yang terkena: PETA, HIKAYAT, SKETSA, CAIR, TERMINAL, LEMPUNG, KASET, dan TITIK. Waktu render per frame turun 3–58×, contohnya adegan peta paling berat dari ±22 detik CPU menjadi 0,4 detik. Di Claude Code dengan komputer yang kuat, tampilan penuh tetap dipakai.
- **Cek sinkron otomatis.** Setiap `npm run render` sekarang mengukur posisi suara di video final (harus dalam ±40 ms) dan memastikan subtitle mulai tepat saat frasa diucapkan. Kalau gagal, video tidak dikirim. Bisa juga dijalankan manual dengan `npm run sync-check`.
- **Master audio lebih aman.** Musik synth dan SFX bergelombang kotak dulu bisa bikin true peak lewat batas, sehingga Claude terpaksa me-mastering ulang manual. Sekarang `npm run render` otomatis meredam puncak yang terlalu tinggi, lalu mengukur hasil akhirnya dan memperbaikinya sendiri kalau perlu. Target tetap −14 LUFS dan true peak di bawah −1,5 dBTP.
- 7 font baru berlisensi bebas: Baloo 2, Bebas Neue, Share Tech Mono, Press Start 2P, Pixelify Sans, Manrope, Martian Mono.

## v1.8.0
- **5 gaya baru, jadi total 13 gaya.** Kelimanya dipilih dari tren gaya motion graphics yang banyak dipakai kreator konten:
  - **LANTANG:** kinetic typography murni. Kata-katanya sendiri yang jadi visual dan subtitle, dengan font yang lebarnya bisa memuai dan menyempit, plus kartu warna penuh yang menyapu masuk.
  - **FLATLIFE:** explainer 2D flat dengan tokoh yang berakting. Ada rig karakter dengan ekspresi, tangan yang bisa memegang alat, podium harga, iris wipe, dan subtitle pil.
  - **CAIR:** liquid motion + liquid glass. Ada blob cair yang menyatu dan memisah, tabung cairan, transisi gelombang, dan kartu kaca buram.
  - **PETA:** peta vektor ala video-essay. Ada kamera terbang di atas peta, garis yang tergambar, pin, lower third, dan kartu data. Sudah termasuk peta Nusantara siap pakai.
  - **KLIPING:** kolase zine stop-motion di atas kertas kardus. Ada kertas sobek, huruf "surat kaleng", selotip, stempel, dan transisi tempelan kertas.
- **Suara per gaya:**
  - LANTANG: beat elektronik.
  - FLATLIFE: ukulele + marimba.
  - CAIR: Rhodes dengan bunyi tetes air.
  - PETA: pizzicato + piano ala dokumenter.
  - KLIPING: lo-fi boom-bap.

  Masing-masing punya 12–13 efek suara sendiri.
- Panduan gaya ditambah pelajaran dari 5 demo baru: getaran kamera yang terlalu cepat terlihat seperti kedip di 60 FPS, angka penghitung yang berubah tiap frame terlihat berkedip, frame kosong saat transisi, dan teks yang terpotong di tepi layar.
- 9 font baru berlisensi bebas: Anybody, Fredoka, Nunito, Sora, DM Serif Display, Barlow Condensed, Abril Fatface, Bungee, Kalam.

## v1.7.0
- **3 gaya baru, jadi total 8 gaya:**
  - **HIKAYAT:** legenda dan sejarah Nusantara dalam bentuk teater bayang. Ada kelir yang disinari lampu minyak, wayang berukir yang lubang tatahannya tembus cahaya, gunungan untuk pergantian adegan, tulisan di daun lontar, dan musik gamelan.
  - **GEOMETRIK:** uang, ekonomi, dan statistik dengan gaya Swiss/Bauhaus. Ada grid tegas, blok warna primer sebagai data, dan angka raksasa.
  - **TERMINAL:** penipuan online, data pribadi, dan AI di layar terminal hijau. Ada teks yang diketik, jendela log, alert yang glitch, dan potret pixel.
- **Suara per gaya:** gamelan sintetis untuk HIKAYAT, marimba + perkusi untuk GEOMETRIK, dan dark synth untuk TERMINAL, masing-masing dengan efek suara sendiri.
- Panduan gaya ditambah pelajaran dari demo: teks di daun lontar dikunci satu baris, cara memilih kata penanda waktu supaya tidak tertukar dengan kata yang sama di awal VO, dan cara menjaga true peak di gaya synth.
- 6 font baru berlisensi bebas: Cinzel, Cormorant Garamond, Archivo, Inter, VT323, JetBrains Mono.

## v1.6.0
- **5 gaya bernama.** Selain dua gaya yang sudah ada (MIDNIGHT dan MINIATUR), sekarang ada tiga gaya baru yang dipilih otomatis sesuai isi naskah:
  - **ARSIP:** gaya map berkas dokumenter untuk sejarah, asal-usul, mitos vs fakta, dan kasus. Ada koran, polaroid, stempel, kartu indeks, dan benang merah di papan gabus.
  - **BLUEPRINT:** gambar teknik untuk menjelaskan cara kerja mesin dan teknologi. Garisnya tergambar sendiri, ada tampilan urai isometrik, callout bernomor, garis ukur, dan panel DETAIL.
  - **SKETSA:** buku catatan hidup untuk psikologi dan kebiasaan. Ada doodle yang bergetar seperti animasi tangan, sketsa pensil di frame pertama, stabilo, dan page flip.
- **Pilih gaya sendiri:** cukup tambahkan "pakai gaya ARSIP" (atau BLUEPRINT, SKETSA, MIDNIGHT, MINIATUR) saat memanggil skill. Tanpa itu, Claude memilih sendiri dan menyebut gaya yang dipakai di laporan akhir.
- **Suara per gaya:** tiap gaya baru punya musik dan efek suara orisinal sendiri. ARSIP pakai noir dengan detak jam dan mesin ketik, BLUEPRINT pakai arpeggio tech dengan bunyi mekanik, SKETSA pakai lo-fi hangat dengan goresan pensil dan page flip. Semuanya dibuat di dalam proyek tanpa sampel pihak ketiga.
- **6 font baru berlisensi bebas:** Playfair Display, Courier Prime, Space Grotesk, IBM Plex Mono, Caveat Brush, Patrick Hand.
- Lembar kontak pratinjau (`sheet.jpg`) sekarang tetap jadi di FFmpeg yang tidak punya filter teks, cukup tanpa label waktu.

## v1.5.1
- **Cek akses jaringan di detik pertama.** Sebelum mulai, Claude mengecek apakah alat render (Remotion dari npm) bisa diunduh. Kalau akses jaringan chat tertutup, Claude langsung berhenti dan menjelaskan cara membukanya (Settings → Capabilities → Allow network egress, atau minta owner untuk akun Team/Enterprise), atau beralih ke Claude Code. Sebelumnya Claude baru gagal di `npm ci` dengan error 403, setelah beberapa menit, tanpa petunjuk.
- Panduan (START_HERE) menyebut syarat **network egress** dengan jelas, plus langkah perbaikan kalau muncul error 403 dari `registry.npmjs.org`.
- Claude Code di Windows: pengecekan `npm` di `check-env` tidak lagi salah melapor "npm belum terpasang" di Node.js versi baru.

## v1.5.0
- **Bisa langsung di chat Claude, tanpa install.** Upload skill, buka chat baru, lampirkan VO + naskah, ketik `/adsy-motion-graph`. Claude merender MP4 60 FPS di dalam chat dan mengirimkan file-nya. Node.js, FFmpeg, dan browser sudah tersedia di chat, jadi tidak ada yang perlu dipasang. Claude Code tetap bisa dipakai, dan render di sana lebih cepat untuk video panjang.
- **Render bertahap yang bisa dilanjutkan.** Video dirender per potongan 2 detik. Kalau waktu satu langkah habis, Claude cukup menjalankan perintah yang sama lagi dan render lanjut dari titik terakhir. Video 40 detik di chat selesai dalam sekitar 5 menit.
- **Revisi lebih cepat:** perubahan kecil di satu bagian video hanya merender ulang bagian itu (sekitar 1,5 menit untuk perbaikan kecil), dan versi sebelumnya tetap tersimpan.
- **Semua tag ElevenLabs terhapus dari subtitle,** termasuk tag bebas seperti `[explaining]`, `[dramatic pause]`, atau `[berbisik]`. Sebelumnya hanya tag dari daftar tetap yang dihapus.
- **Efek suara dari satu daftar:** semua SFX di `audio-plan.json` otomatis dipasang di video, jadi tidak ada efek yang direncanakan tapi lupa dipasang.
- Pengecekan visual lebih hemat: cuplikan beberapa detik digabung dalam satu lembar kontak.

## v1.4.0
- **Subtitle sinkron per kata.** Tiap kata di naskah diselaraskan dengan suara di VO (biasanya meleset hanya 20–40 milidetik), kata yang sedang diucapkan disorot, dan subtitle tidak pernah memotong kalimat. Butuh Python 3; tanpa Python, video tetap jadi dengan timing perkiraan.
- **Library komponen siap pakai:** layar HP dan aplikasi bank, notifikasi, chat, angka rupiah yang berhitung, uang kertas bergaya, label harga, grafik batang dan garis, cincin persentase, termometer, peta Indonesia dengan pin kota dan rute, karakter dengan pose dan ekspresi (termasuk opsi berhijab), warung, serta panah dan lingkaran penunjuk. Adegan jadi lebih cepat dibuat dan hasilnya lebih konsisten.
- **Brand kit:** satu file `adsy-brand.json` (nama channel, warna, logo) langsung mengubah warna dan identitas seluruh video, dengan cek keterbacaan otomatis. File yang sama dipakai di semua skill ADSY.

## v1.3.1
- **Font baru: Plus Jakarta Sans** untuk judul dan teks, dengan cadangan otomatis untuk simbol seperti → supaya tampil sama di macOS, Windows, dan Linux. Jarak antar kata juga dirapikan.
- **Mastering audio lebih aman.** True peak sekarang konsisten di bawah −1,5 dBTP, jadi pengecekan audio otomatis langsung lolos tanpa revisi.
- Instruksi skill dirapikan supaya Claude tidak pernah mengubah file skill di komputermu.

## v1.3
- **Zero-prompt:** cukup lampirkan VO + naskah, lalu jalankan `/adsy-motion-graph`.
- **Sound Department:** musik latar adaptif, SFX yang sinkron, ducking otomatis di bawah suara, dan pengecekan loudness/keheningan.
- Tag ElevenLabs (`[curious]`, `[whispers]`, dll.) otomatis dihapus dari teks di layar.
