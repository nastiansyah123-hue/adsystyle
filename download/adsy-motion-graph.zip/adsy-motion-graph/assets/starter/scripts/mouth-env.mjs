#!/usr/bin/env node
// DOKTER KARTUN mouth track: loudness of the voice-over, 60 values per second (0-100) -> src/mouth.json.
//   npm run mouth -- public/audio/voiceover.mp3
// Fast attack, slower release, so the mouth opens on syllables and closes in pauses. Not phoneme lip-sync.
import {spawnSync} from 'node:child_process';
import {writeFileSync, existsSync} from 'node:fs';
const vo = process.argv[2];
if (!vo || !existsSync(vo)) { console.error('Usage: npm run mouth -- <voice-over>'); process.exit(2); }
const r = spawnSync('ffmpeg', ['-v', 'error', '-i', vo, '-ac', '1', '-ar', '16000', '-f', 'f32le', '-'], {maxBuffer: 1 << 30});
if (r.status !== 0) { console.error(String(r.stderr)); process.exit(1); }
const x = new Float32Array(r.stdout.buffer, r.stdout.byteOffset, Math.floor(r.stdout.length / 4));
const hop = 16000 / 60, n = Math.ceil(x.length / hop), env = new Float64Array(n);
for (let i = 0; i < n; i++) {
  let s = 0, c = 0;
  for (let j = Math.floor(i * hop); j < Math.min(x.length, Math.floor((i + 1) * hop)); j++) { s += x[j] * x[j]; c++; }
  env[i] = c ? Math.sqrt(s / c) : 0;
}
const voiced = [...env].filter((v) => v > 0.005).sort((a, b) => a - b);
const ref = voiced.length ? voiced[Math.floor(voiced.length * 0.9)] : 1;
const out = []; let v = 0;
for (const e of env) { const a = Math.min(1, e / ref); v = a > v ? a : v * 0.75 + a * 0.25; out.push(Math.round(v * 100)); }
writeFileSync('src/mouth.json', JSON.stringify(out));
console.log(`MOUTH READY: ${out.length} frames -> src/mouth.json`);
