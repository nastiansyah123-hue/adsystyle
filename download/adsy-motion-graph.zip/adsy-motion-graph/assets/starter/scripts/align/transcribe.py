#!/usr/bin/env python3
"""ADSY MOTION GRAPH · transcribe.py - rough transcript of a voice-over when the buyer sent no script.

Greedy CTC decoding with the same offline model as align_words.py (Omnilingual-ASR 300M CTC, Indonesian included).
Output is lower-case, unpunctuated and may mis-hear a few words; one line per spoken phrase (pause > 0.45 s).
The agent must turn it into a clean script (punctuation, obvious spelling fixes, never new content) before
`npm run align`, and tell the buyer once that the captions come from the voice and should be checked by ear.

Usage: python transcribe.py VO.mp3 --out input/script.raw.txt
"""
import argparse, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import align_words as A

ap = argparse.ArgumentParser()
ap.add_argument("audio")
ap.add_argument("--out", required=True)
ap.add_argument("--gap", type=float, default=0.45)
args = ap.parse_args()

ctc = A.CTC(A.models_dir())
inv = {v: k for k, v in ctc.vocab.items()}
x = A.load_audio(args.audio)
ids = ctc.logprobs(x).argmax(1)
chars, times, prev = [], [], -1
for t, i in enumerate(ids):
    if i != prev and i != ctc.blank:
        chars.append(inv[int(i)]); times.append(t * A.FRAME)
    prev = i
words, cur, st, last = [], "", 0.0, 0.0
for ch, t in zip(chars, times):
    if ch in (" ", "▁"):
        if cur: words.append((st, last, cur)); cur = ""
    else:
        if not cur: st = t
        cur += ch; last = t
if cur: words.append((st, last, cur))
lines, line = [], []
for k, (s, e, w) in enumerate(words):
    if line and s - words[k - 1][1] > args.gap:
        lines.append(" ".join(line)); line = []
    line.append(w)
if line: lines.append(" ".join(line))
os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)
open(args.out, "w", encoding="utf-8").write("\n".join(lines) + "\n")
print(f"[transcribe] {len(words)} words, {len(lines)} phrases -> {args.out}", file=sys.stderr)
