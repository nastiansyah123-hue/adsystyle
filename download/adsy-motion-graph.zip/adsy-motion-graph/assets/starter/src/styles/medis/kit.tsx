import React from 'react';
import {staticFile} from 'remotion';
import {words} from '../../lib/words';
import {buildPages} from '../../components/WordCaptions';
import {p} from '../shared';

// Fonts for the MEDIS looks (all bundled SIL OFL fonts from public/fonts).
const faces: Array<[string, string, string]> = [
  ['Pos Head', 'BebasNeue-Regular.ttf', '400'],
  ['Pos Text', 'Nunito-Var.ttf', '200 1000'],
  ['Mon Mono', 'ShareTechMono-Regular.ttf', '400'],
  ['Mon Head', 'BarlowCondensed-ExtraBold.ttf', '800'],
  ['Ter Head', 'SpaceGrotesk-Var.ttf', '300 700'],
  ['Ter Mono', 'JetBrainsMono-Var.ttf', '100 800'],
  ['Rek Mono', 'IBMPlexMono-SemiBold.ttf', '600'],
  ['Rek Hand', 'Kalam-Bold.ttf', '700'],
  ['Pap Head', 'Baloo2-Var.ttf', '400 800'],
  ['Kot Head', 'Sora-Var.ttf', '100 800'],
  ['Kot Mono', 'MartianMono-Var.ttf', '100 800'],
  ['Her Head', 'PlayfairDisplay-Var.ttf', '400 900'],
  ['Her Text', 'CormorantGaramond-Var.ttf', '300 700'],
  ['Ron Head', 'BarlowCondensed-SemiBold.ttf', '600'],
  ['Ron Mono', 'DejaVuSansMono.ttf', '400'],
  ['Neo Head', 'Manrope-Var.ttf', '200 800'],
  ['Mik Mono', 'IBMPlexMono-Medium.ttf', '500'],
  ['Ana Head', 'DMSerifDisplay-Regular.ttf', '400'],
  ['Ana Text', 'Inter-Var.ttf', '100 900'],
  ['Pre Head', 'Archivo-Var.ttf', '100 900'],
  ['Pre Mono', 'MartianMono-Var.ttf', '100 800'],
  // v2.1 looks: JAM TUBUH, DUA SISI, LABEL GIZI, WEBTOON, APOTEK, ENDOSKOPI (DOKTER KARTUN uses the starter's Mograph Sans/Text)
  ['Jam Head', 'Sora-Var.ttf', '100 800'], ['Jam Mono', 'MartianMono-Var.ttf', '100 800'],
  ['Dua Head', 'Fredoka-Var.ttf', '300 700'],
  ['Gizi Head', 'Archivo-Var.ttf', '100 900'], ['Gizi Text', 'Inter-Var.ttf', '100 900'], ['Kal Hand', 'CaveatBrush-Regular.ttf', '400'],
  ['Web SFX', 'Bungee-Regular.ttf', '400'], ['Web Text', 'PatrickHand-Regular.ttf', '400'],
  ['Apo Head', 'BarlowCondensed-ExtraBold.ttf', '800'], ['Apo Text', 'IBMPlexMono-SemiBold.ttf', '600'],
  ['End Mono', 'ShareTechMono-Regular.ttf', '400'], ['End Head', 'SpaceGrotesk-Var.ttf', '300 700'],
];
export const MedisFonts: React.FC = () => (
  <style>{faces.map(([f, file, w]) => `@font-face{font-family:'${f}';src:url('${staticFile('fonts/' + file)}') format('truetype');font-weight:${w};}`).join('\n')}</style>
);

export type SceneProps = {t: number; a: number; b: number};

/** Small corner tag naming the look, so the buyer can compare the 12 styles. */
export const StyleTag: React.FC<{t: number; a: number; name: string; font: string; fg: string; bg: string; n: number; of?: number}> = ({t, a, name, font, fg, bg, n, of = 12}) => {
  const q = p(t, a + 0.05, a + 0.4);
  return (
    <div style={{position: 'absolute', top: 96, left: 70, display: 'flex', gap: 14, alignItems: 'center', opacity: q,
      transform: `translateX(${(1 - q) * -30}px)`, zIndex: 50}}>
      <div style={{fontFamily: font, fontSize: 26, letterSpacing: 3, color: bg, background: fg, padding: '8px 14px', borderRadius: 6}}>{String(n).padStart(2, '0')}/{of}</div>
      <div style={{fontFamily: font, fontSize: 30, letterSpacing: 4, color: fg}}>{name}</div>
    </div>
  );
};

export type CapStyle = {font: string; weight?: number; color: string; hl: string; bg: string; radius?: number; size?: number; upper?: boolean; border?: string; shadow?: string; spacing?: number};

const pages = buildPages(words, 4);
const disp = (w: string) => w.replace(/[.,;:]+(["')\]]*)$/, '$1');

/** Word-synced captions drawn in each look's own typeface and colours. */
export const Caps: React.FC<{t: number; s: CapStyle; y?: number}> = ({t, s, y = 1470}) => {
  const page = pages.find((pg) => t >= pg.start - 0.08 && t < pg.end);
  if (!page) return null;
  const pop = p(t, page.start - 0.08, page.start + 0.1);
  return (
    <div style={{position: 'absolute', top: y, left: 70, right: 70, display: 'flex', justifyContent: 'center', zIndex: 40,
      opacity: pop, transform: `translateY(${(1 - pop) * 16}px)`}}>
      <div style={{fontFamily: s.font, fontWeight: s.weight ?? 700, fontSize: s.size ?? 58, lineHeight: 1.16, textAlign: 'center',
        padding: '18px 30px', borderRadius: s.radius ?? 18, background: s.bg, color: s.color, maxWidth: 940,
        textTransform: s.upper ? 'uppercase' : 'none', border: s.border, boxShadow: s.shadow, letterSpacing: s.spacing ?? 0}}>
        {page.words.map((w, k) => {
          const next = page.words[k + 1];
          const active = t >= w.start && t < (next ? next.start : w.end + 0.25);
          return <span key={w.i} style={{color: active ? s.hl : undefined, opacity: t >= w.start - 0.02 ? 1 : 0.5}}>{disp(w.word)}{k < page.words.length - 1 ? ' ' : ''}</span>;
        })}
      </div>
    </div>
  );
};

/** Entry move for a new scene: quick push-in from slightly larger scale. */
export const enter = (t: number, a: number) => {
  const q = p(t, a, a + 0.35);
  return {transform: `scale(${1.06 - 0.06 * q})`, opacity: Math.min(1, q * 3)};
};

/** Thermal (iron) colour map, v 0..1. */
export const iron = (v: number) => {
  const stops: Array<[number, number[]]> = [[0, [8, 4, 40]], [0.22, [60, 12, 110]], [0.42, [150, 30, 120]], [0.6, [228, 60, 50]], [0.76, [252, 150, 30]], [0.9, [255, 225, 90]], [1, [255, 255, 235]]];
  const x = Math.max(0, Math.min(1, v));
  for (let i = 1; i < stops.length; i++) {
    if (x <= stops[i][0]) {
      const [a0, c0] = stops[i - 1], [a1, c1] = stops[i];
      const q = (x - a0) / (a1 - a0);
      return `rgb(${c0.map((c, k) => Math.round(c + (c1[k] - c) * q)).join(',')})`;
    }
  }
  return 'rgb(255,255,235)';
};
