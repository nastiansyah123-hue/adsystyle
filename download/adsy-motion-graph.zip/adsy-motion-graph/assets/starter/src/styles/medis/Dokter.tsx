import React from 'react';
import mouth from '../../mouth.json';
import {lerp, p} from '../shared';

// Original cartoon doctor presenter for the DOKTER KARTUN look: hijab, white coat, stethoscope.
// Mouth follows the voice-over loudness (src/mouth.json from `npm run mouth`, 60 values per second); blinks and small head bob.
export type Pose = 'point' | 'wave' | 'open' | 'think' | 'thumb';
const INK = '#2B2B3A', SKIN = '#F2C7A5', SKIN2 = '#E3AE8A', HIJAB = '#2A9D8F', HIJAB2 = '#1F7F74', COAT = '#FFFFFF', SHIRT = '#BDE6DF';

const env = (t: number) => {
  const a = mouth as number[];
  const i = Math.max(0, Math.min(a.length - 1, Math.floor(t * 60)));
  return (a[i] ?? 0) / 100;
};

// hand target (in the character's 600x800 box) per pose
const HAND: Record<Pose, [number, number, number]> = {
  point: [70, 250, -30], wave: [60, 330, 0], open: [110, 520, 20], think: [250, 450, 0], thumb: [90, 420, -10],
};

export const Dokter: React.FC<{t: number; pose: Pose; poseAt: number; prevPose?: Pose; x?: number; y?: number; s?: number}> = ({t, pose, poseAt, prevPose = 'open', x = 520, y = 1130, s = 1}) => {
  const e = env(t);
  const talk = Math.min(1, e * (0.75 + 0.25 * Math.abs(Math.sin(t * 21))));
  const blink = (t % 3.4) < 0.12 ? 0.1 : 1;
  const bob = Math.sin(t * 2.1) * 1.6 + e * 1.5;
  const q = p(t, poseAt, poseAt + 0.35);
  const A = HAND[prevPose], B = HAND[pose];
  let hx = lerp(A[0], B[0], q), hy = lerp(A[1], B[1], q);
  const hr = lerp(A[2], B[2], q);
  if (pose === 'wave') { hx += Math.sin(t * 9) * 18; hy += Math.cos(t * 9) * 6; }
  if (pose === 'point') hy += Math.sin(t * 3) * 6;
  const sx = 170, sy = 560; // shoulder
  const ex = lerp(sx, hx, 0.45) - 40, ey = lerp(sy, hy, 0.5) + 70; // elbow
  return (
    <svg width={600 * s} height={800 * s} viewBox="0 0 600 800" style={{position: 'absolute', left: x, top: y, overflow: 'visible'}}>
      <ellipse cx="300" cy="800" rx="260" ry="40" fill="#00000014" />
      {/* coat body */}
      <path d="M95 800 C95 640 140 560 220 535 L380 535 C460 560 505 640 505 800 Z" fill={COAT} stroke={INK} strokeWidth="7" strokeLinejoin="round" />
      <path d="M240 540 L300 640 L360 540 Z" fill={SHIRT} stroke={INK} strokeWidth="6" strokeLinejoin="round" />
      <path d="M220 540 L300 700 M380 540 L300 700" fill="none" stroke={INK} strokeWidth="6" />
      <line x1="300" y1="700" x2="300" y2="800" stroke={INK} strokeWidth="6" />
      {/* pocket + badge */}
      <rect x="360" y="650" width="90" height="70" rx="10" fill={COAT} stroke={INK} strokeWidth="5" />
      <rect x="372" y="630" width="8" height="40" rx="3" fill="#3B82F6" /><rect x="388" y="634" width="8" height="36" rx="3" fill="#EF4444" />
      <rect x="140" y="660" width="100" height="40" rx="8" fill="#FFE14D" stroke={INK} strokeWidth="4" />
      <text x="190" y="688" textAnchor="middle" fontFamily="Mograph Sans" fontWeight="800" fontSize="20" fill={INK}>DOKTER</text>
      {/* stethoscope */}
      <path d="M235 545 C215 620 240 690 300 690 C360 690 385 620 365 545" fill="none" stroke="#4B5563" strokeWidth="9" strokeLinecap="round" />
      <path d="M365 600 C420 640 430 700 410 740" fill="none" stroke="#4B5563" strokeWidth="9" strokeLinecap="round" />
      <circle cx="410" cy="748" r="20" fill="#9CA3AF" stroke={INK} strokeWidth="5" />
      {/* hijab (back + drape) */}
      <g transform={`rotate(${bob} 300 420)`}>
        <path d="M150 560 C130 420 160 200 300 190 C440 200 470 420 450 560 C400 600 200 600 150 560 Z" fill={HIJAB} stroke={INK} strokeWidth="7" strokeLinejoin="round" />
        {/* face */}
        <ellipse cx="300" cy="350" rx="108" ry="122" fill={SKIN} stroke={INK} strokeWidth="6" />
        {/* hijab front frame */}
        <path d="M188 330 C180 230 240 205 300 205 C360 205 420 230 412 330 C400 260 360 238 300 238 C240 238 200 260 188 330 Z" fill={HIJAB2} stroke={INK} strokeWidth="6" strokeLinejoin="round" />
        <path d="M195 400 C205 470 250 500 300 505 C350 500 395 470 405 400 C415 470 380 540 300 545 C220 540 185 470 195 400 Z" fill={HIJAB} stroke={INK} strokeWidth="6" strokeLinejoin="round" />
        {/* brows */}
        <path d={`M240 ${300 - (pose === 'think' ? 6 : 0)} q22 -14 44 0`} fill="none" stroke={INK} strokeWidth="6" strokeLinecap="round" />
        <path d="M316 300 q22 -14 44 0" fill="none" stroke={INK} strokeWidth="6" strokeLinecap="round" />
        {/* eyes */}
        <g transform={`translate(0 330) scale(1 ${blink}) translate(0 -330)`}>
          <ellipse cx="262" cy="330" rx="13" ry="16" fill={INK} /><ellipse cx="338" cy="330" rx="13" ry="16" fill={INK} />
          <circle cx="266" cy="325" r="4" fill="#fff" /><circle cx="342" cy="325" r="4" fill="#fff" />
        </g>
        <circle cx="235" cy="380" r="16" fill="#F59E9E" opacity={0.55} /><circle cx="365" cy="380" r="16" fill="#F59E9E" opacity={0.55} />
        <path d="M296 350 q6 16 -4 22" fill="none" stroke={SKIN2} strokeWidth="5" strokeLinecap="round" />
        {/* mouth */}
        {talk < 0.12
          ? <path d="M272 405 Q300 425 328 405" fill="none" stroke={INK} strokeWidth="6" strokeLinecap="round" />
          : <g>
              <path d={`M268 402 Q300 ${404 + 44 * talk} 332 402 Q300 ${398 - 2} 268 402 Z`} fill="#8B1E2D" stroke={INK} strokeWidth="5" strokeLinejoin="round" />
              <ellipse cx="300" cy={402 + 26 * talk} rx={14 * talk + 4} ry={7 * talk} fill="#F27C8A" />
            </g>}
      </g>
      {/* arm */}
      <path d={`M${sx} ${sy} Q${ex} ${ey} ${hx} ${hy}`} fill="none" stroke={INK} strokeWidth="64" strokeLinecap="round" />
      <path d={`M${sx} ${sy} Q${ex} ${ey} ${hx} ${hy}`} fill="none" stroke={COAT} strokeWidth="50" strokeLinecap="round" />
      <g transform={`translate(${hx} ${hy}) rotate(${hr})`}>
        <circle r="30" fill={SKIN} stroke={INK} strokeWidth="6" />
        {(pose === 'point') && <rect x="-8" y="-72" width="16" height="50" rx="8" fill={SKIN} stroke={INK} strokeWidth="5" />}
        {(pose === 'thumb') && <rect x="-8" y="-66" width="18" height="44" rx="9" fill={SKIN} stroke={INK} strokeWidth="5" />}
        {(pose === 'wave' || pose === 'open') && [-24, -8, 8, 24].map((fx) => <rect key={fx} x={fx - 6} y="-58" width="12" height="36" rx="6" fill={SKIN} stroke={INK} strokeWidth="4" />)}
      </g>
    </svg>
  );
};
