import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';
import type {CaptionPage} from '../../components/WordCaptions';
import {StyleFonts} from '../shared';
import {Caption, Card, Echo, fillWdth, fl, Folio, Grain, L, Line, lineW, ps, punch, Roll, Rule, Stack, Tag, W, Walls} from './kit';

// LANTANG — 4 s StyleGallery demo (QA sheet, never a delivery): three cards that wipe over each other —
// justified lines landing word by word with a slam + echo, a word that stretches and a word walled in,
// an odometer number with the folio and the kinetic caption.

const fakePage = (text: string, start: number): CaptionPage[] => {
  const ws = text.split(' ').map((word, i) => ({i, word, start: start + i * 0.32, end: start + i * 0.32 + 0.28}));
  return [{start, end: start + 6, words: ws}];
};
const PAGES = fakePage('Caption ikut kata ini', 2.9);
const PADAT = 400;
const PADAT_FILL = fillWdth('PADAT.', PADAT, W - 90, 0.01, 780);

export const LantangDemo: React.FC = () => {
  const t = useCurrentFrame() / useVideoConfig().fps;
  const sh = punch(t, [0.35, 2.1]);
  const wallQ = ps(t, 2.05, 2.55);
  const padW = PADAT_FILL + (50 - PADAT_FILL) * wallQ;
  return (
    <AbsoluteFill style={{background: L.ink, overflow: 'hidden'}}>
      <StyleFonts />
      <AbsoluteFill style={{transform: `translate(${sh.x}px, ${sh.y}px)`}}>
        {/* 1 — justified lines, slam + echo */}
        <Card t={t} start={0} until={1.95} bg={L.ink} wipe="cut">
          <Stack gap={22}>
            <Tag t={t} at={-0.3} text="KASUS CONTOH" bg={L.hot} color={L.ink} size={84} rot={-2} />
            <Line t={t} words={[{text: 'CONTOH', at: -0.25}]} {...fl('CONTOH', 360)} />
            <div style={{position: 'relative', flexShrink: 0}}>
              <Echo t={t} at={0.35} text="KATA" {...fl('KATA', 420)} color={L.hot} n={2} />
              <Line t={t} words={[{text: 'KATA', at: 0.35, color: L.hot}]} {...fl('KATA', 420)} mode="slam" align="center" />
            </div>
            <Line t={t} words={[{text: 'JADI', at: 0.75, outline: L.paper}, {text: 'GAMBAR', at: 0.95}]} {...fl(['JADI', 'GAMBAR'], 220)} mode="pop" />
            <Rule t={t} at={1.1} dur={0.35} h={16} color={L.hot} />
            <Line t={t} words={[{text: 'DI', at: 1.2}, {text: 'LAYAR.', at: 1.32, outline: L.paper}]} {...fl(['DI', 'LAYAR.'], 170)} />
          </Stack>
        </Card>
        {/* 2 — a word stretches, a word gets walled in */}
        <Card t={t} start={1.5} until={3.3} bg={L.hot} wipe="circle" dur={0.4}>
          <Stack gap={40}>
            <Line t={t} words={[{text: 'MELAR', at: 1.45, color: L.ink}]} {...fl('MELAR', 420)} mode="stretch" fromWdth={58} />
            <Rule t={t} at={1.75} dur={0.4} h={16} color={L.ink} />
            <div style={{position: 'relative', flexShrink: 0}}>
              <Walls q={wallQ} inner={lineW(['PADAT.'], padW, PADAT, 0.01, 780)} h={PADAT * 0.9} color={L.ink} />
              <Line t={t} words={[{text: 'PADAT.', at: 1.9}]} size={PADAT} wdth={padW} weight={780} ls={0.01} align="center" />
            </div>
            <Line t={t} words={[{text: 'LEBAR', at: 2.25, color: L.ink}, {text: 'ATAU', at: 2.4}, {text: 'SEMPIT', at: 2.55, color: L.ink}]} {...fl(['LEBAR', 'ATAU', 'SEMPIT'], 150)} />
          </Stack>
        </Card>
        {/* 3 — odometer number, folio and the kinetic caption */}
        <Card t={t} start={2.85} until={9} bg={L.paper} wipe="up">
          <Folio t={t} dur={4} color={L.ink} label="TOPIK · CONTOH" show={2.85} />
          <Stack gap={24} top={240} bottom={640}>
            <Line t={t} words={[{text: 'ANGKA', at: 2.75}, {text: 'CONTOH', at: 2.95, color: L.blue}]} {...fl(['ANGKA', 'CONTOH'], 180)} color={L.ink} />
            <Roll t={t} value="100" start={2.85} lock={3.45} step={0.12} size={520} wdth={66} color={L.hot} />
            <Rule t={t} at={3.2} dur={0.5} h={14} color={L.ink} />
          </Stack>
          <Caption t={t} pages={PAGES} color={L.ink} top={1330} size={130} />
        </Card>
      </AbsoluteFill>
      <Grain />
    </AbsoluteFill>
  );
};
